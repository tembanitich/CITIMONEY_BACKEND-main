# CITIMONEY Backend Service
Ministry of Foreign affairs and Internation Trade Intranet Backend Service

# Summary
The Backend is created using the Java Spring boot framework

# How to install Java
1. **Download JDK from Oracle.**
the first step is downloading the correct version of JDK and the correct installer for your machine. Since Java is supported for multiple platforms you see a lot of installers available for JDK. if you are running on Windows PC then you should download Windows Installer of 32-bit machine since most Windows desktops and laptops is 32 bit and until you know that it's for Windows Server which can be 64 bit. If you are running on RedHat Linux or Ubuntu then you can also download the tar file.


2. **The second step is to install Java**
If you are running on Windows PC then installing Java is just a cakewalk. just double click on Installer and it will install Java on your machine. 

It usually creates a folder under program files/Java/JDK_version , this folder is important because in many scripts this is refereed as JAVA_HOME and we will specify an environment variable JAVA_HOME pointing to this folder. 

If you are running in Linux or any Unix machine including AIX, Solaris, etc. you just need to extract tar file and it will put all the binary in a folder this will be your JAVA_HOME in Linux.


3. **Third Step is Setting PATH for Java.**
for setting PATH you just need to append JAVA_HOME/bin in a PATH environment variable. For step by step guide and details How to Set PATH for Java in Windows, Linux, and Unix you google for the specific platform


4. **Testing Java PATH**
Before you run your first Java program it's better to test PATH for Java. Now open a command prompt in Windows just go to "Run" and type "cmd". Now type "java" or "javac" if you see large output means Java is in PATH and you are ready to execute the Java program.



# Service Configuration
**BACKEND-SERVICE** - the service runs at port **9052**

# Database Configuration

I have used MYSQl server all you need to do is add **dbserver_mofait** to your Hosts file on your machine. For example dbserver_change_money can point to Localhost/127.0.0.1 or IP address where your database is hosted. See Examples Below

```bash
dbserver_change_money:127.0.0.1
dbserver_change_money:192.xxx.xxx.xxx
```
## How to Run The Backend System

1. You must have Maven, run the following command in a terminal window (in the complete) directory **(CITIMONEY-backend)**:

```bash
./mvnw spring-boot:run
```
or
Build Jar File and run jar file
1 Run Maven install to build the jar

```bash
./mvnw clean install
```
2 Then run Jar file
```bash
Java -jar "jar Name".jar
```
