package zw.co.change.money.app.transactions.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.transactions.model.MerchantWithdrawalRequest;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MerchantWithdrawalRequestRepository extends JpaRepository<MerchantWithdrawalRequest, Long> {
    List<MerchantWithdrawalRequest> findByAccountId(long accountId);
    Optional<MerchantWithdrawalRequest> findByAccountMerchantIdAndApprovalCode(String merchantId, String approvalCode);
    Boolean existsByAccountMerchantIdAndApprovalCode(String merchantId, String approvalCode);
    Page<MerchantWithdrawalRequest> findByAccountId(long accountId, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByAccountMerchantId(String merchantId, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByUserId(String merchantId, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByAccountMerchantIdAndStatus(String merchantId, DepositRequestStatus historyType, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByStatus(DepositRequestStatus historyType, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByUserIdAndStatus(String merchantId,DepositRequestStatus historyType, Pageable pageable);
    List<MerchantWithdrawalRequest> findFirst10ByAccountMerchantIdOrderByCreatedAtDesc( String merchantId);
    List<MerchantWithdrawalRequest> findFirst10ByRequestedByUserIdOrderByCreatedAtDesc( String merchantId);
    Page<MerchantWithdrawalRequest> findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String name, LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByStatusAndAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(DepositRequestStatus transactionType, String name, LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByStatusAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrStatusAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(DepositRequestStatus transactionType, String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,DepositRequestStatus transactionType2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByUserIdAndStatusAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndStatusAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,DepositRequestStatus transactionType, String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,String userId2,DepositRequestStatus transactionType2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String senderFirstName, LocalDateTime startDate, LocalDateTime endDate, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,  Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,String userId2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,  Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByFirstNameContainingIgnoreCaseOrRequestedBySurnameContainingIgnoreCase(String senderFirstName, String senderLastName,  Pageable pageable);
    Page<MerchantWithdrawalRequest> findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCase(String userId,String senderFirstName,String userId2, String senderLastName,  Pageable pageable);
    Page<MerchantWithdrawalRequest> findByAccountMerchantNameContainingIgnoreCase(String name, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate,LocalDateTime endDate, Pageable pageable);
    Page<MerchantWithdrawalRequest> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(LocalDateTime startDate,LocalDateTime endDate, String merchantId,Pageable pageable);
    Page<MerchantWithdrawalRequest> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndRequestedByUserId(LocalDateTime startDate,LocalDateTime endDate, String merchantId,Pageable pageable);
    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p where  p.created_at <= :endRange and  p.created_at >= :startRange", nativeQuery = true)
    double sumAmountByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);
    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT'", nativeQuery = true)
    double sumDepositByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p  where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT' and p.account_manager=:accountManagerId", nativeQuery = true)
    double sumDepositByDateRangeByRequestedById(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("accountManagerId") String accountManagerId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p  where  p.created_at <= :endRange and  p.created_at >= :startRange and p.account_manager=:accountManagerId", nativeQuery = true)
    double sumAmountByDateRangeByRequestedById(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("accountManagerId") String accountManagerId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p inner join merchant_account po on p.account = po.id where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT' and  po.merchant = :merchantId", nativeQuery = true)
    double sumDepositByDateRangeByMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("merchantId") String merchantId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p inner join merchant_account po on p.account = po.id  where  p.created_at <= :endRange and  p.created_at >= :startRange and  po.merchant = :merchantId", nativeQuery = true)
    double sumAmountByDateRangeByMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("merchantId") String merchantId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p inner join merchant_account po on p.account = po.id  inner join merchant_branch pg on po.merchant = pg.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  pg.id = :branchId", nativeQuery = true)
    double sumAmountByDateRangeByBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("branchId") long branchId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_withdrawal_requests p inner join merchant_account po on p.account = po.id  inner join merchant_branch pg on po.merchant = pg.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT' and  pg.id = :branchId", nativeQuery = true)
    double sumDepositByDateRangeByBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("branchId") long branchId);

}
