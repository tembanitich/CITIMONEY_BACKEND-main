package zw.co.change.money.app.authentication.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.authentication.model.RegistrationOtp;

import java.util.Optional;

public interface RegistrationOtpRepository extends JpaRepository<RegistrationOtp, Long> {
    Boolean existsByOtp(String otp);
    Optional<RegistrationOtp> findByOtp(String otp);
    Optional<RegistrationOtp> findByUserId(String userId);
}
