package zw.co.change.money.app.notifications.sms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.notifications.sms.model.PendingSms;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface PendingSmsRepository extends JpaRepository<PendingSms, Long> {
    Optional<PendingSms> findByReference(String reference);
    List<PendingSms> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<PendingSms> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);

    Page<PendingSms> findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String phoneNumber, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<PendingSms> findByPhoneNumberIgnoreCaseContaining(String phoneNumber, Pageable pageable);
}
