package zw.co.change.money.app.util.audit.config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import zw.co.change.money.app.security.user.UserPrincipal;

import java.util.Optional;

public class CustomAuditAware implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()||
                authentication instanceof AnonymousAuthenticationToken) {
            return null;
        }

        return Optional.of(((UserPrincipal) authentication.getPrincipal()).getUserId());
    }
}