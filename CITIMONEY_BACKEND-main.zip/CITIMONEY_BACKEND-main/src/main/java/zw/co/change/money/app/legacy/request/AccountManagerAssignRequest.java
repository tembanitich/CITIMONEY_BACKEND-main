package zw.co.change.money.app.legacy.request;

import lombok.Data;

@Data
public class AccountManagerAssignRequest {
    private String userId;
    private String merchantId;

}
