package zw.co.change.money.app.common.model;

public enum Priority {
    LOW,  MEDIUM,HIGH, CRITICAL
}
