package zw.co.change.money.app.documents.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import zw.co.change.money.app.merchants.model.Merchant;

import javax.persistence.*;
@Entity
@Table(name = "merchantTaxClearanceDocuments")
@Data
public class MerchantTaxClearanceDocument {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fileName;
    private String fileUrl;
    private String fileType;
    private long fileSize;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "merchant", nullable = false)
    @JsonIgnore
    private Merchant merchant;
}
