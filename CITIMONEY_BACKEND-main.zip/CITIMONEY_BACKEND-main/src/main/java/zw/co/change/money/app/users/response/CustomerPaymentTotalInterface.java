package zw.co.change.money.app.users.response;

public interface CustomerPaymentTotalInterface {
    String getName();
    String getSurname();
    long getId();
    double getTotal();
}
