package zw.co.change.money.app.statistics.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "id","name"
        })
})
@EqualsAndHashCode(callSuper = true)
@Data
public class StatisticsCounter extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private double count;
    private boolean forAll=false;
    private String merchantId;
    private String accountManagerId;
    private String cashierId;
    private long branchId;
    private long month;
    private LocalDate day;
}
