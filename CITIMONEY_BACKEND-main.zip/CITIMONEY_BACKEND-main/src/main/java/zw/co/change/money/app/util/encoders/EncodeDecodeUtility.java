package zw.co.change.money.app.util.encoders;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.stereotype.Service;

@Service
public class EncodeDecodeUtility {
    public String ThreefoldBase64Decode(String encodedString) {

        String newString = "";
        for (int i = 0; i < 3; i++) {
            if (i < 1) {
                newString = encodedString;
                byte[] decodedBytes = Base64.decodeBase64(newString);
                newString = new String(decodedBytes);
            } else {

                byte[] decodedBytes = Base64.decodeBase64(newString);
                newString = new String(decodedBytes);
            }
        }
        return newString;
    }
    public String OnefoldBase64Encode(String encodedString) {
        String newString = "";
                newString = encodedString;
                byte[] decodedBytes = Base64.encodeBase64(newString.getBytes());
                newString = new String(decodedBytes);
        return newString;
    }
}
