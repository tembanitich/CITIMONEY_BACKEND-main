package zw.co.change.money.app.accounts.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"merchant"})
@Data
public class AccountMerchantAssignmentHistory extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Merchant merchant;

    private String userId;
}
