package zw.co.change.money.app.notifications.websocket.controllers;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.notifications.websocket.request.MultipleNotificationsMarkAsReadRequest;
import zw.co.change.money.app.notifications.websocket.service.WebSocketService;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.util.constants.AppConstants;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/inAppNotifications")
public class NotificationController {
    @Autowired
    WebSocketService webSocketService;

    @GetMapping("/send/toNotifications/{userId}/{message}")
    public ResponseEntity sendMessageToNotifications(@PathVariable String userId,@PathVariable String message) {

        return webSocketService.sendMessageToNotifications(message,userId);
    }
    @GetMapping("/send/specificBackendAdmin/{userId}/{message}")
    public ResponseEntity sendMessageToBackendAdminSpecific(@PathVariable String userId,@PathVariable String message) {

        return webSocketService.sendMessageToBackendAdminSpecific(message,userId);
    }
    @GetMapping("/send/toGroup/{group}/{message}")
    public ResponseEntity sendMessageToBackendAdminSpecific(@PathVariable WebSocketMessageGroup group, @PathVariable String message) {

        return webSocketService.sendMessageToGroup(message,group);
    }
    @GetMapping("/view/me/")
    public ResponseEntity getMyMessages(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                        @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return webSocketService.getMessagesByUserId(currentUser.getUserId(),page,size);
    }
    @GetMapping("/view/me/byReadStatus/{readStatus}")
    public ResponseEntity getMessagesByUserIdAndReadStatus(@PathVariable boolean readStatus,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return webSocketService.getMessagesByUserIdAndReadStatus(currentUser.getUserId(),readStatus,page,size);
    }
    @GetMapping("/markAsRead/single/{notificationId}")
    public ResponseEntity updateMessageReadStatus(@PathVariable long notificationId) {
        return webSocketService.updateMessageReadStatus(notificationId);
    }
    @PostMapping("/markAsRead/multiple")
    @Operation(description="Mark Multiple Notifications as Read")
    public ResponseEntity updateMultipleMessagesReadStatus(@Valid @RequestBody MultipleNotificationsMarkAsReadRequest request) {
        return webSocketService.updateMultipleMessagesReadStatus(request);
    }
}
