package zw.co.change.money.app.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import zw.co.change.money.app.reports.model.ReportColumnConfiguration;
import zw.co.change.money.app.reports.model.ReportTemplateName;
import zw.co.change.money.app.reports.repository.ReportColumnConfigurationRepository;

import javax.annotation.PostConstruct;
import java.time.LocalDateTime;

@Component("initReportConfigurations")
public class InitReportColumns {
    @Autowired
    ReportColumnConfigurationRepository reportColumnConfigurationRepository;

    private ReportColumnConfiguration SaveColumnConfigurations(String name, String classFieldName, String classFieldType, ReportTemplateName reportTemplateName) {
        ReportColumnConfiguration newRegion = new ReportColumnConfiguration();
        newRegion.setFieldName(classFieldName);
        newRegion.setFieldType(classFieldType);
        newRegion.setName(name);
        newRegion.setReportName(reportTemplateName);
        return reportColumnConfigurationRepository.save(newRegion);
    }

    @PostConstruct
    public void InitializeColumnConfigurations() {

        if (reportColumnConfigurationRepository.findAll().isEmpty()) {
            //Audit Trail
            this.SaveColumnConfigurations("Username", "username", "STRING", ReportTemplateName.AUDIT_TRAIL_REPORT);
            this.SaveColumnConfigurations("Action", "action", "STRING", ReportTemplateName.AUDIT_TRAIL_REPORT);
            this.SaveColumnConfigurations("Action Date", "actionTIme", "STRING", ReportTemplateName.AUDIT_TRAIL_REPORT);

            //System User Activity
            this.SaveColumnConfigurations("Username", "username", "STRING", ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);
            this.SaveColumnConfigurations("Number Of Logins", "loginCount", "LONG", ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);
            this.SaveColumnConfigurations("Last Login Date", "lastLogin", "DATETIME", ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);
            this.SaveColumnConfigurations("Login Channel", "loginChannel", "STRING", ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);

            //User Details
            this.SaveColumnConfigurations("Username", "username", "STRING", ReportTemplateName.USER_DETAILS_REPORT);
            this.SaveColumnConfigurations("Mobile Number", "mobileNumber", "STRING", ReportTemplateName.USER_DETAILS_REPORT);
            this.SaveColumnConfigurations("Email Address", "email", "STRING", ReportTemplateName.USER_DETAILS_REPORT);
            this.SaveColumnConfigurations("Physical Address", "address", "STRING", ReportTemplateName.USER_DETAILS_REPORT);
            this.SaveColumnConfigurations("Last Login Date", "lastLogin", "DATETIME", ReportTemplateName.USER_DETAILS_REPORT);
            this.SaveColumnConfigurations("Total Number Of Transactions", "numberOfTransaction", "LONG", ReportTemplateName.USER_DETAILS_REPORT);
            this.SaveColumnConfigurations("Last Payment Date", "lastPaymentDate", "DATETIME", ReportTemplateName.USER_DETAILS_REPORT);

            //User Permissions
            this.SaveColumnConfigurations("Username", "username", "STRING", ReportTemplateName.USER_PERMISSIONS_REPORT);
            this.SaveColumnConfigurations("Roles", "roles", "STRING", ReportTemplateName.USER_PERMISSIONS_REPORT);
            this.SaveColumnConfigurations("Created By", "createdBy", "STRING", ReportTemplateName.USER_PERMISSIONS_REPORT);
            this.SaveColumnConfigurations("Created Date", "createdDate", "DATETIME", ReportTemplateName.USER_PERMISSIONS_REPORT);
            this.SaveColumnConfigurations("Last Login Date", "lastLogin", "DATETIME", ReportTemplateName.USER_PERMISSIONS_REPORT);
            this.SaveColumnConfigurations("User Status", "status", "LONG", ReportTemplateName.USER_PERMISSIONS_REPORT);

            //Transactions
            this.SaveColumnConfigurations("Transaction Id", "id", "STRING", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Currency", "currency", "STRING", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Sender", "senderAccount", "STRING", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Receiver", "destinationAccount", "STRING", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Transaction Type", "transactionType", "STRING", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Transaction Status", "status", "STRING", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Amount", "amount", "DOUBLE", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Amount In USD", "amountInUsd", "DOUBLE", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Base Exchange Rate", "baseExchangeRateUsed", "DOUBLE", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Merchant Incentive Used", "merchantIncentiveUsed", "DOUBLE", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Total Exchange Rate Used", "totalExchangeRateUsed", "DOUBLE", ReportTemplateName.TRANSACTION_REPORT);
            this.SaveColumnConfigurations("Date", "date", "DATETIME", ReportTemplateName.TRANSACTION_REPORT);



            //Customer Wallets
            this.SaveColumnConfigurations("Id", "id", "LONG", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Amount", "amount", "DOUBLE", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Balance Before", "balanceBefore", "DOUBLE", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Balance After", "balanceAfter", "DOUBLE", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Receiver", "receiver", "STRING", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Sender", "sender", "STRING", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Transaction Type", "historyType", "STRING", ReportTemplateName.CUSTOMER_WALLET);
            this.SaveColumnConfigurations("Date", "dateOfEntry", "DATETIME", ReportTemplateName.CUSTOMER_WALLET);

            //Merchant Accounts
            this.SaveColumnConfigurations("Id", "id", "LONG", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Amount", "amount", "DOUBLE", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Balance Before", "balanceBefore", "DOUBLE", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Balance After", "balanceAfter", "DOUBLE", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Receiver", "receiver", "STRING", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Sender", "sender", "STRING", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Transaction Type", "historyType", "STRING", ReportTemplateName.MERCHANT_ACCOUNT);
            this.SaveColumnConfigurations("Date", "dateOfEntry", "DATETIME", ReportTemplateName.MERCHANT_ACCOUNT);

            //Price History Report
            this.SaveColumnConfigurations("Product Name", "productName", "STRING", ReportTemplateName.PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("Old Price", "oldUsdPrice", "DOUBLE", ReportTemplateName.PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("New Price", "newUsdPrice", "DOUBLE", ReportTemplateName.PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("User", "user", "STRING", ReportTemplateName.PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("Date Of Adjustment", "dateOfAdjustment", "DATETIME", ReportTemplateName.PRODUCT_PRICE_REPORT);


            //Stock History Report
            this.SaveColumnConfigurations("Product Name", "productName", "STRING", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Supplier Name", "supplierName", "STRING", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Quantity", "quantity", "INTEGER", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Adjustment Type", "adjustmentType", "STRING", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Comment", "comment", "STRING", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("User", "user", "STRING", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Date Of Adjustment", "dateOfAdjustment", "DATETIME", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Cost per Product", "costPerProduct", "DOUBLE", ReportTemplateName.PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Total Cost", "totalCost", "DOUBLE", ReportTemplateName.PRODUCT_STOCK_REPORT);



            //Fuel Price History Report
            this.SaveColumnConfigurations("Product Name", "productName", "STRING", ReportTemplateName.FUEL_PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("Old Price", "oldUsdPrice", "DOUBLE", ReportTemplateName.FUEL_PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("New Price", "newUsdPrice", "DOUBLE", ReportTemplateName.FUEL_PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("User", "user", "STRING", ReportTemplateName.FUEL_PRODUCT_PRICE_REPORT);
            this.SaveColumnConfigurations("Date Of Adjustment", "dateOfAdjustment", "DATETIME", ReportTemplateName.FUEL_PRODUCT_PRICE_REPORT);


            //Fuel Stock History Report
            this.SaveColumnConfigurations("Product Name", "productName", "STRING", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Supplier Name", "supplierName", "STRING", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Quantity", "quantity", "INTEGER", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Adjustment Type", "adjustmentType", "STRING", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Comment", "comment", "STRING", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("User", "user", "STRING", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Date Of Adjustment", "dateOfAdjustment", "DATETIME", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Cost per Litre", "costPerLitre", "DOUBLE", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Total Cost", "totalCost", "DOUBLE", ReportTemplateName.FUEL_PRODUCT_STOCK_REPORT);

            //Fuel Stock History Report
            this.SaveColumnConfigurations("Service Station Name", "serviceStationName", "STRING", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Product Name", "productName", "STRING", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Supplier Name", "supplierName", "STRING", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Quantity", "quantity", "INTEGER", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Adjustment Type", "adjustmentType", "STRING", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Comment", "comment", "STRING", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("User", "user", "STRING", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Date Of Adjustment", "dateOfAdjustment", "DATETIME", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Cost per Litre", "costPerLitre", "DOUBLE", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);
            this.SaveColumnConfigurations("Total Cost", "totalCost", "DOUBLE", ReportTemplateName.SERVICE_STATION_FUEL_PRODUCT_STOCK_REPORT);


        }
    }
}
