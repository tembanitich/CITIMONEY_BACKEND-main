package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class PaymentReportData {
    private String customer;
    private String accountNumber;
    private String status;
    private LocalDateTime paymentDate;
    private double total;
    private double deliveryFee;
    private String paymentMethod;
    private String paymentReference;
}
