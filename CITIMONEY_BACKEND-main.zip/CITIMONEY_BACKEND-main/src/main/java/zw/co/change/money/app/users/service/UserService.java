package zw.co.change.money.app.users.service;


import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.transactions.model.Wallet;
import zw.co.change.money.app.transactions.model.WalletStatus;
import zw.co.change.money.app.transactions.repository.WalletRepository;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.request.*;
import zw.co.change.money.app.users.response.*;
import zw.co.change.money.app.util.aop.annotation.AuditTrail;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.notifications.mail.executor.MailExecutor;
import zw.co.change.money.app.notifications.mail.request.Mail;
import zw.co.change.money.app.notifications.sms.executors.SmsExecutor;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.security.roles.model.Permission;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.roles.repository.PermissionRepository;
import zw.co.change.money.app.security.roles.repository.PrivilegeRepository;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.security.roles.response.PermissionResponse;
import zw.co.change.money.app.security.roles.response.PrivilegeResponse;
import zw.co.change.money.app.util.encryption.EncryptionUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.validation.ValidateUserProperties;
import zw.co.change.money.app.variables.model.AppVariable;
import zw.co.change.money.app.variables.model.EmailConfig;
import zw.co.change.money.app.variables.model.SmsConfig;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.EmailConfigRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

import static java.util.stream.Collectors.toList;

@Service
public class UserService {
    @Autowired
    private PrivilegeRepository privilegeRepository;
    @Autowired
    private PermissionRepository permissionRepository;
    @Autowired
    private EmailConfigRepository emailConfigRepository;
    @Autowired
    private SmsConfigRepository smsConfigRepository;
    @Autowired
    private MailExecutor mailExecutor;
    @Autowired
    private AppVariableRepository appVariableRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    MerchantService merchantService;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    UserBrandAmbassadorRepository userBrandAmbassadorRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    MerchantCashierRepository merchantCashierRepository;
    @Autowired
    TellerUserRepository tellerUserRepository;
    @Autowired
    MerchantRepository merchantRepository;
    @Autowired
    MerchantBranchRepository merchantBranchRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;
    @Autowired
    UserSystemAdminRepository userSystemAdminRepository;
    @Autowired
    UserAuditTrailRepository userAuditTrailRepository;
    @Autowired
    ValidateUserProperties validateUserProperties;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    SmsExecutor smsExecutor;

    @Autowired
    AuthenticationService authenticationService;
    @Autowired
    EncryptionUtil encryptionUtil;
    @Autowired
    DateUtil dateUtil;

    public ResponseEntity getAllUserAuditTrail(int page, int size, String userId) {
        formatUtility.validatePageNumberAndSize(page, size);

        // Retrieve Users
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<UserAuditTrail> users = userAuditTrailRepository.findByUserId(userId,pageable);


        if (users.getNumberOfElements() == 0) {
            return ResponseEntity.ok(new PagedResponse<>(Collections.emptyList(), users.getNumber(),
                    users.getSize(), users.getTotalElements(), users.getTotalPages(), users.isLast()));
        }

        List<UserAuditTrailResponse> userResponseList = users.stream().map(this::mapUserAuditTrailEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(userResponseList, users.getNumber(),
                users.getSize(), users.getTotalElements(), users.getTotalPages(), users.isLast()));
    }
    public ResponseEntity searchAuditTrailByAction(String action,int page, int size,String userId) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve Claims
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<UserAuditTrail> failures =  userAuditTrailRepository.findByUserIdAndActionIgnoreCaseContaining(userId,action,pageable);
        List<UserAuditTrailResponse> regions= failures.stream().map(this::mapUserAuditTrailEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }

    @AuditTrail(action = "Change User Status With Id: ",expression ="[0]",middleStatement =" To Status ",expression2 ="[1].toString()")
    public ResponseEntity ActivateOrDeactivateUser(String userId, Boolean status) {
        User theUser = userRepository.findById(userId).orElse(null);
        if (theUser == null) {
            return new ResponseEntity<>(new GenericApiError("could not load users profile",110), HttpStatus.NOT_FOUND);
        }
        theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        theUser.setEnabled(status);
        userRepository.save(theUser);

        return ResponseEntity.ok(new GenericApiResponse("users activation status updated"));
    }
    @AuditTrail(action = "Updated Permissions for User with id: ",expression ="[0].userId",middleStatement ="",expression2 ="")
    public ResponseEntity assignPermissionsToUser(AssignPermissionsRequest request) {
        User userBackendOfficer = userRepository.findById(request.getUserId()).orElse(null);
        List<Permission> permissions = new ArrayList<>();
        List<Privilege> privileges = new ArrayList<>();
        if(userBackendOfficer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load User ",102), HttpStatus.UNAUTHORIZED);
        }

        if(request.getPermissions()!=null){
            for(PermissionRequest permissionRequest: request.getPermissions()){
                Permission permission = permissionRepository.findById(permissionRequest.getPermissionId()).orElse(null);
                if(permission==null){
                    return new ResponseEntity<>(new GenericApiError("Failed To Find One Of The Permissions",110), HttpStatus.NOT_FOUND);
                }else{
                    if(!permissions.contains(permission)){
                        permissions.add(permission);
                    }

                }
                if(permissionRequest.getPriviledges()!=null){
                    for(Long id: permissionRequest.getPriviledges()){
                        Privilege privilege = privilegeRepository.findById(id).orElse(null);
                        if(privilege==null){
                            return new ResponseEntity<>(new GenericApiError("Failed To Find One Of The Privileges",110), HttpStatus.NOT_FOUND);
                        }else{
                            if(!privileges.contains(privilege)){
                                privileges.add(privilege);
                            }

                        }
                    }
                }
            }

        }
        userBackendOfficer.setPermissions(permissions);
        userBackendOfficer.setPrivileges(privileges);
        userRepository.save(userBackendOfficer);

        return ResponseEntity.ok(new GenericApiResponse("Permissions Updated Successfully"));
    }
    @AuditTrail(action = "Updated Profile",expression ="",middleStatement ="",expression2 ="")
    public ResponseEntity updateUserProfile(UpdateUserRequest request, String userId) {

        ResponseEntity theResponse = validateUserProperties.isValidUserProfileUpdateRequest(request, userId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }

        User theUser = userRepository.findById(userId).orElse(null);
        theUser.setUsername(request.getEmail().toLowerCase());
        theUser.setFirstName(request.getFirstName());
        theUser.setSurname(request.getSurname());
        theUser.setEmail(request.getEmail().toLowerCase());
        User savedUser = userRepository.save(theUser);
        return ResponseEntity.ok(authenticationService.mapUserEntityToSpecificSummary(savedUser));
    }
    @AuditTrail(action = "Updated Profile",expression ="",middleStatement ="",expression2 ="")
    public ResponseEntity updateClientProfile(UpdateClientRequest request, String userId) {

        ResponseEntity theResponse = validateUserProperties.isValidClientProfileUpdateRequest(request, userId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }

        UserCustomer customer = userCustomerRepository.findById(userId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load User",110), HttpStatus.NOT_FOUND);
        }

            customer.setUsername(request.getMobileNumber());
            customer.setFirstName(request.getFirstName());
            customer.setSurname(request.getSurname());
            customer.setEmail(request.getEmail().toLowerCase());
            customer.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
            customer.setMobileNumber(request.getMobileNumber());
            userCustomerRepository.save(customer);
            return ResponseEntity.ok(new GenericApiResponse("Profile Updated"));


    }
    public ResponseEntity searchBackendUserByName(SearchRequest request, String loggedInUserId){

        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<User> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = userRepository.findByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = userRepository.findByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = userRepository.findByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = userRepository.findByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = userRepository.findByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =userRepository.findByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<UserSummary> responses = failures.stream().map(authenticationService::mapUserEntityToSpecificSummary).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchMerchantUserByName(SearchRequest request, String loggedInUserId){

        if (!this.isLoggedInUserMerchantAdmin(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        List<MerchantAdmin> admins;
        List<MerchantCashier> cashiers;
        List<BranchManager> branchManagers;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                admins = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantId(request.getSearchQuery(),status,merchant.getId(), request.getSearchQuery(),status,merchant.getId());
                cashiers = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantId(request.getSearchQuery(),status,merchant.getId(), request.getSearchQuery(),status,merchant.getId());
                branchManagers = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantId(request.getSearchQuery(),status,merchant.getId(), request.getSearchQuery(),status,merchant.getId());
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else{
            admins =merchantAdminRepository.findDistinctByMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantIdAndSurnameContainingIgnoreCase(merchant.getId(),request.getSearchQuery(),merchant.getId(),request.getSearchQuery());
            cashiers =merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(merchant.getId(),request.getSearchQuery(),merchant.getId(),request.getSearchQuery());
            branchManagers =branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(merchant.getId(),request.getSearchQuery(),merchant.getId(),request.getSearchQuery());
        }
        List<UserSummary> responses = admins.stream().map(authenticationService::mapUserEntityToSpecificSummary).collect(toList());
        responses.addAll(cashiers.stream().map(authenticationService::mapUserEntityToSpecificSummary).collect(toList()));
        responses.addAll(branchManagers.stream().map(authenticationService::mapUserEntityToSpecificSummary).collect(toList()));
        return  ResponseEntity.ok(new PagedResponse<>(responses, 0,
                responses.size(), responses.size(), 0, true));

    }
    public ResponseEntity searchMerchantBranchUserByName(SearchRequest request, String loggedInUserId){

        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = cashier.getMerchantBranch();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        List<MerchantCashier> cashiers;
        List<BranchManager> branchManagers;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
              cashiers = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchId(request.getSearchQuery(),status,merchant.getId(), request.getSearchQuery(),status,merchant.getId());
                branchManagers = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchId(request.getSearchQuery(),status,merchant.getId(), request.getSearchQuery(),status,merchant.getId());
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else{
            cashiers =merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseOrMerchantBranchIdAndSurnameContainingIgnoreCase(merchant.getId(),request.getSearchQuery(),merchant.getId(),request.getSearchQuery());
            branchManagers =branchManagerRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseOrMerchantBranchIdAndSurnameContainingIgnoreCase(merchant.getId(),request.getSearchQuery(),merchant.getId(),request.getSearchQuery());
        }
        List<UserSummary> responses = cashiers.stream().map(authenticationService::mapUserEntityToSpecificSummary).collect(toList());
        responses.addAll(branchManagers.stream().map(authenticationService::mapUserEntityToSpecificSummary).collect(toList()));
        return  ResponseEntity.ok(new PagedResponse<>(responses, 0,
                responses.size(), responses.size(), 0, true));

    }
    //////////////////////backend Admins////////////////////////////////////////////////////////
    public ResponseEntity getBackendAdminsByStatus(boolean status,int page, int size){
        formatUtility.validatePageNumberAndSize(page, size);
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<UserBackendAdmin> users = userBackendAdminRepository.findByEnabled(status,pageable);
        List<UserBackendAdminResponse> userSummaries = users.stream().map(this::mapBackendAdminEntityToResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(userSummaries, users.getNumber(),
                users.getSize(), users.getTotalElements(), users.getTotalPages(), users.isLast()));
    }
    public ResponseEntity getActiveBackendAdmins(){
        List<UserBackendAdmin> admins = userBackendAdminRepository.findByEnabled(true);
        List<UserBackendAdminResponse> userSummaries = admins.stream().map(this::mapBackendAdminEntityToResponse).collect(toList());
        return ResponseEntity.ok(userSummaries);
    }
    public ResponseEntity changeBackendAdminStatus(String UserId,boolean status){
        UserBackendAdmin userBackendAdmin = userBackendAdminRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Backend Admin with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        userBackendAdminRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Backend Admin Status Successfully Updated"));

    }
    public ResponseEntity searchBackendAdminByName(SearchRequest request,String loggedInUserId){
        UserSystemAdmin systemAdmin = userSystemAdminRepository.findById(loggedInUserId).orElse(null);
        if (systemAdmin == null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<UserBackendAdmin> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = userBackendAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = userBackendAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = userBackendAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = userBackendAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = userBackendAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =userBackendAdminRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<UserBackendAdminResponse> responses = failures.stream().map(this::mapBackendAdminEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllBackendAdmins(int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<UserBackendAdmin> failures = userBackendAdminRepository.findAll(pageable);

        List<UserBackendAdminResponse> ticketFailureResponses = failures.stream().map(this::mapBackendAdminEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBackendAdminById(String userId) {

        UserBackendAdmin admin = userBackendAdminRepository.findById(userId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Backend Admin",110), HttpStatus.NOT_FOUND);
        }
        UserBackendAdminResponse response = this.mapBackendAdminEntityToResponse(admin);

        return   ResponseEntity.ok(response);

    }
    public  ResponseEntity addBackendAdmin(AddBackendAdminRequest request, String userId){
        UserSystemAdmin systemAdmin = userSystemAdminRepository.findById(userId).orElse(null);
        if (systemAdmin == null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddBackendAdminRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_BACK_OFFICE_ADMIN).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        UserBackendAdmin admin = new UserBackendAdmin();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BACK_OFFICE_ADMIN));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_ADMINS);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(stringGeneratorUtility.generateStaffNumber());
        UserBackendAdmin savedAdmin =userBackendAdminRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_BACK_OFFICE_ADMIN,savedAdmin);
        //send Email with Pin
        this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("Backend Admin Created Successfully"));

    }
    public ResponseEntity updateBackendAdmin(UpdateBackendAdminRequest request, String userId){
        UserSystemAdmin systemAdmin = userSystemAdminRepository.findById(userId).orElse(null);
        if(systemAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateBackendAdminRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserBackendAdmin admin = userBackendAdminRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Admin Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setGender(request.getGender());
        userBackendAdminRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Backend Admin Updated Successfully"));
    }
    public ResponseEntity updateBackendProfile(BackendUpdateProfileRequest request, String userId){

        ResponseEntity theResponse = validateUserProperties.isValidBackendUpdateProfileRequest(request,userId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        User admin = userRepository.findById(userId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
//        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setGender(request.getGender());
        userRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Backend Profile Updated Successfully"));
    }
    //////////////////////////////backend Agents//////////////////////////////////////////////
    public ResponseEntity searchBackendAgentByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<UserBackendAgent> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = userBackendAgentRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = userBackendAgentRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = userBackendAgentRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = userBackendAgentRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = userBackendAgentRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =userBackendAgentRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<UserBackendAgentResponse> responses = failures.stream().map(this::mapBackendAgentEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveBackendAgents(){
        List<UserBackendAgent> officers = userBackendAgentRepository.findByEnabled(true);
        List<UserBackendAgentResponse> userSummaries = officers.stream().map(this::mapBackendAgentEntityToResponse).collect(toList());
        return ResponseEntity.ok(userSummaries);
    }
    public ResponseEntity changeBackendAgentStatus(String UserId,boolean status){
        UserBackendAgent userBackendAdmin = userBackendAgentRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Backend Agent with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        userBackendAgentRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Backend Agent Status Successfully Updated"));

    }
    public ResponseEntity getBackendAgentsByStatus(boolean status, int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<UserBackendAgent> failures =  userBackendAgentRepository.findByEnabled(status,pageable);

        List<UserBackendAgentResponse> ticketFailureResponses = failures.stream().map(this::mapBackendAgentEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllBackendAgents(int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<UserBackendAgent> failures = userBackendAgentRepository.findAll(pageable);

        List<UserBackendAgentResponse> ticketFailureResponses = failures.stream().map(this::mapBackendAgentEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBackendAgentById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (agent == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Backend Agent",110), HttpStatus.NOT_FOUND);
        }
        UserBackendAgentResponse response = this.mapBackendAgentEntityToResponse(agent);

        return   ResponseEntity.ok(response);

    }
    public  ResponseEntity addBackendAgent(AddBackendAgentRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddBackendAgentRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_BACK_OFFICE_AGENT).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        UserBackendAgent admin = new UserBackendAgent();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BACK_OFFICE_AGENT));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(stringGeneratorUtility.generateStaffNumber());
        UserBackendAgent savedAdmin =userBackendAgentRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_BACK_OFFICE_AGENT,savedAdmin);
        //send Email with Pin
        this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("Backend Admin Created Successfully"));

    }
    public ResponseEntity updateBackendAgent(UpdateBackendAgentRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateBackendAgentRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserBackendAgent admin = userBackendAgentRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
//        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setGender(request.getGender());
        userBackendAgentRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Backend Agent Updated Successfully"));
    }

    public ResponseEntity getBrandAmbassadorsByStatus(boolean status, int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<UserBrandAmbassador> failures =  userBrandAmbassadorRepository.findByEnabled(status,pageable);

        List<UserBrandAmbassadorResponse> ticketFailureResponses = failures.stream().map(this::mapBrandAmbassadorEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveBrandAmbassadors() {

        List<UserBrandAmbassador> failures =  userBrandAmbassadorRepository.findByEnabled(true);

        List<UserBrandAmbassadorResponse> ticketFailureResponses = failures.stream().map(this::mapBrandAmbassadorEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeBrandAmbassadorsStatus(String UserId,boolean status){
        UserBrandAmbassador userBackendAdmin = userBrandAmbassadorRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("BrandAmbassador with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        userBrandAmbassadorRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("BrandAmbassador Status Successfully Updated"));

    }
    public ResponseEntity getAllBrandAmbassadors(int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<UserBrandAmbassador> failures = userBrandAmbassadorRepository.findAll(pageable);

        List<UserBrandAmbassadorResponse> ticketFailureResponses = failures.stream().map(this::mapBrandAmbassadorEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBrandAmbassadorById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        UserBrandAmbassador customer = userBrandAmbassadorRepository.findById(userId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find BrandAmbassador",110), HttpStatus.NOT_FOUND);
        }
        UserBrandAmbassadorResponse response = this.mapBrandAmbassadorEntityToResponse(customer);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getBrandAmbassadorByPhoneNumber(String phoneNumber, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        UserBrandAmbassador customer = userBrandAmbassadorRepository.findByMobileNumber(phoneNumber).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find BrandAmbassador",110), HttpStatus.NOT_FOUND);
        }
        UserBrandAmbassadorResponse response = this.mapBrandAmbassadorEntityToResponse(customer);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchBrandAmbassadorByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<UserBrandAmbassador> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = userBrandAmbassadorRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = userBrandAmbassadorRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = userBrandAmbassadorRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = userBrandAmbassadorRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = userBrandAmbassadorRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =userBrandAmbassadorRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<UserBrandAmbassadorResponse> responses = failures.stream().map(this::mapBrandAmbassadorEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addBrandAmbassador(AddBrandAmbassadorRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddBrandAmbassadorRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_BA).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,false,true);
        UserBrandAmbassador admin = new UserBrandAmbassador();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BA));
        admin.setResetPin(true);
        admin.setFirstTime(true);
        admin.setEnabled(true);
        admin.setGender(request.getGender());
        admin.setMessageGroup(WebSocketMessageGroup.BA);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        UserBrandAmbassador savedAdmin =userBrandAmbassadorRepository.save(admin);

        userBrandAmbassadorRepository.save(savedAdmin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_BA,savedAdmin);
        //send Email with Pin
        if(savedAdmin.getEmail().toLowerCase()!=null&& !savedAdmin.getEmail().toLowerCase().isEmpty()){
            this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        }

        this.processSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin);

        return ResponseEntity.ok(new GenericApiResponse("Brand Ambassador Created Successfully"));

    }
    public ResponseEntity updateBrandAmbassador(UpdateBrandAmbassadorRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateBrandAmbassadorRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserBrandAmbassador admin = userBrandAmbassadorRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Find BrandAmbassador Profile",110), HttpStatus.NOT_FOUND);
        }
        if(request.getEmail()!=null){
            admin.setEmail(request.getEmail().toLowerCase());
        }
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
//        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        admin.setGender(request.getGender());
        userBrandAmbassadorRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("BrandAmbassador Updated Successfully"));
    }

    public ResponseEntity getCustomersByStatus(boolean status, int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<UserCustomer> failures =  userCustomerRepository.findByEnabled(status,pageable);

        List<UserCustomerResponse> ticketFailureResponses = failures.stream().map(this::mapCustomerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveCustomers() {

        List<UserCustomer> failures =  userCustomerRepository.findByEnabled(true);

        List<UserCustomerResponse> ticketFailureResponses = failures.stream().map(this::mapCustomerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeCustomersStatus(String UserId,boolean status){
        UserCustomer userBackendAdmin = userCustomerRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Customer with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        userCustomerRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Customer Status Successfully Updated"));

    }
    public ResponseEntity getAllCustomers(int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<UserCustomer> failures = userCustomerRepository.findAll(pageable);

        List<UserCustomerResponse> ticketFailureResponses = failures.stream().map(this::mapCustomerEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCustomerById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        UserCustomer customer = userCustomerRepository.findById(userId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        UserCustomerResponse response = this.mapCustomerEntityToResponse(customer);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getCustomerByPhoneNumber(String phoneNumber, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(phoneNumber).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        UserCustomerResponse response = this.mapCustomerEntityToResponse(customer);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchCustomerByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<UserCustomer> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = userCustomerRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = userCustomerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = userCustomerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = userCustomerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = userCustomerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =userCustomerRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<UserCustomerResponse> responses = failures.stream().map(this::mapCustomerEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addCustomer(AddCustomerRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddCustomerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,false,true);
        UserCustomer admin = new UserCustomer();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
        admin.setResetPin(true);
        admin.setFirstTime(true);
        admin.setEnabled(true);
        admin.setGender(request.getGender());
        admin.setMessageGroup(WebSocketMessageGroup.CUSTOMERS);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        UserCustomer savedAdmin =userCustomerRepository.save(admin);

        Wallet wallet = new Wallet();
        wallet.setCustomer(savedAdmin);
        wallet.setBalance(0D);
        wallet.setStatus(WalletStatus.ACTIVE);
        Wallet savedWallet =walletRepository.save(wallet);
        savedAdmin.setWallet(savedWallet);
        userCustomerRepository.save(savedAdmin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_CUSTOMER,savedAdmin);
        //send Email with Pin
        if(savedAdmin.getEmail().toLowerCase()!=null&& !savedAdmin.getEmail().toLowerCase().isEmpty()){
            this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        }

        this.processSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin);

        return ResponseEntity.ok(new GenericApiResponse("Customer Created Successfully"));

    }
    public  UserCustomer addCustomerInternal(String phoneNumber){

        Role role = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
        if(role==null){
            return null;
        }
        String pin = RandomStringUtils.random(4,false,true);
        UserCustomer admin = new UserCustomer();
        admin.setEmail("N/A");
        admin.setFirstName("N/A");
        admin.setSurname("N/A");
        admin.setMobileNumber(phoneNumber);
        admin.setMobileNumberCountryCode("ZW");
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
        admin.setResetPin(true);
        admin.setFirstTime(true);
        admin.setGender(Gender.NOT_SET);
        admin.setMessageGroup(WebSocketMessageGroup.CUSTOMERS);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(phoneNumber);
        UserCustomer savedAdmin =userCustomerRepository.save(admin);

        Wallet wallet = new Wallet();
        wallet.setCustomer(savedAdmin);
        wallet.setBalance(0D);
        wallet.setStatus(WalletStatus.ACTIVE);
        Wallet savedWallet =walletRepository.save(wallet);
        savedAdmin.setWallet(savedWallet);
        userCustomerRepository.save(savedAdmin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_CUSTOMER,savedAdmin);
        //send Email with Pin
        if(savedAdmin.getEmail().toLowerCase()!=null&& !savedAdmin.getEmail().toLowerCase().isEmpty()){
            this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        }

        this.processSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin);
return savedAdmin;
    }
    public ResponseEntity updateCustomer(UpdateCustomerRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateCustomerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer admin = userCustomerRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer Profile",110), HttpStatus.NOT_FOUND);
        }
        if(request.getEmail()!=null){
            admin.setEmail(request.getEmail().toLowerCase());
        }

        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
//        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        admin.setGender(request.getGender());
        userCustomerRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Customer Updated Successfully"));
    }

    public ResponseEntity updateClientProfile(ClientUpdateProfileRequest request, String userId){

        ResponseEntity theResponse = validateUserProperties.isValidClientUpdateProfileRequest(request,userId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer customer = userCustomerRepository.findById(userId).orElse(null);

        if(customer!=null){
            customer.setEmail(request.getEmail().toLowerCase());
            customer.setFirstName(request.getFirstName());
            customer.setSurname(request.getSurname());
            customer.setMobileNumber(request.getMobileNumber());
//            customer.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            customer.setUsername(request.getMobileNumber());
            customer.setGender(request.getGender());
            userCustomerRepository.save(customer);
        }


        return ResponseEntity.ok(new GenericApiResponse("Client Profile Updated Successfully"));
    }

    //////////////////////////////////////////Merchant Users/////////////////////
    public ResponseEntity getMerchantUsersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantAdmin> failures =  merchantAdminRepository.findByEnabled(status,pageable);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyMerchantUsersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantAdmin> failures =  merchantAdminRepository.findByEnabled(status,pageable);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantUsersByMerchantId(String merchantBranchId, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant fuelDealer = merchantRepository.findById(merchantBranchId).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantAdmin> failures =  merchantAdminRepository.findByMerchantId(fuelDealer.getId(),pageable);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveMerchantUsers() {

        List<MerchantAdmin> failures =  merchantAdminRepository.findByEnabled(true);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity getMyActiveMerchantUsers(String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        List<MerchantAdmin> failures =  merchantAdminRepository.findByEnabled(true);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeMerchantUsersStatus(String UserId,boolean status){
        MerchantAdmin userBackendAdmin = merchantAdminRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Operations Manager with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        merchantAdminRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Merchant User Status Successfully Updated"));

    }
    public ResponseEntity getAllMerchantUsers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAdmin> failures = merchantAdminRepository.findAll(pageable);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyMerchantUsers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAdmin> failures = merchantAdminRepository.findAll(pageable);

        List<MerchantUserResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantUserById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin agent = merchantAdminRepository.findById(userId).orElse(null);
        if (agent == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Backend Agent",110), HttpStatus.NOT_FOUND);
        }
        MerchantUserResponse response = this.mapMerchantUserEntityToResponse(agent);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchMerchantUsersByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAdmin> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.BY_MERCHANT_ID)) {
            try {
                Merchant fuelDealer = merchantRepository.findById(request.getFilterValue()).orElse(null);
             
                if(fuelDealer==null){
                    return new ResponseEntity<>(new GenericApiError("Could not load Fuel Dealer",110), HttpStatus.NOT_FOUND);
                }
                failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndMerchantIdOrSurnameContainingIgnoreCaseAndMerchantId(request.getSearchQuery(),fuelDealer.getId(), request.getSearchQuery(),fuelDealer.getId(), pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<MerchantUserResponse> responses = failures.stream().map(this::mapMerchantUserEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addMerchantUser(AddMerchantUserRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddMerchantUserRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Merchant fuelDealer = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        Role role = roleRepository.findByName(RoleName.ROLE_MERCHANT_ADMIN).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        MerchantAdmin admin = new MerchantAdmin();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchant(fuelDealer);
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());

        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_MERCHANT_ADMIN));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        MerchantAdmin savedAdmin = merchantAdminRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_MERCHANT_ADMIN,savedAdmin);
        //send Email with Pin
        this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("Merchant User Created Successfully"));

    }
    public ResponseEntity updateMerchantUser(UpdateMerchantUserRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateMerchantUserRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Merchant fuelDealer = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        MerchantAdmin admin = merchantAdminRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchant(fuelDealer);
        admin.setFirstName(request.getFirstName());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());

        admin.setSurname(request.getSurname());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setGender(request.getGender());
        merchantAdminRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Merchant User Updated Successfully"));
    }
    //////////////////////////////////////////Merchant Cashiers/////////////////////
    public ResponseEntity getMerchantCashiersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures =  merchantCashierRepository.findByEnabled(status,pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyMerchantCashiersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures =  merchantCashierRepository.findByEnabledAndMerchantBranchMerchantId(status,merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyBranchMerchantCashiersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager branchManager = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(branchManager==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures =  merchantCashierRepository.findByEnabledAndMerchantBranchId(status,branchManager.getMerchantBranch().getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantCashiersByMerchantId(long merchantBranchId, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(merchantBranchId).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures =  merchantCashierRepository.findByMerchantBranchId(fuelDealer.getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveMerchantCashiers() {

        List<MerchantCashier> failures =  merchantCashierRepository.findByEnabled(true);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity getMyActiveMerchantCashiers(String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        List<MerchantCashier> failures =  merchantCashierRepository.findByEnabledAndMerchantBranchMerchantId(true,merchantAdmin.getMerchant().getId());

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity getMyBranchActiveMerchantCashiers(String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager branchManager = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(branchManager==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        List<MerchantCashier> failures =  merchantCashierRepository.findByEnabledAndMerchantBranchId(true,branchManager.getMerchantBranch().getId());

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeMerchantCashiersStatus(String UserId,boolean status){
        MerchantCashier userBackendAdmin = merchantCashierRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Operations Manager with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        merchantCashierRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Status Successfully Updated"));

    }
    public ResponseEntity getAllMerchantMerchantCashiers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantCashier> failures = merchantCashierRepository.findByMerchantBranchMerchantId(merchant.getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllMerchantBranchMerchantCashiers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = cashier.getMerchantBranch();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantCashier> failures = merchantCashierRepository.findByMerchantBranchId(merchant.getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllMerchantCashiers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantCashier> failures = merchantCashierRepository.findAll(pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyMerchantCashiers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantCashier> failures = merchantCashierRepository.findByMerchantBranchMerchantId(merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyBranchMerchantCashiers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager branchManager = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(branchManager==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantCashier> failures = merchantCashierRepository.findByMerchantBranchId(branchManager.getMerchantBranch().getId(),pageable);

        List<MerchantCashierResponse> ticketFailureResponses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantCashierById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantCashier agent = merchantCashierRepository.findById(userId).orElse(null);
        if (agent == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Backend Agent",110), HttpStatus.NOT_FOUND);
        }
        MerchantCashierResponse response = this.mapMerchantCashierEntityToResponse(agent);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchMerchantCashiersByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.BY_MERCHANT_BRANCH_ID)) {
            try {
                MerchantBranch fuelDealer = merchantBranchRepository.findById(Long.parseLong(request.getFilterValue())).orElse(null);

                if(fuelDealer==null){
                    return new ResponseEntity<>(new GenericApiError("Could not load Fuel Dealer",110), HttpStatus.NOT_FOUND);
                }
                failures = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndMerchantBranchId(request.getSearchQuery(),fuelDealer.getId(), request.getSearchQuery(),fuelDealer.getId(), pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<MerchantCashierResponse> responses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchMyMerchantCashiersByName(SearchRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndEnabled(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),status,merchantAdmin.getMerchant().getId(), request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getMerchant().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getMerchant().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =merchantCashierRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),merchantAdmin.getMerchant().getId(),request.getSearchQuery(),pageable);
        }
        List<MerchantCashierResponse> responses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchMyBranchMerchantCashiersByName(SearchRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager branchManager = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(branchManager==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantCashier> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndEnabled(branchManager.getMerchantBranch().getId(),request.getSearchQuery(),status,branchManager.getMerchantBranch().getId(), request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(branchManager.getMerchantBranch().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),branchManager.getMerchantBranch().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(branchManager.getMerchantBranch().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),branchManager.getMerchantBranch().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(branchManager.getMerchantBranch().getId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),branchManager.getMerchantBranch().getId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(branchManager.getMerchantBranch().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),branchManager.getMerchantBranch().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =merchantCashierRepository.findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseOrMerchantBranchIdAndSurnameContainingIgnoreCase(branchManager.getMerchantBranch().getId(),request.getSearchQuery(),branchManager.getMerchantBranch().getId(),request.getSearchQuery(),pageable);
        }
        List<MerchantCashierResponse> responses = failures.stream().map(this::mapMerchantCashierEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addMerchantCashier(AddMerchantCashierRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddMerchantCashierRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CASHIER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,false,true);
        MerchantCashier admin = new MerchantCashier();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setSurname(request.getSurname());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CASHIER));
        admin.setCode(stringGeneratorUtility.generateCashierCode());
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getContactMobileNumber());
        MerchantCashier savedAdmin =merchantCashierRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_CASHIER,savedAdmin);
        //send Email with Pin
        this.processAgentSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin,admin.getCode());
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Created Successfully"));

    }
    public  ResponseEntity addMyMerchantCashier(AddMerchantCashierRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddMerchantCashierRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CASHIER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,false,true);
        MerchantCashier admin = new MerchantCashier();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setSurname(request.getSurname());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CASHIER));
        admin.setCode(stringGeneratorUtility.generateCashierCode());
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getContactMobileNumber());
        MerchantCashier savedAdmin =merchantCashierRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_CASHIER,savedAdmin);
        //send Email with Pin
        this.processAgentSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin,admin.getCode());
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Created Successfully"));

    }
    public  ResponseEntity addMyBranchMerchantCashier(AddMerchantCashierRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddMerchantCashierRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CASHIER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,false,true);
        MerchantCashier admin = new MerchantCashier();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setSurname(request.getSurname());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CASHIER));
        admin.setCode(stringGeneratorUtility.generateCashierCode());
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getContactMobileNumber());
        MerchantCashier savedAdmin =merchantCashierRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_CASHIER,savedAdmin);
        //send Email with Pin
        this.processAgentSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin,admin.getCode());
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Created Successfully"));

    }
    public ResponseEntity updateMerchantCashier(UpdateMerchantCashierRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateMerchantCashierRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        MerchantCashier admin = merchantCashierRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getContactMobileNumber());
        merchantCashierRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Updated Successfully"));
    }
    public ResponseEntity updateMyMerchantCashier(UpdateMerchantCashierRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateMerchantCashierRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        MerchantCashier admin = merchantCashierRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getContactMobileNumber());
        merchantCashierRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Updated Successfully"));
    }
    public ResponseEntity updateMyBranchMerchantCashier(UpdateMerchantCashierRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateMerchantCashierRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        MerchantCashier admin = merchantCashierRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getContactMobileNumber());
        merchantCashierRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Cashier Updated Successfully"));
    }
    //////////////////////////////////////////MerchantAccount Manger/////////////////////
    public ResponseEntity getAccountManagersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<AccountManager> failures =  accountManagerRepository.findByEnabled(status,pageable);

        List<AccountManagerResponse> ticketFailureResponses = failures.stream().map(this::mapAccountManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveAccountManagers() {

        List<AccountManager> failures =  accountManagerRepository.findByEnabled(true);

        List<AccountManagerResponse> ticketFailureResponses = failures.stream().map(this::mapAccountManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeAccountManagersStatus(String UserId,boolean status){
        AccountManager userBackendAdmin = accountManagerRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Operations Manager with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        accountManagerRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("MerchantAccount Manager Status Successfully Updated"));

    }
    public ResponseEntity getAllAccountManagers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<AccountManager> failures = accountManagerRepository.findAll(pageable);

        List<AccountManagerResponse> ticketFailureResponses = failures.stream().map(this::mapAccountManagerEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAccountManagerById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager agent = accountManagerRepository.findById(userId).orElse(null);
        if (agent == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Backend Agent",110), HttpStatus.NOT_FOUND);
        }
        AccountManagerResponse response = this.mapAccountManagerEntityToResponse(agent);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchAccountManagersByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<AccountManager> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<AccountManagerResponse> responses = failures.stream().map(this::mapAccountManagerEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addAccountManager(AddAccountManagerRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddAccountManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
    
        Role role = roleRepository.findByName(RoleName.ROLE_ACCOUNT_MANAGER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        AccountManager admin = new AccountManager();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setGender(request.getGender());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setSurname(request.getSurname());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_ACCOUNT_MANAGER));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        AccountManager savedAdmin =accountManagerRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_ACCOUNT_MANAGER,savedAdmin);
        //send Email with Pin
        this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("MerchantAccount Manager Created Successfully"));

    }
    public ResponseEntity updateAccountManager(UpdateAccountManagerRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateAccountManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
      
        AccountManager admin = accountManagerRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        accountManagerRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("MerchantAccount Manager Updated Successfully"));
    }
    public ResponseEntity assignMerchant(AccountManagerAssignMerchantRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAssignMerchantAccountManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }

        AccountManager admin = accountManagerRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load Merchant",110), HttpStatus.NOT_FOUND);
        }
        Set<Merchant> merchants;


        return ResponseEntity.ok(new GenericApiResponse("Merchant Assigned To MerchantAccount Manager  Successfully"));
    }

    //////////////////////////////////////////Branch Managers/////////////////////
    public ResponseEntity getBranchManagersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<BranchManager> failures =  branchManagerRepository.findByEnabled(status,pageable);

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyBranchManagersByStatus(boolean status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<BranchManager> failures =  branchManagerRepository.findByEnabledAndMerchantBranchMerchantId(status,merchantAdmin.getMerchant().getId(),pageable);

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBranchManagersByMerchantId(long merchantBranchId, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(merchantBranchId).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<BranchManager> failures =  branchManagerRepository.findByMerchantBranchId(fuelDealer.getId(),pageable);

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveBranchManagers() {

        List<BranchManager> failures =  branchManagerRepository.findByEnabled(true);

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity getMyActiveBranchManagers(String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        List<BranchManager> failures =  branchManagerRepository.findByEnabledAndMerchantBranchMerchantId(true,merchantAdmin.getMerchant().getId());

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeBranchManagersStatus(String UserId,boolean status){
        BranchManager userBackendAdmin = branchManagerRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Operations Manager with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        branchManagerRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Branch Manager Status Successfully Updated"));

    }
    public ResponseEntity getAllBranchManagers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<BranchManager> failures = branchManagerRepository.findAll(pageable);

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMyBranchManagers(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<BranchManager> failures = branchManagerRepository.findByMerchantBranchMerchantId(merchantAdmin.getMerchant().getId(),pageable);

        List<BranchManagerResponse> ticketFailureResponses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBranchManagerById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        if(backendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You Are Not Allowed To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager agent = branchManagerRepository.findById(userId).orElse(null);
        if (agent == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Backend Agent",110), HttpStatus.NOT_FOUND);
        }
        BranchManagerResponse response = this.mapBranchManagerEntityToResponse(agent);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchBranchManagersByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<BranchManager> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.BY_MERCHANT_BRANCH_ID)) {
            try {
                MerchantBranch fuelDealer = merchantBranchRepository.findById(Long.parseLong(request.getFilterValue())).orElse(null);

                if(fuelDealer==null){
                    return new ResponseEntity<>(new GenericApiError("Could not load Fuel Dealer",110), HttpStatus.NOT_FOUND);
                }
                failures = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndMerchantBranchId(request.getSearchQuery(),fuelDealer.getId(), request.getSearchQuery(),fuelDealer.getId(), pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<BranchManagerResponse> responses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchMyBranchManagersByName(SearchRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<BranchManager> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndEnabled(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),status, merchantAdmin.getMerchant().getId(),request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getMerchant().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getMerchant().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =branchManagerRepository.findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(merchantAdmin.getMerchant().getId(),request.getSearchQuery(),merchantAdmin.getMerchant().getId(),request.getSearchQuery(),pageable);
        }
        List<BranchManagerResponse> responses = failures.stream().map(this::mapBranchManagerEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addBranchManager(AddBranchManagerRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddBranchManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        Role role = roleRepository.findByName(RoleName.ROLE_BRANCH_MANAGER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        BranchManager admin = new BranchManager();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setSurname(request.getSurname());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BRANCH_MANAGER));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        BranchManager savedAdmin =branchManagerRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_BRANCH_MANAGER,savedAdmin);
        //send Email with Pin
        this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("Branch Manager Created Successfully"));

    }
    public  ResponseEntity addMyBranchManager(AddBranchManagerRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddBranchManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        Role role = roleRepository.findByName(RoleName.ROLE_BRANCH_MANAGER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        BranchManager admin = new BranchManager();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setSurname(request.getSurname());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BRANCH_MANAGER));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        BranchManager savedAdmin =branchManagerRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_BRANCH_MANAGER,savedAdmin);
        //send Email with Pin
        this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("Branch Manager Created Successfully"));

    }
    public ResponseEntity updateBranchManager(UpdateBranchManagerRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateBranchManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        BranchManager admin = branchManagerRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setFirstName(request.getFirstName());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setSurname(request.getSurname());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setEnabled(request.isStatus());
        branchManagerRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Branch Manager Updated Successfully"));
    }
    public ResponseEntity updateMyBranchManager(UpdateBranchManagerRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateBranchManagerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        BranchManager admin = branchManagerRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Backend Agent Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setMerchantBranch(fuelDealer);
        admin.setGender(request.getGender());
        admin.setFirstName(request.getFirstName());
        admin.setContactMobileNumber(request.getContactMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getContactMobileNumberCountryCode());
        admin.setSurname(request.getSurname());
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getEmail().toLowerCase());
        admin.setEnabled(request.isStatus());
        branchManagerRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Branch Manager Updated Successfully"));
    }

    //////////////////////////////////////////////////////Teller Users//////////////////////////////////////////////////////////////
    public ResponseEntity getTellersByStatus(boolean status, int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<TellerUser> failures =  tellerUserRepository.findByEnabled(status,pageable);

        List<TellerResponse> ticketFailureResponses = failures.stream().map(this::mapTellerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveTellers() {

        List<TellerUser> failures =  tellerUserRepository.findByEnabled(true);

        List<TellerResponse> ticketFailureResponses = failures.stream().map(this::mapTellerEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity changeTellerStatus(String UserId,boolean status){
        TellerUser userBackendAdmin = tellerUserRepository.findById(UserId).orElse(null);
        if(userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Customer with Provided Id Does not Exist Exist!",110), HttpStatus.EXPECTATION_FAILED);
        }
        userBackendAdmin.setEnabled(status);
        tellerUserRepository.save(userBackendAdmin);
        return ResponseEntity.ok(new GenericApiResponse("Teller User Status Successfully Updated"));

    }
    public ResponseEntity getAllTellers(int page, int size, String userId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<TellerUser> failures = tellerUserRepository.findAll(pageable);

        List<TellerResponse> ticketFailureResponses = failures.stream().map(this::mapTellerEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getTellerById(String userId, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        TellerUser customer = tellerUserRepository.findById(userId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        TellerResponse response = this.mapTellerEntityToResponse(customer);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getTellerByPhoneNumber(String phoneNumber, String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        TellerUser customer = tellerUserRepository.findByMobileNumber(phoneNumber).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        TellerResponse response = this.mapTellerEntityToResponse(customer);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchTellersByName(SearchRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<TellerUser> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean status = Boolean.valueOf(request.getFilterValue());
                failures = tellerUserRepository.findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(request.getSearchQuery(),status, request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Status", 110), HttpStatus.NOT_FOUND);
            }

        } else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = tellerUserRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = tellerUserRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = tellerUserRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = tellerUserRepository.findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else{
            failures =tellerUserRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),pageable);
        }
        List<TellerResponse> responses = failures.stream().map(this::mapTellerEntityToResponse).collect(toList());
        return  ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public  ResponseEntity addTeller(AddTellerRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidAddTellerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_TELLER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(4,false,true);
        TellerUser admin = new TellerUser();
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_TELLER));
        admin.setResetPin(true);
        admin.setEnabled(true);
        admin.setGender(request.getGender());
        admin.setMessageGroup(WebSocketMessageGroup.TELLERS);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        TellerUser savedAdmin =tellerUserRepository.save(admin);

        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(RoleName.ROLE_TELLER,savedAdmin);
        //send Email with Pin
        if(savedAdmin.getEmail().toLowerCase()!=null&& !savedAdmin.getEmail().toLowerCase().isEmpty()){
            this.sendSuccessfulRegistrationEmailWithPin(admin.getEmail().toLowerCase(),pin,admin.getFirstName()+" "+ admin.getSurname());
        }

        this.processSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin);

        return ResponseEntity.ok(new GenericApiResponse("Teller Created Successfully"));

    }
    public ResponseEntity updateTeller(UpdateTellerRequest request, String userId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(userId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUpdateTellerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        TellerUser admin = tellerUserRepository.findById(request.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer Profile",110), HttpStatus.NOT_FOUND);
        }
        admin.setEmail(request.getEmail().toLowerCase());
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setGender(request.getGender());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
//        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        admin.setGender(request.getGender());
        tellerUserRepository.save(admin);
        return ResponseEntity.ok(new GenericApiResponse("Teller Updated Successfully"));
    }

////////////////////////////////////////////////////////////////////In Class Methods//////////////////////////////////////////////////////////////
public MerchantUserResponse mapMerchantUserEntityToResponse(MerchantAdmin admin){
    MerchantUserResponse response = new MerchantUserResponse();
    response.setActive(admin.getEnabled());
    response.setEmail(admin.getEmail().toLowerCase());
    response.setFirstName(admin.getFirstName());
    response.setSurname(admin.getSurname());
    response.setGender(admin.getGender());
    response.setUserId(admin.getUserId());
    response.setContactMobileNumber(admin.getContactMobileNumber());
    response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
    if(admin.getMerchant()!=null){
        response.setMerchant(merchantService.mapEntityToMerchantResponse(admin.getMerchant()));
    }
    response.setPermissions(this.getPermissions(admin));
    return response;
}
    public AccountManagerResponse mapAccountManagerEntityToResponse(AccountManager admin){
    AccountManagerResponse response = new AccountManagerResponse();
    response.setActive(admin.getEnabled());
    response.setEmail(admin.getEmail().toLowerCase());
    response.setFirstName(admin.getFirstName());
    response.setSurname(admin.getSurname());
    response.setGender(admin.getGender());
    response.setUserId(admin.getUserId());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
    response.setPermissions(this.getPermissions(admin));
    return response;
}
    public BranchManagerResponse mapBranchManagerEntityToResponse(BranchManager admin){
    BranchManagerResponse response = new BranchManagerResponse();
    response.setActive(admin.getEnabled());
    response.setEmail(admin.getEmail().toLowerCase());
    response.setFirstName(admin.getFirstName());
    response.setSurname(admin.getSurname());
    response.setGender(admin.getGender());
    response.setUserId(admin.getUserId());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
    if(admin.getMerchantBranch()!=null){
        response.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(admin.getMerchantBranch()));
    }
    response.setPermissions(this.getPermissions(admin));
    return response;
}
    public MerchantCashierResponse mapMerchantCashierEntityToResponse(MerchantCashier admin){
        MerchantCashierResponse response = new MerchantCashierResponse();
        response.setActive(admin.getEnabled());
        response.setEmail(admin.getEmail().toLowerCase());
        response.setCode(admin.getCode());
        response.setFirstName(admin.getFirstName());
        response.setSurname(admin.getSurname());
        response.setGender(admin.getGender());
        response.setUserId(admin.getUserId());
        response.setMobileNumber(admin.getMobileNumber());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
        response.setMobileNumberCountryCode(admin.getMobileNumberCountryCode());
        if(admin.getMerchantBranch()!=null){
            response.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(admin.getMerchantBranch()));
        }
        response.setPermissions(this.getPermissions(admin));
        return response;
    }
    public UserBackendAdminResponse mapBackendAdminEntityToResponse(UserBackendAdmin admin){
        UserBackendAdminResponse response = new UserBackendAdminResponse();
        response.setActive(admin.getEnabled());
        response.setEmail(admin.getEmail().toLowerCase());
        response.setFirstName(admin.getFirstName());
        response.setSurname(admin.getSurname());
        response.setGender(admin.getGender());
        response.setUserId(admin.getUserId());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
        response.setPermissions(this.getPermissions(admin));
        return response;
    }
    public UserBackendAgentResponse mapBackendAgentEntityToResponse(UserBackendAgent admin){
        UserBackendAgentResponse response = new UserBackendAgentResponse();
        response.setActive(admin.getEnabled());
        response.setEmail(admin.getEmail().toLowerCase());
        response.setFirstName(admin.getFirstName());
        response.setSurname(admin.getSurname());
        response.setGender(admin.getGender());
        response.setUserId(admin.getUserId());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
        response.setPermissions(this.getPermissions(admin));
        return response;
    }
    public UserCustomerResponse mapCustomerEntityToResponse(UserCustomer admin){
        UserCustomerResponse response = new UserCustomerResponse();
        response.setActive(admin.getEnabled());
        if(admin.getEmail()!=null){
            response.setEmail(admin.getEmail().toLowerCase());
        }

        response.setFirstName(admin.getFirstName());
        response.setGender(admin.getGender());
        response.setSurname(admin.getSurname());
        response.setCustomerId(admin.getUserId());
        response.setMobileNumber(admin.getMobileNumber());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
        response.setMobileNumberCountryCode(admin.getMobileNumberCountryCode());
        response.setPermissions(this.getPermissions(admin));
        return response;
    }
    public UserBrandAmbassadorResponse mapBrandAmbassadorEntityToResponse(UserBrandAmbassador admin){
        UserBrandAmbassadorResponse response = new UserBrandAmbassadorResponse();
        response.setActive(admin.getEnabled());
        if(admin.getEmail()!=null){
            response.setEmail(admin.getEmail().toLowerCase());
        }

        response.setFirstName(admin.getFirstName());
        response.setGender(admin.getGender());
        response.setSurname(admin.getSurname());
        response.setUserId(admin.getUserId());
        response.setMobileNumber(admin.getMobileNumber());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
        response.setMobileNumberCountryCode(admin.getMobileNumberCountryCode());
        response.setPermissions(this.getPermissions(admin));
        return response;
    }
    public TellerResponse mapTellerEntityToResponse(TellerUser admin){
        TellerResponse response = new TellerResponse();
        response.setActive(admin.getEnabled());
        if(admin.getEmail()!=null){
            response.setEmail(admin.getEmail().toLowerCase());
        }

        response.setFirstName(admin.getFirstName());
        response.setGender(admin.getGender());
        response.setSurname(admin.getSurname());
        response.setUserId(admin.getUserId());
        response.setMobileNumber(admin.getMobileNumber());
        response.setContactMobileNumber(admin.getContactMobileNumber());
        response.setContactMobileNumberCountryCode(admin.getContactMobileNumberCountryCode());
        response.setMobileNumberCountryCode(admin.getMobileNumberCountryCode());
        response.setPermissions(this.getPermissions(admin));
        return response;
    }
    private  List<PermissionResponse> getPermissions(User user) {

        final List<PermissionResponse> responses = new ArrayList<PermissionResponse>();
        final Collection<Permission> collection = user.getPermissions();

        for (final Permission item : collection) {
            List<Privilege> privileges =item.getPrivileges().stream().filter(x -> user.getPrivileges().contains(x)).collect(toList());
            List<PrivilegeResponse> privs= new ArrayList<>();
            for(Privilege p: privileges){
                PrivilegeResponse privilegeResponse= new PrivilegeResponse();
                privilegeResponse.setId(p.getId());
                privilegeResponse.setName(p.getName());
                privs.add(privilegeResponse);
            }
            PermissionResponse response = new PermissionResponse();
            response.setName(item.getName());
            response.setId(item.getId());
            response.setPriviledges(privs);
            responses.add(response);
        }

        return responses;
    }

    public UserAuditTrailResponse mapUserAuditTrailEntityToResponse(UserAuditTrail theUser) {

        UserAuditTrailResponse userAuditTrailResponse = new UserAuditTrailResponse();

        userAuditTrailResponse.setAction(theUser.getAction());
        User user = userRepository.findById(theUser.getUserId()).orElse(null);
        if(user!=null){
            userAuditTrailResponse.setUsername(user.getUsername());
        }else{
            userAuditTrailResponse.setUsername("N/A");
        }

        userAuditTrailResponse.setActionTIme(theUser.getCreatedAt().toString());
        userAuditTrailResponse.setId(theUser.getId());
        userAuditTrailResponse.setUserId(theUser.getUserId());

        return userAuditTrailResponse;
    }
    public void assignPermissionsByRoleToUser(RoleName roleName, User user) {
        Role role = roleRepository.findByName(roleName).orElse(null);
        List<Privilege> privileges = new ArrayList<>();

        List<Permission> permissions = permissionRepository.findByRoles_Id(role.getId());
        for(Permission p: permissions){
            for(Privilege privilege: p.getPrivileges()){
                if(!privileges.contains(privilege)){
                    privileges.add(privilege);
                }
            }

        }
        user.setPermissions(permissions);
        user.setPrivileges(privileges);
        userRepository.save(user);

    }
    public void sendSuccessfulRegistrationEmail(String emailAddress){
        String emailMessage = this.processSuccessRegistrationEmailMessage("REGISTRATION_WITH_PIN");
        this.processSuccessRegistrationEmailNotification(emailAddress,emailMessage);
    }
    private void processAgentSuccessfulRegistrationSMSWithPin(String mobileNumber,String pin,String cashierCode){
        String smsMessage = this.processCashierRegistrationSMSMessageWithPin("CASHIER_REGISTRATION_WITH_PIN",pin,cashierCode);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processCashierRegistrationSMSMessageWithPin(String smsMessageCode,String pin,String cashierCode){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin",pin);
            values.put("cashierCode",cashierCode);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void sendSuccessfulRegistrationEmailWithPin(String emailAddress,String pin,String receiverName){
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(emailAddress);//replace with your desired email
        mail.setSubject("Your ChangeMoney Account is ready!");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Your ChangeMoney Account is ready!");
        model.put("pin",pin);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );

        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
        model.put("supportEmail", appVariableRepository.findByCodeAndActive("SUPPORT_EMAIL", true).getValue());
        model.put("receiverName",receiverName);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"registration",1);
    }
    public void sendSuccessfulRegistrationSMSWithPin(String mobileNumber,String pin){
        String smsMessage = this.processSuccessRegistrationSmsMessageWithPin("REGISTRATION_WITH_PIN",pin);
        this.processSuccessRegistrationSmsNotification(mobileNumber,smsMessage);
    }
    public void sendSuccessfulRegistrationSMS(String mobileNumber){
        String smsMessage = this.processSuccessRegistrationSmsMessage("REGISTRATION_WITH_PIN");
        this.processSuccessRegistrationSmsNotification(mobileNumber,smsMessage);
    }
    public void sendCustomerSuccessfulRegistrationSMS(UserCustomer customer){
        String smsMessage = this.processCustomerSuccessRegistrationSmsMessage("CUSTOMER_SUCCESS_REGISTRATION",customer.getFirstName());
        this.processSuccessRegistrationSmsNotification(customer.getMobileNumber(),smsMessage);
    }
    public void sendCustomerSuccessfulResetSMS(UserCustomer customer){
        String smsMessage = this.processCustomerSuccessResetSmsMessage("SUCCESS_RESET_PIN");
        this.processSuccessRegistrationSmsNotification(customer.getMobileNumber(),smsMessage);
    }
    private String processSuccessRegistrationEmailMessage(String emailMessageCode,String pin){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin", pin);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome TO Rapid Fuel you can now order";
        }
    }
    private String processSuccessRegistrationEmailMessage(String emailMessageCode){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());

            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome TO Rapid Fuel you can now order";
        }
    }
    private String processSuccessRegistrationEmailMessageWith(String emailMessageCode,String pin){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin", pin);

            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome TO Rapid Fuel you can now order";
        }
    }
    private String processSuccessRegistrationSmsMessage(String smsMessageCode){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome To Rapid Fuel You can Now Order";
        }
    }
    private String processSuccessRegistrationSmsMessage(String smsMessageCode,String otp,String appSignature){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin", otp);
            values.put("appSignature", appSignature);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome To Rapid Fuel You can Now Order";
        }
    }
    public void sendSuccessfulRegistrationEmailWithOTP(String emailAddress, String pin){
        String emailMessage = this.processSuccessRegistrationEmailMessage("REGISTRATION_WITH_OTP",pin);
        this.processSuccessRegistrationEmailNotification(emailAddress,emailMessage,pin);
    }
    private String processSuccessRegistrationSmsMessageWithPin(String smsMessageCode,String pin){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin", pin);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome To Rapid Fuel use this pin: "+pin;
        }
    }
    private String processCustomerSuccessRegistrationSmsMessage(String smsMessageCode,String name){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("name", name);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome " + name+" to Rapid Fuel";
        }
    }
    private String processCustomerSuccessResetSmsMessage(String smsMessageCode){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());

            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You have successfully changed your password. Thank you For Using Rapid Fuel.";
        }
    }
    private void processSuccessRegistrationEmailNotification(String email,String emailMessage) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("Welcome To RapidFuel");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Successful Registration");
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );
            mail.setSubject("Welcome To "+ appName.getValue());
        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("emailText",emailMessage);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"general",1);
    }
    private void processSuccessRegistrationEmailNotification(String email,String emailMessage,String pin) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Successful Registration");
        model.put("pin",pin);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );
            mail.setSubject("Welcome To "+ appName.getValue());
        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("emailText",emailMessage);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"registration",1);
    }
    private void processSuccessRegistrationEmailNotificationWithPin(String email,String emailMessage,String pin) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("Welcome To RapidFuel");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Successful Registration");
        model.put("pin",pin);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );
            mail.setSubject("Welcome To "+ appName.getValue());
        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("emailText",emailMessage);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"registration",1);
    }
    private void processSuccessRegistrationSmsNotification(String mobileNumber,String smsMessage) {
        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
    }
    private String processRegistartionSMSMessageWithPin(String smsMessageCode,String pin){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin",pin);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private String processRegistartionSMSMessage(String smsMessageCode){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private void sendSMS(String mobileNumber, String smsMessage){
        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
    }
    private void processSuccessfulRegistrationSMS(String mobileNumber){
        String smsMessage = this.processRegistartionSMSMessage("REGISTRATION");
        this.sendSMS(mobileNumber,smsMessage);
    }
    private void processSuccessfulRegistrationSMSWithPin(String mobileNumber,String pin){
        String smsMessage = this.processRegistartionSMSMessageWithPin("REGISTRATION_WITH_PIN",pin);
        this.sendSMS(mobileNumber,smsMessage);
    }

    public static double roundToHalf(double x) {
        return (double) (Math.ceil(x * 2) / 2);
    }
    public void sendSuccessfulRegistrationSMSWithOTP(String mobileNumber,String otp,String appSignature){
        String smsMessage = this.processSuccessRegistrationSmsMessage("REGISTRATION_OTP_CODE",otp,appSignature);
        this.processSuccessRegistrationSmsNotification(mobileNumber,smsMessage);
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);

        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantAdmin(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserBranchManager(String loggedInUserId){
        BranchManager backendAdmin = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
}
