package zw.co.change.money.app.notifications.websocket.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import zw.co.change.money.app.chat.model.ChatMessage;
import zw.co.change.money.app.chat.repository.ChatMessageRepository;
import zw.co.change.money.app.chat.request.ChatMessageRequest;
import zw.co.change.money.app.chat.response.ChatMessageResponse;
import zw.co.change.money.app.chat.service.ChatService;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessage;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.notifications.websocket.repository.WebSocketMessageRepository;
import zw.co.change.money.app.notifications.websocket.request.MultipleNotificationsMarkAsReadRequest;
import zw.co.change.money.app.notifications.websocket.response.ResponseType;
import zw.co.change.money.app.notifications.websocket.response.WebSocketNotificationResponse;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.users.model.User;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.users.repository.UserBackendAdminRepository;
import zw.co.change.money.app.users.repository.UserCustomerRepository;
import zw.co.change.money.app.users.repository.UserRepository;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.InAppMessageConfigRepository;
import zw.co.change.money.app.util.format.FormatUtility;

import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
@Transactional
public class WebSocketService {
    @Autowired
    ChatMessageRepository chatMessageRepository;
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    InAppMessageConfigRepository inAppMessageConfigRepository;
    @Autowired
    WebSocketMessageRepository webSocketMessageRepository;

    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    UserCustomerRepository userClientRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;

    @Autowired
    UserRepository userRepository;
    @Autowired
    ChatService chatService;
    @Autowired
    FormatUtility formatUtility;

    static double KILOMETER_TO_MILES_CONVERSION_FACTOR = 1.609344;


    private final SimpMessagingTemplate simpMessagingTemplate;

    public WebSocketService(SimpMessagingTemplate simpMessagingTemplate) {
        this.simpMessagingTemplate = simpMessagingTemplate;
    }

    public void saveChatMessageReceived(ChatMessageRequest request) {
        if (request.isFromCustomer()) {
            UserCustomer customer = userCustomerRepository.findById(request.getSenderId()).orElse(null);
            if (customer == null) {
                return;
            }
            if (request.getMessage() != null && !request.getMessage().isEmpty()) {
                ChatMessage chatMessage = new ChatMessage();
                chatMessage.setMessage(request.getMessage());
                chatMessage.setCustomer(customer);
                chatMessage.setReadStatus(false);
                chatMessage.setSenderId(customer.getUserId());
                chatMessage.setFromCustomer(true);
                ChatMessage savedChatMessage = chatMessageRepository.save(chatMessage);
                this.sendChatMessageToCustomer(customer.getUserId(),chatService.mapChatMessageEntityToResponse(savedChatMessage));
                this.sendChatMessageToGroup(WebSocketMessageGroup.BACKEND_AGENT,chatService.mapChatMessageEntityToResponse(savedChatMessage));
                this.sendChatMessageToGroup(WebSocketMessageGroup.BACKEND_ADMINS,chatService.mapChatMessageEntityToResponse(savedChatMessage));

            }
        } else {
            UserCustomer customer = userCustomerRepository.findById(request.getReceiverId()).orElse(null);
            if (customer == null) {
                return;
            }
            User sender = userRepository.findById(request.getSenderId()).orElse(null);
            if (sender == null) {
                return;
            }
            if (request.getMessage() != null && !request.getMessage().isEmpty()) {
                ChatMessage chatMessage = new ChatMessage();
                chatMessage.setMessage(request.getMessage());
                chatMessage.setCustomer(customer);
                chatMessage.setReadStatus(false);
                chatMessage.setReceiverId(customer.getUserId());
                chatMessage.setSenderId(sender.getUserId());
                chatMessage.setFromCustomer(false);
                ChatMessage savedChatMessage = chatMessageRepository.save(chatMessage);

                this.sendChatMessageToCustomer(customer.getUserId(),chatService.mapChatMessageEntityToResponse(savedChatMessage));
                this.sendChatMessageToGroup(WebSocketMessageGroup.BACKEND_AGENT,chatService.mapChatMessageEntityToResponse(savedChatMessage));
                this.sendChatMessageToGroup(WebSocketMessageGroup.BACKEND_ADMINS,chatService.mapChatMessageEntityToResponse(savedChatMessage));
            }

        }
    }

    public ResponseEntity updateMessageReadStatus(long messageId) {
        WebSocketMessage userMessage=webSocketMessageRepository.findById(messageId).orElse(null);
        if(userMessage==null){
            return new ResponseEntity<>(new GenericApiError("Could not Find message",110), HttpStatus.NOT_FOUND);
        }
        userMessage.setReadStatus(true);
        webSocketMessageRepository.save(userMessage);
        return ResponseEntity.ok(new GenericApiResponse("Notification Updated Successfully"));
    }
    public ResponseEntity updateMultipleMessagesReadStatus(MultipleNotificationsMarkAsReadRequest request) {
        for(Long messageId:request.getNotificationIds()){
            WebSocketMessage userMessage=webSocketMessageRepository.findById(messageId).orElse(null);
            if(userMessage==null){
                return new ResponseEntity<>(new GenericApiError("Could not Find Notification",110), HttpStatus.NOT_FOUND);
            }
            userMessage.setReadStatus(true);
            webSocketMessageRepository.save(userMessage);
        }

        return ResponseEntity.ok(new GenericApiResponse("Notifications Updated Successfully"));
    }
    public ResponseEntity getMessagesByUserId(String userId,int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<WebSocketMessage> locations = webSocketMessageRepository.findByUserIdOrderByCreatedAtDesc(userId,pageable);
        List<WebSocketNotificationResponse> responses = locations.stream().map(this::mapToWebSocketMessageResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(responses, locations.getNumber(),
                locations.getSize(), locations.getTotalElements(), locations.getTotalPages(), locations.isLast()));
    }
    public ResponseEntity getMessagesByUserIdAndReadStatus(String userId,boolean readStatus,int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<WebSocketMessage> locations = webSocketMessageRepository.findByUserIdAndReadStatusOrderByCreatedAtDesc(userId,readStatus,pageable);
        List<WebSocketNotificationResponse> responses = locations.stream().map(this::mapToWebSocketMessageResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(responses, locations.getNumber(),
                locations.getSize(), locations.getTotalElements(), locations.getTotalPages(), locations.isLast()));
    }
    public ResponseEntity getUnreadNotificationsCountByUserId(String userId){
        return ResponseEntity.ok(webSocketMessageRepository.countByReadStatusAndUserId(false,userId));
    }





    public ResponseEntity sendMessageToNotifications(String message,String userId){
        User  admin = userRepository.findById(userId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("could not load Admin",110), HttpStatus.NOT_FOUND);
        }
        WebSocketMessage message1 =new WebSocketMessage();
        message1.setMessage(message);
        message1.setReadStatus(false);
        message1.setTitle("Yo Test");
        message1.setUserId(userId);
        WebSocketMessage savedMessage =webSocketMessageRepository.save(message1);
//        simpMessagingTemplate.convertAndSend("/notifications/" + userId,  this.mapToWebSocketMessageResponse(savedMessage));

        return ResponseEntity.ok("Message Updated");
    }

    public ResponseEntity sendMessageToBackendAdminSpecific(String message,String userId){
        User admin = userRepository.findById(userId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("could not load Admin",110), HttpStatus.NOT_FOUND);
        }

        this.sendInAppMessageToSpecificUser(admin.getUserId(),message,"Test To Specific User");

        return ResponseEntity.ok("Message Updated");
    }
    public  void sendNewExchangeRateToCustomers(CurrencyResponse exchangeRate){
        simpMessagingTemplate.convertAndSend("/exchangeRate/" ,  exchangeRate);
    }
    public ResponseEntity sendMessageToGroup(String message,WebSocketMessageGroup group){

        if(group==null){
            return new ResponseEntity<>(new GenericApiError("Group cannot be null",105), HttpStatus.EXPECTATION_FAILED);
        }

        this.sendInAppMessageToGroup(group,message,"Test Group",ResponseType.NOTIFICATION);

        return ResponseEntity.ok("Message Updated");
    }
    public void sendChatMessageToCustomer(String userId, ChatMessageResponse message){
        simpMessagingTemplate.convertAndSendToUser(userId, "/chatMessages",message);
    }
    public void sendChatMessageToGroup(WebSocketMessageGroup group, ChatMessageResponse message){
        simpMessagingTemplate.convertAndSendToUser(group.toString(), "/chatMessages",message);
    }
    public void sendInAppMessageToSpecificUser(String userId,String message,String title,ResponseType messageType){
        WebSocketMessage message1 =new WebSocketMessage();
        message1.setMessage(message);
        message1.setReadStatus(false);
        message1.setTitle(title);
        message1.setUserId(userId);
        message1.setResponseType(messageType);
        WebSocketMessage savedMessage =webSocketMessageRepository.save(message1);

        simpMessagingTemplate.convertAndSendToUser(userId, "/msg", this.mapToWebSocketMessageResponse(savedMessage));
    }
    public void sendInAppMessageToSpecificUser(String userId,String message,String title){
        WebSocketMessage message1 =new WebSocketMessage();
        message1.setMessage(message);
        message1.setReadStatus(false);
        message1.setTitle(title);
        message1.setUserId(userId);
        WebSocketMessage savedMessage =webSocketMessageRepository.save(message1);

//        simpMessagingTemplate.convertAndSendToUser(userId, "/msg", this.mapToWebSocketMessageResponse(savedMessage));
    }
    public void sendInAppMessageToGroup(WebSocketMessageGroup group, String message, String title,ResponseType messageType){
        List<User> users = userRepository.findByMessageGroup(group);

        if(users!=null || users.size()!=0){
            WebSocketMessage savedMessage = new WebSocketMessage();
            for(User u: users){
                WebSocketMessage message1 =new WebSocketMessage();
                message1.setMessage(message);
                message1.setReadStatus(false);
                message1.setTitle(title);
                message1.setResponseType(messageType);
                message1.setUserId(u.getUserId());
                savedMessage =webSocketMessageRepository.save(message1);
            }
            simpMessagingTemplate.convertAndSend("/g/" + group,  this.mapToWebSocketMessageResponse(savedMessage));
        }


    }
    private WebSocketNotificationResponse mapToWebSocketMessageResponse(WebSocketMessage userMessage){
        WebSocketNotificationResponse messageResponse = new WebSocketNotificationResponse();
        messageResponse.setUserId(userMessage.getUserId());
        messageResponse.setId(userMessage.getId());
        messageResponse.setTitle(userMessage.getTitle());
        messageResponse.setMessage(userMessage.getMessage());
        messageResponse.setResponseType(userMessage.getResponseType());
        messageResponse.setTime(String.valueOf(userMessage.getCreatedAt()));
        messageResponse.setReadStatus(userMessage.isReadStatus());
        return messageResponse;
    }

}
