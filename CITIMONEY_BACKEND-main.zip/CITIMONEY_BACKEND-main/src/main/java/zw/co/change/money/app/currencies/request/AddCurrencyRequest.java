package zw.co.change.money.app.currencies.request;

import lombok.Data;

@Data
public class AddCurrencyRequest {
    private String name;
    private double exchangeRate;
}
