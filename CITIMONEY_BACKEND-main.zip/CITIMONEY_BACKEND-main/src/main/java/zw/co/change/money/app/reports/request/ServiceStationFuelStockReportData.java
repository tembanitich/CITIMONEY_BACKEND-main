package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class ServiceStationFuelStockReportData {
    private double quantity;
    private String user;
    private String adjustmentType;
    private String fuelType;
    private String serviceStationName;
    private double costPerLitre;
    private double totalCost;
    private String supplierName;
    private String productName;
    private String comment;
    private LocalDateTime dateOfAdjustment;
}
