package zw.co.change.money.app.accounts.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.users.model.AccountManager;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"account","accountManager"})
@Data
@Table(name = "merchant_account_deposit_requests")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantAccountDepositRequest extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantAccount account;
    private double amount;
    private String approvedBy;
    private String declinedBy;
    private LocalDateTime declinedDate;
    private LocalDateTime approvedDate;

    @Enumerated(EnumType.STRING)
    private DepositRequestStatus status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "accountManager")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private AccountManager accountManager;
}
