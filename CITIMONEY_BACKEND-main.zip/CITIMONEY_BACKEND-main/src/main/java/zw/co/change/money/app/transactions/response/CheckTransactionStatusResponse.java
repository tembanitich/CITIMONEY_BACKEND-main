package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.users.response.UserCustomerResponse;

@Data
public class CheckTransactionStatusResponse {
    private String reference;
    private double amount;
    private TransactionStatus status;
    private TransactionType transactionType;
    private UserCustomerResponse customer;
}
