package zw.co.change.money.app.authentication.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import zw.co.change.money.app.legacy.response.MerchantBranchDto;
import zw.co.change.money.app.legacy.response.MerchantDto;
import zw.co.change.money.app.merchants.response.MerchantBranchResponse;
import zw.co.change.money.app.merchants.response.MerchantResponse;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.security.roles.response.PermissionResponse;

import java.util.Collection;
import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserSummary {

    private List<PermissionResponse> permissions;
    //== users details
    private String userId;
    private String firstName;
    private Boolean verified = false;
    private String mobileNumber;
    private String contactMobileNumber;
    private String contactMobileNumberCountryCode;
    private Boolean available=true;
    private String mobileNumberCountryCode;
    private String username;
    private Boolean enabled = true;
    private Boolean resetPin = false;
    private String surname;
    private String dateCreated;
    private String dateUpdated;
    private String email;
    private String userGroup;
    private WebSocketMessageGroup webSocketMessageGroup;
    private String avatar = "default";
    private String gender;
    private MerchantResponse merchant;
    private MerchantBranchResponse merchantBranch;
    private Collection<? extends GrantedAuthority> userRoles;
    private Collection<? extends GrantedAuthority> privileges;
    private String message = "success";
    private String accessToken;
    private Boolean firstTime = false;

}
