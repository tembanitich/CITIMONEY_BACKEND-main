package zw.co.change.money.app.chat.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.chat.model.ChatMessage;
import zw.co.change.money.app.chat.repository.ChatMessageRepository;
import zw.co.change.money.app.chat.response.ChatMessageResponse;
import zw.co.change.money.app.users.model.User;
import zw.co.change.money.app.users.model.UserBackendAdmin;
import zw.co.change.money.app.users.model.UserBackendAgent;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.users.repository.UserBackendAdminRepository;
import zw.co.change.money.app.users.repository.UserBackendAgentRepository;
import zw.co.change.money.app.users.repository.UserCustomerRepository;
import zw.co.change.money.app.users.repository.UserRepository;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.chat.response.GroupedChatResponse;
import zw.co.change.money.app.notifications.websocket.service.WebSocketService;

import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.response.GenericApiError;

import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class ChatService {
    @Autowired
    ChatMessageRepository chatMessageRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    UserService userService;
    @Autowired
    WebSocketService webSocketService;
    @Autowired
    AuthenticationService authenticationService;
    @Autowired
    UserRepository userRepository;


    public ResponseEntity sendMessageToCustomerSpecific(String message,String userId,String loggedInUserId){
        UserCustomer customer = userCustomerRepository.findById(userId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("could not load Customer",110), HttpStatus.NOT_FOUND);
        }
        User sender = userRepository.findById(loggedInUserId).orElse(null);
        if(sender==null){
            return new ResponseEntity<>(new GenericApiError("could not load sender",110), HttpStatus.NOT_FOUND);
        }
        ChatMessage chatMessage = new ChatMessage();
        chatMessage.setMessage(message);
        chatMessage.setReceiverId(customer.getUserId());
        chatMessage.setCustomer(customer);
        chatMessage.setReadStatus(false);
        chatMessage.setSenderId(sender.getUserId());
        chatMessage.setFromCustomer(false);
        ChatMessage savedChatMessage = chatMessageRepository.save(chatMessage);

        webSocketService.sendChatMessageToCustomer(customer.getUserId(),this.mapChatMessageEntityToResponse(savedChatMessage));

        return ResponseEntity.ok("Message Updated");
    }
    public ResponseEntity getAllChatMessages(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<ChatMessage> failures = chatMessageRepository.findAll(pageable);

        List<ChatMessageResponse> productResponses = failures.stream().map(this::mapChatMessageEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getChatMessageById(long chatMessageId) {

        ChatMessage admin = chatMessageRepository.findById(chatMessageId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Chat Message",110), HttpStatus.NOT_FOUND);
        }
        ChatMessageResponse response = this.mapChatMessageEntityToResponse(admin);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getChatMessageByCustomerId(String customerId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        UserCustomer customer = userCustomerRepository.findById(customerId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        Page<ChatMessage> messages = chatMessageRepository.findByCustomerUserId(customerId,pageable);

        List<ChatMessageResponse> productResponses = messages.stream().map(this::mapChatMessageEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, messages.getNumber(),
                messages.getSize(), messages.getTotalElements(), messages.getTotalPages(), messages.isLast()));

    }
    public ResponseEntity getMyChatMessages(String loggedInUserId,int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        UserCustomer customer = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorized To perfom this action",102), HttpStatus.UNAUTHORIZED);
        }

            Page<ChatMessage> messages = chatMessageRepository.findByCustomerUserId(loggedInUserId,pageable);

            List<ChatMessageResponse> productResponses = messages.stream().map(this::mapChatMessageEntityToResponse).collect(toList());

            return   ResponseEntity.ok(new PagedResponse<>(productResponses, messages.getNumber(),
                    messages.getSize(), messages.getTotalElements(), messages.getTotalPages(), messages.isLast()));



    }
    public ResponseEntity getChatMessagesGroupedByUser(String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        List<GroupedChatResponse> response = new ArrayList<>();
      List<String> userdIds = chatMessageRepository.getCustomers();
        for(String userId :userdIds ){
            UserCustomer customer = userCustomerRepository.findById(userId).orElse(null);
            if(customer!=null){
            List<ChatMessage> chatMessages=   chatMessageRepository.findByCustomerUserId(userId);
                GroupedChatResponse chatResponse = new GroupedChatResponse();
                chatResponse.setCustomer(userService.mapCustomerEntityToResponse(customer));
                chatResponse.setMessages(chatMessages.stream().map(this::mapChatMessageEntityToResponse).collect(toList()));
                response.add(chatResponse);
            }
        }
        return ResponseEntity.ok(response);
    }
    public ChatMessageResponse mapChatMessageEntityToResponse(ChatMessage product){
        ChatMessageResponse response = new ChatMessageResponse();
        response.setReadStatus(product.isReadStatus());
        if(product.getCustomer()!=null){
            UserCustomer customer = userCustomerRepository.findById(product.getCustomer().getUserId()).orElse(null);
                response.setCustomer(userService.mapCustomerEntityToResponse(customer));



        }
        response.setFromCustomer(product.isFromCustomer());
        response.setFromDriver(product.isFromDriver());
        response.setMessage(product.getMessage());
        response.setId(product.getId());
        if(product.getCreatedAt()!=null){
            response.setTime(product.getCreatedAt().toString());
        }
        if(product.getReceiverId()!=null){
            User receiver = userRepository.findById(product.getReceiverId()).orElse(null);
            if(receiver!=null){
                response.setReceiverId(receiver.getUserId());
                response.setReceiverName(receiver.getFirstName() + " "+ receiver.getSurname());
                response.setReceiver(authenticationService.SetBasicSummary(receiver));
            }
        }

        User sender = userRepository.findById(product.getSenderId()).orElse(null);
        if(sender!=null){
            response.setSenderId(sender.getUserId());
            response.setSenderName(sender.getFirstName() + " "+ sender.getSurname());
            response.setSender(authenticationService.SetBasicSummary(sender));
        }

        return response;
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);

        if (backendAdmin == null && agent==null ) {
            return false;
        }else{
            return  true;
        }
    }
}
