package zw.co.change.money.app.reports.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class ReportGenerationDTO {
    @NotNull
    private ReportFormat format;
    @NotNull
    private ReportFilter filter;
    @NotNull
    private ReportDateFilter dateFilter;
    @NotNull
    private ReportType reportType;
    @NotNull
    private String startDateTime;
    @NotNull
    private String endDateTime;
    private String filterValue;
    private String filterValueMax;
    private List<Long> fields;
}
