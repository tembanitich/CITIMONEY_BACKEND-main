package zw.co.change.money.app.users.model;

import lombok.Data;
import zw.co.change.money.app.util.audit.BaseDateAudit;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "user_audit_trails")
@Data
public class UserAuditTrail extends BaseDateAudit {
    private String action;
    private String userId;
    private String merchantId;
    private long branchId;
}