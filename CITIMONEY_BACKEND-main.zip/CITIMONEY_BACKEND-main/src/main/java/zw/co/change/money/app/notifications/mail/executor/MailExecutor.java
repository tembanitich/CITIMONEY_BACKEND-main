package zw.co.change.money.app.notifications.mail.executor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import zw.co.change.money.app.users.model.User;
import zw.co.change.money.app.storage.config.FileStorageProperties;
import zw.co.change.money.app.util.exception.FileStorageException;
import zw.co.change.money.app.notifications.mail.service.MailSenderService;
import zw.co.change.money.app.notifications.mail.request.Mail;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
@Transactional
public class MailExecutor {
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    MailSenderService mailSenderService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private final Path userDocumentsStorageLocation;
    @Autowired
    public MailExecutor(FileStorageProperties fileStorageProperties) {

        this.userDocumentsStorageLocation = Paths.get(fileStorageProperties.getUserDocuments())
                .toAbsolutePath().normalize();

        try {
            Files.createDirectories(this.userDocumentsStorageLocation);

        } catch (Exception ex) {
            throw new FileStorageException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }
    public void ScheduledMailExecutor(Mail mail, String templateName, int timeInSeconds) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {

            try {

                this.mailSenderService.sendEmail(mail,templateName);
                logger.info("Mail Sent Now");
//                mailSenderService.sendRegistrationMail(message, email, password);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.info("Mail interrupted");
                logger.error(">>>>>>>>>>>>>>>Error>>>>>>" + e.getMessage());
            }
        };

        executor.schedule(task, timeInSeconds, TimeUnit.SECONDS);
    }
    public void ScheduledMailExecutorWithAttachent(User user, Mail mail, byte[] attachment, String templateName, int timeInSeconds) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {

            try {
                if (!Files.exists(this.userDocumentsStorageLocation.resolve(user.getUserId()+ File.separator +"Invoices/"))){
                    Files.createDirectories(this.userDocumentsStorageLocation.resolve(user.getUserId() +File.separator +"Invoices/"));
                }
                Path targetLocation = this.userDocumentsStorageLocation.resolve(user.getUserId() +File.separator +"ProductVariation_Images/"+"Order-Invoice-"+ LocalDate.now().toString()+".pdf");
                InputStream targetStream = new ByteArrayInputStream(attachment);
                Files.copy(targetStream, targetLocation, StandardCopyOption.REPLACE_EXISTING);
                this.mailSenderService.sendEmailWithAttachement(mail,templateName,targetLocation);
                logger.info("Mail Sent Now");
//                mailSenderService.sendRegistrationMail(message, email, password);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.info("Mail interrupted");
                logger.error(">>>>>>>>>>>>>>>Error>>>>>>" + e.getMessage());
            }
        };

        executor.schedule(task, timeInSeconds, TimeUnit.SECONDS);
    }

}
