package zw.co.change.money.app.legacy.response;


import lombok.Data;
import zw.co.change.money.app.security.roles.model.RoleName;

@Data
public class RoleDto {
    private Long id;
    private RoleName name;
    private String Description;
    private boolean selfRegEnabled;
}
