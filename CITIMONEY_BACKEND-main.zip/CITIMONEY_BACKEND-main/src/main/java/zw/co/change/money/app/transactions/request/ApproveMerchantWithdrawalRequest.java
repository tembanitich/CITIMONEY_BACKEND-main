package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class ApproveMerchantWithdrawalRequest {
    private long requestId;
}
