package zw.co.change.money.app.users.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.transactions.model.Wallet;

import javax.persistence.*;


@Entity
@Table(name = "usersBrandAmbassadors",uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "mobileNumber"
        })
})
@Data
@EqualsAndHashCode(callSuper = true)
@PrimaryKeyJoinColumn(name = "userId")
@DiscriminatorValue("13")
public class UserBrandAmbassador extends User {
    private String mobileNumber;
    private String nationalId;
    private String mobileNumberCountryCode;
    private Boolean verified = false;
    private Boolean firstTime = false;
}
