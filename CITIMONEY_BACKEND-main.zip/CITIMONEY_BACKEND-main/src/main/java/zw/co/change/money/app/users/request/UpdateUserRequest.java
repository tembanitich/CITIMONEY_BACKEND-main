package zw.co.change.money.app.users.request;

import lombok.Data;

import javax.validation.constraints.NotNull;


@Data
public class UpdateUserRequest {
    @NotNull
    private String email;
    private String firstName;
    private String surname;

}
