package zw.co.change.money.app.util.generators;


import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.transactions.repository.MerchantWithdrawalRequestRepository;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.users.repository.MerchantCashierRepository;
import zw.co.change.money.app.users.repository.UserRepository;
import zw.co.change.money.app.security.roles.model.RoleName;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Year;
import java.time.format.DateTimeFormatter;

@Service
@Transactional
public class StringGeneratorUtility {
    @Autowired
    private TransactionRepository transactionsRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    MerchantRepository merchantRepository;
    @Autowired
    MerchantWithdrawalRequestRepository merchantWithdrawalRequestRepository;
    @Autowired
    FinancialInstitutionRepository financialInstitutionRepository;
    private String generateSecureAlphaNumeric(int len) {
        char[] ch = "123456789ABCDEFGHJKLMNPQRSTUVWXYZ".toCharArray();
        char[] c = new char[len];
        SecureRandom random = new SecureRandom();
        for (int i = 0; i < len; i++) {
            c[i] = ch[random.nextInt(ch.length)];
        }
        return new String(c);
    }

    // == user id
    private String GenerateUserId(RoleName role) {
        String userType;

        if (role.equals(RoleName.ROLE_BACK_OFFICE_AGENT)) {
            userType = "UBO";
        } else if (role.equals(RoleName.ROLE_SYSTEM)) {
            userType = "USA";
        } else if (role.equals(RoleName.ROLE_BACK_OFFICE_ADMIN)) {
            userType = "UBA";
        }  else if (role.equals(RoleName.ROLE_CUSTOMER)) {
            userType = "UCU";
        }
        else {
            userType = "BAD";
        }


        return userType.concat(String.valueOf(LocalDateTime.now().getMonthValue() + 1)).concat(Year.now().format(DateTimeFormatter.ofPattern("uu")))
                .concat("-" + generateSecureAlphaNumeric(3));
    }

    private boolean UserIdAvailable(String code) {
        return userRepository.existsById(code);
    }

    public String fetchValidUserId(RoleName role) {
        String myUserId = GenerateUserId(role);
        while (UserIdAvailable(myUserId)) {
            myUserId = GenerateUserId(role);
        }
        return myUserId;
    }

    // == user toke hash
    private String GenerateTokenHash() {

        return generateSecureAlphaNumeric(10);
    }

    private boolean TokenHashAvailable(String secret) {
        return userRepository.existsByTokenHash(secret);
    }

    public String fetchValidTokenHash() {
        String myHash = GenerateTokenHash();
        while (TokenHashAvailable(myHash)) {
            myHash = GenerateTokenHash();
        }
        return myHash;
    }


    public String generateTransactionId(){
        LocalDate today=     LocalDate.now();
        String id ="";
        do{
            id="";
            id=       RandomStringUtils.random(6, false, true)+ "-"+RandomStringUtils.random(4, true, false) +"-"+ today.getYear()+today.getMonthValue()+today.getDayOfMonth();
            id= id.toUpperCase();
        }while(transactionsRepository.existsById(id));
        return id;
    }
    public String generateCurrencyCode(){
        String id ="";
        do{
            id="";
            id=       RandomStringUtils.random(6, false, true)+ "-"+RandomStringUtils.random(4, true, false).toUpperCase();
        }while(currencyRepository.existsByCode(id));
        return id;
    }
    public String generateCashierCode(){
        String id ="";
        do{
            id="";
            id=       RandomStringUtils.random(6, false, true);
        }while(cashierRepository.existsByCode(id));
        return id;
    }
    public String generateStaffNumber(){
        String id ="";
        do{
            id="";
            id=      RandomStringUtils.random(4, false, true);
        }while(userRepository.existsByUsername(id));
        return id;
    }

    public String generateMerchantId(){
        String id ="";
        do{
            id="";
            id=      RandomStringUtils.random(2, false, true)+"-"+RandomStringUtils.random(5, true, true).toUpperCase();
        }while(merchantRepository.existsById(id));
        return id;
    }
    public String generateWithdrawalApprovalCode(String merchantId){
        String id ="";
        do{
            id="";
            id=      RandomStringUtils.random(6, false, true);
        }while(merchantWithdrawalRequestRepository.existsByAccountMerchantIdAndApprovalCode(merchantId,id));
        return id;
    }
    public String generateMerchantCode(){
        String id ="";
        do{
            id="";
            id=      RandomStringUtils.random(6, false, true);
        }while(merchantRepository.existsByCode(id));
        return id;
    }
    public String generateInstitutionNumber(){
        String id ="";
        do{
            id="";
            id=      RandomStringUtils.random(2, false, true)+"-"+RandomStringUtils.random(5, true, true).toUpperCase();
        }while(financialInstitutionRepository.existsByInstitutionNumber(id));
        return id;
    }

}
