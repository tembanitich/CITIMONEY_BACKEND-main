package zw.co.change.money.app.legacy.response;

import lombok.Data;

@Data
public class AccountDto extends BaseDto {
    private String msisdn;
    private String accountStatus;
    private double accountBalance;
    private String accountAlias;
    private String accountType;
}
