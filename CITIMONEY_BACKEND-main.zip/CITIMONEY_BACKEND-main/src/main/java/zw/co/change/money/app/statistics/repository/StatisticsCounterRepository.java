package zw.co.change.money.app.statistics.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.statistics.model.StatisticsCounter;

import java.time.LocalDate;
import java.util.Optional;

public interface StatisticsCounterRepository extends JpaRepository<StatisticsCounter, Long> {
    Optional<StatisticsCounter> findByName(String name);
    Optional<StatisticsCounter> findByNameAndForAll(String name,boolean isForAll);
    Optional<StatisticsCounter> findByNameAndMerchantId(String name,String merchantId);
    Optional<StatisticsCounter> findByNameAndBranchId(String name,long branchId);
    Optional<StatisticsCounter> findByNameAndAccountManagerId(String name,String merchantId);
    Optional<StatisticsCounter> findByNameAndCashierId(String name,String cashierId);
    Optional<StatisticsCounter> findByNameAndMonthAndForAll(String name, long month,boolean isForAll);
    Optional<StatisticsCounter> findByNameAndMonthAndMerchantId(String name, long month,String merchantId);
    Optional<StatisticsCounter> findByNameAndMonthAndBranchId(String name, long month,long branchId);
    Optional<StatisticsCounter> findByNameAndMonthAndCashierId(String name, long month,String cashierId);

}
