package zw.co.change.money.app.merchants.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;

@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"merchant"})
@Data
public class MerchantBranch extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String branchManagerName;
    private String branchEmail;
    private String contactNumber;
    private String contactNumberCountryCode;
    private boolean active;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Merchant merchant;
}
