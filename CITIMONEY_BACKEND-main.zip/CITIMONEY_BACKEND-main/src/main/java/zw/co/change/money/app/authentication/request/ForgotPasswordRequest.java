package zw.co.change.money.app.authentication.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class ForgotPasswordRequest {

    @NotNull
    private String email;
    @NotNull
    private String mobileNumber;
}
