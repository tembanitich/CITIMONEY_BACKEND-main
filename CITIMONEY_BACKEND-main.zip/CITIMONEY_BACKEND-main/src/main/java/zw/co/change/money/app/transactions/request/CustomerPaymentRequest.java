package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CustomerPaymentRequest {
    private String cashierCode;
    private String currencyCode;
    private String pin;
//    private String acquiringFinancialInstitutionNumber;
//    private String notificationMsisdn;
//    private String accountNumber;
//    private IssueChangeType paymentType;
    private double amount;
}
