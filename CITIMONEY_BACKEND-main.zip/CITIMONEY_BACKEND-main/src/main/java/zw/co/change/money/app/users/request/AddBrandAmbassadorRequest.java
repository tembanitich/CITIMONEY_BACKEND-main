package zw.co.change.money.app.users.request;

import lombok.Data;
import zw.co.change.money.app.users.model.Gender;

import javax.validation.constraints.NotNull;
@Data
public class AddBrandAmbassadorRequest {
    private String firstName;
    private String surname;
    @NotNull
    private String mobileNumber;
    @NotNull
    private String mobileNumberCountryCode;
    @NotNull
    private String email;
    @NotNull
    private Gender gender;
}
