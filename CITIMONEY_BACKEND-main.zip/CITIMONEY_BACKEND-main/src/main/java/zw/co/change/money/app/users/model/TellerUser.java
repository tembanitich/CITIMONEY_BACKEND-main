package zw.co.change.money.app.users.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.merchants.model.MerchantBranch;

import javax.persistence.*;

@Entity
@Table(name = "teller_users")
@Data
@EqualsAndHashCode(callSuper = true)
@PrimaryKeyJoinColumn(name = "userId")
@DiscriminatorValue("12")
public class TellerUser extends User {
    private String mobileNumber;
    private String mobileNumberCountryCode;
}
