package zw.co.change.money.app.merchants.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.response.MerchantTransactionTotalInterface;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MerchantRepository extends JpaRepository<Merchant, String> {
    Optional<Merchant> findByName(String name);
    Optional<Merchant> findByCode(String code);
    Boolean existsByCode(String name);

    List<Merchant> findByActive(boolean status);
    Long countByActive(boolean status);
    Long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate);
    Page<Merchant> findByActive(boolean status, Pageable pageable);
    Page<Merchant> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    List<Merchant> findByNameContainingIgnoreCase(String query);
    Page<Merchant> findByNameContainingIgnoreCase(String query, Pageable pageable);
    Page<Merchant> findByNameContainingIgnoreCaseAndActive(String query,boolean status, Pageable pageable);
    Page<Merchant> findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String query, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    @Query(value ="select po.id,po.name, sum(p.amount_in_usd) as total from transactions p inner join merchant po on p.merchant = po.id WHERE p.status='SUCCESS' group by po.id order by total desc LIMIT 10", nativeQuery = true)
    List<MerchantTransactionTotalInterface> getTop10Merchants();
}
