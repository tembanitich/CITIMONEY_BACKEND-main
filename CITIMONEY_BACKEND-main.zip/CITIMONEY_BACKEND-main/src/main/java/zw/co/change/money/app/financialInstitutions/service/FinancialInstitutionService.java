package zw.co.change.money.app.financialInstitutions.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.financialInstitutions.request.AddFinancialInstitutionRequest;
import zw.co.change.money.app.financialInstitutions.request.UpdateFinancialInstitutionRequest;
import zw.co.change.money.app.financialInstitutions.response.FinancialInstitutionResponse;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.MerchantAdminRepository;
import zw.co.change.money.app.users.repository.MerchantCashierRepository;
import zw.co.change.money.app.users.repository.UserBackendAdminRepository;
import zw.co.change.money.app.users.repository.UserBackendAgentRepository;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.validation.ValidateFinancialInstitutionProperties;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class FinancialInstitutionService {
    @Autowired
    private ValidateFinancialInstitutionProperties validateFinancialInstitutionProperties;
    @Autowired
    private UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    private FinancialInstitutionRepository financialInstitutionRepository;
    @Autowired
    private UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private DateUtil dateUtil;
    
    
    public ResponseEntity addFinancialInstitution(AddFinancialInstitutionRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateFinancialInstitutionProperties.validateAddFinancialInstitutionRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        FinancialInstitution merchant = new FinancialInstitution();
        merchant.setActive(true);
        merchant.setName(request.getName());
        merchant.setDisplayName(request.getDisplayName());
        merchant.setInstitutionNumber(stringGeneratorUtility.generateInstitutionNumber());
        merchant.setActive(true);
        merchant.setMobileMoney(request.isMobileMoney());
        financialInstitutionRepository.save(merchant);


        return ResponseEntity.ok(new GenericApiResponse("Financial Institution Created Successfully"));
    }
    public ResponseEntity updateFinancialInstitution(UpdateFinancialInstitutionRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateFinancialInstitutionProperties.validateUpdateFinancialInstitutionRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }

        FinancialInstitution merchant = financialInstitutionRepository.findByInstitutionNumber(request.getInstitutionNumber()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",110), HttpStatus.NOT_FOUND);
        }
        merchant.setName(request.getName());
        merchant.setName(request.getName());
        merchant.setDisplayName(request.getDisplayName());
        merchant.setMobileMoney(request.isMobileMoney());
        financialInstitutionRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Financial Institution Updated Successfully"));
    }
    public ResponseEntity ActivateOrDeactivateFinancialInstitution(String institutionNumber, Boolean status, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        FinancialInstitution merchant = financialInstitutionRepository.findByInstitutionNumber(institutionNumber).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("could not load Financial Institution",110), HttpStatus.NOT_FOUND);
        }

        merchant.setActive(status);
        financialInstitutionRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Financial Institution activation status updated"));
    }
    public ResponseEntity getFinancialInstitutionsByStatus(boolean status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<FinancialInstitution> failures =  financialInstitutionRepository.findByActive(status,pageable);

        List<FinancialInstitutionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToFinancialInstitutionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveFinancialInstitutions() {
        List<FinancialInstitution> failures =  financialInstitutionRepository.findByActive(true);

        List<FinancialInstitutionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToFinancialInstitutionResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity searchFinancialInstitutionsByName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateFinancialInstitutionProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<FinancialInstitution> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean paymentStatus = Boolean.valueOf(request.getFilterValue());
                failures = financialInstitutionRepository.findByNameContainingIgnoreCaseAndActive(request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = financialInstitutionRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = financialInstitutionRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = financialInstitutionRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = financialInstitutionRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = financialInstitutionRepository.findByNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<FinancialInstitutionResponse> responses = failures.stream().map(this::mapEntityToFinancialInstitutionResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity getAllFinancialInstitutions(int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<FinancialInstitution> failures = financialInstitutionRepository.findAll(pageable);

        List<FinancialInstitutionResponse> productResponses = failures.stream().map(this::mapEntityToFinancialInstitutionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getFinancialInstitutionById(long institutionId) {

        FinancialInstitution admin = financialInstitutionRepository.findById(institutionId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Financial Institution",110), HttpStatus.NOT_FOUND);
        }
        FinancialInstitutionResponse response = this.mapEntityToFinancialInstitutionResponse(admin);

        return   ResponseEntity.ok(response);

    }
    public FinancialInstitutionResponse mapEntityToFinancialInstitutionResponse(FinancialInstitution institution){
        FinancialInstitutionResponse response = new FinancialInstitutionResponse();
        response.setName(institution.getName());
        response.setInstitutionNumber(institution.getInstitutionNumber());
        response.setActive(institution.isActive());
        response.setDisplayName(institution.getDisplayName());
        response.setId(institution.getId());
        response.setMobileMoney(institution.isMobileMoney());
        response.setUrl(institution.getUrl());
        return  response;
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantUser(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantCashier(String loggedInUserId){
        MerchantCashier backendAdmin = cashierRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
}
