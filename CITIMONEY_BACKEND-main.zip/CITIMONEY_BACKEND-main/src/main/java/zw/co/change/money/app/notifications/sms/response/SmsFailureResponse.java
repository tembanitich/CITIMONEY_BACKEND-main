package zw.co.change.money.app.notifications.sms.response;

import lombok.Data;

@Data
public class SmsFailureResponse {
    private Long id;
    private String message;
    private String receiverPhoneNumber;
    private String reason;
    private String date;
    private String methodInExecution;
    private String senderId;
}

