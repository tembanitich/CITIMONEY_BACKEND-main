package zw.co.change.money.app.reports.response;

import lombok.Data;
import zw.co.change.money.app.reports.model.ReportTemplateName;

@Data
public class ReportColumnConfigurationResponse {
    private String name;
    private long id;
    private ReportTemplateName reportName;
    private String fieldName;
    private String fieldType;
}
