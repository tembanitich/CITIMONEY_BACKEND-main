package zw.co.change.money.app.merchants.service;

import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.accounts.model.MerchantAccountStatus;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.accounts.service.AccountsService;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.currencies.model.MerchantIncentive;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.currencies.repository.MerchantIncentiveRepository;
import zw.co.change.money.app.documents.model.MerchantProofOfResidenceDocument;
import zw.co.change.money.app.documents.model.MerchantTaxClearanceDocument;
import zw.co.change.money.app.documents.service.DocumentService;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.request.AddMerchantBranchRequest;
import zw.co.change.money.app.merchants.request.AddMerchantRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantBranchRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantRequest;
import zw.co.change.money.app.merchants.response.MerchantBranchResponse;
import zw.co.change.money.app.merchants.response.MerchantResponse;
import zw.co.change.money.app.notifications.mail.executor.MailExecutor;
import zw.co.change.money.app.notifications.mail.request.Mail;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.validation.ValidateMerchantProperties;
import zw.co.change.money.app.variables.model.AppVariable;
import zw.co.change.money.app.variables.model.EmailConfig;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.EmailConfigRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;
import zw.co.change.money.app.variables.service.AppVariableService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@Service
public class MerchantService {
    @Autowired
    private EmailConfigRepository emailConfigRepository;
    @Autowired
    private SmsConfigRepository smsConfigRepository;
    @Autowired
    private MailExecutor mailExecutor;
    @Autowired
    private UserCustomerRepository customerRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private AppVariableService appVariableService;
    @Autowired
    private AppVariableRepository appVariableRepository;
    @Autowired
    private UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    private UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private MerchantBranchRepository merchantBranchRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private AccountManagerRepository accountManagerRepository;
    @Autowired
    private MerchantIncentiveRepository merchantIncentiveRepository;
    @Autowired
    private AccountsService accountsService;
    @Autowired
    private UserService userService;
    @Autowired
    private DocumentService documentService;
    @Autowired
    private ValidateMerchantProperties validateMerchantProperties;
    @Autowired
    private StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private DateUtil dateUtil;
    public ResponseEntity addMerchant(AddMerchantRequest request, MultipartFile proofOfResidence, MultipartFile taxClearance, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateMerchantProperties.validateAddMerchantRequest(request,proofOfResidence,taxClearance);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        AccountManager accountManager = accountManagerRepository.findDistinctByFirstName("Default").stream().findFirst().orElse(null);
        if(accountManager==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Account Manager",102), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant = new Merchant();
        merchant.setActive(true);
        merchant.setName(request.getName());
        merchant.setCompanyRegNumber(request.getCompanyRegNumber());
        merchant.setId(stringGeneratorUtility.generateMerchantId());
        merchant.setCode(stringGeneratorUtility.generateMerchantCode());
        merchant.setProjectedCashiers(request.getProjectedCashiers());
        merchant.setOfficeAddress(request.getOfficeAddress());
        merchant.setNumberOfBranches(request.getNumberOfBranches());
        merchant.setWithdrawalEmail(request.getWithdrawalEmail());
        merchant.setWithdrawalPhoneNumber(request.getWithdrawalPhoneNumber());
        merchant.setContactPersonSurname(request.getContactPersonSurname());
        merchant.setContactPersonName(request.getContactPersonName());
        merchant.setContactPersonDesignation(request.getContactPersonDesignation());
        merchant.setContactPersonNumber(request.getContactPersonNumber());
        merchant.setContactPersonEmail(request.getContactPersonEmail());
        merchant.setProjectedAdmins(request.getProjectedAdmins());
        merchant.setMinFloatLimit(request.getMinFloatLimit());
        merchant.setProjectedDailyFloatBalance(request.getProjectedDailyFloatBalance());
        merchant.setProjectedNumberOfProducts(request.getProjectedNumberOfProducts());
        merchant.setTradingAs(request.getTradingAs());
        Merchant savedMerchant =merchantRepository.save(merchant);
        //create Documents
        MerchantProofOfResidenceDocument proofOfResidenceDocument= documentService.storeMerchantProofOfResidenceDocument(proofOfResidence,savedMerchant);
        MerchantTaxClearanceDocument taxClearanceDocument= documentService.storeMerchantTaxClearanceDocument(proofOfResidence,savedMerchant);
        savedMerchant.setProofOfResidence(proofOfResidenceDocument);
        savedMerchant.setTaxclearence(taxClearanceDocument);
        // create Merchant Account
        MerchantAccount account = new MerchantAccount();
        account.setAccountBalance(0);
        account.setStatus(MerchantAccountStatus.ACTIVE);
        account.setMerchant(savedMerchant);
        account.setAccountManager(accountManager);
        account.setAccountAlias(savedMerchant.getName());
        MerchantAccount savedAccount =accountRepository.save(account);
        savedMerchant.setMerchantAccount(savedAccount);
        merchantRepository.save(savedMerchant);

        // Create Merchant Incentives
        List<Currency> currencies = currencyRepository.findByActive(true);
        for(Currency currency : currencies){
            MerchantIncentive    incentive= new MerchantIncentive();
            incentive.setMerchant(savedMerchant);
            incentive.setCurrency(currency);
            incentive.setAmount(0);
            merchantIncentiveRepository.save(incentive);
        }


        return ResponseEntity.ok(new GenericApiResponse("Merchant Created Successfully"));
    }
    public ResponseEntity selfRegisterMerchant(AddMerchantRequest request, MultipartFile proofOfResidence, MultipartFile taxClearance){

        ResponseEntity theResponse = validateMerchantProperties.validateAddMerchantRequest(request,proofOfResidence,taxClearance);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        AccountManager accountManager = accountManagerRepository.findDistinctByFirstName("Default").stream().findFirst().orElse(null);
        if(accountManager==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Account Manager",102), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant = new Merchant();
        merchant.setActive(false);
        merchant.setName(request.getName());
        merchant.setId(stringGeneratorUtility.generateMerchantId());
        merchant.setProjectedCashiers(request.getProjectedCashiers());
        merchant.setOfficeAddress(request.getOfficeAddress());
        merchant.setNumberOfBranches(request.getNumberOfBranches());
        merchant.setContactPersonSurname(request.getContactPersonSurname());
        merchant.setContactPersonName(request.getContactPersonName());
        merchant.setContactPersonDesignation(request.getContactPersonDesignation());
        merchant.setContactPersonNumber(request.getContactPersonNumber());
        merchant.setContactPersonEmail(request.getContactPersonEmail());
        merchant.setProjectedAdmins(request.getProjectedAdmins());
        merchant.setMinFloatLimit(request.getMinFloatLimit());
        merchant.setProjectedDailyFloatBalance(request.getProjectedDailyFloatBalance());
        merchant.setProjectedNumberOfProducts(request.getProjectedNumberOfProducts());
        merchant.setTradingAs(request.getTradingAs());
        Merchant savedMerchant =merchantRepository.save(merchant);
        //create Documents
        MerchantProofOfResidenceDocument proofOfResidenceDocument= documentService.storeMerchantProofOfResidenceDocument(proofOfResidence,savedMerchant);
        MerchantTaxClearanceDocument taxClearanceDocument= documentService.storeMerchantTaxClearanceDocument(proofOfResidence,savedMerchant);
        savedMerchant.setProofOfResidence(proofOfResidenceDocument);
        savedMerchant.setTaxclearence(taxClearanceDocument);
        // create Merchant Account
        MerchantAccount account = new MerchantAccount();
        account.setAccountBalance(0);
        account.setStatus(MerchantAccountStatus.ACTIVE);
        account.setMerchant(savedMerchant);
        account.setAccountManager(accountManager);
        account.setAccountAlias(savedMerchant.getName());
        MerchantAccount savedAccount =accountRepository.save(account);
        savedMerchant.setMerchantAccount(savedAccount);
        merchantRepository.save(savedMerchant);

        //send Email to Merchants email
        AppVariable appVariable= appVariableRepository.findByCode("MERCHANTS_APPLICATIONS_EMAIL").orElse(null);
        if(appVariable!=null){
            this.sendMerchantRegistrationEmail(appVariable.getValue(),savedMerchant);
        }

        //send Email TO merchant
        this.sendMerchantRegistrationEmailClient(savedMerchant.getContactPersonEmail(),savedMerchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Created Successfully"));
    }
    public ResponseEntity updateMerchant(UpdateMerchantRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateMerchantProperties.validateUpdateMerchantRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }

        Merchant merchant = merchantRepository.findById(request.getId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
        }
        merchant.setName(request.getName());
        merchant.setWithdrawalEmail(request.getWithdrawalEmail());
        merchant.setWithdrawalPhoneNumber(request.getWithdrawalPhoneNumber());
        merchant.setCompanyRegNumber(request.getCompanyRegNumber());
        merchant.setProjectedCashiers(request.getProjectedCashiers());
        merchant.setOfficeAddress(request.getOfficeAddress());
        merchant.setNumberOfBranches(request.getNumberOfBranches());
        merchant.setContactPersonSurname(request.getContactPersonSurname());
        merchant.setContactPersonNumber(request.getContactPersonNumber());
        merchant.setContactPersonDesignation(request.getContactPersonDesignation());
        merchant.setContactPersonEmail(request.getContactPersonEmail());
        merchant.setContactPersonName(request.getContactPersonName());
        merchant.setProjectedAdmins(request.getProjectedAdmins());
        merchant.setMinFloatLimit(request.getMinFloatLimit());
        merchant.setProjectedDailyFloatBalance(request.getProjectedDailyFloatBalance());
        merchant.setProjectedNumberOfProducts(request.getProjectedNumberOfProducts());
        merchant.setTradingAs(request.getTradingAs());
        merchantRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Updated Successfully"));
    }
    public ResponseEntity ActivateOrDeactivateMerchant(String merchantId, Boolean status, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("could not load Merchant",110), HttpStatus.NOT_FOUND);
        }

        merchant.setActive(status);
        merchantRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant activation status updated"));
    }
    public ResponseEntity getMerchantsByStatus(boolean status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Merchant> failures =  merchantRepository.findByActive(status,pageable);

        List<MerchantResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToMerchantResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveMerchants() {
        List<Merchant> failures =  merchantRepository.findByActive(true);

        List<MerchantResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToMerchantResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity searchMerchantsByName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateMerchantProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Merchant> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean paymentStatus = Boolean.valueOf(request.getFilterValue());
                failures = merchantRepository.findByNameContainingIgnoreCaseAndActive(request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantRepository.findByNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantResponse> responses = failures.stream().map(this::mapEntityToMerchantResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity getAllMerchants(int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Merchant> failures = merchantRepository.findAll(pageable);

        List<MerchantResponse> productResponses = failures.stream().map(this::mapEntityToMerchantResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllAccountManagerMerchants(String loggedInUserId) {
        if(!isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        // Retrieve events
        List<MerchantAccount> accounts = accountRepository.findByAccountManagerUserId(loggedInUserId);
        List<Merchant> failures = new ArrayList<>();
        for(MerchantAccount account: accounts){
            if(account.getMerchant()!=null){
                failures.add(account.getMerchant());
            }
        }


        List<MerchantResponse> productResponses = failures.stream().map(this::mapEntityToMerchantResponse).collect(toList());

        return   ResponseEntity.ok(productResponses);

    }
    public ResponseEntity getMerchantById(String merchantId) {

        Merchant admin = merchantRepository.findById(merchantId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Product",110), HttpStatus.NOT_FOUND);
        }
        MerchantResponse response = this.mapEntityToMerchantResponse(admin);

        return   ResponseEntity.ok(response);

    }

    public ResponseEntity addMerchantBranch(AddMerchantBranchRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateMerchantProperties.validateAddMerchantBranchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantBranch merchantBranch = new MerchantBranch();
        merchantBranch.setActive(true);
        merchantBranch.setName(request.getName());
        merchantBranch.setMerchant(merchant);
        merchantBranch.setBranchEmail(request.getBranchEmail());
        merchantBranch.setBranchManagerName(request.getBranchManagerName());
        merchantBranch.setContactNumber(request.getContactNumber());
        merchantBranch.setContactNumberCountryCode(request.getContactNumberCountryCode());
        merchantBranchRepository.save(merchantBranch);


        return ResponseEntity.ok(new GenericApiResponse("Merchant Branch Created Successfully"));
    }
    public ResponseEntity updateMerchantBranch(UpdateMerchantBranchRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateMerchantProperties.validateUpdateMerchantBranchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantBranch merchantBranch = merchantBranchRepository.findById(request.getId()).orElse(null);
        if(merchantBranch==null){
            return new ResponseEntity<>(new GenericApiError("Could not load MerchantBranch",110), HttpStatus.NOT_FOUND);
        }
        merchantBranch.setName(request.getName());
        merchantBranch.setMerchant(merchant);
        merchantBranch.setBranchEmail(request.getBranchEmail());
        merchantBranch.setBranchManagerName(request.getBranchManagerName());
        merchantBranch.setContactNumber(request.getContactNumber());
        merchantBranch.setContactNumberCountryCode(request.getContactNumberCountryCode());
        merchantBranchRepository.save(merchantBranch);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Branch Updated Successfully"));
    }
    public ResponseEntity ActivateOrDeactivateMerchantBranch(long merchantId, Boolean status, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = merchantBranchRepository.findById(merchantId).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("could not load MerchantBranch",110), HttpStatus.NOT_FOUND);
        }

        merchant.setActive(status);
        merchantBranchRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("MerchantBranch activation status updated"));
    }
    public ResponseEntity getMerchantBranchesByStatus(boolean status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantBranch> failures =  merchantBranchRepository.findByActive(status,pageable);

        List<MerchantBranchResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantBranchesByStatusByMerchantId(String merchantId,boolean status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantBranch> failures =  merchantBranchRepository.findByActiveAndMerchantId(status,merchantId,pageable);

        List<MerchantBranchResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveMerchantBranches() {
        List<MerchantBranch> failures =  merchantBranchRepository.findByActive(true);

        List<MerchantBranchResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity getActiveMerchantBranchesByMerchantId(String merchantId) {
        List<MerchantBranch> failures =  merchantBranchRepository.findByActiveAndMerchantId(true,merchantId);

        List<MerchantBranchResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity searchMerchantBranchesByName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateMerchantProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantBranch> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                boolean paymentStatus = Boolean.valueOf(request.getFilterValue());
                failures = merchantBranchRepository.findByNameContainingIgnoreCaseAndActive(request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantBranchRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantBranchRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantBranchRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantBranchRepository.findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantBranchRepository.findByNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantBranchResponse> responses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity getAllMerchantMerchantBranches(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantBranch> failures = merchantBranchRepository.findByMerchantId(merchant.getId(),pageable);

        List<MerchantBranchResponse> productResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllMerchantBranches(int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantBranch> failures = merchantBranchRepository.findAll(pageable);

        List<MerchantBranchResponse> productResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllMerchantBranchesByMerchantId(String merchantId,int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        Page<MerchantBranch> failures = merchantBranchRepository.findByMerchantId(merchantId,pageable);

        List<MerchantBranchResponse> productResponses = failures.stream().map(this::mapEntityToMerchantBranchResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantBranchById(long merchantId) {

        MerchantBranch admin = merchantBranchRepository.findById(merchantId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Product",110), HttpStatus.NOT_FOUND);
        }
        MerchantBranchResponse response = this.mapEntityToMerchantBranchResponse(admin);

        return   ResponseEntity.ok(response);

    }
    

    public void sendMerchantRegistrationEmail(String emailAddress,Merchant merchant){
        String emailMessage = this.processMerchantRegistrationEmail("MERCHANT_REGISTRATION_SUCCESS_BACKEND",merchant);
        this.processSuccessMerchantRegistrationEmailNotificationBackend(emailAddress,emailMessage,merchant);
    }
    private String processMerchantRegistrationEmail(String emailMessageCode,Merchant merchant){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("merchantName", merchant.getName());

            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome TO Rapid Fuel you can now order";
        }
    }
    private void processSuccessMerchantRegistrationEmailNotificationBackend(String email,String emailMessage,Merchant merchant) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("New Merchant Application");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "New Merchant Application");
        model.put("pin",merchant);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );
            mail.setSubject("Welcome To "+ appName.getValue());
        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("emailText",emailMessage);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"general",1);
    }
    public void sendMerchantRegistrationEmailClient(String emailAddress,Merchant merchant){
        String emailMessage = this.processMerchantRegistrationEmailClient("MERCHANT_REGISTRATION_SUCCESS_CLIENT",merchant);
        this.processSuccessMerchantRegistrationEmailNotificationClient(emailAddress,emailMessage,merchant);
    }
    private String processMerchantRegistrationEmailClient(String emailMessageCode,Merchant merchant){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("merchantName", merchant.getName());

            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome TO Rapid Fuel you can now order";
        }
    }
    private void processSuccessMerchantRegistrationEmailNotificationClient(String email,String emailMessage,Merchant merchant) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("New Merchant Application");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "New Merchant Application");
        model.put("pin",merchant);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );
            mail.setSubject("Welcome To "+ appName.getValue());
        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("emailText",emailMessage);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"general",1);
    }
    public MerchantResponse mapEntityToMerchantResponse(Merchant merchant){
        MerchantResponse response = new MerchantResponse();
        response.setActive(merchant.isActive());
        response.setCompanyRegNumber(merchant.getCompanyRegNumber());
        response.setContactPersonDesignation(merchant.getContactPersonDesignation());
        response.setContactPersonEmail(merchant.getContactPersonEmail());
        response.setContactPersonName(merchant.getContactPersonName());
        response.setId(merchant.getId());
        response.setCode(merchant.getCode());
        response.setContactPersonNumber(merchant.getContactPersonNumber());
        response.setName(merchant.getName());
        response.setWithdrawalEmail(merchant.getWithdrawalEmail());
        response.setWithdrawalPhoneNumber(merchant.getWithdrawalPhoneNumber());
        response.setTradingAs(merchant.getTradingAs());
        response.setMinFloatLimit(merchant.getMinFloatLimit());
        response.setOfficeAddress(merchant.getOfficeAddress());
        response.setProjectedCashiers(merchant.getProjectedCashiers());
        response.setProjectedAdmins(merchant.getProjectedAdmins());
        response.setProjectedDailyFloatBalance(merchant.getProjectedDailyFloatBalance());
        response.setProjectedNumberOfProducts(merchant.getProjectedNumberOfProducts());
        response.setContactPersonSurname(merchant.getContactPersonSurname());
        response.setNumberOfBranches(merchant.getNumberOfBranches());
        if(merchant.getMerchantAccount()!=null){
            response.setAccount(accountsService.mapEntityToAccountResponseWithoutMerchant(merchant.getMerchantAccount()));
        }
        if(merchant.getProofOfResidence()!=null){
            response.setProofOfResidenceDocument(documentService.mapMerchantProofOfResidenceDocumentEntityToResponse(merchant.getProofOfResidence()));
        }
        if(merchant.getTaxclearence()!=null){
            response.setTaxClearanceDocument(documentService.mapMerchantTaxClearanceDocumentEntityToResponse(merchant.getTaxclearence()));
        }
        return response;
    }
    public MerchantBranchResponse mapEntityToMerchantBranchResponse(MerchantBranch merchantBranch){
        MerchantBranchResponse response = new MerchantBranchResponse();
        if(merchantBranch.getMerchant()!=null){
            response.setMerchant(this.mapEntityToMerchantResponse(merchantBranch.getMerchant()));
        }

        response.setBranchEmail(merchantBranch.getBranchEmail());
        response.setBranchManagerName(merchantBranch.getBranchManagerName());
        response.setActive(merchantBranch.isActive());
        response.setContactNumber(merchantBranch.getContactNumber());
        response.setContactNumberCountryCode(merchantBranch.getContactNumberCountryCode());
        response.setId(merchantBranch.getId());
        response.setName(merchantBranch.getName());
        return response;
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantAdmin(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantUser(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantCashier(String loggedInUserId){
        MerchantCashier backendAdmin = cashierRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserAccountManager(String loggedInUserId){
        AccountManager backendAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
}
