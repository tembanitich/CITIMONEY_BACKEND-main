package zw.co.change.money.app.chat.response;

import lombok.Data;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.users.response.UserCustomerResponse;

@Data
public class ChatMessageResponse {
    private Long id;
    private String message;
    private boolean fromCustomer;
    private boolean fromDriver;
    private boolean readStatus;
    private UserSummary sender;
    private String senderName;
    private String receiverName;
    private String senderId;
    private String receiverId;
    private String time;
    private UserSummary receiver;
    private UserCustomerResponse customer;
}
