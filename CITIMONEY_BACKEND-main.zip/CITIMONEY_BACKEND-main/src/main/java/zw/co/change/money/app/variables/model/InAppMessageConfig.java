package zw.co.change.money.app.variables.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.BaseUserDateAudit;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;

@Entity
@Table(name = "cf_in_app_messages", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "code"
        })
})
@Data
@EqualsAndHashCode(callSuper = true)
public class InAppMessageConfig extends BaseUserDateAudit {

    private String code;
    @Size(max = 5000)
    private String content;
    private String[] variables;
    private boolean active;

}