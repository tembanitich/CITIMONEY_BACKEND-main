package zw.co.change.money.app.accounts.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.accounts.model.MerchantAccountStatus;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface AccountRepository extends JpaRepository<MerchantAccount, Long> {

    Optional<MerchantAccount> findFirstByMerchantId(String merchantId);

    List<MerchantAccount> findByStatus(MerchantAccountStatus status);
    Long countByStatus(MerchantAccountStatus status);
    Long countByStatusAndAccountManagerUserId(MerchantAccountStatus status,String userId);
    Long countByAccountManagerUserId(String userId);
    Long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate);
    Page<MerchantAccount> findByStatus(MerchantAccountStatus status, Pageable pageable);
    Page<MerchantAccount> findByStatusAndAccountManagerUserId(MerchantAccountStatus status,String userId, Pageable pageable);
    Page<MerchantAccount> findByMerchantId(String merchantId, Pageable pageable);
    Page<MerchantAccount> findByAccountManagerUserId(String merchantId, Pageable pageable);
    List<MerchantAccount> findByAccountManagerUserId(String merchantId);
    Page<MerchantAccount> findByMerchantNameContainingIgnoreCaseAndStatus(String merchantName,MerchantAccountStatus status, Pageable pageable);
    Page<MerchantAccount> findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndStatus(String userId, String merchantName,MerchantAccountStatus status, Pageable pageable);
    Page<MerchantAccount> findByAccountManagerUserIdAndMerchantNameContainingIgnoreCase(String userId,String merchantName, Pageable pageable);
    Page<MerchantAccount> findByMerchantNameContainingIgnoreCase(String merchantName, Pageable pageable);
    Page<MerchantAccount> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccount> findByMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantName,LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccount> findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId, String merchantName,LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);

}
