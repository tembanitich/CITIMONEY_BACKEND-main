package zw.co.change.money.app.transactions.request;

public enum IssueChangeType {
    WALLET,DIRECT
}
