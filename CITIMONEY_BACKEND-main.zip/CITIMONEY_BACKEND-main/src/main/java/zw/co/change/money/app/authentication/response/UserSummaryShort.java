package zw.co.change.money.app.authentication.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserSummaryShort {
    private String userId;
    private String contactNumber;
    private String firstName;
    private String jobTitle;
    private String username;
    private String surname;
    private String email;
    private String avatar = "default";
}
