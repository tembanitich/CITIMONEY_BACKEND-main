package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.merchants.response.MerchantResponse;
@Data
public class CheckWithdrawalResponse {
    private MerchantResponse merchant;
    private double amount;
    private String approvalCode;
    private String code;
    private String tellerName;
    private double amountInUsd;
}
