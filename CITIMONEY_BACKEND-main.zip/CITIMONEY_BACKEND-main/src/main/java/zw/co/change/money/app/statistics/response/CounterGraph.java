package zw.co.change.money.app.statistics.response;

import lombok.Data;

@Data
public class CounterGraph {
    private String label;
    private double value;
    private double percentageFromLastMonth;
}
