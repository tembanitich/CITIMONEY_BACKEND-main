package zw.co.change.money.app.transactions.model;

public enum TransactionStatus {
    SUCCESS,FAILURE,PENDING,REFUND
}
