package zw.co.change.money.app.accounts.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.transactions.model.Wallet;
import zw.co.change.money.app.users.model.AccountManager;
import zw.co.change.money.app.users.model.User;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.util.Collection;

@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"merchant"})
@Data
public class MerchantAccount extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private MerchantAccountStatus status;
    private String accountAlias;
    private double accountBalance;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Merchant merchant;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "accountManager")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private AccountManager accountManager;
}
