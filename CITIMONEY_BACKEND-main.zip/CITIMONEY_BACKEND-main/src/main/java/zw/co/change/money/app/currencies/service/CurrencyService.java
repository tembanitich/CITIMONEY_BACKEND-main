package zw.co.change.money.app.currencies.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.currencies.model.MerchantIncentive;
import zw.co.change.money.app.currencies.repository.MerchantIncentiveRepository;
import zw.co.change.money.app.currencies.request.UpdateMerchantIncentiveRequest;
import zw.co.change.money.app.currencies.response.ExchangeRateHistoryResponse;
import zw.co.change.money.app.currencies.response.MerchantIncentiveResponse;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.notifications.websocket.service.WebSocketService;
import zw.co.change.money.app.currencies.model.ExchangeRateHistory;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.currencies.repository.ExchangeRateHistoryRepository;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.currencies.request.AddCurrencyRequest;
import zw.co.change.money.app.currencies.request.UpdateCurrencyRequest;
import zw.co.change.money.app.currencies.request.UpdateExchangeRateRequest;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.MerchantAdminRepository;
import zw.co.change.money.app.users.repository.UserBackendAdminRepository;
import zw.co.change.money.app.users.repository.UserBackendAgentRepository;
import zw.co.change.money.app.users.repository.UserRepository;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class CurrencyService {
    @Autowired
    private MerchantIncentiveRepository merchantIncentiveRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    private UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ExchangeRateHistoryRepository exchangeRateHistoryRepository;
    @Autowired
    private StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private DateUtil dateUtil;
    @Autowired
    private WebSocketService webSocketService;
    @Autowired
    private MerchantService merchantService;
    @Autowired
    private AuthenticationService authenticationService;
    public  ResponseEntity addCurrency(AddCurrencyRequest request){
        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Currency Name cannot be Empty",110), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getExchangeRate()==0 ){
            return new ResponseEntity<>(new GenericApiError("Exchange Rate cannot be 0",110), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getExchangeRate()<0 ){
            return new ResponseEntity<>(new GenericApiError("Exchange Rate cannot be Negative",110), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = new Currency();
        currency.setCode(stringGeneratorUtility.generateCurrencyCode());
        currency.setName(request.getName());
        currency.setExchangeRate(request.getExchangeRate());
        currency.setActive(true);
        currencyRepository.save(currency);
        return ResponseEntity.ok(new GenericApiResponse("Currency Created Successfully"));
    }
    public  ResponseEntity updateCurrency(UpdateCurrencyRequest request){
        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Currency Name cannot be Empty",110), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCode()==null || request.getCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Currency Code cannot be Empty",110), HttpStatus.EXPECTATION_FAILED);
        }

        Currency currency = currencyRepository.findByCode(request.getCode()).orElse(null);
        if (currency == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Currency",110), HttpStatus.NOT_FOUND);
        }
        currency.setName(request.getName());
        currencyRepository.save(currency);
        return ResponseEntity.ok(new GenericApiResponse("Currency Updated Successfully"));
    }
    public ResponseEntity ActivateOrDeactivateCurrency(String code, Boolean status, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Currency merchant = currencyRepository.findByCode(code).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("could not load Financial Institution",110), HttpStatus.NOT_FOUND);
        }

        merchant.setActive(status);
        currencyRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Currency activation status updated"));
    }
    public ResponseEntity getActiveCurrencies() {
        List<Currency> failures =  currencyRepository.findByActive(true);

        List<CurrencyResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToCurrencyResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public  ResponseEntity getAllCurrencies(int page, int size,String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Currency> currencies = currencyRepository.findAll(pageable);
        List<CurrencyResponse> productResponses = currencies.stream().map(this::mapEntityToCurrencyResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, currencies.getNumber(),
                currencies.getSize(), currencies.getTotalElements(), currencies.getTotalPages(), currencies.isLast()));
    }
    public ResponseEntity getCurrenciesByStatus(boolean status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Currency> failures =  currencyRepository.findByActive(status,pageable);

        List<CurrencyResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToCurrencyResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCurrencyByCode(String code) {

        Currency admin = currencyRepository.findByCode(code).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Financial Institution",110), HttpStatus.NOT_FOUND);
        }
        CurrencyResponse response = this.mapEntityToCurrencyResponse(admin);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity searchCurrenciesByName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Currency> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)) {
            try {
                Boolean status = Boolean.parseBoolean(request.getFilterValue());
                failures = currencyRepository.findByNameContainingIgnoreCaseAndActive(request.getSearchQuery(),status, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else {
            failures = currencyRepository.findByNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<CurrencyResponse> responses = failures.stream().map(this::mapEntityToCurrencyResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity updateExchangeRate(UpdateExchangeRateRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Currency currency = currencyRepository.findByCode(request.getCode()).orElse(null);
        if (currency == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Currency",110), HttpStatus.NOT_FOUND);
        }
        double balanceBefore =currency.getExchangeRate();
        currency.setExchangeRate(request.getExchangeRate());
        Currency savedCurrency = currencyRepository.save(currency);
        ExchangeRateHistory exchangeRateHistory = new ExchangeRateHistory();
        exchangeRateHistory.setCurrency(savedCurrency);
        exchangeRateHistory.setNewExchangeRate(request.getExchangeRate());
        exchangeRateHistory.setPreviousExchangeRate(balanceBefore);
        exchangeRateHistory.setResponsibleUser(loggedInUserId);
        exchangeRateHistoryRepository.save(exchangeRateHistory);
        this.webSocketService.sendNewExchangeRateToCustomers(this.mapEntityToCurrencyResponse(savedCurrency));
        return ResponseEntity.ok(new GenericApiResponse("Exchange Rate Updated Successfully"));
    }
    public ResponseEntity getCurrentExchangeRates(){
        List<Currency> currencies = currencyRepository.findByActive(true);
        List<CurrencyResponse> responses = currencies.stream().map(this::mapEntityToCurrencyResponse).collect(toList());
        return  ResponseEntity.ok(responses);
    }


    ///Merchant Incentive
    public ResponseEntity updateMerchantIncentive(UpdateMerchantIncentiveRequest request,String loggedInUserId){
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }

        if(request.getMerchantId()==null || request.getMerchantId().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Id cannot be Empty",110), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCurrencyCode()==null || request.getCurrencyCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Currency Code cannot be Empty",110), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()==0 ){
            return new ResponseEntity<>(new GenericApiError("Incentive Rate cannot be 0",110), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0 ){
            return new ResponseEntity<>(new GenericApiError("Incentive Rate cannot be Negative",110), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Merchant",110), HttpStatus.NOT_FOUND);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if (currency == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Currency",110), HttpStatus.NOT_FOUND);
        }

        MerchantIncentive incentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(incentive==null){
            incentive= new MerchantIncentive();
            incentive.setMerchant(merchant);
            incentive.setCurrency(currency);
            incentive.setAmount(request.getAmount());
            merchantIncentiveRepository.save(incentive);
        }else{
            incentive.setAmount(request.getAmount());
            merchantIncentiveRepository.save(incentive);
        }
        return ResponseEntity.ok(new GenericApiResponse("Merchant Incentive Updated Successfully"));
    }
    public  ResponseEntity getAllMerchantIncentives(int page, int size,String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantIncentive> currencies = merchantIncentiveRepository.findAll(pageable);
        List<MerchantIncentiveResponse> productResponses = currencies.stream().map(this::mapEntityToMerchantIncentiveResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, currencies.getNumber(),
                currencies.getSize(), currencies.getTotalElements(), currencies.getTotalPages(), currencies.isLast()));
    }
    public  ResponseEntity getMerchantIncentivesByMerchantId(String merchantId,int page, int size,String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        if(merchantId==null || merchantId.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Id cannot be Empty",110), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Merchant",110), HttpStatus.NOT_FOUND);
        }

        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantIncentive> currencies = merchantIncentiveRepository.findByMerchantId(merchantId,pageable);
        List<MerchantIncentiveResponse> productResponses = currencies.stream().map(this::mapEntityToMerchantIncentiveResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, currencies.getNumber(),
                currencies.getSize(), currencies.getTotalElements(), currencies.getTotalPages(), currencies.isLast()));
    }
    public  ResponseEntity getMyMerchantIncentivesByMerchantId(int page, int size,String loggedInUserId){
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }


        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantIncentive> currencies = merchantIncentiveRepository.findByMerchantId(cashier.getMerchant().getId(),pageable);
        List<MerchantIncentiveResponse> productResponses = currencies.stream().map(this::mapEntityToMerchantIncentiveResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, currencies.getNumber(),
                currencies.getSize(), currencies.getTotalElements(), currencies.getTotalPages(), currencies.isLast()));
    }
    public ResponseEntity searchMerchantIncentivesByCurrency(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantIncentive> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_MERCHANT_ID)) {
            try {
                Merchant merchant = merchantRepository.findById(request.getFilterValue()).orElse(null);
                if (merchant == null) {
                    return new ResponseEntity<>(new GenericApiError("Could Not Find Merchant",110), HttpStatus.NOT_FOUND);
                }
                failures = merchantIncentiveRepository.findByCurrencyNameContainingIgnoreCaseAndMerchantId(request.getSearchQuery(),merchant.getId(), pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else {
            failures = merchantIncentiveRepository.findByCurrencyNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantIncentiveResponse> responses = failures.stream().map(this::mapEntityToMerchantIncentiveResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity searchMyMerchantIncentivesByCurrency(SearchRequest request, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantIncentive> failures;

            failures = merchantIncentiveRepository.findByCurrencyNameContainingIgnoreCaseAndMerchantId(request.getSearchQuery(),cashier.getMerchant().getId(), pageable);

        List<MerchantIncentiveResponse> responses = failures.stream().map(this::mapEntityToMerchantIncentiveResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }


    ///////////////////////////Exchange Rate History///////////////////
    public ResponseEntity getAllExchangeRateHistory(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<ExchangeRateHistory> failures = exchangeRateHistoryRepository.findAll(pageable);

        List<ExchangeRateHistoryResponse> productResponses = failures.stream().map(this::mapEntityToExchangeRateHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetExchangeRateHistoryThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<ExchangeRateHistory> failures = exchangeRateHistoryRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<ExchangeRateHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToExchangeRateHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetExchangeRateHistoryToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<ExchangeRateHistory> failures = exchangeRateHistoryRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<ExchangeRateHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToExchangeRateHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetExchangeRateHistoryThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<ExchangeRateHistory> failures = exchangeRateHistoryRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<ExchangeRateHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToExchangeRateHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetExchangeRateHistoryFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<ExchangeRateHistory> failures = exchangeRateHistoryRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),pageable);

        List<ExchangeRateHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToExchangeRateHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ExchangeRateHistoryResponse mapEntityToExchangeRateHistoryResponse(ExchangeRateHistory history){
        ExchangeRateHistoryResponse paymentRequestResponse = new ExchangeRateHistoryResponse();
        if(history.getResponsibleUser()!=null && !history.getResponsibleUser().isEmpty()){
            User user = userRepository.findById(history.getResponsibleUser()).orElse(null);
            if(user!=null){
                paymentRequestResponse.setResponsibleUser(authenticationService.mapUserEntityToSpecificSummary(user));
            }

        }else if(history.getCreatedBy()!=null &&!history.getCreatedBy().isEmpty()){
            User user = userRepository.findById(history.getCreatedBy()).orElse(null);
            if(user!=null){
                paymentRequestResponse.setResponsibleUser(authenticationService.mapUserEntityToSpecificSummary(user));
            }
        }
        if(history.getCreatedAt()!=null){
            paymentRequestResponse.setDateChanged(history.getCreatedAt().toString());
        }
        if(history.getCurrency()!=null){
            paymentRequestResponse.setDateChanged(history.getCreatedAt().toString());
        }
        paymentRequestResponse.setId(history.getId());
        paymentRequestResponse.setNewExchangeRate(history.getNewExchangeRate());
        paymentRequestResponse.setPreviousExchangeRate(history.getPreviousExchangeRate());


        return  paymentRequestResponse;
    }
    public CurrencyResponse mapEntityToCurrencyResponse(Currency currency){
        CurrencyResponse response = new CurrencyResponse();
        response.setId(currency.getId());

        response.setActive(currency.isActive());
        response.setCode(currency.getCode());
        response.setExchangeRate(currency.getExchangeRate());
        response.setName(currency.getName());
        return response;
    }
    public MerchantIncentiveResponse mapEntityToMerchantIncentiveResponse(MerchantIncentive incentive){
        MerchantIncentiveResponse response = new MerchantIncentiveResponse();
        response.setId(incentive.getId());

        response.setAmount(incentive.getAmount());
        if(incentive.getMerchant()!=null){
            response.setMerchant(merchantService.mapEntityToMerchantResponse(incentive.getMerchant()));
        }
        if(incentive.getCurrency()!=null){
            response.setCurrency(this.mapEntityToCurrencyResponse(incentive.getCurrency()));
        }
        return response;
    }

    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantUser(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
}
