package zw.co.change.money.app.variables.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.BaseUserDateAudit;

import javax.persistence.Entity;

@Entity
@Data
@EqualsAndHashCode(callSuper = true)
public class TermsAndConditions extends BaseUserDateAudit {
    private String description;
    private Boolean enabled = true;
}
