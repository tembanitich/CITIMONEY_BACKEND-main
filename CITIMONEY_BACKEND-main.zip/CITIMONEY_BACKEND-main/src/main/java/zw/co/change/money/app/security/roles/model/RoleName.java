package zw.co.change.money.app.security.roles.model;

public enum RoleName {
    ROLE_SYSTEM,
    ROLE_BACK_OFFICE_ADMIN,
    ROLE_BACK_OFFICE_AGENT,
    ROLE_BA,
    ROLE_CUSTOMER,ROLE_GUEST,

    ROLE_MERCHANT_ADMIN,
    ROLE_ACCOUNT_MANAGER,
    ROLE_TELLER,
    ROLE_BRANCH_MANAGER,
    ROLE_CASHIER,
    NOT_AUTHORIZED
}
