package zw.co.change.money.app.legacy.request;

import lombok.Data;

@Data
public class FileUploadRequestDto {
    private String usersType ;
    private long branchId;
    private String merchantId;
    private String fileData;
}
