package zw.co.change.money.app.statistics.response;

import lombok.Data;

import java.util.List;
@Data
public class PieChartCategory {
    private  String label;
    private List<PieChartItem> items;
}
