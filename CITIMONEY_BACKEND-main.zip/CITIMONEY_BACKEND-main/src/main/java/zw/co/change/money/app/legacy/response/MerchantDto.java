package zw.co.change.money.app.legacy.response;

import lombok.Data;

import java.util.List;
@Data
public class MerchantDto extends BaseDto {
    private String merchantName;
    private String merchantId;
    private String companyRegNumber;
    private String officeAddress;
    private String contactPersonName;
    private String contactPersonSurname;
    private String contactPersonNumber;
    private String contactPersonEmail;
    private String contactPersonDesignation;
    private double minfloatLimit;
    private double maxfloatLimit;
    private int numberOfBranches;
    private int projectedCashiers;
    private boolean status;
    private String userId;
    private List<AccountDto> accounts;
    private List<CurrencyDto> currencies;
}
