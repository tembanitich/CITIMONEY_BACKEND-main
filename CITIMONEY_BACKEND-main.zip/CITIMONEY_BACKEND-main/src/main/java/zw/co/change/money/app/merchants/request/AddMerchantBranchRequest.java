package zw.co.change.money.app.merchants.request;

import lombok.Data;

@Data
public class AddMerchantBranchRequest {
    private String name;
    private String branchManagerName;
    private String branchEmail;
    private String contactNumber;
    private String contactNumberCountryCode;
    private String merchantId;
}
