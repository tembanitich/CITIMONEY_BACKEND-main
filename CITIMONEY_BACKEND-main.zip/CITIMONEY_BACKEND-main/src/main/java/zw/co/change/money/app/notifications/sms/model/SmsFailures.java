package zw.co.change.money.app.notifications.sms.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.util.List;

@Entity
@EqualsAndHashCode(callSuper = true)
@Data
public class SmsFailures extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String content;
    private String receiverPhoneNumber;
    private String reference;
    private boolean isMultiple;
    @ElementCollection
    private List<String> phoneNumbers;
    @Column(length = 10000)
    private String reason;
    private String methodInExecution;
}
