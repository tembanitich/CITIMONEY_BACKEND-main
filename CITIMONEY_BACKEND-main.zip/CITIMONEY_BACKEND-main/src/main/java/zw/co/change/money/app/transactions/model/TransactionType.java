package zw.co.change.money.app.transactions.model;

public enum TransactionType {
    CASH_OUT,CASH_IN,PAYMENT,TRANSFER,CHECK_BALANCE,CHANGE,WITHDRAWAL
}
