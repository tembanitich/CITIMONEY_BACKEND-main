package zw.co.change.money.app.ussd.response;

import lombok.Data;
import zw.co.change.money.app.security.roles.model.RoleName;
@Data
public class CheckUserResponse {
    private CheckUserStatus status;
    private RoleName role;
}
