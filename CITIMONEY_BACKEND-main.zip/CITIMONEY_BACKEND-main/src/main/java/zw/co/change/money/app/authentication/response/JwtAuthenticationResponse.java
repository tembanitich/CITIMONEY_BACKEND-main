package zw.co.change.money.app.authentication.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class JwtAuthenticationResponse {
    private String message = "success";
    private String accessToken;

    //=== base user
    private String userId;
    private Collection<? extends GrantedAuthority> userRole;
    private Collection<? extends GrantedAuthority> userPrivileges;
    private String firstName;
    private Boolean enabled;
    private Boolean available=true;
    private Boolean resetPin;
    private String surname;
    private String mobileNumber;
    private String mobileNumberCountryCode;
    private String email;
    private String userGroup;
}