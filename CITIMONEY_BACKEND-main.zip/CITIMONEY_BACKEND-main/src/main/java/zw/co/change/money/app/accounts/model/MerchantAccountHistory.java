package zw.co.change.money.app.accounts.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.transactions.model.Wallet;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.time.LocalDateTime;
@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"account"})
@Data
@Table(name = "merchant_account_histories")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantAccountHistory extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantAccount account;
    private double balanceBefore;
    private double amount;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receiver")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserCustomer receiver;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserCustomer sender;
    @Enumerated(EnumType.STRING)
    private MerchantAccountHistoryType historyType;
    private double balanceAfter;
    private LocalDateTime dateOfEntry;
}
