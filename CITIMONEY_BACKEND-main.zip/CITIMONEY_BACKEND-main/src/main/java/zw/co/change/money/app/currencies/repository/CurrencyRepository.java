package zw.co.change.money.app.currencies.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.currencies.model.Currency;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CurrencyRepository  extends JpaRepository<Currency, Long> {
    Optional<Currency> findByCode(String currency);

    List<Currency> findByActive(boolean status);
    List<Currency> findByName(String name);
    Long countByActive(boolean status);
    Boolean existsByNameIgnoreCase(String name);
    Boolean existsByCode(String code);
    Long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate);
    Page<Currency> findByActive(boolean status, Pageable pageable);
    Page<Currency> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<Currency> findByNameContainingIgnoreCase(String query, Pageable pageable);
    Page<Currency> findByNameContainingIgnoreCaseAndActive(String query,boolean status, Pageable pageable);
    Page<Currency> findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String query, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);

}
