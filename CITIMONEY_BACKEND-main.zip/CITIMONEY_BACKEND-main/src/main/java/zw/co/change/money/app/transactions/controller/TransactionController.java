package zw.co.change.money.app.transactions.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.accounts.request.ChangeMerchantDepositStatusRequest;
import zw.co.change.money.app.currencies.request.UpdateExchangeRateRequest;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.transactions.model.WalletHistoryType;
import zw.co.change.money.app.transactions.model.WalletStatus;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.request.*;
import zw.co.change.money.app.transactions.service.TransactionService;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.util.model.SearchRequest;

import javax.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/api/transactions")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;

    ////////////////////////////////////////////////////////////Global Transactions//////////////////////////////////////
    @GetMapping("/view/byTransactionByReference/{paymentReference}")
    public ResponseEntity getTransactionByReference(@PathVariable String reference) {
        return transactionService.getTransactionByReference(reference);
    }
    @GetMapping("/checkTransactionStatus")
    public ResponseEntity checkTransactionStatus(@PathVariable String reference) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkTransactionStatus(reference,currentUser.getUserId());
    }

    ////////////////////////////////////////////////////////////Backend Transactions//////////////////////////////////////

    @PostMapping("/issueChange")
    @Operation(description="Issue Change")
    public ResponseEntity issueChange(@Valid @RequestBody IssueChangeRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.issueChange(request,currentUser.getUserId());
    }
    @PostMapping("/checkIssueChange")
    @Operation(description="Check Issue Change")
    public ResponseEntity checkIssueChange(@Valid @RequestBody IssueChangeRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkIssueChange(request,currentUser.getUserId());
    }
    @PostMapping("/transfer")
    @Operation(description="Customer Transfer Credit")
    public ResponseEntity TransferCredit(@Valid @RequestBody CustomerTransferRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.TransferCredit(request,currentUser.getUserId());
    }
    @PostMapping("/payment")
    @Operation(description="Customer Make Payment")
    public ResponseEntity makePayment(@Valid @RequestBody CustomerPaymentRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.makePayment(request,currentUser.getUserId());
    }
    @PostMapping("/cashOut")
    @Operation(description="Customer Make Withdrawal")
    public ResponseEntity cashOut(@Valid @RequestBody CashOutRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.cashOut(request,currentUser.getUserId());
    }
    @PostMapping("/checkCashIn")
    @Operation(description="Cashier Make Deposit")
    public ResponseEntity checkCashIn(@Valid @RequestBody CashInRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkCashIn(request,currentUser.getUserId());
    }
    @PostMapping("/cashIn")
    @Operation(description="Cashier Make Deposit")
    public ResponseEntity cashIn(@Valid @RequestBody CashInRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.cashIn(request,currentUser.getUserId());
    }
    @PostMapping("/backend/search/byCustomerName")
    @Operation(description="Search Transactions")
    public ResponseEntity searchTransactionsByCustomerName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchTransactionsByCustomerName(request,currentUser.getUserId());
    }

    @PostMapping("/checkPaymentRequest")
    @Operation(description="Check Payment Request")
    public ResponseEntity checkPaymentRequest(@Valid @RequestBody CheckPaymentRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkPaymentRequest(request,currentUser.getUserId());
    }
    @PostMapping("/checkCashoutRequest")
    @Operation(description="Check Cashout Request")
    public ResponseEntity checkCashoutRequest(@Valid @RequestBody CheckCashoutRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkCashoutRequest(request,currentUser.getUserId());
    }
    @PostMapping("/checkTransferRequest")
    @Operation(description="Check Transfer Request")
    public ResponseEntity checkTransferRequest(@Valid @RequestBody CheckTransferRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkTransferRequest(request,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all")
    public ResponseEntity getAllTransactions( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getAllTransactions(page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/byStatus/{status}")
    public ResponseEntity getTransactionsByTransactionStatus(@PathVariable TransactionStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getTransactionsByTransactionStatus(status,page,size,currentUser.getUserId());
    }
 
    @GetMapping("/backend/view/byTransactionType/{paymentMethodType}")
    public ResponseEntity getTransactionsByTransactionType(@PathVariable TransactionType paymentMethodType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getTransactionsByTransactionType(paymentMethodType,page,size,currentUser.getUserId());
    }


    @GetMapping("/customer/view/me/payments")
    public ResponseEntity getPaymentTransactionsByCustomerId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                         @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getPaymentTransactionsByCustomerId(page,size,currentUser.getUserId());
    }
    @GetMapping("/customer/view/me/cashouts")
    public ResponseEntity getCashoutTransactionsByCustomerId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCashoutTransactionsByCustomerId(page,size,currentUser.getUserId());
    }
    @GetMapping("/customer/view/me/cashins")
    public ResponseEntity getCashinTransactionsByCustomerId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCashinTransactionsByCustomerId(page,size,currentUser.getUserId());
    }
    @GetMapping("/customer/view/me/transfers")
    public ResponseEntity getTransferTransactionsByCustomerId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getTransferTransactionsByCustomerId(page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/byCustomerId/{customerId}")
    public ResponseEntity getAllTransactionsByCustomerId(@PathVariable String customerId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getAllTransactionsByCustomerId(customerId,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/byCustomerIdAndStatus/{customerId}/{status}")
    public ResponseEntity getTransactionsByCustomerIdAndTransactionStatus(@PathVariable String customerId,@PathVariable TransactionStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getTransactionsByCustomerIdAndTransactionStatus(customerId,status,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/thisWeek")
    public ResponseEntity GetTransactionsThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/today")
    public ResponseEntity GetTransactionsToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/thisMonth")
    public ResponseEntity GetTransactionsThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetTransactionsFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }

    @GetMapping("/backend/view/all/thisWeek/byStatus/{status}")
    public ResponseEntity GetTransactionsThisWeekAndTransactionStatus( @PathVariable TransactionStatus status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsThisWeekAndTransactionStatus(status,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/today/byStatus/{status}")
    public ResponseEntity GetTransactionsTodayAndTransactionStatus( @PathVariable TransactionStatus status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsTodayAndTransactionStatus(status,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/thisMonth/byStatus/{status}")
    public ResponseEntity GetTransactionsThisMonthAndTransactionStatus(@PathVariable TransactionStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsThisMonthAndTransactionStatus(status,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/bydateRangeAndStatus/{status}/{startDateTime}/{endDateTime}")
    public ResponseEntity GetTransactionsFromRangeAndTransactionStatus(@PathVariable TransactionStatus status,@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsFromRangeAndTransactionStatus(status,startDateTime,endDateTime,page,size,currentUser.getUserId());
    }




    @GetMapping("/backend/view/all/thisWeek/byTransactionType/{paymentMethodType}")
    public ResponseEntity GetTransactionsThisWeekAndTransactionType( @PathVariable TransactionType paymentMethodType,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsThisWeekAndTransactionType(paymentMethodType,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/today/byTransactionType/{paymentMethodType}")
    public ResponseEntity GetTransactionsTodayAndTransactionType( @PathVariable TransactionType paymentMethodType,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsTodayAndTransactionType(paymentMethodType,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/all/thisMonth/byTransactionType/{paymentMethodType}")
    public ResponseEntity GetTransactionsThisMonthAndTransactionType(@PathVariable TransactionType paymentMethodType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsThisMonthAndTransactionType(paymentMethodType,page,size,currentUser.getUserId());
    }
    @GetMapping("/backend/view/byDateRangeAndTransactionType/{paymentMethodType}/{startDateTime}/{endDateTime}")
    public ResponseEntity GetTransactionsFromRangeAndTransactionType(@PathVariable TransactionType paymentMethodType,@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetTransactionsFromRangeAndTransactionType(paymentMethodType,startDateTime,endDateTime,page,size,currentUser.getUserId());
    }

    ///////////////////////////////////////////////Customer Wallets /////////////////////////////////////////////////////////////

    @GetMapping("/tellerTransactions")
    public ResponseEntity getRecentTellerTransactions() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getRecentTellerTransactions(currentUser.getUserId());
    }
    @GetMapping("/cashierTransactions")
    public ResponseEntity getRecentCashiersTransactions() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getRecentCashiersTransactions(currentUser.getUserId());
    }
    @GetMapping("/customerTransactions")
    public ResponseEntity getRecentCustomerTransactions() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getRecentCustomerTransactions(currentUser.getUserId());
    }
    @GetMapping("/check-teller")
    public ResponseEntity getCheckTeller() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCheckTeller(currentUser.getUserId());
    }
    @GetMapping("/check-cashier")
    public ResponseEntity getCheckCashier() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCheckCashier(currentUser.getUserId());
    }
    @GetMapping("/check-customer")
    public ResponseEntity getCheckCustomer() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCheckCustomer(currentUser.getUserId());
    }
    @GetMapping("/wallets/view/byCustomerId/{customerId}")
    public ResponseEntity getCustomerWalletByCustomerId(@PathVariable String customerId) {
        return transactionService.getCustomerWalletByCustomerId(customerId);
    }
    @GetMapping("/wallets/view/byWalletId/{walletId}")
    public ResponseEntity getCustomerWalletById(@PathVariable long walletId) {
        return transactionService.getCustomerWalletById(walletId);
    }
    @PostMapping("/wallets/search/byName")
    @Operation(description="Search Merchant Accounts")
    public ResponseEntity searchCustomerWalletsByCustomerName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchCustomerWalletsByCustomerName(request,currentUser.getUserId());
    }
    @GetMapping("/wallets/activation/{walletId}/{status}")
    @Operation(description="Change Merchant Account Status")
    public ResponseEntity changeCustomerWalletStatus(@PathVariable long walletId, @PathVariable WalletStatus status){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.changeCustomerWalletStatus(walletId,status,currentUser.getUserId());
    }
    @GetMapping("/wallets/view/active")
    public ResponseEntity getActiveCustomerWallets() {
        return transactionService.getActiveCustomerWallets();
    }
    @GetMapping("/wallets/view/all")
    public ResponseEntity getAllCustomerWallets(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return transactionService.getAllCustomerWallets(page, size);
    }
    @GetMapping("/wallets/view/byStatus/{status}")
    public ResponseEntity getCustomerWalletsByStatus(@PathVariable WalletStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return transactionService.getCustomerWalletsByStatus(status,page, size);
    }
    ///////////////////////////////////////////////////////////////////Accounts //////////////////////////////////////////
    @PostMapping("/wallets/history/search/byName")
    @Operation(description="Search Merchant Accounts History")
    public ResponseEntity searchWalletHistoriesByMerchantName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchWalletHistoriesByMerchantName(request,currentUser.getUserId());
    }
    @PostMapping("/wallets/history/search/byNameAndCustomerId/{customerId}")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchWalletHistoriesByCustomerId(@PathVariable String customerId,@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchWalletHistoriesByCustomerId(customerId,request,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all")
    public ResponseEntity GetAllWalletHistories( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetAllWalletHistories(page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all/thisWeek")
    public ResponseEntity GetWalletHistoriesThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all/today")
    public ResponseEntity GetWalletHistoriesToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all/thisMonth")
    public ResponseEntity GetWalletHistoriesThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetWalletHistoriesFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/byCustomerIdAndTransactionType/{customerId}/{transactionType}")
    public ResponseEntity GetWalletHistoriesByCustomerIdAndStatus(@PathVariable String customerId, @PathVariable WalletHistoryType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesByCustomerIdAndStatus( customerId,transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/byCustomerId/{customerId}")
    public ResponseEntity GetAllWalletHistoriesByCustomerId(@PathVariable String customerId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetAllWalletHistoriesByCustomerId( customerId,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/byAccountId/{walletId}")
    public ResponseEntity GetAllWalletHistoriesByWalletId(@PathVariable long walletId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetAllWalletHistoriesByWalletId( walletId,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all/thisWeekAndCustomerId/{customerId}")
    public ResponseEntity GetWalletHistoriesThisWeekAndCustomerId(@PathVariable String customerId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesThisWeekAndCustomerId( customerId,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all/todayAndCustomerId/{customerId}")
    public ResponseEntity AndCustomerId(@PathVariable String customerId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                        @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesTodayAndCustomerId( customerId,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/all/thisMonthAndCustomerId/{customerId}")
    public ResponseEntity GetWalletHistoriesThisMonthAndCustomerId(@PathVariable String customerId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesThisMonthAndCustomerId( customerId,page,size,currentUser.getUserId());
    }
    @GetMapping("/wallets/history/view/byDateRangeAndCustomerId/{customerId}/{startDateTime}/{endDateTime}")
    public ResponseEntity GetWalletHistoriesFromRangeAndCustomerId(@PathVariable String customerId,@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetWalletHistoriesFromRangeAndCustomerId( customerId,startDateTime,endDateTime,page,size,currentUser.getUserId());
    }

    ////////////////////////////////////////////////////////////////Cashier Transactions /////////////////////////////////////
    @PostMapping("/cashier/search/byCustomerName")
    @Operation(description="Search Cashier Transactions")
    public ResponseEntity searchCashierTransactionsByCustomerName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchCashierTransactionsByCustomerName(request,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/all")
    public ResponseEntity getAllCashierTransactions( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getAllCashierTransactions(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/byStatus/{status}")
    public ResponseEntity getCashierTransactionsByTransactionStatus(@PathVariable TransactionStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCashierTransactionsByTransactionStatus(status,page,size,currentUser.getUserId());
    }

    @GetMapping("/cashier/view/byTransactionType/{transactionType}")
    public ResponseEntity getCashierTransactionsByTransactionType(@PathVariable TransactionType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCashierTransactionsByTransactionType(transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/all/thisWeek")
    public ResponseEntity GetCashierTransactionsThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetCashierTransactionsThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/all/today")
    public ResponseEntity GetCashierTransactionsToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetCashierTransactionsToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/all/thisMonth")
    public ResponseEntity GetCashierTransactionsThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetCashierTransactionsThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetCashierTransactionsFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetCashierTransactionsFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }

    ////////////////////////////////////////////////////////////////Merchant Transactions /////////////////////////////////////
    @PostMapping("/merchant/search/byCustomerName")
    @Operation(description="Search Merchant Transactions")
    public ResponseEntity searchMerchantTransactionsByCustomerName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchMerchantTransactionsByCustomerName(request,currentUser.getUserId());
    }
    @GetMapping("/merchant/view/all")
    public ResponseEntity getAllMerchantTransactions( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getAllMerchantTransactions(page,size,currentUser.getUserId());
    }
    @GetMapping("/merchant/view/byStatus/{status}")
    public ResponseEntity getMerchantTransactionsByTransactionStatus(@PathVariable TransactionStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getMerchantTransactionsByTransactionStatus(status,page,size,currentUser.getUserId());
    }

    @GetMapping("/merchant/view/byTransactionType/{transactionType}")
    public ResponseEntity getMerchantTransactionsByTransactionType(@PathVariable TransactionType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getMerchantTransactionsByTransactionType(transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/merchant/view/all/thisWeek")
    public ResponseEntity GetMerchantTransactionsThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantTransactionsThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/merchant/view/all/today")
    public ResponseEntity GetMerchantTransactionsToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                       @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantTransactionsToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/merchant/view/all/thisMonth")
    public ResponseEntity GetMerchantTransactionsThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantTransactionsThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/merchant/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantTransactionsFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantTransactionsFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }

    ////////////////////////////////////////////////////////////////Branch Transactions /////////////////////////////////////
    @PostMapping("/branch/search/byCustomerName")
    @Operation(description="Search Branch Transactions")
    public ResponseEntity searchBranchTransactionsByCustomerName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchBranchTransactionsByCustomerName(request,currentUser.getUserId());
    }
    @GetMapping("/branch/view/all")
    public ResponseEntity getAllBranchTransactions( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getAllBranchTransactions(page,size,currentUser.getUserId());
    }
    @GetMapping("/branch/view/byStatus/{status}")
    public ResponseEntity getBranchTransactionsByTransactionStatus(@PathVariable TransactionStatus status, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getBranchTransactionsByTransactionStatus(status,page,size,currentUser.getUserId());
    }

    @GetMapping("/branch/view/byTransactionType/{transactionType}")
    public ResponseEntity getBranchTransactionsByTransactionType(@PathVariable TransactionType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getBranchTransactionsByTransactionType(transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/branch/view/all/thisWeek")
    public ResponseEntity GetBranchTransactionsThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetBranchTransactionsThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/branch/view/all/today")
    public ResponseEntity GetBranchTransactionsToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                        @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetBranchTransactionsToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/branch/view/all/thisMonth")
    public ResponseEntity GetBranchTransactionsThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetBranchTransactionsThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/branch/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetBranchTransactionsFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetBranchTransactionsFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }

    ///////////////////////////////////////////////////////////////Cashier Transactions///////////////////////////////
    @GetMapping("/teller/view/me/withdrawals")
    public ResponseEntity getWithdrawalTransactionsByTellerId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getWithdrawalTransactionsByTellerId(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/me/payments")
    public ResponseEntity getPaymentTransactionsByCashierId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getPaymentTransactionsByCashierId(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/me/cashouts")
    public ResponseEntity getCashoutTransactionsByCashierId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCashoutTransactionsByCashierId(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/me/cashins")
    public ResponseEntity getCashinTransactionsByCashierId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getCashinTransactionsByCashierId(page,size,currentUser.getUserId());
    }
    @GetMapping("/cashier/view/me/changeIssued")
    public ResponseEntity getIssuedChangeTransactionsByCashierId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.getIssuedChangeTransactionsByCashierId(page,size,currentUser.getUserId());
    }

    ///////////////////////////////////////////////////////////////////Accounts //////////////////////////////////////////
    @PostMapping("/withdrawalRequests/apply")
    @Operation(description="Approve Withdrawal Request")
    public ResponseEntity sendWithdrawalRequest(@Valid @RequestBody ApplyMerchantWithdrawalRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.sendWithdrawalRequest(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/checkWithdrawal")
    @Operation(description="Check Withdrawal Request")
    public ResponseEntity checkCompleteWithdrawalRequest(@Valid @RequestBody CompleteMerchantWithdrawalRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.checkCompleteWithdrawalRequest(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/complete")
    @Operation(description="Approve Withdrawal Request")
    public ResponseEntity completeWithdrawalRequest(@Valid @RequestBody CompleteMerchantWithdrawalRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.completeWithdrawalRequest(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/approve")
    @Operation(description="Approve Withdrawal Request")
    public ResponseEntity approveWithdrawalRequest(@Valid @RequestBody ApproveMerchantWithdrawalRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.approveWithdrawalRequest(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/decline")
    @Operation(description="Decline Withdrawal Request")
    public ResponseEntity declineWithdrawalRequest(@Valid @RequestBody ApproveMerchantWithdrawalRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.declineWithdrawalRequest(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/search/byName")
    @Operation(description="Search Merchant Accounts History")
    public ResponseEntity searchMerchantWithdrawalRequestsByMerchantName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchMerchantWithdrawalRequestsByMerchantName(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/search/byNameAndMerchantId/me")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchMerchantWithdrawalRequestsByMerchantId(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchMerchantWithdrawalRequestsByMerchantId(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/search/byNameAndMerchantId/accountManager")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchRequestedByMerchantWithdrawalRequestsByMerchantId(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchRequestedByMerchantWithdrawalRequestsByMerchantId(request,currentUser.getUserId());
    }
    @PostMapping("/withdrawalRequests/search/byNameAndMerchantId/{merchantId}")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchMerchantWithdrawalRequestsByMerchantId(@PathVariable String merchantId,@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.searchMerchantWithdrawalRequestsByMerchantId(merchantId,request,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all")
    public ResponseEntity GetAllMerchantWithdrawalRequests( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetAllMerchantWithdrawalRequests(page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisWeek")
    public ResponseEntity GetMerchantWithdrawalRequestsThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/today")
    public ResponseEntity GetMerchantWithdrawalRequestsToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisMonth")
    public ResponseEntity GetMerchantWithdrawalRequestsThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantWithdrawalRequestsFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byMerchantIdAndTransactionType/accountManager/{withdrawalStatus}")
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsByMerchantIdAndStatus(@PathVariable DepositRequestStatus withdrawalStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetRequestedByMerchantWithdrawalRequestsByMerchantIdAndStatus(withdrawalStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byMerchantIdAndTransactionType/me/{withdrawalStatus}")
    public ResponseEntity GetMyMerchantWithdrawalRequestsByMerchantIdAndStatus( @PathVariable DepositRequestStatus withdrawalStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMyMerchantWithdrawalRequestsByMerchantIdAndStatus(withdrawalStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byStatus/{withdrawalStatus}")
    public ResponseEntity GetMerchantWithdrawalRequestsByStatus(@PathVariable DepositRequestStatus withdrawalStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsByStatus(withdrawalStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byMerchantIdAndTransactionType/{merchantId}/{withdrawalStatus}")
    public ResponseEntity GetMerchantWithdrawalRequestsByMerchantIdAndStatus(@PathVariable String merchantId, @PathVariable DepositRequestStatus withdrawalStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsByMerchantIdAndStatus( merchantId,withdrawalStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byMerchantId/accountManager")
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsByMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                       @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetRequestedByMerchantWithdrawalRequestsByMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byMerchantId/me")
    public ResponseEntity GetMyMerchantWithdrawalRequestsByMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMyMerchantWithdrawalRequestsByMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byMerchantId/{merchantId}")
    public ResponseEntity GetAllMerchantWithdrawalRequestsByMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetAllMerchantWithdrawalRequestsByMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byAccountId/{accountId}")
    public ResponseEntity GetAllMerchantWithdrawalRequestsByAccountId(@PathVariable long accountId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetAllMerchantWithdrawalRequestsByAccountId( accountId,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisWeekAndMerchantId/accountManager")
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsThisWeekAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetRequestedByMerchantWithdrawalRequestsThisWeekAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisWeekAndMerchantId/me")
    public ResponseEntity GetMyMerchantWithdrawalRequestsThisWeekAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMyMerchantWithdrawalRequestsThisWeekAndMerchantId( page,size,currentUser.getUserId());
    }

    @GetMapping("/withdrawalRequests/view/all/thisWeekAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantWithdrawalRequestsThisWeekAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsThisWeekAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/todayAndMerchantId/accountManager")
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsTodayAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetRequestedByMerchantWithdrawalRequestsTodayAndMerchantId( page,size,currentUser.getUserId());
    }

    @GetMapping("/withdrawalRequests/view/all/todayAndMerchantId/me")
    public ResponseEntity GetMyMerchantWithdrawalRequestsTodayAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMyMerchantWithdrawalRequestsTodayAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/todayAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantWithdrawalRequestsTodayAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsTodayAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisMonthAndMerchantId/accountManager")
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetRequestedByMerchantWithdrawalRequestsThisMonthAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisMonthAndMerchantId/me")
    public ResponseEntity GetMyMerchantWithdrawalRequestsThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMyMerchantWithdrawalRequestsThisMonthAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/all/thisMonthAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantWithdrawalRequestsThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsThisMonthAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byDateRangeAndMerchantId/accountManager/{startDateTime}/{endDateTime}")
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsFromRangeAndMerchantId(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetRequestedByMerchantWithdrawalRequestsFromRangeAndMerchantId(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byDateRangeAndMerchantId/me/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMyMerchantWithdrawalRequestsFromRangeAndMerchantId(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMyMerchantWithdrawalRequestsFromRangeAndMerchantId(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/withdrawalRequests/view/byDateRangeAndMerchantId/{merchantId}/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantWithdrawalRequestsFromRangeAndMerchantId(@PathVariable String merchantId,@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return transactionService.GetMerchantWithdrawalRequestsFromRangeAndMerchantId( merchantId,startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
}
