package zw.co.change.money.app.reports.response;

import lombok.Data;
import zw.co.change.money.app.reports.model.ReportTemplateName;

import java.time.LocalDateTime;
@Data
public class UserActivityReportData {
    private String username;
    private long loginCount;
    private LocalDateTime lastLogin;
    private String loginChannel;


}
