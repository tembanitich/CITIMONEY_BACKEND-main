package zw.co.change.money.app.security.roles.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.security.roles.model.Permission;

import java.util.List;

public interface PermissionRepository extends JpaRepository<Permission, Long> {

    Permission findByName(String name);
    List<Permission> findByRoles_Id(long id);

    @Override
    void delete(Permission privilege);

}