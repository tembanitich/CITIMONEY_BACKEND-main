package zw.co.change.money.app.documents.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.documents.model.MerchantProofOfResidenceDocument;

import java.util.Optional;

public interface MerchantProofOfResidenceDocumentRepository extends JpaRepository<MerchantProofOfResidenceDocument, Long> {
    Optional<MerchantProofOfResidenceDocument> findByMerchantId(String  merchantId);

}
