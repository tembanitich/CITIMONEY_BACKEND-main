package zw.co.change.money.app.accounts.response;

import lombok.Data;
import zw.co.change.money.app.accounts.model.MerchantAccountStatus;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.merchants.response.MerchantResponse;


@Data
public class MerchantAccountResponse {
    private Long id;
    private MerchantAccountStatus status;
    private String accountAlias;
    private double accountBalance;
    private boolean active;
    private String merchantId;
    private MerchantResponse merchant;
    private UserSummary user;
}
