package zw.co.change.money.app.authentication.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class LoginRequest {
    @NotBlank
    private String mobileNumberOrEmail;
    private String channel ="WEB";

    @NotBlank
    private String password;
}