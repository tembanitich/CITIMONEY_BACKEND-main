package zw.co.change.money.app.statistics.response;

import lombok.Data;

@Data
public class PieChartItem {
    private String label;
    private double percentage;
}
