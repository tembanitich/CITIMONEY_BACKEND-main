package zw.co.change.money.app.variables.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.variables.model.EmailConfig;

import java.util.Optional;

public interface EmailConfigRepository extends JpaRepository<EmailConfig, Long> {
    Optional<EmailConfig> findByCode(String code);
    EmailConfig findFirstByCode(String code);

}