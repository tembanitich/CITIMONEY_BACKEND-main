package zw.co.change.money.app.ussd.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
@Data
public class UssdCustomerSignUpRequest {
    @NotNull
    private String mobileNumber;
}
