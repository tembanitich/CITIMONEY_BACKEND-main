package zw.co.change.money.app.validation;

import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.currencies.model.MerchantIncentive;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.currencies.repository.MerchantIncentiveRepository;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.request.*;
import zw.co.change.money.app.users.model.MerchantCashier;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.users.repository.MerchantCashierRepository;
import zw.co.change.money.app.users.repository.UserCustomerRepository;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;

@Component
public class ValidateTransactionProperties {
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private MerchantIncentiveRepository merchantIncentiveRepository;
    @Autowired
    private FinancialInstitutionRepository financialInstitutionRepository;
    @Autowired
    private UserCustomerRepository userCustomerRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    private FormatUtility formatUtility;
    public ResponseEntity isValidSearchRequest(SearchRequest request){

        if(request.getSize()==0){
            return new ResponseEntity<>(new GenericApiError("Page Size cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchFilter()==null){
            return new ResponseEntity<>(new GenericApiError("Search Filter cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchQuery()==null || request.getSearchQuery().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Search Query cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }


        if(request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Payment Id",105), HttpStatus.EXPECTATION_FAILED);
            }
            try{
                TransactionStatus.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Status",110),HttpStatus.NOT_FOUND);
            }

        }
        if(request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Payment Id",105), HttpStatus.EXPECTATION_FAILED);
            }
            try{
                TransactionType.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method",110),HttpStatus.NOT_FOUND);
            }

        }
        if(request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            } if(request.getFilterValueMax()==null || request.getFilterValueMax().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Max Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid Start Date",108), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid End Date",108), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidIssueChangeRequest(IssueChangeRequest request,String loggedInUserId){
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(cashier.getMerchantBranch()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier Branch",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(cashier.getMerchantBranch().getMerchant()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }

//        if(request.getAcquiringFinancialInstitutionNumber()==null || request.getAcquiringFinancialInstitutionNumber().isEmpty()){
//            return new ResponseEntity<>(new GenericApiError("Financial Institution Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
//        }
        if(request.getCurrencyCode()==null || request.getCurrencyCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Currency Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getReceiptNumber()==null || request.getReceiptNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Notification Msisdn cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getTenderedAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Tendered amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getTenderedAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Tendered amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getChangeRequired()==0){
            return new ResponseEntity<>(new GenericApiError("Change Required cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getChangeRequired()<0){
            return new ResponseEntity<>(new GenericApiError("Change Required cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getIssueChangeType()==null){
            return new ResponseEntity<>(new GenericApiError("Issue Change Type cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(request.getIssueChangeType().equals(IssueChangeType.WALLET)){

            if(request.getAccountPhoneNumber()==null || request.getAccountPhoneNumber().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Account Phone Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidPhoneNumber(request.getAccountPhoneNumber())) {
                return new ResponseEntity<>(new GenericApiError("Invalid Account Phone Number",105), HttpStatus.EXPECTATION_FAILED);
            }
        }else{
            FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(request.getAcquiringFinancialInstitutionNumber()).orElse(null);
            if(financialInstitution==null){
                return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(request.getNotificationMsisdn()==null || request.getNotificationMsisdn().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Notification Msisdn cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(financialInstitution.isMobileMoney()){
                if(!formatUtility.isValidPhoneNumber(request.getDestinationAccount())) {
                    return new ResponseEntity<>(new GenericApiError("Invalid Mobile Money Account",105), HttpStatus.EXPECTATION_FAILED);
                }
            }
            if(!formatUtility.isValidPhoneNumber(request.getNotificationMsisdn())) {
                return new ResponseEntity<>(new GenericApiError("Invalid Notification Msisdn",105), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidCashInRequest(CashInRequest request, String loggedInUserId){
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        if(merchantAccount==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier Merchant Account",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(merchantAccount.getAccountBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Cashin",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(cashier.getMerchantBranch()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier Branch",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(cashier.getMerchantBranch().getMerchant()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getReceiverPhoneNumber()==null || request.getReceiverPhoneNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Receiver PhoneNumber cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidPhoneNumber(request.getReceiverPhoneNumber())) {
            return new ResponseEntity<>(new GenericApiError("Invalid Receiver Msisdn",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }

        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getReceiverPhoneNumber()).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receivers Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidTransferRequest(CustomerTransferRequest request,String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getReceiverNumber()==null || request.getReceiverNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Receiver PhoneNumber cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidPhoneNumber(request.getReceiverNumber())) {
            return new ResponseEntity<>(new GenericApiError("Invalid Receiver Msisdn",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(loggedInUser.getWallet().getBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Transaction",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getReceiverNumber()).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receivers Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidCashOutRequest(CashOutRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCashierCode()==null || request.getCashierCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Cashier Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(loggedInUser.getWallet().getBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Transaction",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidCheckPaymentRequest(CheckPaymentRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCashierCode()==null || request.getCashierCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Cashier Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCurrencyCode()==null || request.getCurrencyCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Cashier Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(loggedInUser.getWallet().getBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Transaction",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!currency.isActive()){
            return new ResponseEntity<>(new GenericApiError("Currency Deactivated",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(cashier.getMerchantBranch().getMerchant().getId(),currency.getCode()).orElse(null);
        if(merchantIncentive==null){
            return new ResponseEntity<>(new GenericApiError("Currency not available for Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidCheckCashoutRequest(CheckCashoutRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCashierCode()==null || request.getCashierCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Cashier Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCurrencyCode()==null || request.getCurrencyCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Cashier Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(loggedInUser.getWallet().getBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Transaction",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!currency.isActive()){
            return new ResponseEntity<>(new GenericApiError("Currency Deactivated",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(cashier.getMerchantBranch().getMerchant().getId(),currency.getCode()).orElse(null);
        if(merchantIncentive==null){
            return new ResponseEntity<>(new GenericApiError("Currency not available for Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidCheckTransferRequest(CheckTransferRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getReceiverNumber()==null || request.getReceiverNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Receiver Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getReference()==null || request.getReference().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Reference cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(loggedInUser.getWallet().getBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Transaction",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer cashier = userCustomerRepository.findByMobileNumber(request.getReceiverNumber()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receiver Account",105), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
    public  ResponseEntity isValidPaymentRequest(CustomerPaymentRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCashierCode()==null || request.getCashierCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Cashier Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
//        FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(request.getAcquiringFinancialInstitutionNumber()).orElse(null);
//        if(financialInstitution==null){
//            return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",105), HttpStatus.EXPECTATION_FAILED);
//        }
        if(request.getAmount()==0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Amount cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(loggedInUser.getWallet().getBalance()<request.getAmount()){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance to perform Transaction",105), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
}
