package zw.co.change.money.app.financialInstitutions.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.financialInstitutions.request.AddFinancialInstitutionRequest;
import zw.co.change.money.app.financialInstitutions.request.UpdateFinancialInstitutionRequest;
import zw.co.change.money.app.financialInstitutions.service.FinancialInstitutionService;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.util.model.SearchRequest;

import javax.validation.Valid;
@RestController
@RequestMapping("/api/financialInstitutions")
public class FinancialInstitutionController {
    @Autowired
    FinancialInstitutionService productService;
    ////////////////////////////////////////////////////////////////////////////////Fuel Dealers////////////////////////////////////////////////////////////////////////////////////
    @PostMapping(value="/add")
    @Operation(description="add FinancialInstitution")
    public ResponseEntity addFinancialInstitution(@Valid @RequestBody AddFinancialInstitutionRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.addFinancialInstitution(request,currentUser.getUserId());
    }

    @PostMapping("/update")
    @Operation(description="update FinancialInstitution")
    public ResponseEntity updateFinancialInstitution(@Valid @RequestBody UpdateFinancialInstitutionRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateFinancialInstitution(request,currentUser.getUserId());
    }
    @PostMapping("/search/byName")
    @Operation(description="Search FinancialInstitution")
    public ResponseEntity searchFinancialInstitutionsByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchFinancialInstitutionsByName(request,currentUser.getUserId());
    }
    @GetMapping("/activation/{institutionNumber}/{status}")
    @Operation(description="Activate/Deactivate FinancialInstitution")
    public ResponseEntity ActivateOrDeactivateFinancialInstitution(@PathVariable String institutionNumber, @PathVariable Boolean status){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.ActivateOrDeactivateFinancialInstitution(institutionNumber,status,currentUser.getUserId());
    }
    @GetMapping("/view/active")
    public ResponseEntity getActiveFinancialInstitutions() {
        return productService.getActiveFinancialInstitutions();
    }
    @GetMapping("/view/all")
    public ResponseEntity getAllFinancialInstitutions(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getAllFinancialInstitutions(page, size);
    }
    @GetMapping("/view/byStatus/{status}")
    public ResponseEntity getFinancialInstitutionsByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getFinancialInstitutionsByStatus(status,page, size);
    }
    @GetMapping("/view/byFinancialInstitutionId/{institutionId}")
    public ResponseEntity getFinancialInstitutionById(@PathVariable long institutionId) {
        return productService.getFinancialInstitutionById(institutionId);
    }
}
