package zw.co.change.money.app.accounts.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import zw.co.change.money.app.accounts.model.MerchantAccountHistoryType;
import zw.co.change.money.app.users.response.UserCustomerResponse;

import java.time.LocalDateTime;
@Data
public class MerchantAccountHistoryResponse {
    private Long id;
    private MerchantAccountResponse account;
    private double balanceBefore;
    private double balanceAfter;
    private double amount;
    private UserCustomerResponse receiver;
    private UserCustomerResponse sender;
    private MerchantAccountHistoryType transactionType;
    private String dateOfEntry;
}
