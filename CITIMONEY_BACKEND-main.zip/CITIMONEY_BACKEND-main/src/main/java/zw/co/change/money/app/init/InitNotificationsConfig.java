package zw.co.change.money.app.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import zw.co.change.money.app.variables.model.EmailConfig;
import zw.co.change.money.app.variables.model.InAppMessageConfig;
import zw.co.change.money.app.variables.model.SmsConfig;
import zw.co.change.money.app.variables.repository.EmailConfigRepository;
import zw.co.change.money.app.variables.repository.InAppMessageConfigRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;

import javax.annotation.PostConstruct;


@Component("initNotificationConfig")
public class InitNotificationsConfig {
    @Autowired
    EmailConfigRepository emailConfigRepository;

    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    InAppMessageConfigRepository inAppMessageConfigRepository;

    private void saveEmailConfig(String code, String content, String[] variables) {
        EmailConfig myTextConfig = new EmailConfig();
        myTextConfig.setCode(code);
        myTextConfig.setContent(content);
        myTextConfig.setVariables(variables);
        myTextConfig.setActive(true);
        emailConfigRepository.save(myTextConfig);
    }
    private void saveInAppConfig(String code, String content, String[] variables) {
        InAppMessageConfig myTextConfig = new InAppMessageConfig();
        myTextConfig.setCode(code);
        myTextConfig.setContent(content);
        myTextConfig.setVariables(variables);
        myTextConfig.setActive(true);
        inAppMessageConfigRepository.save(myTextConfig);
    }
    private void saveSMSConfig(String code, String content, String[] variables) {
        SmsConfig myTextConfig = new SmsConfig();
        myTextConfig.setCode(code);
        myTextConfig.setContent(content);
        myTextConfig.setVariables(variables);
        myTextConfig.setActive(true);
        smsConfigRepository.save(myTextConfig);
    }

    @PostConstruct
    private void InitializeSmsConfig() {

        ////////////////////////////////////////////////////////save  emails config////////////////////////
        if (emailConfigRepository.findAll().isEmpty()) {
            this.saveEmailConfig("REFUNDED_ORDER", "Your CitiMoney Order with reference: %(orderNumber) was Refunded. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveEmailConfig("MERCHANT_REGISTRATION_SUCCESS_BACKEND", "A New Merchant with name : %(merchantName) Has submitted its information for registration. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"merchantName","supportPhoneNumber"});
            this.saveEmailConfig("MERCHANT_REGISTRATION_SUCCESS_CLIENT", "Dear %(merchantName) we have received your submission for Registration.We are processing your application and we will get back to you as soon as Possible. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"merchantName","supportPhoneNumber"});

            this.saveEmailConfig("SUCCESSFUL_PAYMENT", "You have Successfully paid For CitiMoney Order with reference: %(code) of $ %(amount) and Payment reference %(paymentReference). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","paymentReference","code","supportPhoneNumber"});
            this.saveEmailConfig("FAILED_PAYMENT", "Payment Failed For CitiMoney Order with reference: %(code) of $ %(amount) Litres  reason: %(reason). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","reason","code","supportPhoneNumber"});
            this.saveEmailConfig("DELIVERY_FAILED_NO_WATER_SOURCE", "Couldn't find Fuel Source for Your CitiMoney Order with reference: %(code) of %(litres) Litres .For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveEmailConfig("INVOICE", "You have successfully Placed an order On CitiMoney Please find attached your invoice. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
           this.saveEmailConfig("REGISTRATION", "Your CitiMoney Account Has Been Created Successfully. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
            this.saveEmailConfig("REGISTRATION_WITH_OTP",  "Your CitiMoney Account Has Been Created Successfully.Your Account Verification Code is: %(pin) .For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
            this.saveEmailConfig("CUSTOMER_SUCCESS_REGISTRATION", "Welcome %(name) to CitiMoney your Account Has Been Created Successful you can now order your Fuel.For help call %(supportPhoneNumber)", new String[]{"name","supportPhoneNumber"});
            this.saveEmailConfig("SUCCESS_DELIVERY", "Your CitiMoney Order with reference: %(orderNumber) Was delivered successfully. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveEmailConfig("ORDER_READY_FOR_PAYMENT", "Your CitiMoney Order with reference: %(code) of %(litres) Litres  Is Ready For Payment. Please Use The App To Pay for Delivery to Start. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveEmailConfig("DELIVERY_STARTED", "Driver %(driverName) has just collected Your Order with reference: %(code) of %(litres) Litres  and is now on its way to your Delivery Address. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
           this.saveEmailConfig("NEW_ORDER_AFTER_CANCEL", "New Driver %(driverName) has been assigned to Your New  Order with reference: %(code) of %(litres) Litres  and is on his way To The water Source.Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
           this.saveEmailConfig("NEW_ORDER_AFTER_WATER_SOURCE_DECLINE", "New Driver %(driverName) has been assigned to Your New  Order with reference: %(code) of %(litres) Litres  and is on his way To The  new water Source. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
           this.saveEmailConfig("REFUNDED_PAYMENT", "Successfully Refunded your payment with Reference: %(code) of ZWL %(amount) for order with reference:%(orderCode). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","orderCode","code","supportPhoneNumber"});
           this.saveEmailConfig("REFUND_OR_NEW_ORDER", "There was a problem with your  Order with reference: %(code) of %(litres) Litres  would you want a refund or place a new Order.Login to proceed. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveEmailConfig("DELIVERY_CANCELLED_BEFORE_WATER_SOURCE", "Driver %(driverName) has Cancelled Delivery for Your Order with reference: %(code) of %(litres) Litres  We are now Assigning a new Driver be on Stand By. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
           this.saveEmailConfig("DELIVERY_CANCELLED_AFTER_WATER_SOURCE", "Driver %(driverName) failed to Reach Your Delivery with Your Order with reference: %(code) of %(litres) Litres  We are now Assigning a new Driver to collect Fuel From The Fuel Source. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
           this.saveEmailConfig("DELIVERY_DECLINED", "Fuel Source %(waterSourceName) has just Declined Your Order with reference: %(code) of %(litres) Litres  Please choose a different Fuel Source. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","waterSourceName","code","supportPhoneNumber"});
           this.saveEmailConfig("SUCCESS_DELIVERY_DRIVER", "You successfully delivered CitiMoney Order with reference: %(code) of %(litres) Litres. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveEmailConfig("SUCCESS_COLLECTION_WATER_SOURCE", "You successfully Completed A collection for CitiMoney Order with reference: %(code) of %(litres) Litres. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveEmailConfig("SUCCESS_COLLECTION_DRIVER", "You successfully Collected CitiMoney Order with reference: %(code) of %(litres) Litres. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveEmailConfig("RESET_PIN", "Your CitiMoney password has been reset. Use the following Pin: %(pin) to login and  change your password.For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
           this.saveEmailConfig("RESET_PIN_USSD", "You used CitiMoney USSD Platform to reset your password. Use the following Pin: %(pin) to login and  change your password.For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
            this.saveEmailConfig("SUCCESS_RESET_PIN", "You have successfully changed your password. Thank you For Using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
       }
        ////////////////////////////////////////////////////////save  SMs config////////////////////////
        if (smsConfigRepository.findAll().isEmpty()) {

            this.saveSMSConfig("CUSTOMER_SUCCESS_REGISTRATION", "Welcome %(name) to CitiMoney your Account Has Been Created Successfully you can now login to use the app.For help call %(supportPhoneNumber)", new String[]{"name","supportPhoneNumber"});
            this.saveSMSConfig("REGISTRATION_WITH_PIN", "Welcome to CitiMoney your Account Has Been Created Successfully you can now login with this password %(pin).For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
            this.saveSMSConfig("CASHIER_REGISTRATION_WITH_PIN", "Welcome to CitiMoney your Account Has Been Created Successfully Your Cashier Code is %(cashierCode) and your pin is  %(pin).For help call %(supportPhoneNumber)", new String[]{"pin","cashierCode","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESS_WITHDRAWAL_APPROVAL", "Withdrawal has been approved. approval Code is %(approvalCode) and your merchant code is %(merchantCode).For help call %(supportPhoneNumber)", new String[]{"approvalCode","merchantCode","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESS_WITHDRAWAL_COMPLETE", "Withdrawal has been completed your merchant code is %(merchantCode) Txn ID %(code).For help call %(supportPhoneNumber)", new String[]{"merchantCode","supportPhoneNumber"});

            this.saveSMSConfig("SUCCESSFUL_PAYMENT", "You have Successfully paid For CitiMoney Order with reference: %(code) of $ %(amount). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","code","supportPhoneNumber"});
            this.saveSMSConfig("ISSUE_CHANGE_SUCCESS", "You have Successfully received $ %(amount) %(currency) change From Cashier with Code %(cashierCode) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","cashierCode","supportPhoneNumber"});
            this.saveSMSConfig("ISSUE_CHANGE_SUCCESS_CASHIER", "You have Successfully issued $ %(amount) %(currency) change to %(receiverPhoneNumber) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","receiverPhoneNumber","supportPhoneNumber"});
            this.saveSMSConfig("TRANSFER_CREDIT_SUCCESS_SENDER", "You have Successfully sent $ %(amount) %(currency) credit to %(receiverPhoneNumber) Txn ID %(code) Your new balance is $ %(balance). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","receiverPhoneNumber","balance","supportPhoneNumber"});
            this.saveSMSConfig("PAYMENT_SUCCESS_CUSTOMER", "You have Successfully paid $ %(amount) %(currency) to Cashier %(cashierCode) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","cashierCode","supportPhoneNumber"});
            this.saveSMSConfig("CASH_OUT_SUCCESS_CUSTOMER", "You have Successfully cashed Out $ %(amount) %(currency) from Cashier %(cashierCode) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","cashierCode","supportPhoneNumber"});
            this.saveSMSConfig("CASH_IN_SUCCESS_CUSTOMER", "You have Successfully deposited $ %(amount) %(currency) to Cashier %(cashierCode) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","cashierCode","supportPhoneNumber"});
            this.saveSMSConfig("CASH_IN_SUCCESS_CASHIER", "You have Successfully received a deposit of $ %(amount) %(currency) from Customer %(receiverPhoneNumber) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","receiverPhoneNumber","supportPhoneNumber"});
            this.saveSMSConfig("CASH_OUT_SUCCESS_CASHIER", "You have Successfully  cashed out $ %(amount) %(currency) Customer %(receiverPhoneNumber) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","receiverPhoneNumber","supportPhoneNumber"});
            this.saveSMSConfig("PAYMENT_SUCCESS_CASHIER", "You have Successfully received payment of $ %(amount) %(currency) from customer %(senderPhoneNumber) Txn ID %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","senderPhoneNumber","supportPhoneNumber"});
            this.saveSMSConfig("TRANSFER_CREDIT_SUCCESS_RECEIVER", "You have Successfully received $ %(amount) %(currency) credit from %(senderPhoneNumber) Txn ID %(code) Your new balance is $ %(balance). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","currency","senderPhoneNumber","balance","supportPhoneNumber"});

            this.saveSMSConfig("FAILED_PAYMENT", "Payment Failed For CitiMoney Order with reference: %(code) of $ %(amount) with reason: %(reason). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","reason","code","supportPhoneNumber"});
            this.saveSMSConfig("DELIVERY_FAILED_NO_WATER_SOURCE", "Couldn't find Fuel Source for Your CitiMoney Order with reference: %(code) of %(litres) Litres .For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
            this.saveSMSConfig("REGISTRATION", "Your CitiMoney Account Has Been Created Successfully. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
            this.saveSMSConfig("REGISTRATION_OTP_CODE", "Your OTP Code is: %(pin) %(appSignature). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber","appSignature"});
            this.saveSMSConfig("OTP_CODE", "<#> Your Account Verification Code is: %(pin) %(appSignature).For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber","appSignature"});
            this.saveSMSConfig("SUCCESS_DELIVERY", "Your CitiMoney Order with reference: %(orderNumber) Was delivered successfully. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESS_COLLECTION", "Your CitiMoney Order with reference: %(orderNumber) Was collected successfully. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESS_DELIVERY_TO_DISPATCH", "Driver %(driverName)has completed CitiMoney Order with reference: %(orderNumber) successfully.For help call %(supportPhoneNumber)", new String[]{"driverName","orderNumber","supportPhoneNumber"});
            this.saveSMSConfig("ORDER_READY_FOR_PAYMENT", "Your CitiMoney Order with reference: %(code) of %(litres) Litres  Is Ready For Payment. Please Use The App To Pay for Delivery to Start. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
            this.saveSMSConfig("REFUNDED_ORDER", "Your CitiMoney Order with reference: %(orderNumber) was Refunded. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveSMSConfig("DELIVERY_STARTED", "Driver %(driverName) is on their way with your Order with reference: %(orderNumber) to your Delivery Address. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"driverName","orderNumber","supportPhoneNumber"});
            this.saveSMSConfig("NEW_ORDER_AFTER_CANCEL", "New Driver %(driverName) has been assigned to Your New  Order with reference: %(code) of %(litres) Litres  and is on his way To The water Source.Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
            this.saveSMSConfig("NEW_ORDER_AFTER_WATER_SOURCE_DECLINE", "New Driver %(driverName) has been assigned to Your New  Order with reference: %(code) of %(litres) Litres  and is on his way To The  new water Source. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","driverName","code","supportPhoneNumber"});
            this.saveSMSConfig("REFUNDED_PAYMENT", "Successfully Refunded your payment with Reference: %(code) of ZWL %(amount) for order with reference:%(orderCode). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","orderCode","code","supportPhoneNumber"});
            this.saveSMSConfig("REFUND_OR_NEW_ORDER", "There was a problem with your  Order with reference: %(code) of %(litres) Litres  would you want a refund or place a new Order.Login to proceed. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveSMSConfig("DELIVERY_DECLINED", "Fuel Source %(waterSourceName) has just Declined Your Order with reference: %(code) of %(litres) Litres  Please choose a different Fuel Source. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","waterSourceName","code","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESS_DELIVERY_DRIVER", "You successfully delivered CitiMoney Order with reference: %(code) of %(litres) Litres. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveSMSConfig("RESET_PIN", "<#> Your Account Verification Code is: %(pin) %(appSignature).For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber","appSignature"});
           this.saveSMSConfig("RESET_PIN_USSD", "You Have used The CitiMoney USSD Platform to reset your password. Your Account Verification Code is: %(pin)For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESS_RESET_PIN", "You have successfully changed your password. Thank you For Using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
            this.saveSMSConfig("SUCCESSFUL_ORDER_PLACEMENT", "You have Successfully Placed Order For CitiMoney with reference: %(code). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"code","supportPhoneNumber"});
            this.saveSMSConfig("SUCCESSFUL_ORDER_ASSIGNED", "You have a new Order Assigned to you  with reference: %(code).Login to start Delivery.For help call %(supportPhoneNumber)", new String[]{"code","supportPhoneNumber"});



        }
        ////////////////////////////////////////////////////////save  In App Messages config////////////////////////
        if (inAppMessageConfigRepository.findAll().isEmpty()) {
            this.saveInAppConfig("SUCCESS_DELIVERY", "Your CitiMoney Order with reference: %(orderNumber) Was delivered successfully. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveInAppConfig("SUCCESSFUL_PAYMENT", "You have Successfully paid For CitiMoney Order with reference: %(code) of $ %(amount) and Payment reference %(paymentReference). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","paymentReference","code","supportPhoneNumber"});
            this.saveInAppConfig("SUCCESSFUL_ORDER_PLACEMENT", "You have Successfully Placed Order For CitiMoney with reference: %(code) of $ %(amount) Have Your cash ready when delivery arrives. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","code","supportPhoneNumber"});
            this.saveInAppConfig("FAILED_PAYMENT", "Payment Failed For CitiMoney Order with reference: %(code) of $ %(amount) Litres  reason: %(reason). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","reason","code","supportPhoneNumber"});
            this.saveInAppConfig("DELIVERY_FAILED_NO_WATER_SOURCE", "Couldn't find Fuel Source for Your CitiMoney Order with reference: %(code) of %(litres) Litres .For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
            this.saveInAppConfig("REGISTRATION", "Your CitiMoney Account Has Been Created Successfully. Thank you for using Rapid Fue.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
            this.saveInAppConfig("REGISTRATION_WITH_OTP", "Your CitiMoney Account Has Been Created Successfully.Please login using this pin: %(pin) .For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
            this.saveInAppConfig("ASSIGNED_ORDER_TO_DRIVER", "CitiMoney Order with number: %(orderNumber) is ready for Delivery.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveInAppConfig("NEW_ORDER_READY_FOR_DISPATCH", "CitiMoney Order with number: %(orderNumber) is ready for Dispatch.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveInAppConfig("DECLINED_ORDER_BY_DRIVER", "CitiMoney Order with number: %(orderNumber) was Declined by %(driverName).For help call %(supportPhoneNumber)", new String[]{"orderNumber","driverName","supportPhoneNumber"});
            this.saveInAppConfig("ORDER_READY_FOR_PAYMENT", "Your CitiMoney Order with reference: %(code) of %(litres) Litres  Is Ready For Payment. Please Use The App To Pay for Delivery to Start. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
            this.saveInAppConfig("REFUNDED_ORDER", "Your CitiMoney Order with reference: %(orderNumber) was Refunded. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"orderNumber","supportPhoneNumber"});
            this.saveInAppConfig("DELIVERY_STARTED", "Driver %(driverName) is on their way with your Order with reference: %(orderNumber) to your Delivery Address. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"driverName","orderNumber","supportPhoneNumber"});
           this.saveInAppConfig("REFUNDED_PAYMENT", "Successfully Refunded your payment with Reference: %(code) of ZWL %(amount) for order with reference:%(orderCode). Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"amount","orderCode","code","supportPhoneNumber"});
            this.saveInAppConfig("REFUND_OR_NEW_ORDER", "There was a problem with your  Order with reference: %(code) of %(litres) Litres  would you want a refund or place a new Order.Login to proceed. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
          this.saveInAppConfig("DELIVERY_DECLINED", "Fuel Source %(waterSourceName) has just Declined Your Order with reference: %(code) of %(litres) Litres  Please choose a different Fuel Source. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","waterSourceName","code","supportPhoneNumber"});
            this.saveInAppConfig("SUCCESS_DELIVERY_DRIVER", "You successfully delivered CitiMoney Order with reference: %(code) of %(litres) Litres. Thank you for using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"litres","code","supportPhoneNumber"});
           this.saveInAppConfig("RESET_PIN", "Your CitiMoney password has been reset. Use the following Pin: %(pin) to login and  change your password.For help call %(supportPhoneNumber)", new String[]{"pin","supportPhoneNumber"});
            this.saveInAppConfig("SUCCESS_RESET_PIN", "You have successfully changed your password. Thank you For Using CitiMoney.For help call %(supportPhoneNumber)", new String[]{"supportPhoneNumber"});
        }
    }
}
