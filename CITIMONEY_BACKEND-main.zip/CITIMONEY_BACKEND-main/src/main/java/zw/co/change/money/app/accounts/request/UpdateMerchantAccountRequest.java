package zw.co.change.money.app.accounts.request;

import lombok.Data;
import zw.co.change.money.app.accounts.model.MerchantAccountStatus;
@Data
public class UpdateMerchantAccountRequest {
    private long id;
    private MerchantAccountStatus status;
    private String accountAlias;
    private double accountBalance;
}
