package zw.co.change.money.app.util.response;

import lombok.Data;

@Data
public class GenericApiError {
    private String status;
    private String error;
    private int code;

    public GenericApiError(String error,int code) {
        super();
        this.status = "failed";
        this.error = error;
        this.code = code;
    }
}
