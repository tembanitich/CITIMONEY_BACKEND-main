package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.users.model.UserBrandAmbassador;
import zw.co.change.money.app.users.response.CustomerGrossRevenueInterface;
import zw.co.change.money.app.users.response.CustomerTransactionTotalInterface;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface UserBrandAmbassadorRepository extends JpaRepository<UserBrandAmbassador, String> {
    List<UserBrandAmbassador> findByEnabled(boolean status);
    Page<UserBrandAmbassador> findByEnabled(boolean status, Pageable pageable);
    List<UserBrandAmbassador> findByFirstNameIgnoreCaseContainingOrSurnameIgnoreCaseContaining(String firstName,String surname);

    Boolean existsByMobileNumber(String mobileNumber);
    Optional<UserBrandAmbassador> findByMobileNumber(String mobileNumber);
    Optional<UserBrandAmbassador> findByEmail(String email);
    Long countByEnabled(boolean status);


    Page<UserBrandAmbassador> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    Page<UserBrandAmbassador> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<UserBrandAmbassador> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status,String  surname, boolean status2,Pageable pageable);

}
