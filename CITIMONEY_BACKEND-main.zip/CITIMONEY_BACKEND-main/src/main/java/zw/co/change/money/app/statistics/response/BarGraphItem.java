package zw.co.change.money.app.statistics.response;

import lombok.Data;

@Data
public class BarGraphItem {
    private String label;
    private double value;
}
