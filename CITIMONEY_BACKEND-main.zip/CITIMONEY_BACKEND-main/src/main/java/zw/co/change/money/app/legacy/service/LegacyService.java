package zw.co.change.money.app.legacy.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.repository.AccountMerchantAssignmentHistoryRepository;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.notifications.sms.executors.SmsExecutor;
import zw.co.change.money.app.security.roles.repository.PermissionRepository;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;

@Service
public class LegacyService {
    public static final String ENTITY_ID = "ENTITY_ID";
    public static final String USE_CASE = "USE_CASE";
    public static final String QUERY = "QUERY";
    public static final String SYS_KEY = "SYS_KEY";
    public static final String RESPONSECODE = "RESPONSECODE";
    public static final String MSISDN = "msisdn";
    public static final String BALANCE = "balance";
    public static final String PIN = "pin";
    public static final String AMOUNT = "amount";


    public static final String ROUTE = "route";
    public static final String CONTINUE_FLOW = "continueFlow";
    public static final String OPTIONS = "options";
    public static final String MSG_HEADER = "msgHeader";
    public static final String FOOTERS = "footers";
    public static final String RECEIPT = "receipt";
    public static final String CURRENCIES = "currencies";
    public static final String SELECTED_CURRENCY = "selectedCurrencies";
    public static final String TENDERED_AMOUNT = "tenderedAmount";
    public static final String DESTINATION_MSISDN = "destinationMsisdn";
    public static final String CHANGE_ISSUED = "changeIssued";
    public static final String MERCHANT_ID = "merchantId";
    public static final String CURRENCY = "currency";
    public static final String OLD_PIN = "oldPin";
    public static final String NEW_PIN = "newPin";
    public static final String CONFIRM_NEW_PIN = "confirmPin";
    public static final String BRANCH_ID = "branchId";
    public static final String USER_ID = "userId";
    public static final String ROLE = "role";
    public static final String REFERENCE = "reference";
    public static final String CURRENCY_ID = "currencyId";
    public static final String FROM = "from";
    public static final String SMSURL = "smsUrl";
    public static final String USER_ROLE = "userRole";
    public static final String START_DATE = "startDate";
    public static final String END_DATE = "endDate";
    public static final String REPORT_TYPE = "REPORT_TYPE";
    public static final String TOTAL = "total";
    public static final String BANKS = "banks";
    public static final String SELECTED_BANK = "selectedBank";
    public static final String INSTITUTION_NUMBER = "INSTITUTION_NUMBER";
    public static final String NOTIFICATION_MSISDN = "NOTIFICATION_MSISDN";
    @Autowired
    private AccountMerchantAssignmentHistoryRepository accountMerchantAssignmentHistoryRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private PermissionRepository permissionRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private MerchantCashierRepository merchantCashierRepository;
    @Autowired
    private AccountManagerRepository accountManagerRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private FinancialInstitutionRepository financialInstitutionRepository;
    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private MerchantBranchRepository merchantBranchRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    SmsExecutor smsExecutor;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    UserService userService;
@Autowired
private AuthenticationService authenticationService;

//    public  ResponseEntity getRoles(){
//        List<Role> roles = roleRepository.findAll();
//        return ResponseEntity.ok(this.mapRoleListToResponse(roles));
//    }
//    public  ResponseEntity getAccountManagers(){
//        List<AccountManager> accountManagers = accountManagerRepository.findAll();
//        return ResponseEntity.ok(this.authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(accountManagers)));
//    }
//    public  ResponseEntity getBranchManagers(){
//        List<BranchManager> merchantUsers = branchManagerRepository.findAll();
//        return ResponseEntity.ok(this.authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchantUsers)));
//    }
//    public  ResponseEntity getBranchManagersByMerchantBranchId(long merchantBranchId){
//
//        List<BranchManager> merchantUsers = branchManagerRepository.findByMerchantBranchId(merchantBranchId);
//        return ResponseEntity.ok(this.authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchantUsers)));
//    }
//    public  ResponseEntity getMerchantAdmins(){
//        List<MerchantAdmin> merchantUsers = merchantAdminRepository.findAll();
//        return ResponseEntity.ok(this.authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchantUsers)));
//    }
//    public  ResponseEntity getMerchantCashier(){
//        List<MerchantCashier> merchantUsers = merchantCashierRepository.findAll();
//        return ResponseEntity.ok(this.authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchantUsers)));
//    }
//    public  ResponseEntity getMerchantCashierByMerchantId(String merchantId){
//        List<MerchantCashier> merchantUsers = merchantCashierRepository.findByMerchantBranchMerchantId(merchantId);
//        return ResponseEntity.ok(this.authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchantUsers)));
//    }
//    public ResponseEntity saveMerchantUser  (Map<String, String> additionalData){
//        additionalData = DtoUtil.getAdditionalData(additionalData);
//        if (additionalData.containsKey(MERCHANT_ID)) {
//            String merchantId = additionalData.get(MERCHANT_ID);
//            List<Currency> merchantCurrencies = currencyRepository.findByActiveAndMerchantId(true,merchantId);
//            return ResponseEntity.ok(this.mapCurrencyListToResponse(merchantCurrencies));
//        }else{
//            List<Currency> merchantCurrencies = currencyRepository.findByActive(true);
//            return ResponseEntity.ok(this.mapCurrencyListToResponse(merchantCurrencies));
//        }
//    }
//    public ResponseEntity getCurrencies   (String currencyCode){
//        List<Currency> currencies = new ArrayList<>();
//     List<Currency> currency= currencyRepository.findByCode(currencyCode);
//     if(currency==null){
//         return ResponseEntity.ok(this.mapCurrencyListToResponse(currencies));
//     }else{
//         return ResponseEntity.ok(this.mapCurrencyListToResponse(currency));
//     }
//    }
//    public ResponseEntity  assignMerchant  (AccountManagerAssignRequest request){
//
//        String merchantId = request.getMerchantId();
//        String userId = request.getUserId();
//        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
//        MerchantAdmin merchantUser = merchantAdminRepository.findById(userId).orElse(null);
//        if(merchant!=null && merchantUser!=null){
//            AccountMerchantAssignmentHistory assignmentHistory = new AccountMerchantAssignmentHistory();
//            assignmentHistory.setMerchant(merchant);
//            assignmentHistory.setUserId(userId);
//            accountMerchantAssignmentHistoryRepository.save(assignmentHistory);
//            merchant.setUserId(userId);
//            merchantRepository.save(merchant);
//            List<MerchantAdmin> merchantUsers = new ArrayList<>();
//            merchantUsers.add(merchantUser);
//            return ResponseEntity.ok(this.mapMerchantUserListToResponse(merchantUsers));
//        }else{
//            List<MerchantAdmin> merchantUsers = new ArrayList<>();
//            return ResponseEntity.ok(this.mapMerchantUserListToResponse(merchantUsers));
//        }
//
//    }
//    public ResponseEntity  getMerchantById (String id){
//        AccountManager accountManager = accountManagerRepository.findById(id).orElse(null);
//        if(accountManager==null){
//            return new ResponseEntity<>(new GenericApiError("Could Not Load MerchantAccount Manager",110), HttpStatus.NOT_FOUND);
//        }
//        List<Merchant> merchants = merchantRepository.findByAccountManagerUserId(id);
//
//        return ResponseEntity.ok(this.mapMerchantListToResponse(merchants));
//    }
//    public ResponseEntity   checkMerchantUser (String msisdn){
//        List<MerchantCashier> merchantUsers = new ArrayList<>();
//        MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(msisdn).orElse(null);
//        if (merchantUser != null) {
//            merchantUsers.add(merchantUser);
//        }
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//    }
//    public ResponseEntity authenticate (CashierAuthenticateRequest cashierAuthenticateRequest){
//
//        return authenticationService.LoginLegacy(cashierAuthenticateRequest.getMsisdn(),cashierAuthenticateRequest.getPin());
//    }
//    public ResponseEntity  changePin  (ChangePinRequest changePinRequest){
//        List<MerchantCashier> merchantUsers = new ArrayList<>();
//        User theUser = userRepository.findByUsernameOrEmail(changePinRequest.getMsisdn(), changePinRequest.getMsisdn()).orElse(null);
//        if(theUser==null){
//
//        }
//        if (!changePinRequest.getNewPin().equalsIgnoreCase(changePinRequest.getConfirmPin())) {
////            throw new ServiceException("New Pin and Confirmed Pin do not match");
//        }
//        if (passwordEncoder.matches(changePinRequest.getNewPin(), theUser.getPassword())) {
////            return new ResponseEntity<>(new GenericApiError("New Password Cannot be the same as Old Password",111), HttpStatus.EXPECTATION_FAILED);
//        }
//        if (passwordEncoder.matches(changePinRequest.getOldPin(), theUser.getPassword())) {
////            theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//            theUser.setPassword(passwordEncoder.encode(changePinRequest.getNewPin()));
//            userRepository.save(theUser);
//            Authentication authentication = authenticationManager.authenticate(
//                    new UsernamePasswordAuthenticationToken(theUser.getUsername(), changePinRequest.getNewPin()));
//            SecurityContextHolder.getContext().setAuthentication(authentication);
//
//
//            MerchantCashier customer = merchantCashierRepository.findByMobileNumber(theUser.getEmail().toLowerCase()).orElse(null);
//            if(!(customer==null )){
//
//                String smsMessage = this.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
//                this.sendSuccessfullyChangePassword(customer.getMobileNumber(),smsMessage);
//                merchantUsers.add(customer);
//                return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//
//            }
//
//        } else {
////            return new ResponseEntity<>(new GenericApiError("Incorrect Old Password",112), HttpStatus.EXPECTATION_FAILED);
//        }
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//    }
//    public ResponseEntity   saveOrUpdateMerchantCashier  (MerchantUserDto request){
//
//        MerchantBranch merchantBranch = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
//        List<MerchantCashier> merchantUsers = new ArrayList<>();
//        MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(request.getMsisdn()).orElse(null);
//
//        if (merchantUser != null) {
//            merchantUser.setEmail(request.getMsisdn());
//            merchantUser.setMobileNumber(request.getMsisdn());
//            merchantUser.setMobileNumber(request.getMsisdn());
//            merchantUser.setFirstName(request.getName());
//            merchantUser.setMerchantBranch(merchantBranch);
//            merchantUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//            merchantUser.setUsername(request.getMsisdn());
//            MerchantCashier savedAdmin =merchantCashierRepository.save(merchantUser);
//            merchantUsers.add(savedAdmin);
//            return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
////            throw new ServiceException(ResponseCodes.CANNOT_SAVE_EXISTING_MSISDN, merchantUser.getMsisdn() +", mobile number cannot be saved as new cause its in use");
//        }else{
//            Role role = roleRepository.findByName(RoleName.ROLE_MERCHANT_USER).orElse(null);
//            String pin = RandomStringUtils.random(4,false,true);
//            merchantUser = new MerchantCashier();
//            merchantUser.setEmail(request.getMsisdn());
//            merchantUser.setMobileNumber(request.getMsisdn());
//            merchantUser.setFirstName(request.getName());
//            merchantUser.setMerchantBranch(merchantBranch);
//            merchantUser.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_MERCHANT_USER));
//            merchantUser.setResetPin(true);
//            merchantUser.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
//            merchantUser.setPassword(passwordEncoder.encode(pin));
//            merchantUser.setRoles(Collections.singletonList(role));
//            merchantUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//            merchantUser.setUsername(request.getMsisdn());
//            MerchantCashier savedAdmin =merchantCashierRepository.save(merchantUser);
//            //////////////////////assign Permissions////////////////////////
//            assignPermissionsByRoleToUser(RoleName.ROLE_MERCHANT_USER,savedAdmin);
//            //send SMS with Pin
//            this.processSuccessfulRegistrationSMSWithPin(savedAdmin.getMobileNumber(),pin);
//            merchantUsers.add(savedAdmin);
//            return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//        }
//
//    }
//    public ResponseEntity  saveMerchantUsersFile  (FileUploadRequestDto userDto){
//
//
//        String fileData = userDto.getFileData();
//        byte[] fileDataArray = java.util.Base64.getDecoder().decode(fileData);
//
//        String decodedString = new String(fileDataArray);
//
//        MerchantBranch merchantBranch = merchantBranchRepository.findById(userDto.getBranchId()).orElse(null);
//        List<MerchantCashier> merchantUsers = new ArrayList<>();
//
//        String[] split = decodedString.split("\n");
//        new Thread(() -> {
//            for (String s : split) {
//                String[] cashierArr = s.split(",");
//
//                String msisdn = cashierArr[0];
//                String name = cashierArr[0];
//                MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(msisdn).orElse(null);
//                if (merchantUser != null) {
//                    merchantUser.setEmail(msisdn);
//                    merchantUser.setMobileNumber(msisdn);
//                    merchantUser.setFirstName(name);
//                    merchantUser.setMerchantBranch(merchantBranch);
//                    merchantUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//                    merchantUser.setUsername(msisdn);
//                    MerchantCashier savedAdmin =merchantCashierRepository.save(merchantUser);
//                    merchantUsers.add(savedAdmin);
//
////            throw new ServiceException(ResponseCodes.CANNOT_SAVE_EXISTING_MSISDN, merchantUser.getMsisdn() +", mobile number cannot be saved as new cause its in use");
//                }else{
//                    Role role = roleRepository.findByName(RoleName.ROLE_MERCHANT_USER).orElse(null);
//                    String pin = RandomStringUtils.random(4,false,true);
//                    merchantUser = new MerchantCashier();
//                    merchantUser.setEmail(msisdn);
//                    merchantUser.setMobileNumber(msisdn);
//                    merchantUser.setFirstName(name);
//                    merchantUser.setMerchantBranch(merchantBranch);
//                    merchantUser.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_MERCHANT_USER));
//                    merchantUser.setResetPin(true);
//                    merchantUser.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
//                    merchantUser.setPassword(passwordEncoder.encode(pin));
//                    merchantUser.setRoles(Collections.singletonList(role));
//                    merchantUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//                    merchantUser.setUsername(msisdn);
//                    MerchantCashier savedAdmin =merchantCashierRepository.save(merchantUser);
//                    //////////////////////assign Permissions////////////////////////
//                    assignPermissionsByRoleToUser(RoleName.ROLE_MERCHANT_USER,savedAdmin);
//                    //send SMS with Pin
//                    this.processSuccessfulRegistrationSMSWithPin(savedAdmin.getMobileNumber(),pin);
//                    merchantUsers.add(savedAdmin);
//
//                }
//
//            }
//        }).start();
//
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//    }
//    public ResponseEntity  queryCashier  (String query,Map<String, String> additionalData){
//        List<MerchantAdmin> merchantUsers = new ArrayList<>();
//        if (additionalData.containsKey(BRANCH_ID)) {
//            String branchId =additionalData.get(BRANCH_ID) ;
//            merchantUsers = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseAndMerchantIdOrSurnameContainingIgnoreCaseAndMerchantId(query, branchId, query,branchId);
//            if(merchantUsers==null){
//                merchantUsers = new ArrayList<>();
//            }
//        }
//        merchantUsers = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(query, query);
//        if(merchantUsers==null){
//            merchantUsers = new ArrayList<>();
//        }
//        return ResponseEntity.ok(this.mapMerchantUserListToResponse(merchantUsers));
//    }
//    public ResponseEntity   resetPin (String msisdn){
//
//        List<MerchantCashier> merchantUsers = new ArrayList<>();
//        MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(msisdn).orElse(null);
//        if (merchantUser != null) {
//            merchantUsers.add(merchantUser);
//            String pin = RandomStringUtils.random(4,false,true);
//            merchantUser.setPassword(passwordEncoder.encode(pin));
//            merchantCashierRepository.save(merchantUser);
//            this.processSuccessfulResetSMSWithPin(merchantUser.getMobileNumber(),pin);
//        }
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//
//    }
//    public ResponseEntity getActiveFinancialInstitutions   (){
//        List<FinancialInstitution> financialInstitutions = financialInstitutionRepository.findByActive(true);
//        return ResponseEntity.ok(this.mapFinancialInstitutionListToResponse(financialInstitutions));
//    }
//    public ResponseEntity queryMerchantBranch   (String query){
//        List<MerchantBranch> merchantBranches= merchantBranchRepository.findByNameContainingIgnoreCase( query);
//
//        return ResponseEntity.ok(this.mapMerchantBranchListToResponse(merchantBranches));
//    }
//    public ResponseEntity  getMerchantBranchById  (long id){
//        List<MerchantBranch> merchantBranches= new ArrayList<>();
//        MerchantBranch merchantBranch = merchantBranchRepository.findById(id).orElse(null);
//        if(merchantBranch!=null){
//            merchantBranches.add(merchantBranch);
//        }
//        return ResponseEntity.ok(this.mapMerchantBranchListToResponse(merchantBranches));
//    }
//    public ResponseEntity  updateMerchantFloat(String merchantId, double floatLimit){
//        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
//        if(merchant==null){
//            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
//        }
//        if(floatLimit==0|| floatLimit<0){
//            return new ResponseEntity<>(new GenericApiError("Invalid Float Limit",110), HttpStatus.EXPECTATION_FAILED);
//        }
//        merchant.setMaxfloatLimit(floatLimit);
//        merchantRepository.save(merchant);
//        return ResponseEntity.ok(new GenericApiResponse("Maximum Float Limit Updated Successfully"));
//    }
//    public ResponseEntity  saveOrUpdateMerchant  (MerchantDto merchantDto){
//            List<Merchant> merchants = new ArrayList<>();
//        if(merchantDto.getMerchantId()!=null &&!merchantDto.getMerchantId().isEmpty()){
//            Merchant merchant = merchantRepository.findById(merchantDto.getMerchantId()).orElse(null);
//            merchant.setCompanyRegNumber(merchantDto.getCompanyRegNumber());
//            merchant.setContactPersonDesignation(merchantDto.getContactPersonDesignation());
//            merchant.setContactPersonName(merchantDto.getContactPersonName());
//            merchant.setContactPersonEmail(merchantDto.getContactPersonEmail());
//            merchant.setContactPersonNumber(merchantDto.getContactPersonNumber());
//            merchant.setContactPersonSurname(merchantDto.getContactPersonSurname());
//            merchant.setMaxfloatLimit(merchantDto.getMaxfloatLimit());
//            merchant.setMinfloatLimit(merchantDto.getMinfloatLimit());
//            merchant.setNumberOfBranches(merchantDto.getNumberOfBranches());
//            merchant.setOfficeAddress(merchantDto.getOfficeAddress());
//            merchant.setProjectedCashiers(merchantDto.getProjectedCashiers());
//            merchant.setName(merchantDto.getMerchantName());
//            merchant.setUserId(merchantDto.getUserId());
//            Merchant savedMerchant = merchantRepository.save(merchant);
//            merchants.add(savedMerchant);
//        }else{
//            Merchant merchant = new Merchant();
//            merchant.setActive(true);
//            merchant.setId(stringGeneratorUtility.generateMerchantId());
//            merchant.setCompanyRegNumber(merchantDto.getCompanyRegNumber());
//            merchant.setContactPersonDesignation(merchantDto.getContactPersonDesignation());
//            merchant.setContactPersonName(merchantDto.getContactPersonName());
//            merchant.setContactPersonEmail(merchantDto.getContactPersonEmail());
//            merchant.setContactPersonNumber(merchantDto.getContactPersonNumber());
//            merchant.setContactPersonSurname(merchantDto.getContactPersonSurname());
//            merchant.setMaxfloatLimit(merchantDto.getMaxfloatLimit());
//            merchant.setMinfloatLimit(merchantDto.getMinfloatLimit());
//            merchant.setNumberOfBranches(merchantDto.getNumberOfBranches());
//            merchant.setOfficeAddress(merchantDto.getOfficeAddress());
//            merchant.setProjectedCashiers(merchantDto.getProjectedCashiers());
//            merchant.setName(merchantDto.getMerchantName());
//            merchant.setUserId(merchantDto.getUserId());
//            Merchant savedMerchant = merchantRepository.save(merchant);
//            MerchantAccount merchantAccount = new MerchantAccount();
//            merchantAccount.setAccountBalance(0d);
//            merchantAccount.setAccountStatus("ACTIVE");
//            merchantAccount.setAccountAlias(savedMerchant.getName() + " - MerchantAccount");
//            merchantAccount.setMerchant(savedMerchant);
//            MerchantAccount savedMerchantAccount = accountRepository.save(merchantAccount);
//            Set<MerchantAccount> merchantAccounts = new HashSet<>();
//            merchantAccounts.add(savedMerchantAccount);
//            savedMerchant.setMerchantAccounts(merchantAccounts);
//             savedMerchant = merchantRepository.save(savedMerchant);
//            merchants.add(savedMerchant);
//
//            Role role = roleRepository.findByName(RoleName.ROLE_MERCHANT_ADMIN).orElse(null);
//            String pin = RandomStringUtils.random(4,false,true);
//            MerchantAdmin  merchantUser = new MerchantAdmin();
//            merchantUser.setEmail(savedMerchant.getContactPersonEmail());
//            merchantUser.setFirstName(savedMerchant.getName());
//            merchantUser.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_MERCHANT_ADMIN));
//            merchantUser.setResetPin(true);
//            merchantUser.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
//            merchantUser.setPassword(passwordEncoder.encode(pin));
//            merchantUser.setRoles(Collections.singletonList(role));
//            merchantUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//            merchantUser.setUsername(savedMerchant.getContactPersonEmail());
//            MerchantAdmin savedAdmin =merchantAdminRepository.save(merchantUser);
//            //////////////////////assign Permissions////////////////////////
//            assignPermissionsByRoleToUser(RoleName.ROLE_MERCHANT_ADMIN,savedAdmin);
////            //send SMS with Pin
////            this.processSuccessfulRegistrationSMSWithPin(savedAdmin.getMobileNumber(),pin);
//
//        }
//
//        return ResponseEntity.ok(this.mapMerchantListToResponse(merchants));
//    }
//    public ResponseEntity  saveOrUpdateCurrency  (String id,CurrencyDto currencyDto){
//        List<Currency> currencies = new ArrayList<>();
//        Merchant merchant = merchantRepository.findById(id).orElse(null);
//        Currency currency = currencyRepository.findByCodeAndMerchantId(currencyDto.getCurrencyCode(),id).orElse(null);
//        if(currency==null){
//            currency = new Currency();
//            currency.setActive(true);
//            currency.setExchangeRate(currencyDto.getExchangeRate());
//            currency.setName(currencyDto.getCurrencyName());
//            currency.setMerchant(merchant);
//            currency.setCode(currencyDto.getCurrencyCode());
//            Currency savedCurrency = currencyRepository.save(currency);
//            currencies.add(savedCurrency);
//        }else{
//            currency.setExchangeRate(currencyDto.getExchangeRate());
//            currency.setName(currencyDto.getCurrencyName());
//            currency.setMerchant(merchant);
//            currency.setCode(currencyDto.getCurrencyCode());
//            Currency savedCurrency = currencyRepository.save(currency);
//            currencies.add(savedCurrency);
//        }
//        return ResponseEntity.ok(this.mapCurrencyListToResponse(currencies));
//    }
//    public ResponseEntity  getMerchantById  (String id,
//                                             Pageable pageable){
//        List<Merchant> merchants = new ArrayList<>();
//        Merchant merchant = merchantRepository.findById(id).orElse(null);
//        if(merchant!=null){
//            merchants.add(merchant);
//        }
//        return ResponseEntity.ok(this.mapMerchantListToResponse(merchants));
//    }
//    public ResponseEntity  queryMerchant  (String query){
//        List<Merchant> merchants = new ArrayList<>();
//        if(query!=null){
//            merchants = merchantRepository.findByNameContainingIgnoreCase( query);
//        }else{
//            merchants = merchantRepository.findAll( );
//        }
//
//        if(merchants==null){
//            merchants = new ArrayList<>();
//        }
//        return ResponseEntity.ok(this.mapMerchantListToResponse(merchants));
//    }
//    public ResponseEntity  searchAccountManagers(String query){
//        List<AccountManager> merchants = accountManagerRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase( query,query);
//        if(merchants==null){
//            merchants = new ArrayList<>();
//        }
//        return ResponseEntity.ok(authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchants)));
//    }
//    public ResponseEntity  searchBranchManagers(String query){
//        List<BranchManager> merchants = branchManagerRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase( query,query);
//        if(merchants==null){
//            merchants = new ArrayList<>();
//        }
//        return ResponseEntity.ok(authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchants)));
//    }
//    public ResponseEntity  searchCashiers(String query){
//        List<MerchantCashier> merchants = merchantCashierRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase( query,query);
//        if(merchants==null){
//            merchants = new ArrayList<>();
//        }
//        return ResponseEntity.ok(authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchants)));
//    }
//    public ResponseEntity  searchMerchantAdmin(String query){
//        List<MerchantAdmin> merchants = merchantAdminRepository.findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase( query,query);
//        if(merchants==null){
//            merchants = new ArrayList<>();
//        }
//        return ResponseEntity.ok(authenticationService.mapUserEntityToSpecificSummaryDto(new ArrayList<User>(merchants)));
//    }
//    public ResponseEntity  depositFloatBalance  (MerchantDepositRequest merchantDepositRequest,String userId){
//        List<Merchant> merchants = new ArrayList<>();
//        User user = userRepository.findById(userId).orElse(null);
//        Merchant merchant = merchantRepository.findById(merchantDepositRequest.getMerchantId()).orElse(null);
//        if(merchant!=null && user!=null){
//            merchants.add(merchant);
//            MerchantAccount merchantAccount = merchant.getMerchantAccounts().stream().findFirst().get();
//
//            double newBalance = merchantDepositRequest.getAmount() + merchantAccount.getAccountBalance();
//            if(newBalance>merchant.getMaxfloatLimit()){
//                return new ResponseEntity<>(new GenericApiError("New Balance cannot be greater than Max Float Limit. Update Float Limit",110), HttpStatus.EXPECTATION_FAILED);
//            }
//            Transaction transaction =  Transaction.builder()
//                    .tranType("MERCHANT_FLOAT_DEPOSIT")
//                    .reference(merchantDepositRequest.getReference())
//                    .amount(merchantDepositRequest.getAmount())
//                    .rtgsAmt(merchantDepositRequest.getAmount())
//                    .user(user)
//                    .balanceBefore(merchantAccount.getAccountBalance())
//                    .balanceAfter(newBalance)
//                    .build();
//            Transaction savedTransaction =  transactionRepository.save(transaction);
//            merchantAccount.setAccountBalance(newBalance);
//            transactionRepository.save(savedTransaction);
//        }
//
//
//        return ResponseEntity.ok(this.mapMerchantListToResponse(merchants));
//    }
//    public ResponseEntity  getMerchantBranches  (String id,
//
//                                                         String query,
//                                                 Pageable pageable){
//        List<MerchantBranch> merchantBranches= new ArrayList<>();
//        if(query!=null){
//            merchantBranches= merchantBranchRepository.findByNameContainingIgnoreCaseAndMerchantId( query, id);
//        }else{
//            merchantBranches= merchantBranchRepository.findByMerchantId(id);
//        }
//
//        if(merchantBranches==null){
//            merchantBranches=new ArrayList<>();
//        }
//   return ResponseEntity.ok(this.mapMerchantBranchListToResponse(merchantBranches));
//    }
//    public ResponseEntity  getCashiersByBranchId  (long branchId){
//
//        List<MerchantCashier> merchantBranches= merchantCashierRepository.findByMerchantBranchId( branchId);
//
//
//        if(merchantBranches==null){
//            merchantBranches=new ArrayList<>();
//        }
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantBranches));
//    }
//    public ResponseEntity  getCashiers (){
//
//        List<MerchantCashier> merchantBranches= merchantCashierRepository.findAll( );
//
//
//        if(merchantBranches==null){
//            merchantBranches=new ArrayList<>();
//        }
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantBranches));
//    }
//    public ResponseEntity  saveOrUpdateMerchantBranch  (String id
//            ,MerchantBranchDto merchantDto){
//        List<MerchantBranch> merchantBranches= new ArrayList<>();
//        Merchant merchant = merchantRepository.findById(id).orElse(null);
//        if(merchantDto.getId()!=null){
//            MerchantBranch merchantBranch = merchantBranchRepository.findById(Long.parseLong(merchantDto.getId())).orElse(null);
//            merchantBranch.setMerchant(merchant);
//            merchantBranch.setBranchEmail(merchantDto.getBranchEmail());
//            merchantBranch.setBranchManagerName(merchantDto.getBranchManagerName());
//            merchantBranch.setName(merchantDto.getBranchName());
//            merchantBranch.setContactNumber(merchantDto.getContactNumber());
//            MerchantBranch saveMerchantBranch =merchantBranchRepository.save(merchantBranch);
//            merchantBranches.add(saveMerchantBranch);
//        }else{
//            MerchantBranch merchantBranch = new MerchantBranch();
//            merchantBranch.setMerchant(merchant);
//            merchantBranch.setBranchEmail(merchantDto.getBranchEmail());
//            merchantBranch.setBranchManagerName(merchantDto.getBranchManagerName());
//            merchantBranch.setActive(true);
//            merchantBranch.setName(merchantDto.getBranchName());
//            merchantBranch.setContactNumber(merchantDto.getContactNumber());
//            MerchantBranch saveMerchantBranch =merchantBranchRepository.save(merchantBranch);
//            merchantBranches.add(saveMerchantBranch);
//        }
//
//        return ResponseEntity.ok(this.mapMerchantBranchListToResponse(merchantBranches));
//    }
//    public ResponseEntity  merchantTransactions  (String merchantId,String startDate,String endDate,Map<String, String> additionalData){
//        LocalDate startDateFull =LocalDate.parse(startDate);
//        LocalDate endDateFull =LocalDate.parse(endDate);
//        ReportTypes reportType =ReportTypes.MERCHANT_TRAN;
//        if(additionalData.get("REPORT_TYPE")!=null){
//            reportType =ReportTypes.valueOf(additionalData.get("REPORT_TYPE"));
//        }
//
//        List<Transaction>transactions = new ArrayList<>();
//
//
//            switch (reportType) {
//                case BRANCH_TRAN:
//                    long branchId =0;
//                    if(additionalData.get("BRANCH_ID")!=null){
//                        branchId =Long.parseLong(additionalData.get("BRANCH_ID"));
//                    }
//
//                    MerchantBranch merchantBranch = merchantBranchRepository.findById(branchId).orElse(null);
//                    if(merchantBranch!=null){
//                        transactions = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndMerchantBranchId(startDateFull.atTime(LocalTime.MIN), endDateFull.atTime(LocalTime.MAX),merchantBranch.getId());
//                    }
//
//                    break;
//                case MERCHANT_TRAN:
//                    String merchantId2 =merchantId;
//                    if(additionalData.get("MERCHANT_ID")!=null){
//                        merchantId2 =additionalData.get("MERCHANT_ID");
//                    }
//                    Merchant merchant = merchantRepository.findById(merchantId2).orElse(null);
//                    if(merchant!=null){
//                        transactions = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndMerchantId(startDateFull.atTime(LocalTime.MIN), endDateFull.atTime(LocalTime.MAX),merchantId2);
//                    }
//                    break;
//                case CASHIER_TRAN:
//                    String mobileNumber =merchantId;
//                    if(additionalData.get("MSISDN")!=null){
//                        mobileNumber =additionalData.get("MSISDN");
//                    }
//
//                    MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(mobileNumber).orElse(null);
//                    if(merchantUser!=null){
//                        transactions = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndUserUserId(startDateFull.atTime(LocalTime.MIN), endDateFull.atTime(LocalTime.MAX),merchantUser.getUserId());
//
//                    }
//                    break;
//                default:
//                    String mobileNumber2 =merchantId;
//                    if(additionalData.get("MSISDN")!=null){
//                        mobileNumber2 =additionalData.get("MSISDN");
//                    }
//                    MerchantCashier merchantUser2 = merchantCashierRepository.findByMobileNumber(mobileNumber2).orElse(null);
//                    if(merchantUser2!=null){
//                        transactions = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndUserUserId(startDateFull.atTime(LocalTime.MIN), endDateFull.atTime(LocalTime.MAX),merchantUser2.getUserId());
//
//                    }
//                    break;
//            }
//
//        Map<String, String> additionalData2 = new HashMap<>();
//        double totalChangeIssued = 0;
//        for (Transaction transaction : transactions) {
//            totalChangeIssued = totalChangeIssued + transaction.getAmount();
//        }
//        additionalData2.put(TOTAL, ""+NumbersUtil.round(totalChangeIssued,2));
//        return ResponseEntity.ok(this.mapTransactionListToResponse(transactions));
//
//    }
//    public ResponseEntity  branchTansactions  (long branchId,String startDate, String endDate){
//        LocalDate startDateFull =LocalDate.parse(startDate);
//        LocalDate endDateFull =LocalDate.parse(endDate);
//        List<Transaction>transactions = new ArrayList<>();
//        MerchantBranch merchantBranch = merchantBranchRepository.findById(branchId).orElse(null);
//        if(merchantBranch!=null){
//            transactions = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndMerchantBranchId(startDateFull.atTime(LocalTime.MIN), endDateFull.atTime(LocalTime.MAX),merchantBranch.getId());
//        }
//
//        return ResponseEntity.ok(this.mapTransactionListToResponse(transactions));
//    }
//    public ResponseEntity  cashieransactions  (String msisidn,String startDate, String endDate){
//        LocalDate startDateFull =LocalDate.parse(startDate);
//        LocalDate endDateFull =LocalDate.parse(endDate);
//        List<Transaction>transactions = new ArrayList<>();
//        MerchantCashier merchantUser2 = merchantCashierRepository.findByMobileNumber(msisidn).orElse(null);
//        if(merchantUser2!=null){
//            transactions = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndUserUserId(startDateFull.atTime(LocalTime.MIN), endDateFull.atTime(LocalTime.MAX),merchantUser2.getUserId());
//
//        }
//        return ResponseEntity.ok(this.mapTransactionListToResponse(transactions));
//    }
//    public ResponseEntity  selfRegister  (SubscriberKycDetailsDto subscriberKycDetailsDto,Map<String, String> additionalData){
//        Role role = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
//        if(role==null){
////            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
//        }
//        String pin = RandomStringUtils.random(4,false,true);
//        UserCustomer admin = new UserCustomer();
//        admin.setFirstName(subscriberKycDetailsDto.getFirstName());
//        admin.setSurname(subscriberKycDetailsDto.getLastName());
//        admin.setMobileNumber(subscriberKycDetailsDto.getMsisdn());
//        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
//        admin.setResetPin(true);
//        admin.setGender(Gender.valueOf(subscriberKycDetailsDto.getSex().toUpperCase(Locale.ROOT)));
//        admin.setMessageGroup(WebSocketMessageGroup.CUSTOMERS);
//        admin.setPassword(passwordEncoder.encode(pin));
//        admin.setRoles(Collections.singletonList(role));
//        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
//        admin.setUsername(subscriberKycDetailsDto.getMsisdn());
//        UserCustomer savedAdmin =userCustomerRepository.save(admin);
//        //////////////////////assign Permissions////////////////////////
//        assignPermissionsByRoleToUser(RoleName.ROLE_CUSTOMER,savedAdmin);
//
//        this.processSuccessfulRegistrationSMSWithPin(admin.getMobileNumber(),pin);
//
//        // create merchantAccount
//        MerchantAccount merchantAccount = new MerchantAccount();
//        merchantAccount.setAccountAlias(subscriberKycDetailsDto.getMsisdn() + " - MerchantAccount");
//
//        if (additionalData.containsKey(BALANCE)) {
//            Double balance =Double.parseDouble(additionalData.get(BALANCE));
//            merchantAccount.setAccountBalance(balance);
//        } else {
//            merchantAccount.setAccountBalance(0d);
//        }
//        merchantAccount.setAccountStatus("ACTIVE");
//        merchantAccount.setMsisdn(admin.getMobileNumber());
//        merchantAccount.setUser(admin);
//        MerchantAccount savedMerchantAccount = accountRepository.save(merchantAccount);
//        List<UserCustomer> users = new ArrayList<>();
//        List<MerchantAccount> merchantAccounts = new ArrayList<>();
//        users.add(savedAdmin);
//        merchantAccounts.add(savedMerchantAccount);
//        return ResponseEntity.ok(this.mapSubscriberKycDetailsListToResponse(users, merchantAccounts));
//    }
//    public ResponseEntity   issueChange (IssueChangeLegacyRequest issueChangeLegacyRequest){
//        List<Transaction> transactions = new ArrayList<>();
//
//        Merchant merchant = merchantRepository.findById(issueChangeLegacyRequest.getMerchantId()).orElse(null);
//        FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(issueChangeLegacyRequest.getAcquiringFinancialInstitutionNumber()).orElse(null);
//        Currency currency = currencyRepository.findByCode(issueChangeLegacyRequest.getCurrency()).orElse(null);
//        MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(issueChangeLegacyRequest.getMsisdn()).orElse(null);
//        if(merchant!=null){
//            MerchantAccount merchantAccount = accountRepository.findFirstByMerchantId(merchant.getId()).orElse(null);
//            if(merchantAccount !=null){
//                if(merchantAccount.getAccountBalance()<0){
//                    return new ResponseEntity<>(new GenericApiError("Top Up MerchantAccount",105), HttpStatus.EXPECTATION_FAILED);
//                }
//                if(merchantAccount.getAccountBalance()<((issueChangeLegacyRequest.getTenderedAmount()- issueChangeLegacyRequest.getChangeIssued())*currency.getExchangeRate())){
//                    return new ResponseEntity<>(new GenericApiError("Top Up MerchantAccount",105), HttpStatus.EXPECTATION_FAILED);
//                }
//                Transaction transaction =  Transaction.builder()
//                        .transactionType(TransactionType.CHANGE)
//                        .amount(issueChangeLegacyRequest.getTenderedAmount())
//                        .issuedChange(issueChangeLegacyRequest.getChangeIssued())
//                        .requiredChange(issueChangeLegacyRequest.getChangeRequired())
//                        .exchangeRate(currency.getExchangeRate())
//                        .notificationMsisdn(issueChangeLegacyRequest.getNotificationMsisdn())
//                        .financialInstitution(financialInstitution)
//                        .reference(issueChangeLegacyRequest.getReceipt())
//                        .merchantAccount(merchantAccount)
//                        .rtgsAmt((issueChangeLegacyRequest.getTenderedAmount()- issueChangeLegacyRequest.getChangeIssued())*currency.getExchangeRate())
//                        .merchant(merchant)
//                        .merchantBranch(merchantUser.getMerchantBranch())
//                        .currency(currency)
//                        .destinationAccount(issueChangeLegacyRequest.getDestinationAccount())
//                        .user(merchantUser)
//                       .build();
//                Transaction savedTransaction =  transactionRepository.save(transaction);
//                merchantAccount.setAccountBalance(merchantAccount.getAccountBalance()-((issueChangeLegacyRequest.getTenderedAmount()- issueChangeLegacyRequest.getChangeIssued())*currency.getExchangeRate()));
//                accountRepository.save(merchantAccount);
//                String message = this.processIssuedChange("ISSUE_CHANGE");
//                this.sendSMS(issueChangeLegacyRequest.getNotificationMsisdn(),message);
//                transactions.add(savedTransaction);
//            }else{
//                return new ResponseEntity<>(new GenericApiError("Could not load MerchantAccount",110), HttpStatus.EXPECTATION_FAILED);
//            }
//
//
//
//        }
//        return ResponseEntity.ok(this.mapTransactionListToResponse(transactions));
//
//
//    }
//    public ResponseEntity  chechMerchantBalance  (String merchantId,Map<String, String> additionalData,Pageable pageable){
//        List<MerchantAccount> merchantAccounts = new ArrayList<>();
//        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
//        MerchantAccount merchantAccount = accountRepository.findFirstByMerchantId(merchantId).orElse(null);
//        if(merchant!=null && merchantAccount !=null){
//            merchantAccounts.add(merchantAccount);
//        }
//        return ResponseEntity.ok(this.mapAccountListToResponse(merchantAccounts));
//    }
//    public ResponseEntity  checkUssdMerchantUser   (String msisdn,Map<String, String> additionalData,Pageable pageable){
//        List<MerchantCashier> merchantUsers = new ArrayList<>();
//        MerchantCashier merchantUser = merchantCashierRepository.findByMobileNumber(msisdn).orElse(null);
//        if (merchantUser != null) {
//            merchantUsers.add(merchantUser);
//        }
//        return ResponseEntity.ok(this.mapMerchantCashierListToResponse(merchantUsers));
//    }
//    public ResponseEntity  authenticateUssd   (CashierAuthenticateRequest cashierAuthenticateRequest,Pageable pageable){
//        return authenticationService.LoginLegacy(cashierAuthenticateRequest.getMsisdn(),cashierAuthenticateRequest.getPin());
//    }
//    public ResponseEntity  getUssdActiveFinancialInstitutions  (){
//        List<FinancialInstitution> financialInstitutions = financialInstitutionRepository.findByActive(true);
//        return ResponseEntity.ok(this.mapFinancialInstitutionListToResponse(financialInstitutions));
//    }
//    public ResponseEntity  saveUssdMerchantUser  (Map<String, String> additionalData,
//                                                  Pageable pageable){
//        additionalData = DtoUtil.getAdditionalData(additionalData);
//        if (additionalData.containsKey(MERCHANT_ID)) {
//            String merchantId = additionalData.get(MERCHANT_ID);
//            List<Currency> merchantCurrencies = currencyRepository.findByActiveAndMerchantId(true,merchantId);
//            return ResponseEntity.ok(this.mapCurrencyListToResponse(merchantCurrencies));
//        }else{
//            List<Currency> merchantCurrencies = currencyRepository.findByActive(true);
//            return ResponseEntity.ok(this.mapCurrencyListToResponse(merchantCurrencies));
//        }
//    }
//    public ResponseEntity  issueUssdChange  (IssueChangeLegacyRequest issueChangeLegacyRequest){
//        List<Transaction> transactions = new ArrayList<>();
//        Merchant merchant = merchantRepository.findById(issueChangeLegacyRequest.getMerchantId()).orElse(null);
//        FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(issueChangeLegacyRequest.getAcquiringFinancialInstitutionNumber()).orElse(null);
//        Currency currency = currencyRepository.findByCodeAndMerchantId(issueChangeLegacyRequest.getCurrency(), issueChangeLegacyRequest.getMerchantId()).orElse(null);
//        User merchantUser = userRepository.findById(issueChangeLegacyRequest.getMsisdn()).orElse(null);
//        if(merchant!=null){
//            MerchantAccount merchantAccount = accountRepository.findFirstByMerchantId(merchant.getId()).orElse(null);
//            Transaction transaction =  Transaction.builder()
//                    .tranType("CHANGE_ISSUE")
//                    .amount(issueChangeLegacyRequest.getTenderedAmount())
//                    .issuedChange(issueChangeLegacyRequest.getChangeIssued())
//                    .requiredChange(issueChangeLegacyRequest.getChangeRequired())
//                    .exchangeRate(currency.getExchangeRate())
//                    .notificationMsisdn(issueChangeLegacyRequest.getNotificationMsisdn())
//                    .financialInstitution(financialInstitution)
//                    .destinationAccount(issueChangeLegacyRequest.getDestinationAccount())
//                    .user(merchantUser)
//                    .balanceBefore(merchantAccount.getAccountBalance())
//                    .balanceAfter(merchantAccount.getAccountBalance()-(issueChangeLegacyRequest.getChangeRequired()*currency.getExchangeRate()))
//                    .build();
//            Transaction savedTransaction =  transactionRepository.save(transaction);
//            merchantAccount.setAccountBalance(merchantAccount.getAccountBalance()-(issueChangeLegacyRequest.getChangeRequired()*currency.getExchangeRate()));
//            accountRepository.save(merchantAccount);
//            String message = this.processIssuedChange("ISSUE_CHANGE");
//            this.sendSMS(issueChangeLegacyRequest.getNotificationMsisdn(),message);
//            transactions.add(savedTransaction);
//
//
//        }
//        return ResponseEntity.ok(this.mapTransactionListToResponse(transactions));
//    }
//    public ResponseEntity  chechUssdMerchantBalance  (String merchantId,Map<String, String> additionalData,Pageable pageable){
//        List<MerchantAccount> merchantAccounts = new ArrayList<>();
//        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
//        MerchantAccount merchantAccount = accountRepository.findFirstByMerchantId(merchantId).orElse(null);
//        if(merchant!=null && merchantAccount !=null){
//            merchantAccounts.add(merchantAccount);
//        }
//        return ResponseEntity.ok(this.mapAccountListToResponse(merchantAccounts));
//    }
//
//    private AccountDto mapAccountToResponse(MerchantAccount accounts){
//        AccountDto dto = new AccountDto();
//        dto.setAccountAlias(accounts.getAccountAlias());
//        dto.setMsisdn(accounts.getMsisdn());
//        dto.setAccountBalance(accounts.getAccountBalance());
//        dto.setAccountAlias(accounts.getAccountAlias());
//        dto.setAccountStatus(accounts.getAccountStatus());
//        dto.setAccountType(accounts.getAccountType());
//        dto.setId("" + accounts.getId());
//        dto.setDateUpdated( accounts.getUpdatedAt().toString());
//        dto.setDateCreated( accounts.getCreatedAt().toString());
//        return dto;
//    }
//    private CurrencyDto mapCurrencyToResponse(Currency accounts){
//        CurrencyDto dto = new CurrencyDto();
//        dto.setCurrencyCode(accounts.getCode());
//        dto.setCurrencyName(accounts.getName());
//        dto.setExchangeRate(accounts.getExchangeRate());
//        dto.setId("" + accounts.getId());
//        dto.setDateUpdated( accounts.getUpdatedAt().toString());
//        dto.setDateCreated( accounts.getCreatedAt().toString());
//        return dto;
//    }
//    public MerchantDto mapMerchantToResponse(Merchant currency){
//        MerchantDto dto = new MerchantDto();
//        if(currency.getMerchantAccounts()!=null){
//
//            dto.setAccounts(currency.getMerchantAccounts().stream().map(this::mapAccountToResponse).collect(toList()));
//        }
//
//        dto.setCompanyRegNumber(currency.getName());
//        dto.setMerchantId(currency.getId());
//        dto.setContactPersonDesignation(currency.getContactPersonDesignation());
//        dto.setContactPersonEmail(currency.getContactPersonEmail());
//        dto.setContactPersonName(currency.getContactPersonName());
//        dto.setContactPersonNumber(currency.getContactPersonNumber());
//        dto.setContactPersonSurname(currency.getContactPersonSurname());
//        if(currency.getCurrencies()!=null){
//            dto.setCurrencies(currency.getCurrencies().stream().map(this::mapCurrencyToResponse).collect(toList()));
//        }
//
//        dto.setMaxfloatLimit(currency.getMaxfloatLimit());
//        dto.setMerchantName(currency.getName());
//        dto.setMinfloatLimit(currency.getMinfloatLimit());
//        dto.setNumberOfBranches(currency.getNumberOfBranches());
//        dto.setOfficeAddress(currency.getOfficeAddress());
//        dto.setProjectedCashiers(currency.getProjectedCashiers());
//        dto.setUserId(currency.getUserId());
//        dto.setStatus(currency.isActive());
//        dto.setId(""+currency.getId());
//        dto.setDateUpdated(currency.getUpdatedAt().toString());
//        dto.setDateCreated(currency.getCreatedAt().toString());
//        return dto;
//    }
//    public MerchantBranchDto mapMerchantBranchToResponse(MerchantBranch merchantBranch){
//        MerchantBranchDto dto = new MerchantBranchDto();
//        if(merchantBranch.getMerchant()!=null){
//            dto.setMerchant(this.mapMerchantToResponse(merchantBranch.getMerchant()));
//        }
//
//        dto.setBranchEmail(merchantBranch.getName());
//        dto.setBranchManagerName(merchantBranch.getBranchManagerName());
//        dto.setBranchName(merchantBranch.getBranchManagerName());
//        dto.setContactNumber(merchantBranch.getContactNumber());
//        dto.setId(""+merchantBranch.getId());
//        dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//        dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//        return dto;
//    }
//    private FinancialInstitutionDto mapFinancialInstitutionToResponse(FinancialInstitution accounts){
//        FinancialInstitutionDto dto = new FinancialInstitutionDto();
//        dto.setInstitutionNumber(accounts.getInstitutionNumber());
//        dto.setName(accounts.getName());
//        dto.setDisplayName(accounts.getDisplayName());
//        dto.setStatus(accounts.isActive());
//        dto.setMobileMoney(accounts.isMobileMoney());
//        dto.setId("" + accounts.getId());
//        dto.setDateUpdated( accounts.getUpdatedAt().toString());
//        dto.setDateCreated( accounts.getCreatedAt().toString());
//        return dto;
//    }
//    public TransactionDto mapTransactionToResponse(Transaction merchantBranch){
//        TransactionDto dto = new TransactionDto();
//        dto.setAmount(merchantBranch.getAmount());
//        dto.setBalanceAfter(merchantBranch.getBalanceAfter());
//        dto.setBalanceBefore(merchantBranch.getBalanceBefore());
//        dto.setDestinationAccount(merchantBranch.getDestinationAccount());
//        dto.setIssuedChange(merchantBranch.getIssuedChange());
//        dto.setNotificationMsisdn(merchantBranch.getNotificationMsisdn());
//        dto.setReference(merchantBranch.getReference());
//        dto.setRtgsAmt(merchantBranch.getRtgsAmt());
//        dto.setTransactionCharge(merchantBranch.getTransactionCharge());
//        dto.setTranType(merchantBranch.getTranType());
//        dto.setId(""+merchantBranch.getId());
//        dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//        dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//        return dto;
//    }
//    public MerchantUserDto mapMerchantUserToResponse(MerchantAdmin merchantBranch){
//        MerchantUserDto dto = new MerchantUserDto();
//        if(merchantBranch.getMerchant()!=null){
//            dto.setMerchant(this.mapMerchantToResponse(merchantBranch.getMerchant()));
//        }
//
//        dto.setActive(merchantBranch.getEnabled());
//        dto.setName(merchantBranch.getFirstName());
//        dto.setId(""+merchantBranch.getUserId());
//        dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//        dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//        return dto;
//    }
//    private ResponseDto<RoleDto> mapRoleListToResponse(List<Role> currencies){
//        ResponseDto<RoleDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<RoleDto> dtos = new ArrayList<>();
//        if(currencies!=null && !currencies.isEmpty()){
//            if(currencies.size()==1) {
//                RoleDto dto = new RoleDto();
//                dto.setName(currencies.get(0).getName());
//                dto.setDescription(currencies.get(0).getDescription());
//                dto.setSelfRegEnabled(currencies.get(0).isSelfRegEnabled());
//                dto.setId(currencies.get(0).getId());
//                responseDto.setDto(dto);
//            }
//                for(Role currency :currencies){
//                    RoleDto dto = new RoleDto();
//                    dto.setName(currency.getName());
//                    dto.setDescription(currency.getDescription());
//                    dto.setSelfRegEnabled(currency.isSelfRegEnabled());
//                    dto.setId(currency.getId());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(currencies.size());
//                pageResponseDto.setSize(currencies.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(currencies.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<CurrencyDto> mapCurrencyListToResponse(List<Currency> currencies){
//        ResponseDto<CurrencyDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<CurrencyDto> dtos = new ArrayList<>();
//        if(currencies!=null && !currencies.isEmpty()){
//            if(currencies.size()==1) {
//                CurrencyDto dto = new CurrencyDto();
//                dto.setCurrencyCode(currencies.get(0).getCode());
//                dto.setCurrencyName(currencies.get(0).getName());
//                dto.setExchangeRate(currencies.get(0).getExchangeRate());
//                dto.setId("" + currencies.get(0).getId());
//                dto.setDateUpdated("" + currencies.get(0).getUpdatedAt());
//                dto.setDateCreated("" + currencies.get(0).getCreatedAt());
//                responseDto.setDto(dto);
//            }
//                for(Currency currency :currencies){
//                    CurrencyDto dto = new CurrencyDto();
//                    dto.setCurrencyCode(currency.getCode());
//                    dto.setCurrencyName(currency.getName());
//                    dto.setExchangeRate(currency.getExchangeRate());
//                    dto.setId(""+currency.getId());
//                    dto.setDateUpdated(""+currency.getUpdatedAt());
//                    dto.setDateCreated(""+currency.getCreatedAt());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(currencies.size());
//                pageResponseDto.setSize(currencies.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(currencies.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<AccountDto> mapAccountListToResponse(List<MerchantAccount> merchantAccounts){
//        ResponseDto<AccountDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<AccountDto> dtos = new ArrayList<>();
//        if(merchantAccounts !=null && !merchantAccounts.isEmpty()){
//            if(merchantAccounts.size()==1) {
//                AccountDto dto = new AccountDto();
//                dto.setAccountAlias(merchantAccounts.get(0).getAccountAlias());
//                dto.setMsisdn(merchantAccounts.get(0).getMsisdn());
//                dto.setAccountBalance(merchantAccounts.get(0).getAccountBalance());
//                dto.setAccountAlias(merchantAccounts.get(0).getAccountAlias());
//                dto.setAccountStatus(merchantAccounts.get(0).getAccountStatus());
//                dto.setAccountType(merchantAccounts.get(0).getAccountType());
//                dto.setId("" + merchantAccounts.get(0).getId());
//                dto.setDateUpdated("" + merchantAccounts.get(0).getUpdatedAt());
//                dto.setDateCreated("" + merchantAccounts.get(0).getCreatedAt());
//                responseDto.setDto(dto);
//            }
//                for(MerchantAccount currency : merchantAccounts){
//                    AccountDto dto = new AccountDto();
//                    dto.setAccountAlias(merchantAccounts.get(0).getAccountAlias());
//                    dto.setMsisdn(merchantAccounts.get(0).getMsisdn());
//                    dto.setAccountBalance(merchantAccounts.get(0).getAccountBalance());
//                    dto.setAccountAlias(merchantAccounts.get(0).getAccountAlias());
//                    dto.setAccountStatus(merchantAccounts.get(0).getAccountStatus());
//                    dto.setAccountType(merchantAccounts.get(0).getAccountType());
//                    dto.setId(""+currency.getId());
//                    dto.setDateUpdated(""+currency.getUpdatedAt());
//                    dto.setDateCreated(""+currency.getCreatedAt());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(merchantAccounts.size());
//                pageResponseDto.setSize(merchantAccounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(merchantAccounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<FinancialInstitutionDto> mapFinancialInstitutionListToResponse(List<FinancialInstitution> accounts){
//        ResponseDto<FinancialInstitutionDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<FinancialInstitutionDto> dtos = new ArrayList<>();
//        if(accounts!=null && !accounts.isEmpty()){
//            if(accounts.size()==1) {
//                FinancialInstitutionDto dto = new FinancialInstitutionDto();
//                dto.setInstitutionNumber(accounts.get(0).getInstitutionNumber());
//                dto.setName(accounts.get(0).getName());
//                dto.setDisplayName(accounts.get(0).getDisplayName());
//                dto.setStatus(accounts.get(0).isActive());
//                dto.setMobileMoney(accounts.get(0).isMobileMoney());
//                dto.setId("" + accounts.get(0).getId());
//                dto.setDateUpdated("" + accounts.get(0).getUpdatedAt());
//                dto.setDateCreated("" + accounts.get(0).getCreatedAt());
//                responseDto.setDto(dto);
//            }
//                for(FinancialInstitution currency :accounts){
//                    FinancialInstitutionDto dto = new FinancialInstitutionDto();
//                    dto.setInstitutionNumber(currency.getInstitutionNumber());
//                    dto.setName(currency.getName());
//                    dto.setDisplayName(currency.getDisplayName());
//                    dto.setStatus(currency.isActive());
//                    dto.setMobileMoney(currency.isMobileMoney());
//                    dto.setId(""+currency.getId());
//                    dto.setDateUpdated(""+currency.getUpdatedAt());
//                    dto.setDateCreated(""+currency.getCreatedAt());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(accounts.size());
//                pageResponseDto.setSize(accounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(accounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<MerchantDto> mapMerchantListToResponse(List<Merchant> accounts){
//        ResponseDto<MerchantDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<MerchantDto> dtos = new ArrayList<>();
//        if(accounts!=null && !accounts.isEmpty()){
//            if(accounts.size()==1) {
//                MerchantDto dto = new MerchantDto();
//                if(accounts.get(0).getMerchantAccounts()!=null){
//                    dto.setAccounts(accounts.get(0).getMerchantAccounts().stream().map(this::mapAccountToResponse).collect(toList()));
//                }
//
//                dto.setCompanyRegNumber(accounts.get(0).getName());
//                dto.setMerchantId(accounts.get(0).getId());
//                dto.setContactPersonDesignation(accounts.get(0).getContactPersonDesignation());
//                dto.setContactPersonEmail(accounts.get(0).getContactPersonEmail());
//                dto.setContactPersonName(accounts.get(0).getContactPersonName());
//                dto.setContactPersonNumber(accounts.get(0).getContactPersonNumber());
//                dto.setContactPersonSurname(accounts.get(0).getContactPersonSurname());
//                if(accounts.get(0).getCurrencies()!=null){
//                    dto.setCurrencies(accounts.get(0).getCurrencies().stream().map(this::mapCurrencyToResponse).collect(toList()));
//                }
//
//                dto.setMaxfloatLimit(accounts.get(0).getMaxfloatLimit());
//                dto.setMerchantName(accounts.get(0).getName());
//                dto.setMinfloatLimit(accounts.get(0).getMinfloatLimit());
//                dto.setNumberOfBranches(accounts.get(0).getNumberOfBranches());
//                dto.setOfficeAddress(accounts.get(0).getOfficeAddress());
//                dto.setProjectedCashiers(accounts.get(0).getProjectedCashiers());
//                dto.setUserId(accounts.get(0).getUserId());
//                dto.setStatus(accounts.get(0).isActive());
//                dto.setId("" + accounts.get(0).getId());
//                dto.setDateUpdated(accounts.get(0).getUpdatedAt().toString());
//                dto.setDateCreated( accounts.get(0).getCreatedAt().toString());
//                responseDto.setDto(dto);
//            }
//                for(Merchant currency :accounts){
//                    MerchantDto dto = new MerchantDto();
//                    if(currency.getMerchantAccounts()!=null){
//
//                        dto.setAccounts(currency.getMerchantAccounts().stream().map(this::mapAccountToResponse).collect(toList()));
//                    }
//
//                    dto.setCompanyRegNumber(currency.getName());
//                    dto.setMerchantId(currency.getId());
//                    dto.setContactPersonDesignation(currency.getContactPersonDesignation());
//                    dto.setContactPersonEmail(currency.getContactPersonEmail());
//                    dto.setContactPersonName(currency.getContactPersonName());
//                    dto.setContactPersonNumber(currency.getContactPersonNumber());
//                    dto.setContactPersonSurname(currency.getContactPersonSurname());
//                    if(currency.getCurrencies()!=null){
//                        dto.setCurrencies(currency.getCurrencies().stream().map(this::mapCurrencyToResponse).collect(toList()));
//                    }
//
//                    dto.setMaxfloatLimit(currency.getMaxfloatLimit());
//                    dto.setMerchantName(currency.getName());
//                    dto.setMinfloatLimit(currency.getMinfloatLimit());
//                    dto.setNumberOfBranches(currency.getNumberOfBranches());
//                    dto.setOfficeAddress(currency.getOfficeAddress());
//                    dto.setProjectedCashiers(currency.getProjectedCashiers());
//                    dto.setUserId(currency.getUserId());
//                    dto.setStatus(currency.isActive());
//                    dto.setId(""+currency.getId());
//                    dto.setDateUpdated(currency.getUpdatedAt().toString());
//                    dto.setDateCreated(currency.getCreatedAt().toString());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(accounts.size());
//                pageResponseDto.setSize(accounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(accounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<MerchantBranchDto> mapMerchantBranchListToResponse(List<MerchantBranch> accounts){
//        ResponseDto<MerchantBranchDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<MerchantBranchDto> dtos = new ArrayList<>();
//        if(accounts!=null && !accounts.isEmpty()){
//            if(accounts.size()==1) {
//                MerchantBranchDto dto = new MerchantBranchDto();
//                if(accounts.get(0).getMerchant()!=null){
//                    dto.setMerchant(this.mapMerchantToResponse(accounts.get(0).getMerchant()));
//                }
//
//                dto.setBranchEmail(accounts.get(0).getName());
//                dto.setBranchManagerName(accounts.get(0).getBranchManagerName());
//                dto.setBranchName(accounts.get(0).getBranchManagerName());
//                dto.setContactNumber(accounts.get(0).getContactNumber());
//                dto.setId("" + accounts.get(0).getId());
//                dto.setDateUpdated(accounts.get(0).getUpdatedAt().toString());
//                dto.setDateCreated( accounts.get(0).getCreatedAt().toString());
//                responseDto.setDto(dto);
//            }
//                for(MerchantBranch merchantBranch :accounts){
//                    MerchantBranchDto dto = new MerchantBranchDto();
//                    if(accounts.get(0).getMerchant()!=null){
//                        dto.setMerchant(this.mapMerchantToResponse(accounts.get(0).getMerchant()));
//                    }
//
//                    dto.setBranchEmail(merchantBranch.getName());
//                    dto.setBranchManagerName(merchantBranch.getBranchManagerName());
//                    dto.setBranchName(merchantBranch.getBranchManagerName());
//                    dto.setContactNumber(merchantBranch.getContactNumber());
//                    dto.setId(""+merchantBranch.getId());
//                    dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//                    dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(accounts.size());
//                pageResponseDto.setSize(accounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(accounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<TransactionDto> mapTransactionListToResponse(List<Transaction> accounts){
//        ResponseDto<TransactionDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        double total=0;
//        List<TransactionDto> dtos = new ArrayList<>();
//        if(accounts!=null && !accounts.isEmpty()){
//            if(accounts.size()==1) {
//                TransactionDto dto = new TransactionDto();
//                if(accounts.get(0).getMerchant()!=null){
//                    dto.setMerchant(this.mapMerchantToResponse(accounts.get(0).getMerchant()));
//                }
//                if(accounts.get(0).getCurrency()!=null){
//                    dto.setCurrency(this.mapCurrencyToResponse(accounts.get(0).getCurrency()));
//                }
//                if(accounts.get(0).getFinancialInstitution()!=null){
//                    dto.setFinancialInstitution(this.mapFinancialInstitutionToResponse(accounts.get(0).getFinancialInstitution()));
//                }
//                if(accounts.get(0).getFinancialInstitution()!=null){
//                    dto.setFinancialInstitution(this.mapFinancialInstitutionToResponse(accounts.get(0).getFinancialInstitution()));
//                }
//                if(accounts.get(0).getMerchantAccount()!=null){
//                    dto.setAccount(this.mapAccountToResponse(accounts.get(0).getMerchantAccount()));
//                }
//                dto.setAmount(accounts.get(0).getAmount());
//                dto.setBalanceAfter(accounts.get(0).getBalanceAfter());
//                dto.setBalanceBefore(accounts.get(0).getBalanceBefore());
//                dto.setDestinationAccount(accounts.get(0).getDestinationAccount());
//
//                dto.setIssuedChange(accounts.get(0).getIssuedChange());
//                dto.setNotificationMsisdn(accounts.get(0).getNotificationMsisdn());
//                dto.setReference(accounts.get(0).getReference());
//                dto.setRtgsAmt(accounts.get(0).getRtgsAmt());
//                dto.setTransactionCharge(accounts.get(0).getTransactionCharge());
//                dto.setTranType(accounts.get(0).getTranType());
//                dto.setId("" + accounts.get(0).getId());
//                dto.setDateUpdated(accounts.get(0).getUpdatedAt().toString());
//                dto.setDateCreated( accounts.get(0).getCreatedAt().toString());
//                responseDto.setDto(dto);
//            }
//                for(Transaction merchantBranch :accounts){
//                    TransactionDto dto = new TransactionDto();
//                    if(merchantBranch.getMerchant()!=null){
//                        dto.setMerchant(this.mapMerchantToResponse(merchantBranch.getMerchant()));
//                    }
//                    if(merchantBranch.getMerchant()!=null){
//                        dto.setMerchant(this.mapMerchantToResponse(merchantBranch.getMerchant()));
//                    }
//                    if(merchantBranch.getCurrency()!=null){
//                        dto.setCurrency(this.mapCurrencyToResponse(merchantBranch.getCurrency()));
//                    }
//                    if(merchantBranch.getFinancialInstitution()!=null){
//                        dto.setFinancialInstitution(this.mapFinancialInstitutionToResponse(merchantBranch.getFinancialInstitution()));
//                    }
//                    dto.setAmount(merchantBranch.getAmount());
//                    dto.setBalanceAfter(merchantBranch.getBalanceAfter());
//                    dto.setBalanceBefore(merchantBranch.getBalanceBefore());
//                    dto.setDestinationAccount(merchantBranch.getDestinationAccount());
//                    dto.setIssuedChange(merchantBranch.getIssuedChange());
//                    dto.setNotificationMsisdn(merchantBranch.getNotificationMsisdn());
//                    dto.setReference(merchantBranch.getReference());
//                    dto.setRtgsAmt(merchantBranch.getRtgsAmt());
//                    dto.setTransactionCharge(merchantBranch.getTransactionCharge());
//                    dto.setTranType(merchantBranch.getTranType());
//                    dto.setId(""+merchantBranch.getId());
//                    dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//                    dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//                    total= total+merchantBranch.getIssuedChange();
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(accounts.size());
//                pageResponseDto.setSize(accounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(accounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        Map<String, String> additionalData = new HashMap<>();
//        additionalData.put("total",total+"");
//        responseDto.setAdditionalData(additionalData);
//        return responseDto;
//    }
//    private ResponseDto<MerchantUserDto> mapMerchantUserListToResponse(List<MerchantAdmin> accounts){
//        ResponseDto<MerchantUserDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<MerchantUserDto> dtos = new ArrayList<>();
//        if(accounts!=null && !accounts.isEmpty()){
//            if(accounts.size()==1) {
//                MerchantUserDto dto = new MerchantUserDto();
//                if(accounts.get(0).getMerchant()!=null){
//                    dto.setMerchant(this.mapMerchantToResponse(accounts.get(0).getMerchant()));
//                }
//
//                dto.setActive(accounts.get(0).getEnabled());
//                dto.setName(accounts.get(0).getFirstName());
//                dto.setId("" + accounts.get(0).getUserId());
//                dto.setDateUpdated(accounts.get(0).getUpdatedAt().toString());
//                dto.setDateCreated( accounts.get(0).getCreatedAt().toString());
//                responseDto.setDto(dto);
//            }
//                for(MerchantAdmin merchantBranch :accounts){
//                    MerchantUserDto dto = new MerchantUserDto();
//                    if(merchantBranch.getMerchant()!=null){
//                        dto.setMerchant(this.mapMerchantToResponse(merchantBranch.getMerchant()));
//                    }
//
//                    dto.setActive(merchantBranch.getEnabled());
//                    dto.setName(merchantBranch.getFirstName());
//                    dto.setId(""+merchantBranch.getUserId());
//                    dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//                    dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(accounts.size());
//                pageResponseDto.setSize(accounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(accounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<MerchantCashierDto> mapMerchantCashierListToResponse(List<MerchantCashier> accounts){
//        ResponseDto<MerchantCashierDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<MerchantCashierDto> dtos = new ArrayList<>();
//        if(accounts!=null && !accounts.isEmpty()){
//            if(accounts.size()==1) {
//                MerchantCashierDto dto = new MerchantCashierDto();
//                if(accounts.get(0).getMerchantBranch()!=null){
//                    dto.setMerchantBranch(this.mapMerchantBranchToResponse(accounts.get(0).getMerchantBranch()));
//                }
//
//                dto.setActive(accounts.get(0).getEnabled());
//                dto.setMsisdn(accounts.get(0).getMobileNumber());
//                dto.setName(accounts.get(0).getFirstName());
//                dto.setId("" + accounts.get(0).getUserId());
//                dto.setDateUpdated(accounts.get(0).getUpdatedAt().toString());
//                dto.setDateCreated( accounts.get(0).getCreatedAt().toString());
//                responseDto.setDto(dto);
//            }
//                for(MerchantCashier merchantBranch :accounts){
//                    MerchantCashierDto dto = new MerchantCashierDto();
//                    if(merchantBranch.getMerchantBranch()!=null){
//                        dto.setMerchantBranch(this.mapMerchantBranchToResponse(merchantBranch.getMerchantBranch()));
//                    }
//
//                    dto.setActive(merchantBranch.getEnabled());
//                    dto.setMsisdn(merchantBranch.getMobileNumber());
//                    dto.setName(merchantBranch.getFirstName());
//                    dto.setId(""+merchantBranch.getUserId());
//                    dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//                    dto.setDateCreated(merchantBranch.getCreatedAt().toString());
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(accounts.size());
//                pageResponseDto.setSize(accounts.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(accounts.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    private ResponseDto<SubscriberKycDetailsDto> mapSubscriberKycDetailsListToResponse(List<UserCustomer> users,List<MerchantAccount> merchantAccounts){
//        ResponseDto<SubscriberKycDetailsDto> responseDto = new ResponseDto<>();
//        responseDto.setSuccess(true);
//        responseDto.setNarrative("Success");
//        List<SubscriberKycDetailsDto> dtos = new ArrayList<>();
//        if(users!=null && !users.isEmpty()){
//            if(users.size()==1) {
//                SubscriberKycDetailsDto dto = new SubscriberKycDetailsDto();
//                dto.setFirstName(users.get(0).getFirstName());
//                dto.setMsisdn(users.get(0).getMobileNumber());
//                dto.setLastName(users.get(0).getSurname());
//                dto.setSex(users.get(0).getGender().toString());
//                dto.setNationalId(users.get(0).getNationalId());
//                if(merchantAccounts !=null) {
//                    dto.setAccounts(merchantAccounts.stream().map(this::mapAccountToResponse).collect(toList()));
//                }
//                dto.setId(users.get(0).getUserId());
//                dto.setDateUpdated(users.get(0).getUpdatedAt().toString());
//                dto.setDateCreated( users.get(0).getCreatedAt().toString());
//                responseDto.setDto(dto);
//            }
//                for(UserCustomer merchantBranch :users){
//                    SubscriberKycDetailsDto dto = new SubscriberKycDetailsDto();
//                    dto.setFirstName(merchantBranch.getFirstName());
//                    dto.setMsisdn(merchantBranch.getMobileNumber());
//                    dto.setLastName(merchantBranch.getSurname());
//                    dto.setSex(merchantBranch.getGender().toString());
//                    dto.setNationalId(merchantBranch.getNationalId());
//                    if(merchantAccounts !=null) {
//                        dto.setAccounts(merchantAccounts.stream().map(this::mapAccountToResponse).collect(toList()));
//                    }
//                    dto.setId(merchantBranch.getUserId());
//                    dto.setDateUpdated(merchantBranch.getUpdatedAt().toString());
//                    dto.setDateCreated( merchantBranch.getCreatedAt().toString());
//                    responseDto.setDto(dto);
//                    dtos.add(dto);
//                }
//                PageResponseDto pageResponseDto = new PageResponseDto();
//                pageResponseDto.setFirst(true);
//                pageResponseDto.setLast(true);
//                pageResponseDto.setTotalPages(1);
//                pageResponseDto.setTotalElements(users.size());
//                pageResponseDto.setSize(users.size());
//                pageResponseDto.setNumber(1);
//                pageResponseDto.setNumberOfElements(users.size());
//                responseDto.setPageResponseDto(pageResponseDto);
//                responseDto.setDtos(dtos);
//
//        }
//        return responseDto;
//    }
//    public void assignPermissionsByRoleToUser(RoleName roleName, User user) {
//        Role role = roleRepository.findByName(roleName).orElse(null);
//        List<Privilege> privileges = new ArrayList<>();
//
//        List<Permission> permissions = permissionRepository.findByRoles_Id(role.getId());
//        for(Permission p: permissions){
//            for(Privilege privilege: p.getPrivileges()){
//                if(!privileges.contains(privilege)){
//                    privileges.add(privilege);
//                }
//            }
//
//        }
//        user.setPermissions(permissions);
//        user.setPrivileges(privileges);
//        userRepository.save(user);
//
//    }
//    private void processSuccessfulRegistrationSMSWithPin(String mobileNumber,String pin){
//        String smsMessage = this.processRegistartionSMSMessageWithPin("REGISTRATION_WITH_PIN",pin);
//        this.sendSMS(mobileNumber,smsMessage);
//    }
//    private void processSuccessfulResetSMSWithPin(String mobileNumber,String pin){
//        String smsMessage = this.processResetSMSMessageWithPin("RESET_WITH_PIN",pin);
//        this.sendSMS(mobileNumber,smsMessage);
//    }
//    private String processResetSMSMessageWithPin(String smsMessageCode,String pin){
//        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
//        if(emailConfig!=null){
//            Map<String, String> values = new HashMap<>();
//            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
//            values.put("pin",pin);
//            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
//            String textMessage = sub.replace(emailConfig.getContent());
//            return textMessage;
//        }else{
//            return "You Have Successfully Reset Your Password: "+pin;
//        }
//    }
//    private String processRegistartionSMSMessageWithPin(String smsMessageCode,String pin){
//        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
//        if(emailConfig!=null){
//            Map<String, String> values = new HashMap<>();
//            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
//            values.put("pin",pin);
//            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
//            String textMessage = sub.replace(emailConfig.getContent());
//            return textMessage;
//        }else{
//            return "You Have Successfully CHanged Your Password";
//        }
//    }
//    private String processIssuedChange(String smsMessageCode){
//        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
//        if(emailConfig!=null){
//            Map<String, String> values = new HashMap<>();
//            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
//            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
//            String textMessage = sub.replace(emailConfig.getContent());
//            return textMessage;
//        }else{
//            return "You Have received Change";
//        }
//    }
//    private void sendSMS(String mobileNumber, String smsMessage){
//        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
//    }
//    private void sendSuccessfullyChangePassword(String mobileNumber, String smsMessage){
//        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
//    }
//    private String processSuccessPasswordChangeSmsMessage(String smsMessageCode){
//        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
//        if(emailConfig!=null){
//            Map<String, String> values = new HashMap<>();
//            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
//            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
//            String textMessage = sub.replace(emailConfig.getContent());
//            return textMessage;
//        }else{
//            return "You Have Successfully CHanged Your Password";
//        }
//    }
}
