package zw.co.change.money.app.legacy.response;

public enum ReportTypes {
    MERCHANT_TRAN,BRANCH_TRAN,CASHIER_TRAN
}
