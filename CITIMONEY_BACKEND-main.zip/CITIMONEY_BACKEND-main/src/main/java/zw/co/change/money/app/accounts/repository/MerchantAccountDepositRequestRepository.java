package zw.co.change.money.app.accounts.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.accounts.model.MerchantAccountDepositRequest;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

public interface MerchantAccountDepositRequestRepository extends JpaRepository<MerchantAccountDepositRequest, Long> {
    List<MerchantAccountDepositRequest> findByAccountId(long accountId);
    Page<MerchantAccountDepositRequest> findByAccountId(long accountId, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountMerchantId(String merchantId, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerUserId(String merchantId, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountMerchantIdAndStatus(String merchantId, DepositRequestStatus historyType, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByStatus( DepositRequestStatus historyType, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerUserIdAndStatus(String merchantId,DepositRequestStatus historyType, Pageable pageable);
    List<MerchantAccountDepositRequest> findFirst10ByAccountMerchantIdOrderByCreatedAtDesc( String merchantId);
    List<MerchantAccountDepositRequest> findFirst10ByAccountManagerUserIdOrderByCreatedAtDesc( String merchantId);
    Page<MerchantAccountDepositRequest> findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String name, LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByStatusAndAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(DepositRequestStatus transactionType, String name, LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByStatusAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrStatusAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(DepositRequestStatus transactionType, String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,DepositRequestStatus transactionType2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerUserIdAndStatusAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndStatusAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,DepositRequestStatus transactionType, String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,String userId2,DepositRequestStatus transactionType2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String senderFirstName, LocalDateTime startDate, LocalDateTime endDate, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,  Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,String userId2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,  Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerFirstNameContainingIgnoreCaseOrAccountManagerSurnameContainingIgnoreCase(String senderFirstName, String senderLastName,  Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCase(String userId,String senderFirstName,String userId2, String senderLastName,  Pageable pageable);
    Page<MerchantAccountDepositRequest> findByAccountMerchantNameContainingIgnoreCase(String name, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate,LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccountDepositRequest> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(LocalDateTime startDate,LocalDateTime endDate, String merchantId,Pageable pageable);
    Page<MerchantAccountDepositRequest> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountManagerUserId(LocalDateTime startDate,LocalDateTime endDate, String merchantId,Pageable pageable);
    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p where  p.created_at <= :endRange and  p.created_at >= :startRange", nativeQuery = true)
    double sumAmountByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);
    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT'", nativeQuery = true)
    double sumDepositByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p  where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT' and p.account_manager=:accountManagerId", nativeQuery = true)
    double sumDepositByDateRangeByAccountManagerId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("accountManagerId") String accountManagerId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p  where  p.created_at <= :endRange and  p.created_at >= :startRange and p.account_manager=:accountManagerId", nativeQuery = true)
    double sumAmountByDateRangeByAccountManagerId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("accountManagerId") String accountManagerId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p inner join merchant_account po on p.account = po.id where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT' and  po.merchant = :merchantId", nativeQuery = true)
    double sumDepositByDateRangeByMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("merchantId") String merchantId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p inner join merchant_account po on p.account = po.id  where  p.created_at <= :endRange and  p.created_at >= :startRange and  po.merchant = :merchantId", nativeQuery = true)
    double sumAmountByDateRangeByMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("merchantId") String merchantId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p inner join merchant_account po on p.account = po.id  inner join merchant_branch pg on po.merchant = pg.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  pg.id = :branchId", nativeQuery = true)
    double sumAmountByDateRangeByBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("branchId") long branchId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_deposit_requests p inner join merchant_account po on p.account = po.id  inner join merchant_branch pg on po.merchant = pg.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status ='DEPOSIT' and  pg.id = :branchId", nativeQuery = true)
    double sumDepositByDateRangeByBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("branchId") long branchId);

}
