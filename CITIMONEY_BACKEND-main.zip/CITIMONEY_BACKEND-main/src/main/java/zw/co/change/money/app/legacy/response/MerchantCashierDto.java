package zw.co.change.money.app.legacy.response;

import lombok.Data;

@Data
public class MerchantCashierDto extends BaseDto {
    private String msisdn;
    private String name;
    private boolean active;
    private long branchId;

    private MerchantBranchDto merchantBranch;
}
