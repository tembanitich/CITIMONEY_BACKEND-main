package zw.co.change.money.app.users.request;

import lombok.Data;
import zw.co.change.money.app.users.model.Gender;

import javax.validation.constraints.NotNull;
@Data
public class AddAccountManagerRequest {
    private String firstName;
    private String surname;
    private String contactMobileNumber;
    private String contactMobileNumberCountryCode;
    @NotNull
    private String email;
    @NotNull
    private Gender gender;
}
