package zw.co.change.money.app.financialInstitutions.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
@EqualsAndHashCode(callSuper = true,exclude = {""})
@Data
public class FinancialInstitution extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String institutionNumber;
    private String name;
    private String displayName;
    private boolean active;
    private boolean isMobileMoney;
    private String url;
}
