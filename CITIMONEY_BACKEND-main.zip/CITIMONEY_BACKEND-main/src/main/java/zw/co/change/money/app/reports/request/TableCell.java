package zw.co.change.money.app.reports.request;

import lombok.Data;

@Data
public class TableCell {
    private String text;
    private int position;
}
