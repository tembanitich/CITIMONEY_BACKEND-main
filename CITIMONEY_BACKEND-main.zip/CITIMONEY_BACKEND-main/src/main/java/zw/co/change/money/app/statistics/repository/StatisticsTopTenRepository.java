package zw.co.change.money.app.statistics.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.statistics.model.StatisticsTopTen;

import java.util.List;
import java.util.Optional;

public interface StatisticsTopTenRepository  extends JpaRepository<StatisticsTopTen, Long> {
    Optional<StatisticsTopTen> findByNameAndPositionAndGlobal(String name, int position,boolean isGlobal);
    Optional<StatisticsTopTen> findByNameAndPositionAndBranchId(String name, int position,long branchId);
    Optional<StatisticsTopTen> findByNameAndPositionAndMerchantId(String name, int position,String merchantId);
    List<StatisticsTopTen> findByNameAndGlobalOrderByPositionAsc(String name,boolean isGlobal);
    List<StatisticsTopTen> findByNameAndMerchantIdOrderByPositionAsc(String name,String merchantId);
    List<StatisticsTopTen> findByNameAndBranchIdOrderByPositionAsc(String name,long branchId);
}
