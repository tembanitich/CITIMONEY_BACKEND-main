package zw.co.change.money.app.transactions.model;

public enum WalletHistoryType {
    DEBIT,CREDIT,DEPOSIT
}
