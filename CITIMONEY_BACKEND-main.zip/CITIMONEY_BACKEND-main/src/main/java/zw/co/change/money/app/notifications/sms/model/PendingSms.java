package zw.co.change.money.app.notifications.sms.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@EqualsAndHashCode(callSuper = true)
@Data
public class PendingSms extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String phoneNumber;
    private boolean isMultiple;
    @ElementCollection
    private List<String> phoneNumbers;
    private LocalDateTime dateTimeSent;
    private String message;
    private int reference;
}
