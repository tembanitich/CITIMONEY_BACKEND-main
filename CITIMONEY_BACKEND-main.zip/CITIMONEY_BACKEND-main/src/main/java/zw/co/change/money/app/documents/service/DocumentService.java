package zw.co.change.money.app.documents.service;

import io.trbl.blurhash.BlurHash;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.documents.model.MerchantProofOfResidenceDocument;
import zw.co.change.money.app.documents.model.MerchantTaxClearanceDocument;
import zw.co.change.money.app.documents.repository.MerchantProofOfResidenceDocumentRepository;
import zw.co.change.money.app.documents.repository.MerchantTaxClearanceDocumentRepository;
import zw.co.change.money.app.documents.response.MerchantProofOfResidenceDocumentResponse;
import zw.co.change.money.app.documents.response.MerchantTaxClearanceDocumentResponse;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.storage.config.FileStorageProperties;
import zw.co.change.money.app.util.exception.FileStorageException;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
@Service
public class DocumentService {
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private MerchantProofOfResidenceDocumentRepository merchantProofOfResidenceDocumentRepository;
    @Autowired
    private MerchantTaxClearanceDocumentRepository merchantTaxClearanceDocumentRepository;
    @Autowired
    private FileStorageProperties fileStorageProperties;

    private final Path merchantDocumentsStorageLocation;


    @Autowired
    public DocumentService(FileStorageProperties fileStorageProperties) {

        this.merchantDocumentsStorageLocation = Paths.get(fileStorageProperties.getMerchantDocuments())
                .toAbsolutePath().normalize();

        try {
            Files.createDirectories(this.merchantDocumentsStorageLocation);

        } catch (Exception ex) {
            throw new FileStorageException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    public MerchantProofOfResidenceDocument storeMerchantProofOfResidenceDocument(MultipartFile file, Merchant merchant) {

        MerchantProofOfResidenceDocument merchantProofOfResidenceDocument = merchantProofOfResidenceDocumentRepository.findByMerchantId(merchant.getId()).orElse(null);
        // Normalize file name
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        try {
            // Check if the file's name contains invalid characters
            if (fileName.contains("..")) {
                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
            }


            if (!Files.exists(this.merchantDocumentsStorageLocation.resolve(merchant.getId()+ File.separator +"Proof_Of_Residence/"))){
                Files.createDirectories(this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Proof_Of_Residence/"));
            }

            System.out.println("File Storage:  " +fileName );
            Path targetLocation = this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Proof_Of_Residence/"+fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);


            if(merchantProofOfResidenceDocument ==null){
                merchantProofOfResidenceDocument = new MerchantProofOfResidenceDocument();
                merchantProofOfResidenceDocument.setMerchant(merchant);
                merchantProofOfResidenceDocument.setFileName(fileName);
                merchantProofOfResidenceDocument.setFileSize(file.getSize());
                merchantProofOfResidenceDocument.setFileType(file.getContentType());
                merchantProofOfResidenceDocument.setFileUrl(this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Proof_Of_Residence/"+fileName).toString());
                MerchantProofOfResidenceDocument savedProofOfResidenceDocument = merchantProofOfResidenceDocumentRepository.save(merchantProofOfResidenceDocument);

                return savedProofOfResidenceDocument;
            }else{

                merchantProofOfResidenceDocument.setMerchant(merchant);
                merchantProofOfResidenceDocument.setFileName(fileName);
                merchantProofOfResidenceDocument.setFileSize(file.getSize());
                merchantProofOfResidenceDocument.setFileType(file.getContentType());
                merchantProofOfResidenceDocument.setFileUrl(this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Proof_Of_Residence/"+fileName).toString());
                MerchantProofOfResidenceDocument savedProofOfResidenceDocument = merchantProofOfResidenceDocumentRepository.save(merchantProofOfResidenceDocument);

                return savedProofOfResidenceDocument;
            }


        } catch (IOException ex) {

            throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);

        }




    }
    public MerchantTaxClearanceDocument storeMerchantTaxClearanceDocument(MultipartFile file, Merchant merchant) {

        MerchantTaxClearanceDocument merchantProofOfResidenceDocument = merchantTaxClearanceDocumentRepository.findByMerchantId(merchant.getId()).orElse(null);
        // Normalize file name
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());

        try {
            // Check if the file's name contains invalid characters
            if (fileName.contains("..")) {
                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
            }


            if (!Files.exists(this.merchantDocumentsStorageLocation.resolve(merchant.getId()+ File.separator +"Tax_clearance/"))){
                Files.createDirectories(this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Tax_clearance/"));
            }

            System.out.println("File Storage:  " +fileName );
            Path targetLocation = this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Tax_clearance/"+fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);


            if(merchantProofOfResidenceDocument ==null){
                merchantProofOfResidenceDocument = new MerchantTaxClearanceDocument();
                merchantProofOfResidenceDocument.setMerchant(merchant);
                merchantProofOfResidenceDocument.setFileName(fileName);
                merchantProofOfResidenceDocument.setFileSize(file.getSize());
                merchantProofOfResidenceDocument.setFileType(file.getContentType());
                merchantProofOfResidenceDocument.setFileUrl(this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Tax_clearance/"+fileName).toString());
                MerchantTaxClearanceDocument savedProofOfResidenceDocument = merchantTaxClearanceDocumentRepository.save(merchantProofOfResidenceDocument);

                return savedProofOfResidenceDocument;
            }else{

                merchantProofOfResidenceDocument.setMerchant(merchant);
                merchantProofOfResidenceDocument.setFileName(fileName);
                merchantProofOfResidenceDocument.setFileSize(file.getSize());
                merchantProofOfResidenceDocument.setFileType(file.getContentType());
                merchantProofOfResidenceDocument.setFileUrl(this.merchantDocumentsStorageLocation.resolve(merchant.getId() +File.separator +"Tax_clearance/"+fileName).toString());
                MerchantTaxClearanceDocument savedProofOfResidenceDocument = merchantTaxClearanceDocumentRepository.save(merchantProofOfResidenceDocument);

                return savedProofOfResidenceDocument;
            }


        } catch (IOException ex) {

            throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);

        }




    }

    public ResponseEntity<Resource> downloadMerchantProofOfResidenceDocument(String merchantId)  throws IOException{
        Merchant company = merchantRepository.findById(merchantId).orElse(null);
        if(company!=null) {
            if(company.getProofOfResidence()!=null){

                            InputStreamResource resource = new InputStreamResource(new FileInputStream(company.getProofOfResidence().getFileUrl()));
                            HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+company.getProofOfResidence().getFileName());
                            return ResponseEntity.ok()
                                    .headers(headers)
                                    .contentLength(company.getProofOfResidence().getFileSize())
                                    .contentType(MediaType.valueOf(company.getProofOfResidence().getFileType()))
                                    .body(resource);

            }
            else{
                ClassPathResource resource = new ClassPathResource("/static/images/document_not_found.pdf");
                InputStreamResource inputStreamResource = new InputStreamResource(resource.getInputStream());
                HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+resource.getFilename());
                return ResponseEntity.ok()
                        .headers(headers)
                        .contentLength(resource.getInputStream().available())
                        .contentType(MediaType.APPLICATION_PDF)
                        .body(inputStreamResource);
            }

        }
        ClassPathResource resource = new ClassPathResource("/static/images/document_not_found.pdf");
        InputStreamResource inputStreamResource = new InputStreamResource(resource.getInputStream());
        HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+resource.getFilename());
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(resource.getInputStream().available())
                .contentType(MediaType.APPLICATION_PDF)
                .body(inputStreamResource);

    }
    public ResponseEntity<Resource> downloadMerchantTaxClearanceDocument(String merchantId)  throws IOException{
        Merchant company = merchantRepository.findById(merchantId).orElse(null);
        if(company!=null) {
            if(company.getTaxclearence()!=null){

                            InputStreamResource resource = new InputStreamResource(new FileInputStream(company.getTaxclearence().getFileUrl()));
                            HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+company.getTaxclearence().getFileName());
                            return ResponseEntity.ok()
                                    .headers(headers)
                                    .contentLength(company.getTaxclearence().getFileSize())
                                    .contentType(MediaType.valueOf(company.getTaxclearence().getFileType()))
                                    .body(resource);

            }
            else{
                ClassPathResource resource = new ClassPathResource("/static/images/document_not_found.pdf");
                InputStreamResource inputStreamResource = new InputStreamResource(resource.getInputStream());
                HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+resource.getFilename());
                return ResponseEntity.ok()
                        .headers(headers)
                        .contentLength(resource.getInputStream().available())
                        .contentType(MediaType.APPLICATION_PDF)
                        .body(inputStreamResource);
            }

        }
        ClassPathResource resource = new ClassPathResource("/static/images/document_not_found.pdf");
        InputStreamResource inputStreamResource = new InputStreamResource(resource.getInputStream());
        HttpHeaders headers = new HttpHeaders(); headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+resource.getFilename());
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(resource.getInputStream().available())
                .contentType(MediaType.APPLICATION_PDF)
                .body(inputStreamResource);

    }


    public MerchantTaxClearanceDocumentResponse mapMerchantTaxClearanceDocumentEntityToResponse(MerchantTaxClearanceDocument productImageDocument){
        MerchantTaxClearanceDocumentResponse response = new MerchantTaxClearanceDocumentResponse();
        response.setFileName(productImageDocument.getFileName());
        response.setFileSize(productImageDocument.getFileSize());
        response.setFileType(productImageDocument.getFileType());
        response.setId(productImageDocument.getId());
        response.setFileUrl(productImageDocument.getFileUrl());
        if(productImageDocument.getMerchant()!=null){
            response.setMerchantId(productImageDocument.getMerchant().getId());
        }
        return response;
    }
    public MerchantProofOfResidenceDocumentResponse mapMerchantProofOfResidenceDocumentEntityToResponse(MerchantProofOfResidenceDocument productImageDocument){
        MerchantProofOfResidenceDocumentResponse response = new MerchantProofOfResidenceDocumentResponse();
        response.setFileName(productImageDocument.getFileName());
        response.setFileSize(productImageDocument.getFileSize());
        response.setFileType(productImageDocument.getFileType());
        response.setId(productImageDocument.getId());
        response.setFileUrl(productImageDocument.getFileUrl());
        if(productImageDocument.getMerchant()!=null){
            response.setMerchantId(productImageDocument.getMerchant().getId());
        }
        return response;
    }
}
