package zw.co.change.money.app.users.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.UserSystemAdmin;

import java.util.List;

public interface UserSystemAdminRepository extends JpaRepository<UserSystemAdmin, String> {
    List<UserSystemAdmin> findByEnabled(boolean status);
}