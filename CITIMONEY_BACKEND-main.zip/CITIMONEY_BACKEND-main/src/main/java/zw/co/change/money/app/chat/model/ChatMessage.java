package zw.co.change.money.app.chat.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.users.model.User;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"customer"})
@Data
public class ChatMessage extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String message;
    private boolean readStatus;
    private boolean isFromCustomer;
    private boolean isFromDriver;
    private String senderId;
    private String receiverId;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "client")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private User customer;
}
