package zw.co.change.money.app.users.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.UserGuest;

public interface UserGuestRepository extends JpaRepository<UserGuest, String> {
}
