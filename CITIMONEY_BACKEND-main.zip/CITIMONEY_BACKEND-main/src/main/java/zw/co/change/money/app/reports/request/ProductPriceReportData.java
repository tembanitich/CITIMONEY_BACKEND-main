package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class ProductPriceReportData {
    private String productName;
    private double oldUsdPrice;
    private double newUsdPrice;
    private String user;
    private LocalDateTime dateOfAdjustment;

}
