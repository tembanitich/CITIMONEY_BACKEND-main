package zw.co.change.money.app.accounts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.model.*;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.accounts.repository.MerchantAccountDepositRequestRepository;
import zw.co.change.money.app.accounts.repository.MerchantAccountHistoryRepository;
import zw.co.change.money.app.accounts.request.ChangeMerchantDepositStatusRequest;
import zw.co.change.money.app.accounts.request.DepositMerchantAccountRequest;
import zw.co.change.money.app.accounts.request.UpdateMerchantAccountRequest;
import zw.co.change.money.app.accounts.response.MerchantAccountDepositRequestResponse;
import zw.co.change.money.app.accounts.response.MerchantAccountHistoryResponse;
import zw.co.change.money.app.accounts.response.MerchantAccountResponse;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class AccountsService {
    @Autowired
    private MerchantAccountDepositRequestRepository merchantAccountDepositRequestRepository;
    @Autowired
    private MerchantAccountHistoryRepository merchantAccountHistoryRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private AccountManagerRepository accountManagerRepository;
    @Autowired
    private UserCustomerRepository userCustomerRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    private UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private MerchantService merchantService;
    @Autowired
    private AuthenticationService authenticationService;
    @Autowired
    private UserService userService;
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private DateUtil dateUtil;

    public ResponseEntity updateMerchantAccount(UpdateMerchantAccountRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }

        MerchantAccount merchant = accountRepository.findById(request.getId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account",110), HttpStatus.NOT_FOUND);
        }
        merchant.setStatus(request.getStatus());
        merchant.setAccountAlias(request.getAccountAlias());
        merchant.setAccountBalance(request.getAccountBalance());
        accountRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Account Updated Successfully"));
    }
    public ResponseEntity updateMyMerchantAccount(UpdateMerchantAccountRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }

        MerchantAccount merchant = accountRepository.findById(request.getId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account",110), HttpStatus.NOT_FOUND);
        }
        merchant.setStatus(request.getStatus());
        merchant.setAccountAlias(request.getAccountAlias());
        merchant.setAccountBalance(request.getAccountBalance());
        accountRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Account Updated Successfully"));
    }
    public ResponseEntity updateAccountManagerMerchantAccount(UpdateMerchantAccountRequest request, String loggedInUserId){
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }

        MerchantAccount merchant = accountRepository.findById(request.getId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account",110), HttpStatus.NOT_FOUND);
        }
        merchant.setStatus(request.getStatus());
        merchant.setAccountAlias(request.getAccountAlias());
        merchant.setAccountBalance(request.getAccountBalance());
        accountRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Account Updated Successfully"));
    }
    public ResponseEntity depositMerchantAccount(DepositMerchantAccountRequest request, String loggedInUserId){
        if(!this.isLoggedInUserBackendUserAndAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(request.getAmount()==0|| request.getAmount()<0){
            return new ResponseEntity<>(new GenericApiError("Invalid Amount",110), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccount merchantAccount = accountRepository.findById(request.getId()).orElse(null);
        if(merchantAccount==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account",110), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccountDepositRequest depositRequest = new MerchantAccountDepositRequest();
        depositRequest.setAccount(merchantAccount);
        depositRequest.setAccountManager(merchantAdmin);
        depositRequest.setStatus(DepositRequestStatus.PENDING);
        depositRequest.setAmount(request.getAmount());
        merchantAccountDepositRequestRepository.save(depositRequest);
        accountRepository.save(merchantAccount);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Account Deposit Request Submitted Successfully"));
    }
    public ResponseEntity changeMerchantAccountStatus(long accountId, MerchantAccountStatus status, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUserAndAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAccount merchant = accountRepository.findById(accountId).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("could not load Merchant Account",110), HttpStatus.NOT_FOUND);
        }

        merchant.setStatus(status);
        accountRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Merchant Account status updated"));
    }
    public ResponseEntity getMerchantAccountsByStatus(MerchantAccountStatus status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantAccount> failures =  accountRepository.findByStatus(status,pageable);

        List<MerchantAccountResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAccountManagerMerchantAccountsByStatus(MerchantAccountStatus status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<MerchantAccount> failures =  accountRepository.findByStatusAndAccountManagerUserId(status,merchantAdmin.getUserId(),pageable);

        List<MerchantAccountResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveMerchantAccounts() {
        List<MerchantAccount> failures =  accountRepository.findByStatus(MerchantAccountStatus.ACTIVE);

        List<MerchantAccountResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity searchMerchantAccountsByMerchantName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
     
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccount> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACCOUNT_STATUS)) {
            try {
                MerchantAccountStatus paymentStatus = MerchantAccountStatus.valueOf(request.getFilterValue());
                failures = accountRepository.findByMerchantNameContainingIgnoreCaseAndStatus(request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = accountRepository.findByMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = accountRepository.findByMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = accountRepository.findByMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = accountRepository.findByMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = accountRepository.findByMerchantNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantAccountResponse> responses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity searchAccountManagerMerchantAccountsByMerchantName(SearchRequest request, String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccount> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_ACCOUNT_STATUS)) {
            try {
                MerchantAccountStatus paymentStatus = MerchantAccountStatus.valueOf(request.getFilterValue());
                failures = accountRepository.findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndStatus(merchantAdmin.getUserId(),request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = accountRepository.findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = accountRepository.findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = accountRepository.findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = accountRepository.findByAccountManagerUserIdAndMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = accountRepository.findByAccountManagerUserIdAndMerchantNameContainingIgnoreCase(merchantAdmin.getUserId(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountResponse> responses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity getAllMerchantAccounts(int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccount> failures = accountRepository.findAll(pageable);

        List<MerchantAccountResponse> productResponses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllMyMerchantAccounts(int page, int size, String loggedInUserId) {
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccount> failures = accountRepository.findByMerchantId(merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountResponse> productResponses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllAccountManagerMerchantAccounts(int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccount> failures = accountRepository.findByAccountManagerUserId(merchantAdmin.getUserId(),pageable);

        List<MerchantAccountResponse> productResponses = failures.stream().map(this::mapEntityToAccountResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantAccountById(long accountId) {

        MerchantAccount admin = accountRepository.findById(accountId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Account",110), HttpStatus.NOT_FOUND);
        }
        MerchantAccountResponse response = this.mapEntityToAccountResponse(admin);

        return   ResponseEntity.ok(response);

    }

    public ResponseEntity searchMerchantAccountHistoriesByMerchantName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountHistory> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            MerchantAccountHistoryType filter = MerchantAccountHistoryType.valueOf(request.getFilterValue());
            failures = merchantAccountHistoryRepository.findByHistoryTypeAndAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
    else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountHistoryRepository.findByAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountHistoryRepository.findByAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountHistoryRepository.findByAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountHistoryRepository.findByAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountHistoryRepository.findByAccountMerchantNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantAccountHistoryResponse> responses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity searchMerchantAccountHistoriesByMerchantId(String merchantId,SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountHistory> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            MerchantAccountHistoryType filter = MerchantAccountHistoryType.valueOf(request.getFilterValue());
            failures = merchantAccountHistoryRepository.findByHistoryTypeAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
    else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseOrSenderSurnameContainingIgnoreCaseOrReceiverFirstNameContainingIgnoreCaseOrReceiverSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountHistoryResponse> responses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetMerchantAccountHistoriesThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantAccountHistories(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findAll(pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantAccountHistoriesByMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountMerchantId(merchantId,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesByMerchantIdAndStatus(String merchantId,MerchantAccountHistoryType transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountMerchantIdAndHistoryType(merchantId,transactionType,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantAccountHistoriesByAccountId(long accountId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountId(accountId,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(startOfDay,endOfDay,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesThisWeekAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantId,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesTodayAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startOfDay,endOfDay,merchantId,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesThisMonthAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantId,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountHistoriesFromRangeAndMerchantId(String merchantId,String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantId,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity searchMerchantAccountHistoriesByMerchantId(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserMerchantUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountHistory> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            MerchantAccountHistoryType filter = MerchantAccountHistoryType.valueOf(request.getFilterValue());
            failures = merchantAccountHistoryRepository.findByHistoryTypeAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountHistoryRepository.findBySenderFirstNameContainingIgnoreCaseOrSenderSurnameContainingIgnoreCaseOrReceiverFirstNameContainingIgnoreCaseOrReceiverSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountHistoryResponse> responses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetMyMerchantAccountHistoriesByMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountMerchantId(merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountHistoriesByMerchantIdAndStatus(MerchantAccountHistoryType transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountMerchantIdAndHistoryType(merchantAdmin.getMerchant().getId(),transactionType,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountHistoriesThisWeekAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountHistoriesTodayAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startOfDay,endOfDay,merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountHistoriesThisMonthAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountHistoriesFromRangeAndMerchantId(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity searchAccountManagerMerchantAccountHistoriesByMerchantId(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserAccountManager(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountHistory> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            MerchantAccountHistoryType filter = MerchantAccountHistoryType.valueOf(request.getFilterValue());
            failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndHistoryTypeAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndHistoryTypeAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndHistoryTypeAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndHistoryTypeAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCase(merchantAdmin.getUserId(),request.getSearchQuery(),merchantAdmin.getUserId(),request.getSearchQuery(),merchantAdmin.getUserId(),request.getSearchQuery(),merchantAdmin.getUserId(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountHistoryResponse> responses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesByMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserId(merchantAdmin.getUserId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesByMerchantIdAndStatus(MerchantAccountHistoryType transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByAccountAccountManagerUserIdAndHistoryType(merchantAdmin.getUserId(),transactionType,pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesThisWeekAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountAccountManagerUserId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesTodayAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountAccountManagerUserId(startOfDay,endOfDay,merchantAdmin.getUserId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesThisMonthAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountAccountManagerUserId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesFromRangeAndMerchantId(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountHistory> failures = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountAccountManagerUserId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),pageable);

        List<MerchantAccountHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    
    ///////////////////////////////////////////////////////////////////Merchant Deposit Request//////////////////////////////
    public ResponseEntity approveMerchantDeposit(ChangeMerchantDepositStatusRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAccountDepositRequest depositRequest= merchantAccountDepositRequestRepository.findById(request.getRequestId()).orElse(null);
        if(depositRequest==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account Deposit Request",110), HttpStatus.NOT_FOUND);
        }
        if(depositRequest.getStatus().equals(DepositRequestStatus.APPROVED)){
            return new ResponseEntity<>(new GenericApiError("Merchant Account Deposit Request Already Aproved",110), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccount merchantAccount = depositRequest.getAccount();
        if(merchantAccount==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account",110), HttpStatus.EXPECTATION_FAILED);
        }
        double oldBalance= merchantAccount.getAccountBalance();
        double newBalance = merchantAccount.getAccountBalance()+ depositRequest.getAmount();
        MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
        merchantAccountHistory.setAccount(merchantAccount);
        merchantAccountHistory.setBalanceBefore(oldBalance);
        merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.DEPOSIT);
        merchantAccountHistory.setAmount(depositRequest.getAmount());
        merchantAccountHistory.setBalanceAfter(newBalance);
        merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
        merchantAccountHistoryRepository.save(merchantAccountHistory);
        merchantAccount.setAccountBalance(newBalance);
        accountRepository.save(merchantAccount);
        ////Update Request
        depositRequest.setStatus(DepositRequestStatus.APPROVED);
        depositRequest.setApprovedBy(loggedInUserId);
        depositRequest.setApprovedDate(LocalDateTime.now());
        merchantAccountDepositRequestRepository.save(depositRequest);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Account Deposit Request Approved Successfully"));
    }
    public ResponseEntity declineMerchantDeposit(ChangeMerchantDepositStatusRequest request, String loggedInUserId){
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAccountDepositRequest depositRequest= merchantAccountDepositRequestRepository.findById(request.getRequestId()).orElse(null);
        if(depositRequest==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account Deposit Request",110), HttpStatus.NOT_FOUND);
        }
        if(depositRequest.getStatus().equals(DepositRequestStatus.DECLINED)){
            return new ResponseEntity<>(new GenericApiError("Merchant Account Deposit Request Already Declined",110), HttpStatus.EXPECTATION_FAILED);
        }


        ////Update Request
        depositRequest.setStatus(DepositRequestStatus.DECLINED);
        depositRequest.setDeclinedBy(loggedInUserId);
        depositRequest.setDeclinedDate(LocalDateTime.now());
        merchantAccountDepositRequestRepository.save(depositRequest);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Account Deposit Request Declined Successfully"));
    }
    public ResponseEntity searchMerchantAccountDepositRequestsByMerchantName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountDepositRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantAccountDepositRequestRepository.findByStatusAndAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountDepositRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountDepositRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountDepositRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountDepositRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountDepositRequestRepository.findByAccountMerchantNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantAccountDepositRequestResponse> responses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity searchMerchantAccountDepositRequestsByMerchantId(String merchantId,SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountDepositRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_DEPOSIT_REQUEST_STATUS)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantAccountDepositRequestRepository.findByStatusAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrStatusAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),pageable);
        } else {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseOrAccountManagerSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountDepositRequestResponse> responses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetMerchantAccountDepositRequestsThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantAccountDepositRequests(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findAll(pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantAccountDepositRequestsByMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountMerchantId(merchantId,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsByMerchantIdAndStatus(String merchantId,DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountMerchantIdAndStatus(merchantId,transactionType,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsByStatus(DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByStatus(transactionType,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantAccountDepositRequestsByAccountId(long accountId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountId(accountId,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsThisWeekAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantId,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsTodayAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startOfDay,endOfDay,merchantId,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsThisMonthAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantId,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantAccountDepositRequestsFromRangeAndMerchantId(String merchantId,String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantId,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity searchMerchantAccountDepositRequestsByMerchantId(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserMerchantUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountDepositRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_DEPOSIT_REQUEST_STATUS)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantAccountDepositRequestRepository.findByStatusAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrStatusAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerFirstNameContainingIgnoreCaseOrAccountManagerSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountDepositRequestResponse> responses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetMyMerchantAccountDepositRequestsByMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountMerchantId(merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountDepositRequestsByMerchantIdAndStatus(DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountMerchantIdAndStatus(merchantAdmin.getMerchant().getId(),transactionType,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountDepositRequestsThisWeekAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountDepositRequestsTodayAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startOfDay,endOfDay,merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountDepositRequestsThisMonthAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantAccountDepositRequestsFromRangeAndMerchantId(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity searchAccountManagerMerchantAccountDepositRequestsByMerchantId(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserAccountManager(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantAccountDepositRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_DEPOSIT_REQUEST_STATUS)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndStatusAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndStatusAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndAccountManagerFirstNameContainingIgnoreCaseOrAccountManagerUserIdAndAccountManagerSurnameContainingIgnoreCase(merchantAdmin.getUserId(),request.getSearchQuery(),merchantAdmin.getUserId(),request.getSearchQuery(), pageable);
        }
        List<MerchantAccountDepositRequestResponse> responses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsByMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountManagerUserId(merchantAdmin.getUserId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsByMerchantIdAndStatus(DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByAccountManagerUserIdAndStatus(merchantAdmin.getUserId(),transactionType,pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsThisWeekAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountManagerUserId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsTodayAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountManagerUserId(startOfDay,endOfDay,merchantAdmin.getUserId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsThisMonthAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountManagerUserId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsFromRangeAndMerchantId(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantAccountDepositRequest> failures = merchantAccountDepositRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountManagerUserId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),pageable);

        List<MerchantAccountDepositRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountDepositRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }


    public MerchantAccountResponse mapEntityToAccountResponseWithoutMerchant(MerchantAccount merchantAccount){
        MerchantAccountResponse response = new MerchantAccountResponse();
        response.setId(merchantAccount.getId());
        if(merchantAccount.getMerchant()!=null){
            response.setMerchantId(merchantAccount.getMerchant().getId());
        }
        response.setAccountAlias(merchantAccount.getAccountAlias());
        response.setStatus(merchantAccount.getStatus());
        response.setAccountBalance(merchantAccount.getAccountBalance());
        return response;
    }
    public MerchantAccountResponse mapEntityToAccountResponse(MerchantAccount merchantAccount){
        MerchantAccountResponse response = new MerchantAccountResponse();
        response.setId(merchantAccount.getId());
        if(merchantAccount.getMerchant()!=null){
            response.setMerchant(merchantService.mapEntityToMerchantResponse(merchantAccount.getMerchant()));
        }
        response.setAccountAlias(merchantAccount.getAccountAlias());
        response.setStatus(merchantAccount.getStatus());
        response.setAccountBalance(merchantAccount.getAccountBalance());
        return response;
    }
    public MerchantAccountHistoryResponse mapEntityToAccountHistoryResponse(MerchantAccountHistory merchantAccount){
        MerchantAccountHistoryResponse response = new MerchantAccountHistoryResponse();
        response.setId(merchantAccount.getId());
        if(merchantAccount.getAccount()!=null){
            response.setAccount(this.mapEntityToAccountResponse(merchantAccount.getAccount()));
        }
        if(merchantAccount.getReceiver()!=null){
                response.setReceiver(userService.mapCustomerEntityToResponse(merchantAccount.getReceiver()));
        }
        if(merchantAccount.getSender()!=null){
                response.setSender(userService.mapCustomerEntityToResponse(merchantAccount.getSender()));
        }
        if(merchantAccount.getHistoryType()!=null){
            response.setTransactionType(merchantAccount.getHistoryType());
        }
        response.setBalanceAfter(merchantAccount.getBalanceAfter());
        response.setAmount(merchantAccount.getAmount());
        response.setBalanceBefore(merchantAccount.getBalanceBefore());
        if(merchantAccount.getDateOfEntry()!=null){
            response.setDateOfEntry(merchantAccount.getDateOfEntry().toString());
        }
       
        return response;
    }
    public MerchantAccountDepositRequestResponse mapEntityToAccountDepositRequestResponse(MerchantAccountDepositRequest merchantAccount){
        MerchantAccountDepositRequestResponse response = new MerchantAccountDepositRequestResponse();
        response.setId(merchantAccount.getId());
        if(merchantAccount.getAccount()!=null){
            response.setAccount(this.mapEntityToAccountResponse(merchantAccount.getAccount()));
        }
        if(merchantAccount.getApprovedBy()!=null){
            User user = userRepository.findById(merchantAccount.getApprovedBy()).orElse(null);
            if(user!=null){
                response.setApprovedBy(authenticationService.mapUserEntityToSpecificSummary(user));
            }

        }
        if(merchantAccount.getDeclinedBy()!=null){
            User user = userRepository.findById(merchantAccount.getDeclinedBy()).orElse(null);
            if(user!=null){
                response.setDeclinedBy(authenticationService.mapUserEntityToSpecificSummary(user));
            }

        }
        if(merchantAccount.getAccountManager()!=null){
                response.setAccountManager(userService.mapAccountManagerEntityToResponse(merchantAccount.getAccountManager()));
        }
        if(merchantAccount.getStatus()!=null){
            response.setStatus(merchantAccount.getStatus());
        }
        response.setAmount(merchantAccount.getAmount());
        if(merchantAccount.getCreatedAt()!=null){
            response.setDateOfEntry(merchantAccount.getCreatedAt().toString());
        }
        if(merchantAccount.getApprovedDate()!=null){
            response.setApprovedDate(merchantAccount.getApprovedDate().toString());
        }
        if(merchantAccount.getDeclinedDate()!=null){
            response.setDeclinedDate(merchantAccount.getDeclinedDate().toString());
        }
        return response;
    }

    private boolean isLoggedInUserBackendUserAndAccountManager(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        AccountManager accountManager = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null &&accountManager==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantUser(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserAccountManager(String loggedInUserId){
        AccountManager backendAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantCashier(String loggedInUserId){
        MerchantCashier backendAdmin = cashierRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
}
