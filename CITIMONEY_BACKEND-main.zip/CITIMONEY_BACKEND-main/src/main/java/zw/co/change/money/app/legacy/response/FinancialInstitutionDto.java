package zw.co.change.money.app.legacy.response;

import lombok.Data;

@Data
public class FinancialInstitutionDto extends BaseDto {
    private String institutionNumber;
    private String name;
    private String displayName;
    private boolean status;
    private boolean isMobileMoney;
}
