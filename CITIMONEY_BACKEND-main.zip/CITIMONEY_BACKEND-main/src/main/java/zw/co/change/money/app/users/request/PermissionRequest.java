package zw.co.change.money.app.users.request;
import lombok.Data;

import java.util.List;
@Data
public class PermissionRequest {
    private long permissionId;
    private List<Long> priviledges;
}
