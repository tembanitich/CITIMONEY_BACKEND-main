package com.digitalkrapht.subscription.users.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.merchants.model.Merchant;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "account_managers")
@Data
@EqualsAndHashCode(callSuper = true,exclude = {"accounts"})
@PrimaryKeyJoinColumn(name = "userId")
@DiscriminatorValue("7")
public class AccountManager extends User {
    @OneToMany(mappedBy="accountManager")
    private Set<MerchantAccount> accounts;

}
