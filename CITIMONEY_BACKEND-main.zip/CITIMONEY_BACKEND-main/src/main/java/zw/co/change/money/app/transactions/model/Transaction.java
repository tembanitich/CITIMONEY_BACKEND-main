package zw.co.change.money.app.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.users.model.MerchantCashier;
import zw.co.change.money.app.users.model.TellerUser;
import zw.co.change.money.app.users.model.User;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;

@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"merchant"})
@Data
@Table(name = "transactions")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Transaction extends UserDateAudit {
    @Id
    private String id;
    private String reference;
    private String approvalCode;
    private double amount;
    private double amountInUsd;
    private double baseExchangeRateUsed;
    private double merchantIncentiveUsed;
    private double totalExchangeRateUsed;
    private double changeAlreadyIssued;
    private double changeAlreadyIssuedInUsd;
    private double requiredChange;
    private double requiredChangeInUsd;
    private String destinationAccount;
    private String senderAccount;
    private double transactionCharge;
    private double transactionChargeInUsd;
    private String notificationMsisdn;
    @Enumerated(EnumType.STRING)
    private TransactionType transactionType;
    @Enumerated(EnumType.STRING)
    private TransactionStatus status;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Merchant merchant;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sender")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserCustomer sender;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receiver")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserCustomer receiver;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchantBranch")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantBranch merchantBranch;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private UserCustomer customer;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "teller")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private TellerUser teller;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cashier")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantCashier cashier;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "currency")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Currency currency;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "financialInstitution")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private FinancialInstitution financialInstitution;
}
