package zw.co.change.money.app.accounts.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.accounts.model.AccountMerchantAssignmentHistory;

public interface AccountMerchantAssignmentHistoryRepository  extends JpaRepository<AccountMerchantAssignmentHistory, Long> {
}
