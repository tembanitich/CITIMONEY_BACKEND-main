package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.users.response.UserCustomerResponse;
@Data
public class CheckTransferResponse {
    private UserCustomerResponse receiver;
    private double amount;
    private String reference;
    private double customerBalance;
}
