package zw.co.change.money.app.variables.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.variables.request.TCRequest;
import zw.co.change.money.app.variables.request.AppVariableRequest;
import zw.co.change.money.app.variables.request.SmsConfigRequest;
import zw.co.change.money.app.variables.service.AppVariableService;
import zw.co.change.money.app.variables.service.SmsConfigService;
import zw.co.change.money.app.variables.service.TermsAndCOnditionsService;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/admin/configurables")
public class ConfigurablesController {


    @Autowired
    AppVariableService appVariableService;
    @Autowired
    SmsConfigService smsConfigService;
    @Autowired
    TermsAndCOnditionsService tcService;


    //===App Variables
    @PostMapping("/app/update")
   
    public ResponseEntity UpdateOrAddAppVariables(@Valid @RequestBody AppVariableRequest appVariableRequest) {
        
        return appVariableService.UpdateOrCreateAppVariable(appVariableRequest);
    }

    @GetMapping("/app/changeStatus/{code}/{status}")
   
    public ResponseEntity changeStatusAppVariable(@PathVariable String code,@PathVariable boolean status) {
        
        return appVariableService.changeStatusAppVariable(code,status);
    }

    @GetMapping("/app")
   
    public ResponseEntity getAllAppVariables() {
        
        return appVariableService.GetAllAppVariables();
    }

    //===SMS Config
    @PostMapping("/sms/update")
   
    public ResponseEntity UpdateOrAddSmsConfigs(@Valid @RequestBody SmsConfigRequest smsConfigRequest) {
        
        return smsConfigService.AddSmsConfig(smsConfigRequest);
    }

    @GetMapping("/sms/changeStatus/{code}/{status}")
   
    public ResponseEntity changeStatusSms(@PathVariable String code,@PathVariable boolean status) {
        
        return smsConfigService.changeSmsConfigStatus(code,status);
    }

    @GetMapping("/sms")
   
    public ResponseEntity getAllSmsConfigs() {
        
        return smsConfigService.GetAllSmsConfigs();
    }



    //    Terms And Conditions
    @PostMapping("/tc/add")
   
    public ResponseEntity AddTc(@Valid @RequestBody TCRequest request) {
        
        return tcService.addTC(request);
    }

    @PostMapping("/tc/update")
   
    public ResponseEntity UpdateTc(@Valid @RequestBody TCRequest request) {
        
        return tcService.updateTC(request);
    }

    @GetMapping("/tc/active")
   
    public ResponseEntity GetActive() {
        
        return tcService.getActiveTc();
    }
}

