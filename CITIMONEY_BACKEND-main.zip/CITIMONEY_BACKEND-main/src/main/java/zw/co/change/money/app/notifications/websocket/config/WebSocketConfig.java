package zw.co.change.money.app.notifications.websocket.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import zw.co.change.money.app.security.jwt.JwtTokenProvider;
import zw.co.change.money.app.security.user.CustomUserDetailsService;

@Configuration
// Enable WebSocket's message broker
@EnableWebSocketMessageBroker
public class WebSocketConfig implements WebSocketMessageBrokerConfigurer {
    @Autowired
    private JwtTokenProvider tokenProvider;
    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    /**
     * Register STOMP's endpoint
     * We don't need to implement WebSocketHandler, STOMP has done this thing.
     * <p>
     */
    @Override
    public void registerStompEndpoints(StompEndpointRegistry stompEndpointRegistry) {
        // Register the endpoint of STOMP, and use SockJS protocol
        stompEndpointRegistry.addEndpoint("/ws")
                .setAllowedOrigins("http://localhost:4200","https://digitalkrapht.com")
                .addInterceptors(new HandshakeInterceptor()).withSockJS();
    }

    /**
     * Configure message broker
     * <p>
     *
     * @param registry message broker registry
     */
    @Override
    public void configureMessageBroker(MessageBrokerRegistry registry) {
        // Configure global message broker, client will subscribe these message brokers to receive messages
        registry.enableSimpleBroker("/b", "/g", "/user","/notifications","/exchangeRate","/customerChatMessages");
        //Configure Application
        registry.setApplicationDestinationPrefixes("/app");
        // configure point to point message's prefix
        registry.setUserDestinationPrefix("/user");
    }

    @Override
    public void configureClientInboundChannel(ChannelRegistration registration) {
        registration.interceptors(new CustomChannelInterceptor(this.tokenProvider,this.customUserDetailsService));
    }

//    @Configuration
//    public class WebSocketSecurityConfig extends AbstractSecurityWebSocketMessageBrokerConfigurer {
//
////    @Override
////    protected void configureInbound(MessageSecurityMetadataSourceRegistry messages) {
////        messages.simpTypeMatchers(CONNECT, UNSUBSCRIBE, DISCONNECT, HEARTBEAT).permitAll()
////                .simpSubscribeDestMatchers("/notifications/**").authenticated()
////                .anyMessage().authenticated();
////    }
//
//    }
}