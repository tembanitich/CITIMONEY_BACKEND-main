package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.users.model.MerchantAdmin;
import zw.co.change.money.app.users.model.MerchantCashier;
import zw.co.change.money.app.users.response.CustomerTransactionTotalInterface;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MerchantCashierRepository extends JpaRepository<MerchantCashier, String> {
    Optional<MerchantCashier> findByMobileNumber(String mobileNumber);
    Optional<MerchantCashier> findByCode(String code);
    Boolean existsByCode(String code);
    List<MerchantCashier> findByEnabled(boolean status);
    List<MerchantCashier> findByMerchantBranchId(long branchId);
    List<MerchantCashier> findByMerchantBranchMerchantId(String branchId);
    Page<MerchantCashier> findByMerchantBranchId(long branchId, Pageable pageable);
    Page<MerchantCashier> findByEnabled(boolean status, Pageable pageable);
    List<MerchantCashier> findByEnabledAndMerchantBranchMerchantId(boolean status,String merchantId);
    Page<MerchantCashier> findByEnabledAndMerchantBranchMerchantId(boolean status,String merchantId, Pageable pageable);
    Page<MerchantCashier> findByMerchantBranchMerchantId(String merchantId, Pageable pageable);
    Page<MerchantCashier> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd,String merchantId2, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<MerchantCashier> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndEnabled(String merchantId,String  firstName, boolean status,String merchantId2, String  surname, boolean status2, Pageable pageable);
    Page<MerchantCashier> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(String merchantId,String  firstName,String merchantId2,String  surname, Pageable pageable);


    List<MerchantCashier> findByEnabledAndMerchantBranchId(boolean status,long merchantId);
    Page<MerchantCashier> findByEnabledAndMerchantBranchId(boolean status,long merchantId, Pageable pageable);
    Page<MerchantCashier> findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long merchantId,String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd,long merchantId2, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<MerchantCashier> findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantBranchIdAndSurnameContainingIgnoreCaseAndEnabled(long merchantId,String  firstName, boolean status,long merchantId2, String  surname, boolean status2, Pageable pageable);
    Page<MerchantCashier> findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseOrMerchantBranchIdAndSurnameContainingIgnoreCase(long merchantId,String  firstName,long merchantId2,String  surname, Pageable pageable);

    List<MerchantCashier> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(String merchantId, String  firstName, String merchantId2, String  surname);
    List<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantId(String  firstName, boolean status,String merchantId, String  surname, boolean status2,String merchantId2);

    List<MerchantCashier> findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseOrMerchantBranchIdAndSurnameContainingIgnoreCase(long merchantId, String  firstName, long merchantId2, String  surname);
    List<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchId(String  firstName, boolean status,long merchantId, String  surname, boolean status2,long merchantId2);

    List<MerchantCashier> findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<MerchantCashier> findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);

    Long countByEnabled(boolean status);
    Long countByMerchantBranchMerchantId(String merchantId);
    Long countByMerchantBranchId(long branchId);
    Long countByEnabledAndMerchantBranchMerchantId(boolean status,String merchantId);
    Long countByEnabledAndMerchantBranchId(boolean status,long branchId);
    Page<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    List<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname);
    List<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndMerchantBranchId(String  firstName,long branchId,String  surname,long branchId2);
    Page<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndMerchantBranchId(String  firstName,long branchId,String  surname,long branchId2, Pageable pageable);
    Page<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<MerchantCashier> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status, String  surname, boolean status2, Pageable pageable);
    @Query(value ="select po.user_id as id,po.code as name, sum(p.amount_in_usd) as total from transactions p inner join merchant_cashier_users po on p.cashier = po.user_id WHERE p.status='SUCCESS' group by po.user_id order by total desc LIMIT 10", nativeQuery = true)
    List<CustomerTransactionTotalInterface> getTop10Cashiers();
    @Query(value ="select po.user_id as id,po.code as name, sum(p.amount_in_usd) as total from transactions p inner join merchant_cashier_users po on p.cashier = po.user_id WHERE p.status='SUCCESS' and p.merchant=:merchantId group by po.user_id order by total desc LIMIT 10", nativeQuery = true)
    List<CustomerTransactionTotalInterface> getTop10CashiersByMerchantId(@Param("merchantId") String merchantId);
}