package zw.co.change.money.app.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.authentication.request.CustomerSignUpRequest;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.request.*;
import zw.co.change.money.app.ussd.request.UssdCustomerSignUpRequest;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.response.GenericApiError;

@Service
public class ValidateUserProperties {

    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    UserBrandAmbassadorRepository userBrandAmbassadorRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    MerchantCashierRepository merchantCashierRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    MerchantRepository merchantRepository;
    @Autowired
    MerchantBranchRepository merchantBranchRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;

    public ResponseEntity isValidAddMerchantUserRequest(AddMerchantUserRequest request){
        Merchant fuelDealer = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateMerchantUserRequest(UpdateMerchantUserRequest request){
        Merchant fuelDealer = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
        }
        MerchantAdmin userBackendAgent = merchantAdminRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }

    public ResponseEntity isValidAddMerchantCashierRequest(AddMerchantCashierRequest request){
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantCashier admin2 = merchantCashierRepository.findByMobileNumber(request.getContactMobileNumber()).orElse(null);
        if(admin2!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Number Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateMerchantCashierRequest(UpdateMerchantCashierRequest request){
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        MerchantCashier userBackendAgent = merchantCashierRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }

    public ResponseEntity isValidAddAccountManagerRequest(AddAccountManagerRequest request){

        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateAccountManagerRequest(UpdateAccountManagerRequest request){

        AccountManager userBackendAgent = accountManagerRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidAssignMerchantAccountManagerRequest(AccountManagerAssignMerchantRequest request){

        AccountManager userBackendAgent = accountManagerRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load Merchant",110), HttpStatus.NOT_FOUND);
        }

        return ResponseEntity.ok(true);
    }

    public ResponseEntity isValidAddBranchManagerRequest(AddBranchManagerRequest request){
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateBranchManagerRequest(UpdateBranchManagerRequest request){
        MerchantBranch fuelDealer = merchantBranchRepository.findById(request.getBranchId()).orElse(null);
        if(fuelDealer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",110), HttpStatus.NOT_FOUND);
        }
        BranchManager userBackendAgent = branchManagerRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }

    public ResponseEntity isValidAddBackendAdminRequest(AddBackendAdminRequest request){
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateBackendAdminRequest(UpdateBackendAdminRequest request){
        UserBackendAdmin userBackendAgent = userBackendAdminRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidAddBackendAgentRequest(AddBackendAgentRequest request){
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateBackendAgentRequest(UpdateBackendAgentRequest request){
        UserBackendAgent userBackendAgent = userBackendAgentRepository.findById(request.getUserId()).orElse(null);
        if(userBackendAgent==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidBackendUpdateProfileRequest(BackendUpdateProfileRequest request, String userId){
        UserBackendAgent userBackendAgent = userBackendAgentRepository.findById(userId).orElse(null);
        UserBackendAdmin userBackendAdmin = userBackendAdminRepository.findById(userId).orElse(null);
        if(userBackendAgent==null && userBackendAdmin==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load User",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if(admin!=null && !admin.getUserId().equals(userBackendAgent.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidAddCustomerRequest(AddCustomerRequest request){
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()!=null&& !request.getEmail().toLowerCase().isEmpty()) {
            User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if (admin != null) {
                return new ResponseEntity<>(new GenericApiError("Another Customer with Same Email Already Exists", 104), HttpStatus.EXPECTATION_FAILED);
            }
        }

            User admin = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
            if (admin != null) {
                return new ResponseEntity<>(new GenericApiError("Another User  with Same Phone Number Already Exists", 104), HttpStatus.EXPECTATION_FAILED);
            }

        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidAddBrandAmbassadorRequest(AddBrandAmbassadorRequest request){
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()!=null&& !request.getEmail().toLowerCase().isEmpty()) {
            User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if (admin != null) {
                return new ResponseEntity<>(new GenericApiError("Another Customer with Same Email Already Exists", 104), HttpStatus.EXPECTATION_FAILED);
            }
        }

            User admin = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
            if (admin != null) {
                return new ResponseEntity<>(new GenericApiError("Another User  with Same Phone Number Already Exists", 104), HttpStatus.EXPECTATION_FAILED);
            }

        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidAddTellerRequest(AddTellerRequest request){
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()!=null&& !request.getEmail().toLowerCase().isEmpty()) {
            User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if (admin != null) {
                return new ResponseEntity<>(new GenericApiError("Another Customer with Same Email Already Exists", 104), HttpStatus.EXPECTATION_FAILED);
            }
        }

            User admin = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
            if (admin != null) {
                return new ResponseEntity<>(new GenericApiError("Another User  with Same Phone Number Already Exists", 104), HttpStatus.EXPECTATION_FAILED);
            }

        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidSignUpCustomerRequest(CustomerSignUpRequest request){
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getPassword()==null || request.getPassword().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Password cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getPassword().length()<6){
            return new ResponseEntity<>(new GenericApiError("Password is Too short must be 6 characters or more",103), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(userRepository.existsByUsername(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is already registered",110), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUssdSignUpCustomerRequest(String mobileNumber){

        if(mobileNumber==null || mobileNumber.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }


        if(!formatUtility.isValidPhoneNumber(mobileNumber)){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(userRepository.existsByUsername(mobileNumber)){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is already registered",110), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateCustomerRequest(UpdateCustomerRequest request){
        UserCustomer userCustomer = userCustomerRepository.findById(request.getUserId()).orElse(null);
        if(userCustomer==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load Customer",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }

        User customer = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
        if(customer!=null && !customer.getUserId().equals(userCustomer.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Mobile Number Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()!=null&& !request.getEmail().toLowerCase().isEmpty()){
            if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
                return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
            }
            User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if(admin!=null && !admin.getUserId().equals(userCustomer.getUserId())){
                return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateBrandAmbassadorRequest(UpdateBrandAmbassadorRequest request){
        UserBrandAmbassador userCustomer = userBrandAmbassadorRepository.findById(request.getUserId()).orElse(null);
        if(userCustomer==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load Brand Ambassador",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }

        User customer = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
        if(customer!=null && !customer.getUserId().equals(userCustomer.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Mobile Number Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()!=null&& !request.getEmail().toLowerCase().isEmpty()){
            if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
                return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
            }
            User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if(admin!=null && !admin.getUserId().equals(userCustomer.getUserId())){
                return new ResponseEntity<>(new GenericApiError("Another Brand Ambassador with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUpdateTellerRequest(UpdateTellerRequest request){
        UserCustomer userCustomer = userCustomerRepository.findById(request.getUserId()).orElse(null);
        if(userCustomer==null){
            return new ResponseEntity<>(new GenericApiError("Could not Load Customer",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }

        User customer = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
        if(customer!=null && !customer.getUserId().equals(userCustomer.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Mobile Number Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()!=null&& !request.getEmail().toLowerCase().isEmpty()){
            if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
                return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
            }
            User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if(admin!=null && !admin.getUserId().equals(customer.getUserId())){
                return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidClientUpdateProfileRequest(ClientUpdateProfileRequest request,String userId){
        UserCustomer userCustomer = userCustomerRepository.findById(userId).orElse(null);

        if(userCustomer==null ){
            return new ResponseEntity<>(new GenericApiError("Could not Load Customer",110), HttpStatus.NOT_FOUND);
        }
        if(request.getFirstName()==null || request.getFirstName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("First Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSurname()==null || request.getSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getEmail().toLowerCase()==null || request.getEmail().toLowerCase().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidEmail(request.getEmail().toLowerCase())){
            return new ResponseEntity<>(new GenericApiError("Email is not valid",106), HttpStatus.EXPECTATION_FAILED);
        }
        User admin = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        User customer = userRepository.findByUsername(request.getMobileNumber()).orElse(null);
        if(customer!=null && !customer.getUserId().equals(userCustomer.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Mobile Number Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        if(admin!=null && !admin.getUserId().equals(userCustomer.getUserId())){
            return new ResponseEntity<>(new GenericApiError("Another MerchantAccount with Same Email Already Exists",104), HttpStatus.EXPECTATION_FAILED);
        }
        return ResponseEntity.ok(true);
    }
    public ResponseEntity isValidUserProfileUpdateRequest(UpdateUserRequest request, String userId) {

        if (!userRepository.existsById(userId)) {
            return new ResponseEntity<>(new GenericApiError("Could not load User",110), HttpStatus.NOT_FOUND);
        }

//
        //=== headquartersEmail
        if (!formatUtility.isValidEmail(request.getEmail().toLowerCase())) {
            return new ResponseEntity<>(new GenericApiError("Invalid Email Address",106), HttpStatus.EXPECTATION_FAILED);
        }

        User userByEmail = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
        if (userByEmail != null && !userByEmail.getUserId().equalsIgnoreCase(userId)) {
            return new ResponseEntity<>(new GenericApiError("Email Address Already In Use",104), HttpStatus.EXPECTATION_FAILED);
        }



        return new ResponseEntity<>(true, HttpStatus.OK);
    }
    public ResponseEntity isValidClientProfileUpdateRequest(UpdateClientRequest request, String userId) {

        if (!userRepository.existsById(userId)) {
            return new ResponseEntity<>(new GenericApiError("Could not load User",110), HttpStatus.NOT_FOUND);
        }

//
        //=== headquartersEmail
        if(request.getEmail().toLowerCase()!=null && !request.getEmail().toLowerCase().isEmpty()){
            if (!formatUtility.isValidEmail(request.getEmail().toLowerCase())) {
                return new ResponseEntity<>(new GenericApiError("Invalid Email Address",106), HttpStatus.EXPECTATION_FAILED);
            }
            User userByEmail = userRepository.findByEmail(request.getEmail().toLowerCase()).orElse(null);
            if (userByEmail != null && !userByEmail.getUserId().equalsIgnoreCase(userId)) {
                return new ResponseEntity<>(new GenericApiError("Email Address Already In Use",104), HttpStatus.EXPECTATION_FAILED);
            }
        }




        if(request.getMobileNumber()==null || request.getMobileNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMobileNumberCountryCode()==null || request.getMobileNumberCountryCode().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Mobile Number Country Code cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is Invalid",107), HttpStatus.EXPECTATION_FAILED);
        }

        return new ResponseEntity<>(true, HttpStatus.OK);
    }
}
