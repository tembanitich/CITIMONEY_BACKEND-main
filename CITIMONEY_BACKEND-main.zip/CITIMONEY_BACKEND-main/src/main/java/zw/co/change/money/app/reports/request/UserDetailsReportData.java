package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class UserDetailsReportData {
    private String username;
    private String email;
    private String address;
    private String mobileNumber;
    private LocalDateTime lastLogin;
    private long numberOfTransaction;
    private LocalDateTime lastPaymentDate;
}
