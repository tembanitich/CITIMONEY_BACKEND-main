package zw.co.change.money.app.currencies.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.currencies.request.AddCurrencyRequest;
import zw.co.change.money.app.currencies.request.UpdateCurrencyRequest;
import zw.co.change.money.app.currencies.request.UpdateExchangeRateRequest;
import zw.co.change.money.app.currencies.request.UpdateMerchantIncentiveRequest;
import zw.co.change.money.app.currencies.service.CurrencyService;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.util.model.SearchRequest;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/currencies")
public class CurrencyController {
    @Autowired
    CurrencyService productService;
    ////////////////////////////////////////////////////////////////////////////////Fuel Dealers////////////////////////////////////////////////////////////////////////////////////
    @PostMapping(value="/add")
    @Operation(description="add Currency")
    public ResponseEntity addCurrency(@Valid @RequestBody AddCurrencyRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.addCurrency(request);
    }

    @PostMapping("/update")
    @Operation(description="update Fuel Dealer")
    public ResponseEntity updateCurrency(@Valid @RequestBody UpdateCurrencyRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateCurrency(request);
    }
    @PostMapping("/search/byName")
    @Operation(description="Search Currency")
    public ResponseEntity searchCurrenciesByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchCurrenciesByName(request,currentUser.getUserId());
    }
    @GetMapping("/activation/{institutionNumber}/{status}")
    @Operation(description="Activate/Deactivate Currency")
    public ResponseEntity ActivateOrDeactivateCurrency(@PathVariable String institutionNumber, @PathVariable Boolean status){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.ActivateOrDeactivateCurrency(institutionNumber,status,currentUser.getUserId());
    }
    @GetMapping("/view/active")
    public ResponseEntity getActiveCurrencies() {
        return productService.getActiveCurrencies();
    }
    @GetMapping("/view/all")
    public ResponseEntity getAllCurrencies(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAllCurrencies(page, size,currentUser.getUserId());
    }
    @GetMapping("/view/byStatus/{status}")
    public ResponseEntity getCurrenciesByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getCurrenciesByStatus(status,page, size);
    }
    @GetMapping("/view/byCurrencyCode/{code}")
    public ResponseEntity getCurrencyByCode(@PathVariable String code) {
        return productService.getCurrencyByCode(code);
    }
//////////////////////////////////////////////////////Exchange rates///////////////////////////////////////////
    @PostMapping(value="/exchangeRate/update")
    @Operation(description="Update Global Currency")
    public ResponseEntity updateExchangeRate(@Valid @RequestBody UpdateExchangeRateRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateExchangeRate(request,currentUser.getUserId());
    }
    @GetMapping("/exchangeRate/view/current")
    public ResponseEntity getCurrentExchangeRates() {
        return productService.getCurrentExchangeRates();


    }
    //////////////////////////////////////////////////Incentives////////////////////////////////////////////////////////
    @PostMapping(value="/incentives/update")
    @Operation(description="Update Merchant Incentive")
    public ResponseEntity updateMerchantIncentive(@Valid @RequestBody UpdateMerchantIncentiveRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateMerchantIncentive(request,currentUser.getUserId());
    }
    @PostMapping(value="/incentives/search/me")
    @Operation(description="Search Merchant Incentive")
    public ResponseEntity searchMyMerchantIncentivesByCurrency(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMyMerchantIncentivesByCurrency(request,currentUser.getUserId());
    }
    @PostMapping(value="/incentives/search")
    @Operation(description="Search Merchant Incentive")
    public ResponseEntity searchMerchantIncentivesByCurrency(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantIncentivesByCurrency(request,currentUser.getUserId());
    }
    @GetMapping("/incentives/view/me")
    public ResponseEntity getMyMerchantIncentivesByMerchantId(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getMyMerchantIncentivesByMerchantId(page, size,currentUser.getUserId());
    }
    @GetMapping("/incentives/view/all")
    public ResponseEntity getAllMerchantIncentives(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAllMerchantIncentives(page, size,currentUser.getUserId());
    }
    @GetMapping("/incentives/view/byMerchantId/{merchantId}")
    public ResponseEntity getMerchantIncentivesByMerchantId(@PathVariable String merchantId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getMerchantIncentivesByMerchantId(merchantId,page, size,currentUser.getUserId());
    }
}
