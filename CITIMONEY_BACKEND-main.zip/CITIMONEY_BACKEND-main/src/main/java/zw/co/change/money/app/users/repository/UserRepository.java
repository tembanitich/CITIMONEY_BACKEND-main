package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.users.model.User;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
    Optional<User> findByEmail(String email);

    Optional<User> findByUsernameOrEmail(String username, String email);
    Optional<User> findByUsername(String username);

    Optional<User> findByTokenHash(String tokenHash);

    Boolean existsByUsername(String username);

    Boolean existsByTokenHash(String tokenHash);


    Boolean existsByEmail(String email);

    Page<User> findByRolesIn(List<Role> roles, Pageable pageable);
    List<User> findByRolesIn(List<Role> roles);
    List<User> findByMessageGroup(WebSocketMessageGroup group);
    List<User> findByRolesInAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(List<Role> roles, LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<User> findByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String query,String query2, Pageable pageable);
    Page<User> findByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String query,boolean status,String query2,boolean status2, Pageable pageable);
    List<User> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<User> findByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String query,LocalDateTime dayStart, LocalDateTime dayEnd,String query2,LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);

}