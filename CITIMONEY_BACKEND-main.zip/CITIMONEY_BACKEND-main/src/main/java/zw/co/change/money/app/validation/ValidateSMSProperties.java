package zw.co.change.money.app.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.response.GenericApiError;

@Service
public class ValidateSMSProperties {
    @Autowired
    FormatUtility formatUtility;
    public ResponseEntity isValidSearchRequest(SearchRequest request){
        if(!request.getSearchFilter().equals(SearchFilter.ALL)&&!request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)&&!request.getSearchFilter().equals(SearchFilter.TODAY) &&!request.getSearchFilter().equals(SearchFilter.THIS_WEEK) &&!request.getSearchFilter().equals(SearchFilter.THIS_MONTH)){
            return new ResponseEntity<>(new GenericApiError("Filter Is Not Allowed For This Search",122), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchFilter().equals(SearchFilter.BY_ACTIVATION_STATUS)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Filter value cannot be empty",105),HttpStatus.EXPECTATION_FAILED);
            }
        }
        if(request.getSize()==0){
            return new ResponseEntity<>(new GenericApiError("Page Size cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchFilter()==null){
            return new ResponseEntity<>(new GenericApiError("Search Filter cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchQuery()==null || request.getSearchQuery().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Search Query cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            } if(request.getFilterValueMax()==null || request.getFilterValueMax().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Max Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid Start Date",108), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid End Date",108), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
}
