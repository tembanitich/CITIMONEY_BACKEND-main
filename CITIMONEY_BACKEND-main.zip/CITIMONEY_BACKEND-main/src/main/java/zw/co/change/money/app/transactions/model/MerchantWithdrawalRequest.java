package zw.co.change.money.app.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.users.model.AccountManager;
import zw.co.change.money.app.users.model.MerchantAdmin;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.time.LocalDateTime;
@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"account"})
@Data
@Table(name = "merchant_withdrawal_requests")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantWithdrawalRequest extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "account")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantAccount account;
    @Enumerated(EnumType.STRING)
    private DepositRequestStatus status;
    private double amount;

    private String completedBy;
    private LocalDateTime completedDate;

    private String approvalCode;
    private String approvedBy;
    private String declinedBy;
    private LocalDateTime declinedDate;
    private LocalDateTime approvedDate;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "requestedBy")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantAdmin requestedBy;

}
