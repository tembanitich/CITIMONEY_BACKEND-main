package zw.co.change.money.app.variables.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import zw.co.change.money.app.variables.model.AppVariable;

import java.util.Optional;

@Repository
@Transactional
public interface AppVariableRepository extends JpaRepository<AppVariable, Long> {

    AppVariable findByCodeAndActive(String code, Boolean active);
    Optional<AppVariable> findByCode(String code);

    Boolean existsByCode(String code);

    Boolean existsByCodeAndActive(String code, Boolean status);

    @Modifying
    @Query(value = "SET GLOBAL max_allowed_packet=1073741824;", nativeQuery = true)
    public void expandPacketSizeAllowedByMysqlDatabase();
}
