package zw.co.change.money.app.statistics.controller;


import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.statistics.service.StatisticsService;

@RestController
@RequestMapping("/api/statistics")
public class StatisticsController {
    @Autowired
    StatisticsService campaignService;

    @GetMapping("/view/dashboard/")
    @Operation(description="view Home Dashboard")
    public ResponseEntity getDashboard() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return campaignService.getDashboard(currentUser.getUserId());
    }
}
