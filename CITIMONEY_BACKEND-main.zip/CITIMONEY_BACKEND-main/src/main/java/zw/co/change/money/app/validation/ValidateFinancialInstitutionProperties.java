package zw.co.change.money.app.validation;

import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.financialInstitutions.request.AddFinancialInstitutionRequest;
import zw.co.change.money.app.financialInstitutions.request.UpdateFinancialInstitutionRequest;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
@Service
public class ValidateFinancialInstitutionProperties {
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private FinancialInstitutionRepository financialInstitutionRepository;
    public ResponseEntity isValidSearchRequest(SearchRequest request){

        if(request.getSize()==0){
            return new ResponseEntity<>(new GenericApiError("Page Size cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchFilter()==null){
            return new ResponseEntity<>(new GenericApiError("Search Filter cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchQuery()==null || request.getSearchQuery().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Search Query cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }


        if(request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Payment Id",105), HttpStatus.EXPECTATION_FAILED);
            }
            try{
                TransactionStatus.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Status",110),HttpStatus.NOT_FOUND);
            }

        }
        if(request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Payment Id",105), HttpStatus.EXPECTATION_FAILED);
            }
            try{
                TransactionType.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method",110),HttpStatus.NOT_FOUND);
            }

        }
        if(request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            } if(request.getFilterValueMax()==null || request.getFilterValueMax().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Max Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid Start Date",108), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid End Date",108), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity validateAddFinancialInstitutionRequest(AddFinancialInstitutionRequest request){

        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("FinancialInstitution cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getDisplayName()==null || request.getDisplayName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Display Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getUrl()==null || request.getUrl().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Url cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
    public  ResponseEntity validateUpdateFinancialInstitutionRequest(UpdateFinancialInstitutionRequest request){
        FinancialInstitution merchant = financialInstitutionRepository.findByInstitutionNumber(request.getInstitutionNumber()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load FinancialInstitution",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Financial Institution cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getDisplayName()==null || request.getDisplayName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Display Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getUrl()==null || request.getUrl().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Url cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }


        return ResponseEntity.ok(true);
    }
}
