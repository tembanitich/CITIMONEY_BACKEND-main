package zw.co.change.money.app.accounts.model;

public enum MerchantAccountStatus {
    ACTIVE,CLOSED,BLOCKED
}
