package zw.co.change.money.app.users.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.util.audit.UserDateAudit;
import zw.co.change.money.app.security.roles.model.Permission;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Collection;

@Entity
@Table(name = "users", uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "username"
        }),
        @UniqueConstraint(columnNames = {
                "email"
        })
})

@Data
@EqualsAndHashCode(callSuper = true)
@DiscriminatorValue("0")
@Inheritance(strategy = InheritanceType.JOINED)
public class User extends UserDateAudit {
    @Id
    private String userId;

    //=== base user
    private String firstName;
    private String loginChannel;
    private LocalDateTime lastLogin;
    private long loginCount;
    private long pinTryCount=0;
    private Boolean enabled = true;
    private Boolean blocked = false;

    private Boolean resetPin = true;
    private String surname;
    private WebSocketMessageGroup messageGroup;
    private String email;
    @Enumerated(EnumType.STRING)
    private Gender gender = Gender.NOT_SET;
    private String contactMobileNumber;
    private String contactMobileNumberCountryCode;
    //=== security
    private String username;
    private String password;
    private String tokenHash = "default";
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "users_roles", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "userId"),
            inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
    private Collection<Role> roles;

    @ManyToMany
    @JoinTable(name = "user_privileges", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "userId"),
            inverseJoinColumns = @JoinColumn(name = "privilege_id", referencedColumnName = "id"))
    private Collection<Privilege> privileges;

    @ManyToMany
    @JoinTable(name = "user_permissions", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "userId"),
            inverseJoinColumns = @JoinColumn(name = "permission_id", referencedColumnName = "id"))
    private Collection<Permission> permissions;


}
