package zw.co.change.money.app.legacy.response;

import lombok.Data;

@Data
public class CurrencyDto extends BaseDto {
    private String currencyCode;
    private String currencyName;
    private double exchangeRate;
}
