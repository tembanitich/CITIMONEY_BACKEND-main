package zw.co.change.money.app.notifications.websocket.response;

public enum ResponseType {
   CHAT, ORDER_REQUEST,NOTIFICATION,REMOVE_ORDER,ORDER_DISPATCH_REQUEST,ORDER_STATUS,NONE
}
