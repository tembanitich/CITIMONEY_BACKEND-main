package zw.co.change.money.app.documents.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.documents.model.MerchantProofOfResidenceDocument;
import zw.co.change.money.app.documents.model.MerchantTaxClearanceDocument;

import java.util.Optional;

public interface MerchantTaxClearanceDocumentRepository extends JpaRepository<MerchantTaxClearanceDocument, Long> {
    Optional<MerchantTaxClearanceDocument> findByMerchantId(String  merchantId);

}
