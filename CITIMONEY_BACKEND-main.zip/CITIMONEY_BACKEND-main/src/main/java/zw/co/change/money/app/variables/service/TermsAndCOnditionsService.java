package zw.co.change.money.app.variables.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.variables.repository.TermsAndConditionsRepository;
import zw.co.change.money.app.variables.request.TCRequest;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.variables.model.TermsAndConditions;

@Service
public class TermsAndCOnditionsService {
    @Autowired
    TermsAndConditionsRepository repository;

    public ResponseEntity addTC(TCRequest request) {
        TermsAndConditions tc = new TermsAndConditions();
        tc.setDescription(request.getDescription());
        repository.save(tc);
        return ResponseEntity.ok(new GenericApiResponse("Terms saved"));
    }

    public ResponseEntity updateTC(TCRequest request) {
        TermsAndConditions tc = repository.findById(request.getId()).orElse(null);
        if (tc == null) {
            return new ResponseEntity<>(new GenericApiError("Failed to load terms",110), HttpStatus.EXPECTATION_FAILED);
        }
        tc.setDescription(request.getDescription());
        repository.save(tc);
        return ResponseEntity.ok(new GenericApiResponse("Terms updated"));
    }

    public ResponseEntity getActiveTc() {
        return ResponseEntity.ok(repository.findByEnabled(true));
    }
}
