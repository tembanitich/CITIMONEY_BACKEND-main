package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class SmsMessageReportData {
    private String message;
    private String receiverPhoneNumber;
    private LocalDateTime date;
}
