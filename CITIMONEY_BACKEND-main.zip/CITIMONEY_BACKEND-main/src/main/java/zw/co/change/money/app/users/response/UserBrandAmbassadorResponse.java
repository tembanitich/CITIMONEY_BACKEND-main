package zw.co.change.money.app.users.response;

import lombok.Data;
import zw.co.change.money.app.security.roles.response.PermissionResponse;
import zw.co.change.money.app.users.model.Gender;

import java.util.List;
@Data
public class UserBrandAmbassadorResponse {
    private String firstName;
    private String userId;
    private boolean active;
    private String surname;
    private String mobileNumber;
    private String mobileNumberCountryCode;
    private String contactMobileNumber;
    private String contactMobileNumberCountryCode;
    private String email;
    private Gender gender;
    private List<PermissionResponse> permissions;
}
