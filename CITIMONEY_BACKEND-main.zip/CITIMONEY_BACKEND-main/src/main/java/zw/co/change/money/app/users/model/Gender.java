package zw.co.change.money.app.users.model;

public enum Gender {
    MALE,
    FEMALE,
    NOT_SET,
    COMPANY,
    OTHER
}
