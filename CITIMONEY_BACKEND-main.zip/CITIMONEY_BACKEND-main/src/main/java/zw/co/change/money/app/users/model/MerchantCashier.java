package zw.co.change.money.app.users.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.merchants.model.MerchantBranch;

import javax.persistence.*;

@Entity
@Table(name = "merchant_cashier_users")
@Data
@EqualsAndHashCode(callSuper = true)
@PrimaryKeyJoinColumn(name = "userId")
@DiscriminatorValue("9")
public class MerchantCashier extends User {
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchantBranch")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private MerchantBranch merchantBranch;
    private String mobileNumber;
    private String mobileNumberCountryCode;
    private String code;
}
