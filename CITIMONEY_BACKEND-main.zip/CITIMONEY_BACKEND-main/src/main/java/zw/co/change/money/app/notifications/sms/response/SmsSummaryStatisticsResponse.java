package zw.co.change.money.app.notifications.sms.response;

import lombok.Data;

@Data
public class SmsSummaryStatisticsResponse {
    private long pendingSmsCount;
    private long failedSmsCount;
    private long successSmsCount;
}
