package zw.co.change.money.app.legacy.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;


import java.io.Serializable;
import java.util.Date;
import java.util.Map;
import java.util.Objects;
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BaseDto implements Serializable {
    protected String id;
    protected String dateCreated;

    protected String dateUpdated;
    protected Map<String,String> additionalData;



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BaseDto baseDto = (BaseDto) o;
        return Objects.equals(id, baseDto.id);
    }

    @Override
    public int hashCode() {

        return Objects.hash(id);
    }
}
