package zw.co.change.money.app.users.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.transactions.model.Wallet;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "usersCustomers",uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "mobileNumber"
        })
})
@Data
@EqualsAndHashCode(callSuper = true)
@PrimaryKeyJoinColumn(name = "userId")
@DiscriminatorValue("3")
public class UserCustomer extends User {
    private String mobileNumber;
    private String nationalId;
    private String mobileNumberCountryCode;
    private Boolean verified = false;
    private Boolean firstTime = false;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "wallet")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Wallet wallet;
}
