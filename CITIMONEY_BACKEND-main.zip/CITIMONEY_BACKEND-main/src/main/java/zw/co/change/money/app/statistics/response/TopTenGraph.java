package zw.co.change.money.app.statistics.response;

import lombok.Data;

import java.util.List;
@Data
public class TopTenGraph {
    private List<TopTenGraphItem> items;
    private double total;
    private String topTenGraphLabel;
}
