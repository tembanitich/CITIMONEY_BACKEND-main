package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.transactions.model.Wallet;
import zw.co.change.money.app.transactions.model.WalletHistoryType;
@Data
public class WalletHistoryResponse {
    private Long id;
    private WalletResponse wallet;
    private double balanceBefore;
    private double amount;
    private UserSummary receiver;
    private UserSummary sender;
    private String senderName;
    private String receiverName;
    private WalletHistoryType transactionType;
    private double balanceAfter;
    private String dateOfEntry;
}
