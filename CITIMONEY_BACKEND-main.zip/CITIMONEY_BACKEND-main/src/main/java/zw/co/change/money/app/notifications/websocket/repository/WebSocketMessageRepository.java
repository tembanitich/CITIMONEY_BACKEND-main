package zw.co.change.money.app.notifications.websocket.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessage;

import java.util.List;

public interface WebSocketMessageRepository extends JpaRepository<WebSocketMessage, Long> {
    List<WebSocketMessage> findByUserIdOrderByCreatedAtDesc(String userId);
    Page<WebSocketMessage> findByUserIdOrderByCreatedAtDesc(String userId, Pageable pageable);
    Page<WebSocketMessage> findByUserIdAndReadStatusOrderByCreatedAtDesc(String userId,boolean readStatus, Pageable pageable);
    Long countByReadStatus(boolean readStatus);
    Long countByReadStatusAndUserId(boolean readStatus,String userId);
}
