package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.BranchManager;
import zw.co.change.money.app.users.model.MerchantCashier;

import java.time.LocalDateTime;
import java.util.List;

public interface BranchManagerRepository extends JpaRepository<BranchManager, String> {
    List<BranchManager> findByEnabled(boolean status);
    Page<BranchManager> findByEnabled(boolean status, Pageable pageable);
    List<BranchManager> findByMerchantBranchId(long merchantBranchId);
    Page<BranchManager> findByMerchantBranchId(long merchantBranchId, Pageable pageable);
    Long countByEnabled(boolean status);
    Long countByMerchantBranchMerchantId(String merchantId);
    Long countByMerchantBranchId(long branchId);
    Long countByEnabledAndMerchantBranchMerchantId(boolean status,String merchantId);
    Long countByEnabledAndMerchantBranchId(boolean status,long branchId);
    Page<BranchManager> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    List<BranchManager> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname);
    List<BranchManager> findDistinctByFirstNameContainingIgnoreCaseAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndMerchantBranchId(String  firstName,long branchId,String  surname,long branchId2);
    Page<BranchManager> findDistinctByFirstNameContainingIgnoreCaseAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndMerchantBranchId(String  firstName,long branchId,String  surname,long branchId2, Pageable pageable);
    Page<BranchManager> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<BranchManager> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status, String  surname, boolean status2, Pageable pageable);

    List<BranchManager> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(String merchantId, String  firstName, String merchantId2, String  surname);
    List<BranchManager> findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchMerchantId(String  firstName, boolean status,String merchantId, String  surname, boolean status2,String merchantId2);
    List<BranchManager> findDistinctByMerchantBranchIdAndFirstNameContainingIgnoreCaseOrMerchantBranchIdAndSurnameContainingIgnoreCase(long merchantId, String  firstName, long merchantId2, String  surname);
    List<BranchManager> findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantBranchIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantBranchId(String  firstName, boolean status,long merchantId, String  surname, boolean status2,long merchantId2);
    List<BranchManager> findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<BranchManager> findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);

    List<BranchManager> findByEnabledAndMerchantBranchMerchantId(boolean status, String merchantId);
    Page<BranchManager> findByEnabledAndMerchantBranchMerchantId(boolean status,String merchantId, Pageable pageable);
    Page<BranchManager> findByMerchantBranchMerchantId(String merchantId, Pageable pageable);
    Page<BranchManager> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd,String merchantId2, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<BranchManager> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCaseAndEnabled(String merchantId,String  firstName, boolean status,String merchantId2, String  surname, boolean status2, Pageable pageable);
    Page<BranchManager> findDistinctByMerchantBranchMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantBranchMerchantIdAndSurnameContainingIgnoreCase(String merchantId,String  firstName,String merchantId2,String  surname, Pageable pageable);


}
