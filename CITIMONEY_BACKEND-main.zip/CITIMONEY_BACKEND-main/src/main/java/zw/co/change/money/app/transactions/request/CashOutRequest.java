package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CashOutRequest {
    private String cashierCode;
    private String pin;
    private double amount;
}
