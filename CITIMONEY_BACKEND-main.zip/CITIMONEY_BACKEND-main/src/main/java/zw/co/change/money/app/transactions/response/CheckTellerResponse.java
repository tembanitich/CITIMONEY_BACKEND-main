package zw.co.change.money.app.transactions.response;

import lombok.Data;


@Data
public class CheckTellerResponse {
    private String msisdn;
    private String id;
    private double totalWithdrawal;

}