package zw.co.change.money.app.notifications.sms.response;

import lombok.Data;

@Data
public class SmsSuccessResponse {
    private Long id;
    private String message;
    private String referenceId;
    private String timeReceived;
    private String timeRouted;
    private String timeDelivered;
    private String dateNotificationReceived;
    private String destination;
    private String senderId;
}