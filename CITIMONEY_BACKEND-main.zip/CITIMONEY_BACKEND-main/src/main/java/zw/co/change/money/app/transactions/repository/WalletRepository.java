package zw.co.change.money.app.transactions.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.accounts.model.MerchantAccountStatus;
import zw.co.change.money.app.transactions.model.Transaction;
import zw.co.change.money.app.transactions.model.Wallet;
import zw.co.change.money.app.transactions.model.WalletStatus;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface WalletRepository extends JpaRepository<Wallet, Long> {
    Optional<Wallet> findByCustomerUserId(String userId);
    List<Wallet> findByStatus(WalletStatus status);
    Page<Wallet> findByStatus(WalletStatus status, Pageable pageable);
    Page<Wallet> findByCustomerFirstNameIgnoreCaseContainingAndStatusOrCustomerSurnameIgnoreCaseContainingAndStatus(String merchantName,WalletStatus status,String merchantName2,WalletStatus status2, Pageable pageable);
    Page<Wallet> findByCustomerFirstNameIgnoreCaseContainingOrCustomerSurnameIgnoreCaseContaining(String name, String query, Pageable pageable);
    Page<Wallet> findByCustomerFirstNameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String name, LocalDateTime startDate,LocalDateTime endDate, String query,LocalDateTime startDate2,LocalDateTime endDate2, Pageable pageable);
}
