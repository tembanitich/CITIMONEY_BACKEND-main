package zw.co.change.money.app.accounts.response;

import lombok.Data;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.users.response.AccountManagerResponse;

import javax.persistence.*;
import java.time.LocalDateTime;

@Data
public class MerchantAccountDepositRequestResponse {
    private Long id;
    private MerchantAccountResponse account;
    private double amount;
    private String  dateOfEntry;
    private DepositRequestStatus status;
    private AccountManagerResponse accountManager;
    private UserSummary approvedBy;
    private String approvedDate;
    private UserSummary declinedBy;
    private String declinedDate;
}
