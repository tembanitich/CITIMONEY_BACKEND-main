package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class UserPermissionsReportData {
    private String username;
    private String roles;
    private String createdBy;
    private LocalDateTime createdDate;
    private String status;
    private LocalDateTime lastLogin;
}
