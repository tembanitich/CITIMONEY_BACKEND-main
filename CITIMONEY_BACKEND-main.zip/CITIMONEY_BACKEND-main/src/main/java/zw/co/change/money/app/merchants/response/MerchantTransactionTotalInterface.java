package zw.co.change.money.app.merchants.response;

public interface MerchantTransactionTotalInterface {
    String getName();
    long getId();
    double getTotal();
}
