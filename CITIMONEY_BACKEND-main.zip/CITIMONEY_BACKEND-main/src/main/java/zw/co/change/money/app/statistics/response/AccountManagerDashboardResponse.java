package zw.co.change.money.app.statistics.response;

import lombok.Data;
import zw.co.change.money.app.accounts.response.MerchantAccountHistoryResponse;
import zw.co.change.money.app.transactions.response.TransactionResponse;

import java.util.List;
@Data
public class AccountManagerDashboardResponse {
    private long accountsCount;
    private List<CounterGraph> depositsCountersThisMonth;
    private List<CounterGraph> depositsCountersThisWeek;
    private List<CounterGraph> depositsCountersThisYear;
    private  List<MerchantAccountHistoryResponse> lastDeposits;
}
