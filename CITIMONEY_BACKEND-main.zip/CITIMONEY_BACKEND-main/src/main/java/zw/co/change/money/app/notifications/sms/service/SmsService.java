package zw.co.change.money.app.notifications.sms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.notifications.sms.SmsUtil;
import zw.co.change.money.app.notifications.sms.model.SmsFailures;
import zw.co.change.money.app.notifications.sms.model.SmsResponses;
import zw.co.change.money.app.notifications.sms.repository.PendingSmsRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsFailuresRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsResponsesRepository;
import zw.co.change.money.app.notifications.sms.response.PendingSmsResponse;
import zw.co.change.money.app.notifications.sms.response.SmsFailureResponse;
import zw.co.change.money.app.notifications.sms.response.SmsSuccessResponse;
import zw.co.change.money.app.notifications.sms.response.SmsSummaryStatisticsResponse;
import zw.co.change.money.app.users.model.UserBackendAdmin;
import zw.co.change.money.app.users.model.UserBackendAgent;
import zw.co.change.money.app.users.repository.UserBackendAdminRepository;
import zw.co.change.money.app.users.repository.UserBackendAgentRepository;
import zw.co.change.money.app.users.repository.UserCustomerRepository;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.validation.ValidateSMSProperties;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.notifications.sms.model.PendingSms;

import java.io.IOException;
import java.time.*;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class SmsService {
    @Autowired
    ValidateSMSProperties validateSMSProperties;
    @Autowired
    SmsFailuresRepository smsFailuresRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    SmsUtil smsUtil;
    @Autowired
    SmsResponsesRepository smsResponsesRepository;
    @Autowired
    PendingSmsRepository pendingSmsRepository;
    @Autowired
    FormatUtility formatUtilty;
    @Autowired
    DateUtil dateUtil;
    ///////////////////////////Ticket Failures///////////////////////////
    public ResponseEntity sendSMSTest(String message,String mobileNumber){
        try {
            smsUtil.SendSms(message,mobileNumber);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(new GenericApiResponse("SMS sent Successfully"));
    }
    public ResponseEntity getSmsSummaryStatistics(){
        SmsSummaryStatisticsResponse response = new SmsSummaryStatisticsResponse();
        response.setFailedSmsCount(smsFailuresRepository.count());
        response.setPendingSmsCount(pendingSmsRepository.count());
        response.setSuccessSmsCount(smsResponsesRepository.count());
        return  ResponseEntity.ok(response);


    }
    public ResponseEntity GetSmsFailureByFailureReason(String failure, int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<SmsFailures> failures =  smsFailuresRepository.findByMethodInExecution(failure,pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity GetAllSmsFailures(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<SmsFailures> failures = smsFailuresRepository.findAll(pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchSmsFailuresByPhoneNumber(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateSMSProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtilty.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<SmsFailures> failures;
if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = smsFailuresRepository.findByReceiverPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = smsFailuresRepository.findByReceiverPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = smsFailuresRepository.findByReceiverPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),  LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDateTime startDate = LocalDate.parse(request.getFilterValue()).atTime(LocalTime.MIN);
            LocalDateTime endDate = LocalDate.parse(request.getFilterValueMax()).atTime(LocalTime.MAX);
            failures = smsFailuresRepository.findByReceiverPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate, endDate, pageable);
        } else {
            failures = smsFailuresRepository.findByReceiverPhoneNumberIgnoreCaseContaining(request.getSearchQuery(), pageable);
        }
        List<SmsFailureResponse> responses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }

    public ResponseEntity GetAllPendingSms(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<PendingSms> failures = pendingSmsRepository.findAll(pageable);

        List<PendingSmsResponse> ticketFailureResponses = failures.stream().map(this::mapPendingSmsEntityToSpecificPendingSmsResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetPendingSmsThisWeek(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<PendingSms> failures = pendingSmsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<PendingSmsResponse> ticketFailureResponses = failures.stream().map(this::mapPendingSmsEntityToSpecificPendingSmsResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetPendingSmsToday(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<PendingSms> failures = pendingSmsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<PendingSmsResponse> ticketFailureResponses = failures.stream().map(this::mapPendingSmsEntityToSpecificPendingSmsResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetPendingSmsThisMonth(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<PendingSms> failures = pendingSmsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<PendingSmsResponse> ticketFailureResponses = failures.stream().map(this::mapPendingSmsEntityToSpecificPendingSmsResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetPendingSmsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtilty.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtilty.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<PendingSms> failures = pendingSmsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<PendingSmsResponse> ticketFailureResponses = failures.stream().map(this::mapPendingSmsEntityToSpecificPendingSmsResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchPendingSmsByPhoneNumber(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateSMSProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtilty.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<PendingSms> failures;
        if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = pendingSmsRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = pendingSmsRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = pendingSmsRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),  LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDateTime startDate = LocalDate.parse(request.getFilterValue()).atTime(LocalTime.MIN);
            LocalDateTime endDate = LocalDate.parse(request.getFilterValueMax()).atTime(LocalTime.MAX);
            failures = pendingSmsRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate, endDate, pageable);
        } else {
            failures = pendingSmsRepository.findByPhoneNumberIgnoreCaseContaining(request.getSearchQuery(), pageable);
        }
        List<PendingSmsResponse> responses = failures.stream().map(this::mapPendingSmsEntityToSpecificPendingSmsResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }

    public ResponseEntity GetSmsFailuresThisWeek(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<SmsFailures> failures = smsFailuresRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetSmsFailuresToday(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<SmsFailures> failures = smsFailuresRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetSmsFailuresThisMonth(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<SmsFailures> failures = smsFailuresRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetSmsFailuresFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtilty.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtilty.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<SmsFailures> failures = smsFailuresRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity GetSmsFailuresByPhoneNumberFromRange(String phoneNumber,String  startDateTimeString,String  endDateTimeString,int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);

        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtilty.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtilty.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<SmsFailures> failures = smsFailuresRepository.findByReceiverPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(phoneNumber,startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),pageable);

        List<SmsFailureResponse> ticketFailureResponses = failures.stream().map(this::mapSmsFailureEntityToSpecificSmsFailureResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity GetSmsSuccessesThisWeek(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<SmsResponses> failures = smsResponsesRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<SmsSuccessResponse> ticketFailureResponses = failures.stream().map(this::mapSmsSuccessEntityToSpecificSmsFailureResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllSmsSuccesses(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<SmsResponses> failures = smsResponsesRepository.findAll(pageable);

        List<SmsSuccessResponse> ticketFailureResponses = failures.stream().map(this::mapSmsSuccessEntityToSpecificSmsFailureResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetSmsSuccessesToday(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<SmsResponses> failures = smsResponsesRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<SmsSuccessResponse> ticketFailureResponses = failures.stream().map(this::mapSmsSuccessEntityToSpecificSmsFailureResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetSmsSuccessesThisMonth(int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<SmsResponses> failures = smsResponsesRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<SmsSuccessResponse> ticketFailureResponses = failures.stream().map(this::mapSmsSuccessEntityToSpecificSmsFailureResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetSmsSuccessesFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size) {
        formatUtilty.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtilty.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtilty.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<SmsResponses> failures = smsResponsesRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<SmsSuccessResponse> ticketFailureResponses = failures.stream().map(this::mapSmsSuccessEntityToSpecificSmsFailureResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchSmsSuccessesByPhoneNumber(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateSMSProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtilty.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<SmsResponses> failures;
        if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = smsResponsesRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = smsResponsesRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = smsResponsesRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),  LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDateTime startDate = LocalDate.parse(request.getFilterValue()).atTime(LocalTime.MIN);
            LocalDateTime endDate = LocalDate.parse(request.getFilterValueMax()).atTime(LocalTime.MAX);
            failures = smsResponsesRepository.findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate, endDate, pageable);
        } else {
            failures = smsResponsesRepository.findByPhoneNumberIgnoreCaseContaining(request.getSearchQuery(), pageable);
        }
        List<SmsSuccessResponse> responses = failures.stream().map(this::mapSmsSuccessEntityToSpecificSmsFailureResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }

    private SmsFailureResponse mapSmsFailureEntityToSpecificSmsFailureResponse(SmsFailures smsFailures){
        SmsFailureResponse smsFailureResponse = new SmsFailureResponse();
        smsFailureResponse.setMessage(smsFailures.getContent());
        smsFailureResponse.setId(smsFailures.getId());
        if(smsFailures.getCreatedAt()!=null) {
            smsFailureResponse.setDate(smsFailures.getCreatedAt().toString());
        }

        smsFailureResponse.setMethodInExecution(smsFailures.getMethodInExecution());
        smsFailureResponse.setReason(smsFailures.getReason());
        smsFailureResponse.setReceiverPhoneNumber(smsFailures.getReceiverPhoneNumber());


        return smsFailureResponse;
    }
    private SmsSuccessResponse mapSmsSuccessEntityToSpecificSmsFailureResponse(SmsResponses smsFailures){
        SmsSuccessResponse smsFailureResponse = new SmsSuccessResponse();
        smsFailureResponse.setId(smsFailures.getId());
        if(smsFailures.getTimeDelivered()!=null) {
            smsFailureResponse.setDateNotificationReceived(smsFailures.getTimeDelivered().toString());
        }

        smsFailureResponse.setDestination(smsFailures.getDestination());
        smsFailureResponse.setMessage(smsFailures.getMessage());
        smsFailureResponse.setReferenceId(smsFailures.getReferenceId());
        if(smsFailures.getTimeDelivered()!=null){
            smsFailureResponse.setTimeDelivered(smsFailures.getTimeDelivered().toString());
        }
        if(smsFailures.getTimeReceived()!=null){
            smsFailureResponse.setTimeReceived(smsFailures.getTimeReceived().toString());
        }
        if(smsFailures.getTimeRouted()!=null){
            smsFailureResponse.setTimeRouted(smsFailures.getTimeRouted().toString());
        }




        return smsFailureResponse;
    }
    private PendingSmsResponse mapPendingSmsEntityToSpecificPendingSmsResponse(PendingSms smsFailures){
        PendingSmsResponse smsFailureResponse = new PendingSmsResponse();
        if(smsFailures.getCreatedAt()!=null){
            smsFailureResponse.setDateOfProcessing(smsFailures.getCreatedAt().toString());
        }

        smsFailureResponse.setId(smsFailures.getId());
        smsFailureResponse.setMessage(smsFailures.getMessage());
        smsFailureResponse.setPhoneNumber(smsFailures.getPhoneNumber());
        smsFailureResponse.setReference(smsFailures.getReference());

        return smsFailureResponse;
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);

        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }


}
