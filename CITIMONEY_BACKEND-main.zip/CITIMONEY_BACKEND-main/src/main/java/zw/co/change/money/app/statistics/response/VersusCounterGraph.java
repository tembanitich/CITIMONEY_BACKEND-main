package zw.co.change.money.app.statistics.response;

import lombok.Data;

import java.util.List;
@Data
public class VersusCounterGraph {
    private List<VersusCounterGraphItem> items;
    private String versusCounterLabel;
}
