package zw.co.change.money.app.notifications.websocket.response;

import lombok.Data;

@Data
public class WebSocketRemoveOrderResponse {
    private ResponseType responseType;
    private String orderId;
}
