package zw.co.change.money.app.currencies.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.currencies.model.ExchangeRateHistory;
import zw.co.change.money.app.currencies.model.MerchantIncentive;

import java.util.List;
import java.util.Optional;

public interface MerchantIncentiveRepository extends JpaRepository<MerchantIncentive, Long> {
    List<MerchantIncentive> findByMerchantId(String merchantId);
    Page<MerchantIncentive> findByMerchantId(String merchantId, Pageable pageable);
    Page<MerchantIncentive> findByCurrencyNameContainingIgnoreCase(String currencyName, Pageable pageable);
    Page<MerchantIncentive> findByCurrencyNameContainingIgnoreCaseAndMerchantId(String currencyName,String merchantId, Pageable pageable);
    Optional<MerchantIncentive> findByMerchantIdAndCurrencyCode(String merchantId, String currencyCode);

}
