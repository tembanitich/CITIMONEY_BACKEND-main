package zw.co.change.money.app.notifications.sms;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import zw.co.change.money.app.notifications.sms.model.PendingSms;
import zw.co.change.money.app.notifications.sms.model.SmsFailures;
import zw.co.change.money.app.notifications.sms.model.SmsResponses;
import zw.co.change.money.app.notifications.sms.repository.PendingSmsRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsFailuresRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsResponsesRepository;
import zw.co.change.money.app.notifications.sms.response.SmsGatewayResponse;
import zw.co.change.money.app.notifications.sms.response.SmsSuccessResponse;
import zw.co.change.money.app.util.json.JsonUtil;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import org.json.JSONObject;
import org.json.XML;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class SmsUtil {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    PendingSmsRepository pendingSmsRepository;
    @Autowired
    SmsResponsesRepository smsResponsesRepository;
    @Autowired
    SmsFailuresRepository smsFailuresRepository;
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    private JsonUtil jsonUtil;

    public ResponseEntity SendSms(String smsMessage, String Phonenumber) throws IOException{

        try {
            final String uri = appVariableRepository.findByCodeAndActive("SMS_GATEWAY_URL", true).getValue();
            final String username = appVariableRepository.findByCodeAndActive("SMS_GATEWAY_USERNAME", true).getValue();
            final String password = appVariableRepository.findByCodeAndActive("SMS_GATEWAY_PASSWORD", true).getValue();
            final String senderId = appVariableRepository.findByCodeAndActive("SMS_GATEWAY_SENDER_ID", true).getValue();
            HttpEntity<?> entity = new HttpEntity<String>("");
            RestTemplate restTemplate1 = new RestTemplate();
            UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromUriString(uri)
                    .queryParam("user", username)
                    .queryParam("password", password)
                    .queryParam("mobiles", Phonenumber)
                    .queryParam("sms", smsMessage)
                    .queryParam("senderid", senderId);
            System.out.println(uriBuilder.buildAndExpand().toUri());

            ResponseEntity<String> response = restTemplate1.postForEntity(uriBuilder.buildAndExpand().toUri(), entity, String.class);
            JSONObject soapDatainJsonObject = XML.toJSONObject(response.getBody());
            ObjectMapper jsonObjectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            JsonNode jsonNode = jsonUtil.convertJsonFormat(soapDatainJsonObject);
            System.out.println("Response..............");
            System.out.println(jsonNode);
            SmsGatewayResponse gatewayResponse = jsonObjectMapper.treeToValue(jsonNode, SmsGatewayResponse.class);
            if(gatewayResponse!=null){
                SmsResponses pendingSms =   this.savePendingSMS(gatewayResponse,smsMessage,Phonenumber);
                return new ResponseEntity(pendingSms, HttpStatus.OK);

            }else{
                SmsFailures smsFailure=   this.saveFailedSMS("No response from SMS Gateway",smsMessage,Phonenumber);
                return new ResponseEntity<>(smsFailure, HttpStatus.EXPECTATION_FAILED);
            }


        } catch (Exception e) {
            logger.info(">>>>>>>>>>>>>Logging SMS GATEWAY error here<<<<<<<<<<<<<<");
            logger.info(e.getMessage());
            SmsFailures smsFailure=   this.saveFailedSMS(e.getMessage(),smsMessage,Phonenumber);
            return new ResponseEntity<>(smsFailure, HttpStatus.EXPECTATION_FAILED);
        }

    }
    public ResponseEntity SendSmsMultiple(String callBackUrl,String smsMessage, List<String> phoneNumbers) throws IOException{
        try {
            String url = appVariableRepository.findByCode("SMS_GATEWAY_URL").orElse(null).getValue();
            String notificationUrl = appVariableRepository.findByCode("SMS_GATEWAY_NOTIFY_URL").orElse(null).getValue();
            SmsModelMultiple smsModel = new SmsModelMultiple();


            smsModel.setMessage(smsMessage);
            smsModel.setPhoneNumbers(phoneNumbers);
            smsModel.setCallBackUrl(notificationUrl);
            final String uri = url+"/sms-gateway/sendSingleSMS";
            System.out.println("Sending sms Url is:"+uri);

            HttpHeaders headers = new HttpHeaders();
            String token = appVariableRepository.findByCode("SMS_GATEWAY_API_KEY").orElse(null).getValue();

            headers.set("Authorization", "API-KEY "+token);

            HttpEntity<SmsModelMultiple> entity = new HttpEntity<>(smsModel, headers);
            System.out.println(entity.toString());
            RestTemplate restTemplate1 = new RestTemplate();
            JsonNode rootNode;
            rootNode = restTemplate1.postForObject(uri, entity, JsonNode.class);
            ObjectMapper jsonObjectMapper = new ObjectMapper();
            SmsGatewayResponse gatewayResponse = jsonObjectMapper.treeToValue(rootNode, SmsGatewayResponse.class);
            if(gatewayResponse!=null){
                logger.info(">>>>>>>>>>>>>Response For Multiple <<<<<<<<<<<<<< " );
                logger.info(gatewayResponse.toString());
                List<String> numbers = new ArrayList<>();
                for(String s : phoneNumbers){
                    numbers.add(s);
                }
                PendingSms pendingSms =   this.savePendingSMSMultiple(gatewayResponse,smsMessage,numbers);
                return new ResponseEntity(pendingSms, HttpStatus.OK);

            }else{
                List<String> numbers = new ArrayList<>();
                for(String s : phoneNumbers){
                    numbers.add(s);
                }
                SmsFailures smsFailure=   this.saveFailedSMSMultiple("No response from SMS Gateway",smsMessage,numbers);
                return new ResponseEntity<>(smsFailure, HttpStatus.EXPECTATION_FAILED);
            }


        } catch (Exception e) {
            logger.info(">>>>>>>>>>>>>Logging SMS Gateway error here<<<<<<<<<<<<<<");
            logger.info(e.getMessage());
            List<String> numbers = new ArrayList<>();
            for(String s : phoneNumbers){
                numbers.add(s);
            }
            SmsFailures smsFailure=   this.saveFailedSMSMultiple(e.getMessage(),smsMessage,numbers);
            return new ResponseEntity<>(smsFailure, HttpStatus.EXPECTATION_FAILED);
        }
    }


private PendingSms savePendingSMSMultiple(SmsGatewayResponse gatewayResponse,String smsMessage,List<String> Phonenumbers){
    PendingSms pendingSms = new PendingSms();
    pendingSms.setMessage(smsMessage);
    pendingSms.setPhoneNumbers(Phonenumbers);
    pendingSms.setMultiple(true);
    if(gatewayResponse.getSmslist()!=null &&gatewayResponse.getSmslist().getSms()!=null){
        pendingSms.setReference(gatewayResponse.getSmslist().getSms().getSmsclientid());
    }

    PendingSms savedPendingSms =pendingSmsRepository.save(pendingSms);
    return savedPendingSms;
}
private SmsResponses savePendingSMS(SmsGatewayResponse gatewayResponse,String smsMessage,String Phonenumber){
    SmsResponses successResponse = new SmsResponses();
    successResponse.setMessage(smsMessage);
    successResponse.setReferenceId(gatewayResponse.getSmslist().getSms().getMessageid()+"");
    successResponse.setDestination(Phonenumber);
    successResponse.setPhoneNumber(Phonenumber);
    successResponse.setTimeDelivered(LocalDateTime.now());
    successResponse.setTimeReceived(LocalDateTime.now());
    successResponse.setTimeRouted(LocalDateTime.now());
    SmsResponses savedPendingSms =smsResponsesRepository.save(successResponse);
    return savedPendingSms;
}
    private SmsFailures saveFailedSMS(String reason,String smsMessage,String Phonenumber){
        SmsFailures smsFailure= new SmsFailures();
        smsFailure.setContent(smsMessage);
        smsFailure.setReference(RandomStringUtils.random(12,true,true));
        smsFailure.setMethodInExecution("SMS_GENERATION");
        smsFailure.setReceiverPhoneNumber(Phonenumber);
        smsFailure.setMultiple(false);
        smsFailure.setReason(reason);
        SmsFailures savedSmsFailure=smsFailuresRepository.save(smsFailure);
        return savedSmsFailure;
    }
    private SmsFailures saveFailedSMSMultiple(String reason,String smsMessage,List<String> Phonenumbers){
        SmsFailures smsFailure= new SmsFailures();
        smsFailure.setContent(smsMessage);
        smsFailure.setReference(RandomStringUtils.random(12,true,true));
        smsFailure.setMethodInExecution("SMS_GENERATION");
        smsFailure.setPhoneNumbers(Phonenumbers);
        smsFailure.setMultiple(true);
        smsFailure.setReason(reason);
        SmsFailures savedSmsFailure=smsFailuresRepository.save(smsFailure);
        return savedSmsFailure;
    }

}
