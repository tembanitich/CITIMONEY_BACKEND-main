package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class ApplyMerchantWithdrawalRequest {
    private double amount;
}
