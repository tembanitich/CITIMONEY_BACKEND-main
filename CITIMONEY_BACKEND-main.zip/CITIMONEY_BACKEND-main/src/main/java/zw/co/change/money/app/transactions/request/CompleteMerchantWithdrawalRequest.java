package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CompleteMerchantWithdrawalRequest {
    private String approval;
    private String code;
    private String pin;
}
