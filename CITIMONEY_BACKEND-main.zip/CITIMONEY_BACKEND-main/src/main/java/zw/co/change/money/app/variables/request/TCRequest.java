package zw.co.change.money.app.variables.request;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class TCRequest {
    @NotNull
    private String description;
    private Long id;
}
