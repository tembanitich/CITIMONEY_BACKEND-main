package zw.co.change.money.app.variables.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.BaseUserDateAudit;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name = "cf_variables")
@Data
@EqualsAndHashCode(callSuper = true)
public class AppVariable extends BaseUserDateAudit {

    private String code;
    private AppVariableType type;
    @Size(max = 5000)
    private String value;
    private boolean active;

}
