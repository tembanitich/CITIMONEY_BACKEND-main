package zw.co.change.money.app.reports.request;

public enum ReportDateFilter {
    ALL,TODAY,THIS_WEEK,THIS_MONTH,THIS_YEAR,CUSTOM
}
