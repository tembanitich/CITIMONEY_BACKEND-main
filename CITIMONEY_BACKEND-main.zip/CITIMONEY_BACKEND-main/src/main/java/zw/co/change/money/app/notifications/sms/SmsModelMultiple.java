package zw.co.change.money.app.notifications.sms;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;
@Data
public class SmsModelMultiple {
    @NotNull
    private String message;
    @NotNull
    private String callBackUrl;
    @NotNull
    private List<String> phoneNumbers;
}
