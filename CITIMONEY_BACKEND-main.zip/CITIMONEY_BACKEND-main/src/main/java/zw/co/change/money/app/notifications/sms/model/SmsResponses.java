package zw.co.change.money.app.notifications.sms.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@EqualsAndHashCode(callSuper = true)
@Data
public class SmsResponses extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String referenceId;
    private String message;
    private LocalDateTime timeReceived ;
    private LocalDateTime timeRouted  ;
    private LocalDateTime timeDelivered   ;
    private boolean isMultiple;
    private String phoneNumber;
    private String destination ;
}
