package zw.co.change.money.app.variables.response;

import lombok.Data;

@Data
public class SmsConfigResponse {
    private String code;
    private String content;
    private String[] variables;
    private boolean active;
}
