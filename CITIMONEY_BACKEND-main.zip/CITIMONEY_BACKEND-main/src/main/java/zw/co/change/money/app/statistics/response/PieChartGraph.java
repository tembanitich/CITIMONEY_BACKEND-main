package zw.co.change.money.app.statistics.response;

import lombok.Data;

import java.util.List;
@Data
public class PieChartGraph {
    private List<PieChartCategory> categories;
    private String pieChartName;
}
