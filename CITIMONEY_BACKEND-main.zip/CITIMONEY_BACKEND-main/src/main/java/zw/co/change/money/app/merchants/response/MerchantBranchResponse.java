package zw.co.change.money.app.merchants.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

@Data
public class MerchantBranchResponse {
    private Long id;
    private String name;
    private String branchManagerName;
    private String branchEmail;
    private String contactNumber;
    private String contactNumberCountryCode;
    private boolean active;
    private MerchantResponse merchant;
}
