package zw.co.change.money.app.legacy.response;

import lombok.Data;

import java.util.List;
@Data
public class SubscriberKycDetailsDto extends BaseDto {
    private String firstName;
    private String msisdn;
    private String lastName;
    private String nationalId;
    private String sex;
    private List<AccountDto> accounts;
}
