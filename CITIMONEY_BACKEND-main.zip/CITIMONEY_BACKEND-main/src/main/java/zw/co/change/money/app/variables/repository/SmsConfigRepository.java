package zw.co.change.money.app.variables.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import zw.co.change.money.app.variables.model.SmsConfig;

import java.util.Optional;

@Repository
public interface SmsConfigRepository extends JpaRepository<SmsConfig, Long> {
    Optional<SmsConfig> findByCode(String code);
    SmsConfig findFirstByCode(String code);

}
