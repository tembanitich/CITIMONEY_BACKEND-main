package zw.co.change.money.app.ussd.service;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.accounts.model.MerchantAccountHistory;
import zw.co.change.money.app.accounts.model.MerchantAccountHistoryType;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.accounts.repository.MerchantAccountHistoryRepository;
import zw.co.change.money.app.authentication.model.RegistrationOtp;
import zw.co.change.money.app.authentication.repository.RegistrationOtpRepository;
import zw.co.change.money.app.authentication.request.CustomerSignUpRequest;
import zw.co.change.money.app.authentication.request.LoginRequest;
import zw.co.change.money.app.authentication.request.ResetPasswordRequest;
import zw.co.change.money.app.authentication.response.JwtAuthenticationResponse;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.currencies.model.MerchantIncentive;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.currencies.repository.MerchantIncentiveRepository;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.currencies.service.CurrencyService;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.notifications.mail.executor.MailExecutor;
import zw.co.change.money.app.notifications.sms.executors.SmsExecutor;
import zw.co.change.money.app.security.jwt.JwtTokenProvider;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.transactions.model.*;
import zw.co.change.money.app.transactions.repository.MerchantWithdrawalRequestRepository;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.repository.WalletHistoryRepository;
import zw.co.change.money.app.transactions.repository.WalletRepository;
import zw.co.change.money.app.transactions.request.*;
import zw.co.change.money.app.transactions.response.CheckCustomerResponse;
import zw.co.change.money.app.transactions.response.CheckPaymentResponse;
import zw.co.change.money.app.transactions.response.CheckTransferResponse;
import zw.co.change.money.app.transactions.response.WalletResponse;
import zw.co.change.money.app.transactions.service.TransactionService;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.ussd.request.*;
import zw.co.change.money.app.ussd.response.CheckUserResponse;
import zw.co.change.money.app.ussd.response.CheckUserStatus;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.numbers.NumbersUtil;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.validation.ValidateTransactionProperties;
import zw.co.change.money.app.validation.ValidateUserProperties;
import zw.co.change.money.app.variables.model.SmsConfig;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@Service
public class UssdService {
    @Autowired
    UserService userService;
    @Autowired
    SmsExecutor smsExecutor;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    MailExecutor mailExecutor;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    RegistrationOtpRepository registrationOtpRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    UserBrandAmbassadorRepository userBrandAmbassadorRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    MerchantCashierRepository merchantCashierRepository;

    @Autowired
    TellerUserRepository tellerUserRepository;
    @Autowired
    UserSystemAdminRepository userSystemAdminRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private TransactionRepository transactionsRepository;
    @Autowired
    private AccountRepository merchantAccountRepository;
    @Autowired
    private WalletHistoryRepository walletHistoryRepository;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private MerchantAccountHistoryRepository merchantAccountHistoryRepository;
    @Autowired
    private MerchantWithdrawalRequestRepository merchantWithdrawalRequestRepository;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    JwtTokenProvider tokenProvider;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    private MerchantIncentiveRepository merchantIncentiveRepository;
    @Autowired
    AuthenticationService authenticationService;
    @Autowired
    private CurrencyService currencyService;
    @Autowired
    private MerchantService merchantService;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    ValidateUserProperties validateUserProperties;
    @Autowired
    private ValidateTransactionProperties validateTransactionProperties;
    @Autowired
    StringGeneratorUtility stringGeneratorUtility;


    public ResponseEntity ussdCustomerLogin(UssdLoginRequest loginRequest) {


        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getMobileNumber(), loginRequest.getPin()));
        SecurityContextHolder.getContext().setAuthentication(authentication);


        User theUser = userRepository.findByUsernameOrEmail(loginRequest.getMobileNumber(), loginRequest.getMobileNumber()).orElse(null);
        if(theUser==null){
            JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
            myAuthResponse.setMessage("Something's happened!");
            return new ResponseEntity<>(myAuthResponse, HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer userCustomer =userCustomerRepository.findById(theUser.getUserId()).orElse(null);
        if(userCustomer==null){
            JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
            myAuthResponse.setMessage("Customer Does Not Exist");
            return new ResponseEntity<>(myAuthResponse, HttpStatus.EXPECTATION_FAILED);
        }
        if (theUser.getEnabled()) {
            String jwt = tokenProvider.generateToken(authentication);
            UserSummary summary = authenticationService.mapUserEntityToSpecificSummary(theUser);
            if(summary==null){
                return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
            }
            summary.setAccessToken("Bearer " + jwt);
            theUser.setLoginChannel("USSD");
            theUser.setLoginCount(theUser.getLoginCount()+1);
            theUser.setLastLogin(LocalDateTime.now());
            userRepository.save(theUser);
            return ResponseEntity.ok(summary);
        }


        JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
        myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
        return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
    }
    public ResponseEntity ussdBALogin(UssdLoginRequest loginRequest) {


        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getMobileNumber(), loginRequest.getPin()));
        SecurityContextHolder.getContext().setAuthentication(authentication);


        User theUser = userRepository.findByUsernameOrEmail(loginRequest.getMobileNumber(), loginRequest.getMobileNumber()).orElse(null);
        if(theUser==null){
            JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
            myAuthResponse.setMessage("Something's happened!");
            return new ResponseEntity<>(myAuthResponse, HttpStatus.EXPECTATION_FAILED);
        }
        UserBrandAmbassador userCustomer =userBrandAmbassadorRepository.findById(theUser.getUserId()).orElse(null);
        if(userCustomer==null){
            JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
            myAuthResponse.setMessage("Brand Ambassador Does Not Exist");
            return new ResponseEntity<>(myAuthResponse, HttpStatus.EXPECTATION_FAILED);
        }
        if (theUser.getEnabled()) {
            String jwt = tokenProvider.generateToken(authentication);
            UserSummary summary = authenticationService.mapUserEntityToSpecificSummary(theUser);
            if(summary==null){
                return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
            }
            summary.setAccessToken("Bearer " + jwt);
            theUser.setLoginChannel("USSD");
            theUser.setLoginCount(theUser.getLoginCount()+1);
            theUser.setLastLogin(LocalDateTime.now());
            userRepository.save(theUser);
            return ResponseEntity.ok(summary);
        }


        JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
        myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
        return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
    }
    public ResponseEntity checkUser(String mobileNumber){
        if(mobileNumber==null){
            return new ResponseEntity<>(new GenericApiError("Mobile Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        User theUser = userRepository.findByUsernameOrEmail(mobileNumber, mobileNumber).orElse(null);
        if(theUser==null){
           // must be new User
            CheckUserResponse response = new CheckUserResponse();
            response.setRole(RoleName.ROLE_CUSTOMER);
            response.setStatus(CheckUserStatus.IS_NEW_USER);
            return ResponseEntity.ok(response);

        }else{
            UserBrandAmbassador brandAmbassador =userBrandAmbassadorRepository.findByMobileNumber(mobileNumber).orElse(null);
            UserCustomer customer =userCustomerRepository.findByMobileNumber(mobileNumber).orElse(null);
            if(brandAmbassador==null && customer==null){
                // Is not allowed to use USSD
                CheckUserResponse response = new CheckUserResponse();
                response.setRole(RoleName.NOT_AUTHORIZED);
                response.setStatus(CheckUserStatus.OTHER);
                return ResponseEntity.ok(response);
            }else if(brandAmbassador!=null){
                CheckUserResponse response = new CheckUserResponse();
                response.setRole(RoleName.ROLE_BA);
                if(brandAmbassador.getFirstTime()){
                    // must be First Time using their account
                    response.setStatus(CheckUserStatus.IS_FIRST_TIME_USER);
                }else  if(brandAmbassador.getResetPin()){
                    // must be have recently done reset Pin
                    response.setStatus(CheckUserStatus.IS_RESET_PIN);
                }else  if(!brandAmbassador.getEnabled()){
                    // account deactivated
                    response.setStatus(CheckUserStatus.IS_INACTIVE);
                }else{
                    // account is active
                    response.setStatus(CheckUserStatus.IS_ACTIVE);
                }
                return ResponseEntity.ok(response);
            }else{
                CheckUserResponse response = new CheckUserResponse();
                response.setRole(RoleName.ROLE_CUSTOMER);
                if(customer.getFirstTime()){
                    // must be First Time using their account
                    response.setStatus(CheckUserStatus.IS_FIRST_TIME_USER);
                }else  if(customer.getResetPin()){
                    // must be have recently done reset Pin
                    response.setStatus(CheckUserStatus.IS_RESET_PIN);
                }else  if(!customer.getEnabled()){
                    // account deactivated
                    response.setStatus(CheckUserStatus.IS_INACTIVE);
                }else{
                    // account is active
                    response.setStatus(CheckUserStatus.IS_ACTIVE);
                }
                return ResponseEntity.ok(response);
            }

        }
    }
    public ResponseEntity ussdResetPassword(UssdResetPasswordRequest request){
        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",107), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        UserBrandAmbassador brandAmbassador = userBrandAmbassadorRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        if(customer==null &&brandAmbassador==null){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is not registered on this platform",110), HttpStatus.NOT_FOUND);
        }
        if(customer!=null){
            String pin = RandomStringUtils.random(6,false,true);

//            customer.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            customer.setResetPin(true);
            userRepository.save(customer);
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(customer.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(customer.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN_USSD",pin);
            this.sendSMS(customer.getMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }else{
            String pin = RandomStringUtils.random(6,false,true);

//            customer.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            brandAmbassador.setResetPin(true);
            userRepository.save(brandAmbassador);
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(brandAmbassador.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(brandAmbassador.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN_USSD",pin);
            this.sendSMS(brandAmbassador.getMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }


    }
    public ResponseEntity ussdConfirmOTP(UssdConfirmOTPRequest request){
        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getOtp()==null || request.getOtp().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("OTP cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getNewPin()==null || request.getNewPin().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("New Pin cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        UserBrandAmbassador brandAmbassador = userBrandAmbassadorRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        if(customer==null&&brandAmbassador==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Customer",110), HttpStatus.NOT_FOUND);
        }
        RegistrationOtp registrationOtp = registrationOtpRepository.findByOtp(request.getOtp()).orElse(null);
        if(registrationOtp==null){
            return new ResponseEntity<>(new GenericApiError("Invalid OTP",127), HttpStatus.EXPECTATION_FAILED);
        }
        if(customer!=null){
            if (customer.getEnabled()) {

                customer.setLoginChannel("USSD");
                customer.setLoginCount(customer.getLoginCount()+1);
                customer.setLastLogin(LocalDateTime.now());
                customer.setVerified(true);
                customer.setResetPin(false);
                customer.setFirstTime(false);
                customer.setPassword(passwordEncoder.encode(request.getNewPin()));
                userCustomerRepository.save(customer);
                //send Successfully Registered SMS to Customer
                //send Email with Pin
                String smsMessage = authenticationService.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
                this.sendSMS(customer.getMobileNumber(),smsMessage);
                registrationOtpRepository.delete(registrationOtp);
                Authentication authentication = authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(customer.getUsername(), request.getNewPin()));
                SecurityContextHolder.getContext().setAuthentication(authentication);
                String jwt = tokenProvider.generateToken(authentication);
                UserSummary summary = authenticationService.mapUserEntityToSpecificSummary(customer);
                summary.setAccessToken("Bearer " + jwt);
                return ResponseEntity.ok(summary);
            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("Customer Account locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }else{

            if (brandAmbassador.getEnabled()) {
                brandAmbassador.setLoginChannel("USSD");
                brandAmbassador.setLoginCount(brandAmbassador.getLoginCount()+1);
                brandAmbassador.setLastLogin(LocalDateTime.now());
                brandAmbassador.setVerified(true);
                brandAmbassador.setResetPin(false);
                customer.setFirstTime(false);
                customer.setPassword(passwordEncoder.encode(request.getNewPin()));
                userBrandAmbassadorRepository.save(brandAmbassador);
                //send Successfully Registered SMS to Customer
                //send Email with Pin
                String smsMessage = authenticationService.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
                this.sendSMS(brandAmbassador.getMobileNumber(),smsMessage);
                registrationOtpRepository.delete(registrationOtp);
                Authentication authentication = authenticationManager.authenticate(
                        new UsernamePasswordAuthenticationToken(brandAmbassador.getUsername(), request.getNewPin()));
                SecurityContextHolder.getContext().setAuthentication(authentication);
                String jwt = tokenProvider.generateToken(authentication);
                UserSummary summary = authenticationService.mapUserEntityToSpecificSummary(brandAmbassador);
                summary.setAccessToken("Bearer " + jwt);
                return ResponseEntity.ok(summary);
            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("Brand Ambassador Account locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }


    }
    public ResponseEntity ussdFirstTimeLogin(UssdAfterRegistrationChangePasswordRequest request){
        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getOldPin()==null || request.getOldPin().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Old Pin cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getNewPin()==null || request.getNewPin().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("OTP cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }

        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        UserBrandAmbassador brandAmbassador = userBrandAmbassadorRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        if(customer==null&&brandAmbassador==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Customer",110), HttpStatus.NOT_FOUND);
        }

        if(customer!=null){
            if (customer.getEnabled()) {
                if (passwordEncoder.matches(request.getNewPin(), customer.getPassword())) {
                    return new ResponseEntity<>(new GenericApiError("New Pin Cannot be the same as Old Pin",111), HttpStatus.EXPECTATION_FAILED);
                }
                if (passwordEncoder.matches(request.getOldPin(), customer.getPassword())) {
                    customer.setLoginChannel("USSD");
                    customer.setLoginCount(customer.getLoginCount()+1);
                    customer.setLastLogin(LocalDateTime.now());
                    customer.setVerified(true);
                    customer.setResetPin(false);
                    customer.setFirstTime(false);
                    customer.setPassword(passwordEncoder.encode(request.getNewPin()));
                    userCustomerRepository.save(customer);
                    //send Successfully Registered SMS to Customer
                    //send Email with Pin
                    String smsMessage = authenticationService.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
                    this.sendSMS(customer.getMobileNumber(),smsMessage);

                    Authentication authentication = authenticationManager.authenticate(
                            new UsernamePasswordAuthenticationToken(customer.getUsername(), request.getNewPin()));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    String jwt = tokenProvider.generateToken(authentication);
                    UserSummary summary = authenticationService.mapUserEntityToSpecificSummary(customer);
                    summary.setAccessToken("Bearer " + jwt);
                    return ResponseEntity.ok(summary);
                }else{
                    return new ResponseEntity<>(new GenericApiError("Incorrect Old Pin",111), HttpStatus.EXPECTATION_FAILED);
                }

            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("Customer Account locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }else{

            if (brandAmbassador.getEnabled()) {
                if (passwordEncoder.matches(request.getNewPin(), customer.getPassword())) {
                    return new ResponseEntity<>(new GenericApiError("New Pin Cannot be the same as Old Pin",111), HttpStatus.EXPECTATION_FAILED);
                }
                if (passwordEncoder.matches(request.getOldPin(), customer.getPassword())) {
                    brandAmbassador.setLoginChannel("USSD");
                    brandAmbassador.setLoginCount(brandAmbassador.getLoginCount()+1);
                    brandAmbassador.setLastLogin(LocalDateTime.now());
                    brandAmbassador.setVerified(true);
                    brandAmbassador.setResetPin(false);
                    customer.setFirstTime(false);
                    customer.setPassword(passwordEncoder.encode(request.getNewPin()));
                    userBrandAmbassadorRepository.save(brandAmbassador);
                    //send Successfully Registered SMS to Customer
                    //send Email with Pin
                    String smsMessage = authenticationService.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
                    this.sendSMS(brandAmbassador.getMobileNumber(),smsMessage);
                    Authentication authentication = authenticationManager.authenticate(
                            new UsernamePasswordAuthenticationToken(brandAmbassador.getUsername(), request.getNewPin()));
                    SecurityContextHolder.getContext().setAuthentication(authentication);
                    String jwt = tokenProvider.generateToken(authentication);
                    UserSummary summary = authenticationService.mapUserEntityToSpecificSummary(brandAmbassador);
                    summary.setAccessToken("Bearer " + jwt);
                    return ResponseEntity.ok(summary);
                }else{
                    return new ResponseEntity<>(new GenericApiError("Incorrect Old Pin",111), HttpStatus.EXPECTATION_FAILED);
                }

            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("Brand Ambassador Account locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }


    }
    public  ResponseEntity ussdCustomerSignUp(String mobileNumber){

        ResponseEntity theResponse = validateUserProperties.isValidUssdSignUpCustomerRequest(mobileNumber);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(6,false,true);
        UserCustomer admin = new UserCustomer();
        admin.setFirstName(mobileNumber);
        admin.setSurname("N/A");
        admin.setMobileNumber(mobileNumber);
        admin.setMobileNumberCountryCode("ZW");
        admin.setContactMobileNumber(mobileNumber);
        admin.setContactMobileNumberCountryCode("ZW");
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
        admin.setResetPin(false);
        admin.setFirstTime(true);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(mobileNumber);
        UserCustomer savedAdmin =userCustomerRepository.save(admin);
        Wallet wallet = new Wallet();
        wallet.setCustomer(savedAdmin);
        wallet.setBalance(0D);
        wallet.setStatus(WalletStatus.ACTIVE);
        Wallet savedWallet =walletRepository.save(wallet);
        savedAdmin.setWallet(savedWallet);
        userCustomerRepository.save(savedAdmin);
        //////////////////////assign Permissions////////////////////////
        userService.assignPermissionsByRoleToUser(RoleName.ROLE_CUSTOMER,savedAdmin);

        //send Email with Pin

        String smsMessage = this.processSuccessRegistrationSmsMessage("REGISTRATION_OTP_CODE",pin);
        this.sendSMS(mobileNumber,smsMessage);


        return ResponseEntity.ok(new GenericApiResponse("Customer Created Successfully"));

    }
    public  ResponseEntity ussdBARegister(String mobileNumber,String loggedInUser){
        UserBrandAmbassador brandAmbassador = userBrandAmbassadorRepository.findById(loggedInUser).orElse(null);
        if(brandAmbassador==null){
            return new ResponseEntity<>(new GenericApiError("You are not authorized to perform this Action",110), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateUserProperties.isValidUssdSignUpCustomerRequest(mobileNumber);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(6,false,true);
        UserCustomer admin = new UserCustomer();
        admin.setFirstName(mobileNumber);
        admin.setSurname("N/A");
        admin.setMobileNumber(mobileNumber);
        admin.setMobileNumberCountryCode("ZW");
        admin.setContactMobileNumber(mobileNumber);
        admin.setContactMobileNumberCountryCode("ZW");
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
        admin.setResetPin(false);
        admin.setFirstTime(true);
        admin.setPassword(passwordEncoder.encode(pin));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(mobileNumber);
        UserCustomer savedAdmin =userCustomerRepository.save(admin);
        Wallet wallet = new Wallet();
        wallet.setCustomer(savedAdmin);
        wallet.setBalance(0D);
        wallet.setStatus(WalletStatus.ACTIVE);
        Wallet savedWallet =walletRepository.save(wallet);
        savedAdmin.setWallet(savedWallet);
        userCustomerRepository.save(savedAdmin);
        //////////////////////assign Permissions////////////////////////
        userService.assignPermissionsByRoleToUser(RoleName.ROLE_CUSTOMER,savedAdmin);

        //send Email with Pin

        String smsMessage = this.processSuccessRegistrationSmsMessage("REGISTRATION_OTP_CODE",pin);
        this.sendSMS(mobileNumber,smsMessage);


        return ResponseEntity.ok(new GenericApiResponse("Customer Created Successfully"));

    }
    public ResponseEntity checkPaymentRequest(CheckPaymentRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCheckPaymentRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        double merchantIncentiveAmount=0;
        Merchant merchant=cashier.getMerchantBranch().getMerchant();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        double totalExchangeRate = currency.getExchangeRate()+ merchantIncentive.getAmount();
        double walletBalance = loggedInUser.getWallet().getBalance();
        double amountInUsd = request.getAmount()* totalExchangeRate;
        if(walletBalance<amountInUsd){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance",105), HttpStatus.EXPECTATION_FAILED);
        }
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountInUsd);
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);
    }
    public ResponseEntity checkCashoutRequest(CheckCashoutRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCheckCashoutRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        double merchantIncentiveAmount=0;
        Merchant merchant=cashier.getMerchantBranch().getMerchant();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        double totalExchangeRate = currency.getExchangeRate()+ merchantIncentive.getAmount();
        double walletBalance = loggedInUser.getWallet().getBalance();
        double amountInUsd = (request.getAmount()* totalExchangeRate)+(request.getAmount()* totalExchangeRate)*0.05;
        if(walletBalance<amountInUsd){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance",105), HttpStatus.EXPECTATION_FAILED);
        }
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountInUsd);
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);
    }
    public ResponseEntity checkTransferRequest(CheckTransferRequest request, String loggedInUserId){
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCheckTransferRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer receiver = userCustomerRepository.findByMobileNumber(request.getReceiverNumber()).orElse(null);
        if(receiver==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receiver",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(receiver.getUserId().equals(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("Transaction not allowed",105), HttpStatus.EXPECTATION_FAILED);
        }

        double walletBalance = loggedInUser.getWallet().getBalance();
        double amountInUsd =request.getAmount()+ (request.getAmount()*0.01);
        if(walletBalance<amountInUsd){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance",105), HttpStatus.EXPECTATION_FAILED);
        }
        CheckTransferResponse response = new CheckTransferResponse();
        response.setReceiver(userService.mapCustomerEntityToResponse(receiver));
        response.setAmount(request.getAmount());
        response.setReference(request.getReference());
        return ResponseEntity.ok(response);
    }
    public ResponseEntity TransferCredit(CustomerTransferRequest request, String loggedInUserId){

        ResponseEntity theResponse = validateTransactionProperties.isValidTransferRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer loggedInUser = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loggedInUser.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loggedInUser.setBlocked(false);
            loggedInUser.setEnabled(true);
            loggedInUser.setPinTryCount(0);
            userCustomerRepository.save(loggedInUser);
        }catch (BadCredentialsException e){
            if(loggedInUser.getPinTryCount()==2){
                loggedInUser.setPinTryCount(loggedInUser.getPinTryCount() +1);
                loggedInUser.setBlocked(true);
                loggedInUser.setEnabled(false);
                userCustomerRepository.save(loggedInUser);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= loggedInUser.getPinTryCount()+1;
                loggedInUser.setPinTryCount(count);
                userCustomerRepository.save(loggedInUser);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getReceiverNumber()).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receivers Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        double transactionCharge = NumbersUtil.round(((1/100)* request.getAmount()),2);
        double totalAmount =transactionCharge+ request.getAmount();
        // create transaction
        Transaction transaction = new Transaction();
        transaction.setId(stringGeneratorUtility.generateTransactionId());
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setTransactionType(TransactionType.TRANSFER);
        transaction.setAmount(request.getAmount());
        transaction.setAmountInUsd(request.getAmount());
        transaction.setMerchant(null);
        transaction.setMerchantBranch(null);
        transaction.setCurrency(currency);
        transaction.setCustomer(customer);
        transaction.setNotificationMsisdn(customer.getMobileNumber());
        transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
        transaction.setMerchantIncentiveUsed(0);
        transaction.setTotalExchangeRateUsed(currency.getExchangeRate());
        transaction.setTransactionCharge(transactionCharge);
        transaction.setTransactionCharge(NumbersUtil.round(((1/100)* request.getAmount()),2));
        transaction.setSender(loggedInUser);
        transaction.setReceiver(customer);
        transaction.setReference(request.getReference());
        transactionsRepository.save(transaction);

        // Deduct from Sender Wallet
        Wallet senderWallet = loggedInUser.getWallet();
        double amountToDeduct =totalAmount;
        double senderWalletBalanceBefore = senderWallet.getBalance();
        senderWallet.setBalance(senderWalletBalanceBefore-amountToDeduct);
        //create Merchant Account History
        WalletHistory senderWalletHistory = new WalletHistory();
        senderWalletHistory.setWallet(senderWallet);
        senderWalletHistory.setHistoryType(WalletHistoryType.DEBIT);
        senderWalletHistory.setAmount(amountToDeduct);
        senderWalletHistory.setSender(loggedInUser);
        senderWalletHistory.setReceiver(customer);
        senderWalletHistory.setBalanceAfter(senderWallet.getBalance());
        senderWalletHistory.setBalanceBefore(senderWalletBalanceBefore);
        senderWalletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistoryRepository.save(senderWalletHistory);
        walletRepository.save(senderWallet);
        // Add To Customer Wallet
        Wallet wallet = customer.getWallet();
        double amountToAdd =totalAmount;
        double walletBalanceBefore = wallet.getBalance();
        wallet.setBalance(walletBalanceBefore+amountToAdd);
        //create Merchant Account History
        WalletHistory walletHistory = new WalletHistory();
        walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.CREDIT);
        walletHistory.setAmount(amountToAdd);
        walletHistory.setSender(loggedInUser);
        walletHistory.setReceiver(customer);
        walletHistory.setBalanceAfter(wallet.getBalance());
        walletHistory.setBalanceBefore(walletBalanceBefore);
        walletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistoryRepository.save(walletHistory);
        walletRepository.save(wallet);
        //send SMS to Sender
        transactionService.processTransferSuccessSender(loggedInUser.getMobileNumber(),transaction,senderWallet.getBalance());
        //send SMS to Receiver
        transactionService.processTransferSuccessReceiver(customer.getMobileNumber(),transaction,wallet.getBalance());
        CheckTransferResponse response = new CheckTransferResponse();
        response.setReceiver(userService.mapCustomerEntityToResponse(customer));
        response.setAmount(request.getAmount());
        response.setReference(request.getReference());
        return ResponseEntity.ok(response);

    }
    public ResponseEntity makePayment(CustomerPaymentRequest request, String loggedInUserId){

        ResponseEntity theResponse = validateTransactionProperties.isValidPaymentRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }

        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(customer.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            customer.setBlocked(false);
            customer.setEnabled(true);
            customer.setPinTryCount(0);
            userCustomerRepository.save(customer);
        }catch (BadCredentialsException e){
            if(customer.getPinTryCount()==2){
                customer.setPinTryCount(customer.getPinTryCount() +1);
                customer.setBlocked(true);
                customer.setEnabled(false);
                userCustomerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= customer.getPinTryCount()+1;
                customer.setPinTryCount(count);
                userCustomerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }

        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
//        if(request.getPaymentType().equals(IssueChangeType.WALLET)){
        // create transaction
        Transaction transaction = new Transaction();
        transaction.setId(stringGeneratorUtility.generateTransactionId());
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setTransactionType(TransactionType.PAYMENT);
        transaction.setAmount(request.getAmount());
        transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
        transaction.setMerchant(merchant);
        transaction.setCashier(cashier);
        transaction.setMerchantBranch(cashier.getMerchantBranch());
        transaction.setCurrency(currency);
        transaction.setCustomer(customer);
        transaction.setCashier(cashier);
        transaction.setNotificationMsisdn(customer.getMobileNumber());
        transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
        transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
        transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
        transactionsRepository.save(transaction);

        double amountToRemove =(merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount();
        //Add Amount to merchant
        double merchantBalanceBefore = merchantAccount.getAccountBalance();
        MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
        merchantAccountHistory.setAccount(merchantAccount);
        merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.CREDIT);
        merchantAccountHistory.setAmount(amountToRemove);
        merchantAccountHistory.setSender(customer);
        merchantAccountHistory.setBalanceBefore(merchantBalanceBefore);
        merchantAccountHistory.setBalanceAfter(merchantBalanceBefore+amountToRemove);
        merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
        merchantAccountHistoryRepository.save(merchantAccountHistory);
        merchantAccount.setAccountBalance(merchantBalanceBefore+amountToRemove);
        merchantAccountRepository.save(merchantAccount);
        // Add To Customer Wallet
        Wallet wallet = customer.getWallet();

        double walletBalanceBefore = wallet.getBalance();
        wallet.setBalance(walletBalanceBefore-amountToRemove);
        //create Merchant Account History
        WalletHistory walletHistory = new WalletHistory();
        walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.DEBIT);
        walletHistory.setAmount(amountToRemove);
        walletHistory.setBalanceAfter(wallet.getBalance());
        walletHistory.setBalanceBefore(walletBalanceBefore);
        walletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistory.setSender(customer);
        walletHistory.setReceiver(cashier);
        walletHistoryRepository.save(walletHistory);
        walletRepository.save(wallet);
        //send SMS to customer
        transactionService.processPaymentSuccessCustomer(customer.getMobileNumber(),transaction);
        //send SMS to Cashier
        transactionService.processPaymentSuccessCashier(cashier.getMobileNumber(),transaction);
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountToRemove);
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);
//        }else{
//            FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(request.getAcquiringFinancialInstitutionNumber()).orElse(null);
//            if(financialInstitution==null){
//                return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",105), HttpStatus.EXPECTATION_FAILED);
//            }
//            // create transaction
//            Transaction transaction = new Transaction();
//            transaction.setId(stringGeneratorUtility.generateTransactionId());
//            transaction.setStatus(TransactionStatus.SUCCESS);
//            transaction.setTransactionType(TransactionType.PAYMENT);
//            transaction.setAmount(request.getAmount());
//            transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
//            transaction.setMerchant(merchant);
//            transaction.setMerchantBranch(cashier.getMerchantBranch());
//            transaction.setCurrency(currency);
//            transaction.setCustomer(customer);
//            transaction.setNotificationMsisdn(request.getNotificationMsisdn());
//            transaction.setSenderAccount(request.getAccountNumber());
//            transaction.setCashier(cashier);
//            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
//            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
//            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
//            transactionsRepository.save(transaction);
//
//            //Add Amount to merchant
//            //..................................
//
//
//            //send SMS to customer
//            this.processPaymentSuccessCustomer(request.getNotificationMsisdn(),transaction);
//            //send SMS to Cashier
//            this.processPaymentSuccessCashier(cashier.getMobileNumber(),transaction);
//            return ResponseEntity.ok(new GenericApiResponse("Payment Done Successfully"));
//        }

    }
    public ResponseEntity cashOut(CashOutRequest request, String loggedInUserId){
        ResponseEntity theResponse = validateTransactionProperties.isValidCashOutRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(customer.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            customer.setBlocked(false);
            customer.setEnabled(true);
            customer.setPinTryCount(0);
            userCustomerRepository.save(customer);
        }catch (BadCredentialsException e){
            if(customer.getPinTryCount()==2){
                customer.setPinTryCount(customer.getPinTryCount() +1);
                customer.setBlocked(true);
                customer.setEnabled(false);
                userCustomerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= customer.getPinTryCount()+1;
                customer.setPinTryCount(count);
                userCustomerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }

        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        double transactionCharge =NumbersUtil.round(((5/100)* request.getAmount()),2);
        double totalAmount =transactionCharge+ request.getAmount();
        // create transaction
        Transaction transaction = new Transaction();
        transaction.setId(stringGeneratorUtility.generateTransactionId());
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setTransactionType(TransactionType.CASH_OUT);
        transaction.setAmount(request.getAmount());
        transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
        transaction.setMerchant(merchant);
        transaction.setCashier(cashier);
        transaction.setMerchantBranch(cashier.getMerchantBranch());
        transaction.setCurrency(currency);
        transaction.setCustomer(customer);
        transaction.setTransactionCharge(transactionCharge);
        transaction.setTransactionChargeInUsd(transactionCharge);
        transaction.setCashier(cashier);
        transaction.setNotificationMsisdn(customer.getMobileNumber());
        transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
        transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
        transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
        transactionsRepository.save(transaction);

        //Add Amount to merchant
        double merchantBalanceBefore = merchantAccount.getAccountBalance();
        MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
        merchantAccountHistory.setAccount(merchantAccount);
        merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.CREDIT);
        merchantAccountHistory.setAmount(totalAmount);
        merchantAccountHistory.setSender(customer);
        merchantAccountHistory.setBalanceBefore(merchantBalanceBefore);
        merchantAccountHistory.setBalanceAfter(merchantBalanceBefore+totalAmount);
        merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
        merchantAccountHistoryRepository.save(merchantAccountHistory);
        merchantAccount.setAccountBalance(merchantBalanceBefore+totalAmount);
        merchantAccountRepository.save(merchantAccount);

        //..................................
        // Add To Customer Wallet
        Wallet wallet = customer.getWallet();
        double amountToRemove =totalAmount;
        double walletBalanceBefore = wallet.getBalance();
        wallet.setBalance(walletBalanceBefore-amountToRemove);
        //create Merchant Account History
        WalletHistory walletHistory = new WalletHistory();
        walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.DEBIT);
        walletHistory.setSender(customer);
        walletHistory.setReceiver(cashier);
        walletHistory.setAmount(amountToRemove);
        walletHistory.setBalanceAfter(wallet.getBalance());
        walletHistory.setBalanceBefore(walletBalanceBefore);
        walletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistoryRepository.save(walletHistory);
        walletRepository.save(wallet);
        //send SMS to customer
        transactionService.processCashOutSuccessCustomer(customer.getMobileNumber(),transaction);
        //send SMS to Cashier
        transactionService.processCashOutSuccessCashier(cashier.getMobileNumber(),transaction);
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountToRemove);
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);


    }
    public ResponseEntity ussdGetCurrencies(){
        List<Currency> failures =  currencyRepository.findByActive(true);

        List<CurrencyResponse> ticketFailureResponses = failures.stream().map(currencyService::mapEntityToCurrencyResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);
    }
    public  ResponseEntity checkBalance(String loggedInUser){
        UserCustomer customer = userCustomerRepository.findById(loggedInUser).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not authorized to perform this Action",110), HttpStatus.UNAUTHORIZED);
        }
        Wallet admin = walletRepository.findByCustomerUserId(customer.getUserId()).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Wallet",110), HttpStatus.EXPECTATION_FAILED);
        }
        CheckCustomerResponse response = new CheckCustomerResponse();
        WalletResponse walletResponse = transactionService.mapWalletEntityToResponse(admin);
        response.setMsisdn(customer.getMobileNumber());
        response.setId(customer.getUserId());
        response.setCurrentBalance(admin.getBalance());
        response.setWallet(walletResponse);
        return   ResponseEntity.ok(response);
    }


    private void sendSMS(String mobileNumber, String message){
        smsExecutor.ScheduledSmsExecutor(mobileNumber,message,1);
    }
    private String processSuccessRegistrationSmsMessage(String smsMessageCode,String otp){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin", otp);
            values.put("appSignature", "");
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Welcome To ChangeMoney You can Now Order";
        }
    }
    private String processResetPasswordSMSMessage(String smsMessageCode,String pin){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin",pin);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
}
