package zw.co.change.money.app.authentication.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
@Data
public class CustomerSignUpRequest {
    private String firstName;
    @NotNull
    private String appSignature;
    private String surname;
    @NotNull
    private String mobileNumber;
    @NotNull
    private String mobileNumberCountryCode;
    @NotNull
    private String password;
}
