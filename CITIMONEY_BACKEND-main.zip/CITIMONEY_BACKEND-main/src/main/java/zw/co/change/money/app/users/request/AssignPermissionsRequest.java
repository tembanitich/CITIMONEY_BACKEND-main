package zw.co.change.money.app.users.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.List;
@Data
public class AssignPermissionsRequest {
    @NotNull
    private List<PermissionRequest> permissions;
    @NotNull
    private String userId;
}
