package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CheckTransferRequest {
    private String receiverNumber;
    private String reference;
    private double amount;
}
