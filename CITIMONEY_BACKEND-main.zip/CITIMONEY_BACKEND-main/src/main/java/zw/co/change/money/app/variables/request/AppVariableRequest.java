package zw.co.change.money.app.variables.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
public class AppVariableRequest {
    @NotNull
    private String code;
    @NotNull
    @Size(max = 5000)
    private String value;
}
