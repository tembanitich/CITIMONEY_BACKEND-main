package zw.co.change.money.app.notifications.sms.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
public class SmsGatewayResponse {
    public Smslist smslist;
    @lombok.Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Sms{
        public int messageid;
        @JsonProperty("mobile-no")
        public String mobileNo;
        public int smsclientid;
    }
    @lombok.Data
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Smslist{
        public Sms sms;
    }




}
