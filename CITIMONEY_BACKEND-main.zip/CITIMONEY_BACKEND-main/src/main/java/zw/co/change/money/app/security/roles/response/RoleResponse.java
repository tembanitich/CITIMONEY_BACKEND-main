package zw.co.change.money.app.security.roles.response;

import lombok.Data;

@Data
public class RoleResponse {
    private String roleName;
    private String roleDescription;
}
