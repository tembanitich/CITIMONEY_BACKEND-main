package zw.co.change.money.app.variables.model;

public enum AppVariableType {
    STRING,DOUBLE,INTEGER,BOOLEAN
}
