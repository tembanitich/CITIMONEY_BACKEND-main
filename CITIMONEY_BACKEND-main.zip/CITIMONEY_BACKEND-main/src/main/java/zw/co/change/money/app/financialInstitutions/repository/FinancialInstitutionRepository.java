package zw.co.change.money.app.financialInstitutions.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface FinancialInstitutionRepository extends JpaRepository<FinancialInstitution, Long> {
    Optional<FinancialInstitution> findByName(String name);

    List<FinancialInstitution> findByActive(boolean status);
    Optional<FinancialInstitution> findByInstitutionNumber(String number);
    Boolean existsByInstitutionNumber(String number);
    Long countByActive(boolean status);
    Long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate);
    Page<FinancialInstitution> findByActive(boolean status, Pageable pageable);
    Page<FinancialInstitution> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<FinancialInstitution> findByNameContainingIgnoreCase(String query, Pageable pageable);
    Page<FinancialInstitution> findByNameContainingIgnoreCaseAndActive(String query,boolean status, Pageable pageable);
    Page<FinancialInstitution> findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String query, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);

}
