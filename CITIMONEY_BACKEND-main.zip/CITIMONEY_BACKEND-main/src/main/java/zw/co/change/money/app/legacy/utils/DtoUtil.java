package zw.co.change.money.app.legacy.utils;

import java.util.HashMap;
import java.util.Map;

public class DtoUtil {
    public  static Map<String, String> getAdditionalData(Map additionalData){
        if(additionalData== null){
            additionalData = new HashMap<>();
        }
        return additionalData;
    }
}
