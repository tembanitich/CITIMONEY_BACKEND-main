package zw.co.change.money.app.currencies.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.currencies.model.ExchangeRateHistory;

import java.time.LocalDateTime;
import java.util.List;

public interface ExchangeRateHistoryRepository extends JpaRepository<ExchangeRateHistory, Long> {
    List<ExchangeRateHistory> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<ExchangeRateHistory> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);

    List<ExchangeRateHistory> findByCurrencyIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long currencyId,LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<ExchangeRateHistory> findByCurrencyIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long currencyId,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
}

