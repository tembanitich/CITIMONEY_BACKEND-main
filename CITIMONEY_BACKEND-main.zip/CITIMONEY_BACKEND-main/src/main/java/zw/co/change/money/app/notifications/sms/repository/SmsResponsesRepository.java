package zw.co.change.money.app.notifications.sms.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.notifications.sms.model.SmsResponses;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SmsResponsesRepository extends JpaRepository<SmsResponses, Long> {
    Optional<SmsResponses> findByReferenceId(String reference);
    List<SmsResponses> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<SmsResponses> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<SmsResponses> findByPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String phoneNumber, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<SmsResponses> findByPhoneNumberIgnoreCaseContaining(String phoneNumber, Pageable pageable);
}
