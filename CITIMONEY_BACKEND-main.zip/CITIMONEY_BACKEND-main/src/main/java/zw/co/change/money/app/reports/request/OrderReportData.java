package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class OrderReportData {
    private String customer;
    private String paymentMethod;
    private String driver;
    private String status;
    private String productSummary;
    private String fulfillmentType;
    private LocalDateTime orderDate;
    private String orderNumber;
    private double total;
}
