package zw.co.change.money.app.notifications.websocket.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.StringUtils;
import zw.co.change.money.app.security.jwt.JwtTokenProvider;
import zw.co.change.money.app.security.user.CustomUserDetailsService;
import zw.co.change.money.app.security.user.UserPrincipal;

import java.util.List;

public class CustomChannelInterceptor implements ChannelInterceptor {

    private JwtTokenProvider tokenProvider;

    private CustomUserDetailsService customUserDetailsService;
    @Autowired
    CustomChannelInterceptor(JwtTokenProvider tokenProvider,CustomUserDetailsService customUserDetailsService){
        this.customUserDetailsService =customUserDetailsService;
        this.tokenProvider =tokenProvider;
    }


    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {

        StompHeaderAccessor accessor =  MessageHeaderAccessor.getAccessor(message,StompHeaderAccessor.class);
        if (StompCommand.CONNECT == accessor.getCommand()) {
//            List<String> authorization;
            if(accessor.getNativeHeader("Authorization")==null){
                System.out.println(accessor.getHeader("Authorization"));
            }
            List<String> authorization = accessor.getNativeHeader("Authorization");

            String accessToken = getJwtFromRequest(authorization.get(0));
            if (accessToken!=null &&!accessToken.isEmpty() && tokenProvider.validateToken(accessToken)) {
                String tokenHash  = tokenProvider.getUserTokenHashFromToken(accessToken);
                UserDetails userDetails = customUserDetailsService.loadUserByTokenHash(tokenHash);
                UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                accessor.setUser(authentication);
            }
        }
        if (StompCommand.SUBSCRIBE == accessor.getCommand()) {
//          String userId=  getDestination(accessor.getDestination(), "/notifications/");
//          if(!verifyUser(accessor.getUser(),userId)){
//              return null;
//          }

           System.out.println("Ikurova Subscribe");
            System.out.println(message);
        }
       if (StompCommand.CONNECTED == accessor.getCommand()) {
            System.out.println("Ikurova Connected  After Completion");
            System.out.println(message);
        }
        if (StompCommand.MESSAGE == accessor.getCommand()) {
            System.out.println("Ikurova Message  After Completion");
            System.out.println(message);
        }
        return message;
    }

    private String getDestination(String s, String prefix){
        if (s.startsWith(prefix)) {
            return s.substring(prefix.length(), s.length());
        }
        return null;
    }
    private Boolean verifyUser(Object user, String userId){
        UsernamePasswordAuthenticationToken userAuth=  (UsernamePasswordAuthenticationToken)user;
        UserPrincipal principal = (UserPrincipal)userAuth.getPrincipal();

        return principal.getUserId().equals(userId);

    }

    private String getJwtFromRequest(String bearerToken){
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

}
