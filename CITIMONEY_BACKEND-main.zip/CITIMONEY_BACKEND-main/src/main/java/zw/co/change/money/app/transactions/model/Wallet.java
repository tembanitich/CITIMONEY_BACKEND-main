package zw.co.change.money.app.transactions.model;

import lombok.*;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;

@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"customer"})
@Data
@Table(name = "wallets")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Wallet extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double balance;
    private WalletStatus status;
    @OneToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "customer", nullable = true)
    private UserCustomer customer;
    private String ecocashAccount;
    private String oneMoneyAccount;
    private String telecashAccount;
}
