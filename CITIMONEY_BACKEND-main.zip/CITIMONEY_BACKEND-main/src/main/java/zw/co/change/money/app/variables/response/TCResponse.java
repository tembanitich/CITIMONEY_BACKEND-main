package zw.co.change.money.app.variables.response;

import lombok.Data;

@Data
public class TCResponse {
    private String description;
}
