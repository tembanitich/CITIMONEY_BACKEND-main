package zw.co.change.money.app.variables.response;

import lombok.Data;

@Data
public class AppVariableResponse {
    private String code;
    private String value;
    private boolean active;
}
