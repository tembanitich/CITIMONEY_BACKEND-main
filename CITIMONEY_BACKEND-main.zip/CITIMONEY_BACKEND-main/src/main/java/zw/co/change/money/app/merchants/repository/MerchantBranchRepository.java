package zw.co.change.money.app.merchants.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MerchantBranchRepository extends JpaRepository<MerchantBranch, Long> {
    Optional<MerchantBranch> findByName(String name);

    List<MerchantBranch> findByActive(boolean status);
    Long countByActive(boolean status);
    Long countByActiveAndMerchantId(boolean status,String merchantId);
    Long countByMerchantId(String merchantId);
    Long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate);
    Page<MerchantBranch> findByActive(boolean status, Pageable pageable);
    Page<MerchantBranch> findByActiveAndMerchantId(boolean status,String merchantId, Pageable pageable);
    List<MerchantBranch> findByActiveAndMerchantId(boolean status,String merchantId);
    Page<MerchantBranch> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantBranch> findByNameContainingIgnoreCase(String query, Pageable pageable);
    List<MerchantBranch> findByNameContainingIgnoreCase(String query);
    List<MerchantBranch> findByNameContainingIgnoreCaseAndMerchantId(String query,String merchantId);
    List<MerchantBranch> findByMerchantId(String merchantId);
    Page<MerchantBranch> findByMerchantId(String merchantId, Pageable pageable);
    Page<MerchantBranch> findByNameContainingIgnoreCaseAndActive(String query,boolean status, Pageable pageable);
    Page<MerchantBranch> findByNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String query, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);

}
