package zw.co.change.money.app.accounts.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.accounts.model.MerchantAccountHistory;
import zw.co.change.money.app.accounts.model.MerchantAccountHistoryType;
import zw.co.change.money.app.transactions.model.Transaction;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.WalletHistory;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

public interface MerchantAccountHistoryRepository extends JpaRepository<MerchantAccountHistory, Long> {
    List<MerchantAccountHistory> findByAccountId(long accountId);
    Page<MerchantAccountHistory> findByAccountId(long accountId, Pageable pageable);
    Page<MerchantAccountHistory> findByAccountMerchantId(String merchantId, Pageable pageable);
    Page<MerchantAccountHistory> findByAccountAccountManagerUserId(String merchantId, Pageable pageable);
    Page<MerchantAccountHistory> findByAccountMerchantIdAndHistoryType(String merchantId,MerchantAccountHistoryType historyType, Pageable pageable);
    Page<MerchantAccountHistory> findByAccountAccountManagerUserIdAndHistoryType(String merchantId,MerchantAccountHistoryType historyType, Pageable pageable);
    List<MerchantAccountHistory> findFirst10ByAccountMerchantIdOrderByCreatedAtDesc( String merchantId);
    List<MerchantAccountHistory> findFirst10ByAccountAccountManagerUserIdOrderByCreatedAtDesc( String merchantId);
    Page<MerchantAccountHistory> findByAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(String name,LocalDateTime startDate,LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccountHistory> findByHistoryTypeAndAccountMerchantNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(MerchantAccountHistoryType transactionType, String name, LocalDateTime startDate, LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccountHistory> findByHistoryTypeAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(MerchantAccountHistoryType transactionType, String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,MerchantAccountHistoryType transactionType2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,MerchantAccountHistoryType transactionType3, String senderFirstName2, LocalDateTime startDate3, LocalDateTime endDate3,MerchantAccountHistoryType transactionType4, String senderLastName3, LocalDateTime startDate4, LocalDateTime endDate4, Pageable pageable);
    Page<MerchantAccountHistory> findByAccountAccountManagerUserIdAndHistoryTypeAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndHistoryTypeAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndHistoryTypeAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndHistoryTypeAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(String userId,MerchantAccountHistoryType transactionType, String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,String userId2,MerchantAccountHistoryType transactionType2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,String userId3,MerchantAccountHistoryType transactionType3, String senderFirstName2, LocalDateTime startDate3, LocalDateTime endDate3,String userId4,MerchantAccountHistoryType transactionType4, String senderLastName3, LocalDateTime startDate4, LocalDateTime endDate4, Pageable pageable);
    Page<MerchantAccountHistory> findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(String userId,String senderFirstName, LocalDateTime startDate, LocalDateTime endDate,String userId2, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2,String userId3, String senderFirstName2, LocalDateTime startDate3, LocalDateTime endDate3,String userId4, String senderLastName3, LocalDateTime startDate4, LocalDateTime endDate4, Pageable pageable);
    Page<MerchantAccountHistory> findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(String senderFirstName, LocalDateTime startDate, LocalDateTime endDate, String senderLastName, LocalDateTime startDate2, LocalDateTime endDate2, String senderFirstName2, LocalDateTime startDate3, LocalDateTime endDate3, String senderLastName3, LocalDateTime startDate4, LocalDateTime endDate4, Pageable pageable);
    Page<MerchantAccountHistory> findBySenderFirstNameContainingIgnoreCaseOrSenderSurnameContainingIgnoreCaseOrReceiverFirstNameContainingIgnoreCaseOrReceiverSurnameContainingIgnoreCase(String senderFirstName, String senderLastName,  String senderFirstName2,  String senderLastName3,Pageable pageable);
    Page<MerchantAccountHistory> findByAccountAccountManagerUserIdAndSenderFirstNameContainingIgnoreCaseOrAccountAccountManagerUserIdAndSenderSurnameContainingIgnoreCaseOrAccountAccountManagerUserIdAndReceiverFirstNameContainingIgnoreCaseOrAccountAccountManagerUserIdAndReceiverSurnameContainingIgnoreCase(String userId,String senderFirstName,String userId2, String senderLastName, String userId3, String senderFirstName2,String userId4,  String senderLastName3,Pageable pageable);
    Page<MerchantAccountHistory> findByAccountMerchantNameContainingIgnoreCase(String name, Pageable pageable);
    Page<MerchantAccountHistory> findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(LocalDateTime startDate,LocalDateTime endDate, Pageable pageable);
    Page<MerchantAccountHistory> findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(LocalDateTime startDate,LocalDateTime endDate, String merchantId,Pageable pageable);
    List<MerchantAccountHistory> findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(LocalDateTime startDate,LocalDateTime endDate, String merchantId);
    Page<MerchantAccountHistory> findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountAccountManagerUserId(LocalDateTime startDate,LocalDateTime endDate, String merchantId,Pageable pageable);
    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p where  p.created_at <= :endRange and  p.created_at >= :startRange", nativeQuery = true)
    double sumAmountByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);
    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.history_type ='DEPOSIT'", nativeQuery = true)
    double sumDepositByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p inner join merchant_account po on p.account = po.id  where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.history_type ='DEPOSIT' and po.account_manager=:accountManagerId", nativeQuery = true)
    double sumDepositByDateRangeByAccountManagerId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("accountManagerId") String accountManagerId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p inner join merchant_account po on p.account = po.id  where  p.created_at <= :endRange and  p.created_at >= :startRange and po.account_manager=:accountManagerId", nativeQuery = true)
    double sumAmountByDateRangeByAccountManagerId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("accountManagerId") String accountManagerId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p inner join merchant_account po on p.account = po.id where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.history_type ='DEPOSIT' and  po.merchant = :merchantId", nativeQuery = true)
    double sumDepositByDateRangeByMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("merchantId") String merchantId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p inner join merchant_account po on p.account = po.id  where  p.created_at <= :endRange and  p.created_at >= :startRange and  po.merchant = :merchantId", nativeQuery = true)
    double sumAmountByDateRangeByMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("merchantId") String merchantId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p inner join merchant_account po on p.account = po.id  inner join merchant_branch pg on po.merchant = pg.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  pg.id = :branchId", nativeQuery = true)
    double sumAmountByDateRangeByBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("branchId") long branchId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from merchant_account_histories p inner join merchant_account po on p.account = po.id  inner join merchant_branch pg on po.merchant = pg.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.history_type ='DEPOSIT' and  pg.id = :branchId", nativeQuery = true)
    double sumDepositByDateRangeByBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("branchId") long branchId);

}

