package zw.co.change.money.app.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import zw.co.change.money.app.security.roles.model.Permission;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.roles.repository.PermissionRepository;
import zw.co.change.money.app.security.roles.repository.PrivilegeRepository;
import zw.co.change.money.app.security.roles.repository.RoleRepository;

import javax.annotation.PostConstruct;
import java.util.*;

@Component("initRoles")
public class initRoles {

    @Autowired
    PermissionRepository permissionRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    PrivilegeRepository privilegeRepository;

    private Privilege savePrivilege(final String name) {
        Privilege privilege = privilegeRepository.findByName(name);
        if (privilege == null) {
            privilege = new Privilege(name);
            privilege = privilegeRepository.save(privilege);
        }
        return privilege;
    }

    private void saveNewRole(final RoleName name, String description, boolean selfRegEnabled, final Collection<Permission> permissions) {
        Role role = roleRepository.findByName(name).orElse(null);
        if (role == null) {
            role = new Role();
        }
        role.setName(name);
        role.setDescription(description);
        role.setPermissions(permissions);
        role.setSelfRegEnabled(selfRegEnabled);
        roleRepository.save(role);
    }
    private Permission saveNewPermission(final String name, final Collection<Privilege> privileges) {
        Permission role = new Permission();
        role.setName(name);
        role.setPrivileges(privileges);
       return permissionRepository.save(role);
    }

    @PostConstruct
    private void InitializeRolesAndPrivileges(){
        if (roleRepository.findAll().isEmpty()) {

            // == system Admin privileges
            final Privilege createAppVariables = savePrivilege("UPDATE_APP_VARIABLES");
        // == Ministry Admin privileges
            final Privilege createMerchantAdmins = savePrivilege("CREATE_MERCHANT_ADMINS");
            final Privilege updateMerchantAdmins = savePrivilege("EDIT_MERCHANT_ADMINS");
            final Privilege viewMerchantAdmins = savePrivilege("VIEW_MERCHANT_ADMINS");
            final Privilege activateMerchantAdmins = savePrivilege("ACTIVATE_MERCHANT_ADMINS");
            // == Ministry Agent privileges
            final Privilege createMerchantCashiers = savePrivilege("CREATE_MERCHANT_CASHIERS");
            final Privilege updateMerchantCashiers = savePrivilege("EDIT_MERCHANT_CASHIERS");
            final Privilege viewMerchantCashiers = savePrivilege("VIEW_MERCHANT_CASHIERS");
            final Privilege activateMerchantCashiers = savePrivilege("ACTIVATE_MERCHANT_CASHIERS");

            // == Department Supervisors privileges
            final Privilege createBranchManagers = savePrivilege("CREATE_BRANCH_MANAGERS");
            final Privilege updateBranchManagers = savePrivilege("EDIT_BRANCH_MANAGERS");
            final Privilege viewBranchManagers = savePrivilege("VIEW_BRANCH_MANAGERS");
            final Privilege activateBranchManagers = savePrivilege("ACTIVATE_BRANCH_MANAGERS");
            // == Department Employees privileges
            final Privilege createAccountManagers = savePrivilege("CREATE_ACCOUNT_MANAGERS");
            final Privilege updateAccountManagers = savePrivilege("EDIT_ACCOUNT_MANAGERS");
            final Privilege viewAccountManagers = savePrivilege("VIEW_ACCOUNT_MANAGERS");
            final Privilege activateAccountManagers = savePrivilege("ACTIVATE_ACCOUNT_MANAGERS");

            final Privilege createCustomers = savePrivilege("CREATE_CUSTOMERS");
            final Privilege updateCustomers = savePrivilege("EDIT_CUSTOMERS");
            final Privilege viewCustomers = savePrivilege("VIEW_CUSTOMERS");
            final Privilege activateCustomers = savePrivilege("ACTIVATE_CUSTOMERS");
            final Privilege editCustomersWallet = savePrivilege("EDIT_CUSTOMERS_WALLET");
            final Privilege viewCustomersWallet = savePrivilege("VIEW_CUSTOMERS_WALLET");
            // == backend Agents privileges
            final Privilege createBackendAgents = savePrivilege("CREATE_BACKEND_AGENTS");
            final Privilege updateBackendAgents = savePrivilege("EDIT_BACKEND_AGENTS");
            final Privilege viewBackendAgents = savePrivilege("VIEW_BACKEND_AGENTS");
            final Privilege activateBackendAgents = savePrivilege("ACTIVATE_BACKEND_AGENTS");
            // == brand Ambassador privileges
            final Privilege createBrandAmbassadors= savePrivilege("CREATE_BRAND_AMBASSADORS");
            final Privilege updateBrandAmbassadors = savePrivilege("EDIT_BRAND_AMBASSADORS");
            final Privilege viewBrandAmbassadors = savePrivilege("VIEW_BRAND_AMBASSADORS");
            final Privilege activateBrandAmbassadors = savePrivilege("ACTIVATE_BRAND_AMBASSADORS");
            // == backend Admin privileges
            final Privilege createBackendAdmins = savePrivilege("CREATE_BACKEND_ADMINS");
            final Privilege updateBackendAdmins = savePrivilege("EDIT_BACKEND_ADMINS");
            final Privilege viewBackendAdmins = savePrivilege("VIEW_BACKEND_ADMINS");
            final Privilege activateBackendAdmins = savePrivilege("ACTIVATE_BACKEND_ADMINS");
            // == backend Admin privileges

            final Privilege viewMerchantDeposits = savePrivilege("VIEW_MERCHANT_DEPOSITS");
            final Privilege approveMerchantDeposits = savePrivilege("APPROVE_MERCHANT_DEPOSITS");

            final Privilege view_merchant_withdrawals = savePrivilege("VIEW_MERCHANT_WITHDRAWALS");
            final Privilege applyMerchantWithdrawals = savePrivilege("APPLY_MERCHANT_WITHDRAWALS");
            final Privilege approveMerchantWithdrawals = savePrivilege("APPROVE_MERCHANT_WITHDRAWALS");
            final Privilege completeMerchantWithdrawals = savePrivilege("COMPLETE_MERCHANT_WITHDRAWALS");

            final Privilege createTellers = savePrivilege("CREATE_TELLERS");
            final Privilege updateTellers = savePrivilege("EDIT_TELLERS");
            final Privilege viewTellers = savePrivilege("VIEW_TELLERS");
            final Privilege activateTellers = savePrivilege("ACTIVATE_TELLERS");

            // == Team Spaces privileges
            final Privilege createMerchants = savePrivilege("CREATE_MERCHANTS");
            final Privilege updateMerchants = savePrivilege("EDIT_MERCHANTS");
            final Privilege viewMerchants = savePrivilege("VIEW_MERCHANTS");
            final Privilege activateMerchants = savePrivilege("ACTIVATE_MERCHANTS");
            final Privilege createMerchantBranches = savePrivilege("CREATE_MERCHANT_BRANCHES");
            final Privilege updateMerchantBranches = savePrivilege("EDIT_MERCHANT_BRANCHES");
            final Privilege viewMerchantBranches = savePrivilege("VIEW_MERCHANT_BRANCHES");
            final Privilege activateMerchantBranches = savePrivilege("ACTIVATE_MERCHANT_BRANCHES");
            final Privilege editMerchantAccounts = savePrivilege("EDIT_MERCHANT_ACCOUNTS");
            final Privilege viewMerchantAccounts = savePrivilege("VIEW_MERCHANT_ACCOUNTS");
            final Privilege depositMerchantAccounts = savePrivilege("DEPOSIT_MERCHANT_ACCOUNTS");
            final Privilege assignMerchantAccounts = savePrivilege("ASSIGN_MERCHANT_ACCOUNTS");
            // == Task privileges
//            final Privilege createFinancialInstitutions = savePrivilege("CREATE_FINANCIAL_INSTITUTIONS");
            final Privilege updateFinancialInstitutions = savePrivilege("EDIT_FINANCIAL_INSTITUTIONS");
            final Privilege viewFinancialInstitutions = savePrivilege("VIEW_FINANCIAL_INSTITUTIONS");
            final Privilege activateFinancialInstitutions = savePrivilege("ACTIVATE_FINANCIAL_INSTITUTIONS");


            // == Project privileges
            final Privilege createCurrencies = savePrivilege("CREATE_CURRENCIES");
            final Privilege updateCurrencies = savePrivilege("EDIT_CURRENCIES");
            final Privilege viewCurrencies = savePrivilege("VIEW_CURRENCIES");
            final Privilege activateCurrencies = savePrivilege("ACTIVATE_CURRENCIES");


            final Privilege editMerchantIncentives = savePrivilege("EDIT_MERCHANT_INCENTIVES");
            final Privilege viewMerchantIncentives = savePrivilege("VIEW_MERCHANT_INCENTIVES");

            final Privilege viewTransactions = savePrivilege("VIEW_TRANSACTIONS");


            // == Department privileges
            final Privilege makePayment = savePrivilege("MAKE_PAYMENT");

            final Privilege makeTransfer = savePrivilege("MAKE_TRANSFER");
            final Privilege makeCashout = savePrivilege("MAKE_CASHOUT");
            final Privilege makeIssueChange = savePrivilege("MAKE_ISSUE_CHANGE");
            final Privilege makeCashin = savePrivilege("MAKE_CASHIN");

            // == sms management privileges
            final Privilege viewSMSLogs = savePrivilege("VIEW_SMS_LOGS");

            // == report management privileges
            final Privilege auditTrailReport= savePrivilege("GENERATE_AUDIT_TRAIL_REPORT");
            final Privilege permissionsReport= savePrivilege("GENERATE_USER_PERMISSIONS_REPORT");
            final Privilege userActivityReport = savePrivilege("GENERATE_USER_ACTIVITY_REPORT");
            final Privilege paymentsReport = savePrivilege("GENERATE_TRANSACTIONS_REPORT");
            final Privilege merchantAccountReport = savePrivilege("GENERATE_MERCHANT_ACCOUNT_REPORT");
            final Privilege customerAccountReport = savePrivilege("GENERATE_CUSTOMER_ACCOUNT_REPORT");

            final Privilege viewDashboard = savePrivilege("VIEW_DASHBOARD");

            final List<Privilege> systemAdminAppVariableManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(createAppVariables));




            final List<Privilege> backendAdminMerchantDepositsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(viewMerchantDeposits,approveMerchantDeposits));

            final List<Privilege> backendAdminMerchantWithdrawalsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(view_merchant_withdrawals,applyMerchantWithdrawals,approveMerchantWithdrawals));
            final List<Privilege> backendAdminTellerWithdrawalsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(completeMerchantWithdrawals));

            final List<Privilege> backendAdminDashboardManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(viewDashboard));

            final List<Privilege> backendAdminSMSManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(viewSMSLogs));

            final List<Privilege> backendAdminReportsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(auditTrailReport,permissionsReport,userActivityReport,paymentsReport,merchantAccountReport,customerAccountReport
                    ));
            final List<Privilege> companyAdminReportsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(auditTrailReport,permissionsReport,userActivityReport,paymentsReport,merchantAccountReport
                    ));
            final List<Privilege> branchReportsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(auditTrailReport,permissionsReport,userActivityReport,paymentsReport,merchantAccountReport
                    ));
            final List<Privilege> accountAdminReportsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(merchantAccountReport
                    ));
            final List<Privilege> cashierReportsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(paymentsReport
                    ));
            final List<Privilege> customerReportsManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(paymentsReport,customerAccountReport
                    ));
            final List<Privilege> systemAdminUserManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(createBackendAdmins,updateBackendAdmins,viewBackendAdmins,activateBackendAdmins));

            final List<Privilege> backendAdminManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(createBackendAgents,updateBackendAgents,viewBackendAgents,activateBackendAgents,
                            createTellers,updateTellers,viewTellers,activateTellers,
                            createAccountManagers,updateAccountManagers,viewAccountManagers,activateAccountManagers,
                            createBranchManagers,updateBranchManagers,viewBranchManagers,activateBranchManagers,
                            createCustomers,updateCustomers,viewCustomers,activateCustomers,
                            createMerchantAdmins,updateMerchantAdmins,viewMerchantAdmins,activateMerchantAdmins,
                            createMerchantCashiers,updateMerchantCashiers,viewMerchantCashiers,activateMerchantCashiers,
                            createBrandAmbassadors,updateBrandAmbassadors,viewBrandAmbassadors,activateBrandAmbassadors

                    ));
            final List<Privilege> backendAgentManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( createAccountManagers,updateAccountManagers,viewAccountManagers,activateAccountManagers,
                            createBranchManagers,updateBranchManagers,viewBranchManagers,activateBranchManagers,
                            createCustomers,updateCustomers,viewCustomers,activateCustomers,
                            createTellers,updateTellers,viewTellers,activateTellers,
                            createMerchantAdmins,updateMerchantAdmins,viewMerchantAdmins,activateMerchantAdmins,
                            createMerchantCashiers,updateMerchantCashiers,viewMerchantCashiers,activateMerchantCashiers,
                            createBrandAmbassadors,updateBrandAmbassadors,viewBrandAmbassadors,activateBrandAmbassadors

                    ));
            final List<Privilege> cliendUserManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( createBranchManagers,updateBranchManagers,viewBranchManagers,activateBranchManagers,createMerchantCashiers,updateMerchantCashiers,viewMerchantCashiers,activateMerchantCashiers
                    ));
            final List<Privilege> baUserManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(  createCustomers,updateCustomers,viewCustomers,activateCustomers
                    ));
            final List<Privilege> branchUserManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( createMerchantCashiers,updateMerchantCashiers,viewMerchantCashiers,activateMerchantCashiers
                    ));
            final List<Privilege> merchantManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( createMerchants,updateMerchants,viewMerchants,activateMerchants,
                            createMerchantBranches,updateMerchantBranches,viewMerchantBranches,activateMerchantBranches

                    ));
            final List<Privilege> institutionManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( updateFinancialInstitutions,viewFinancialInstitutions,activateFinancialInstitutions
                    ));
            final List<Privilege> currencyManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( createCurrencies,updateCurrencies,viewCurrencies,activateCurrencies
                    ));
            final List<Privilege> merchantAccountManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( editMerchantAccounts,depositMerchantAccounts,assignMerchantAccounts,viewMerchantAccounts));
            final List<Privilege> companyAccountManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( viewMerchantAccounts));
            final List<Privilege> customerWalletManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( editCustomersWallet,viewCustomersWallet));
            final List<Privilege> incentivesManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( editMerchantIncentives,viewMerchantIncentives));
            final List<Privilege> incentivesAdminManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList(viewMerchantIncentives));
            final List<Privilege> transactionManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( viewTransactions));
            final List<Privilege> customerTransactionManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( makeCashin,makeCashout,makeTransfer,makePayment));
            final List<Privilege> companyCustomerTransactionManagementPriviledges =
                    new ArrayList<Privilege>(Arrays.asList( makeCashin,makeIssueChange));
            //////////////////////////////system admin permissions///////////////////////////////////////////////////////
           Permission systemAdminUserManagementPermission = this.saveNewPermission("User Management",  systemAdminUserManagementPriviledges);
           Permission systemAdminAppVariavlesManagementPermission = this.saveNewPermission("App Variables Management",  systemAdminAppVariableManagementPriviledges);
            final List<Permission> systemAdminPermissions =
                    new ArrayList<Permission>(Arrays.asList(systemAdminUserManagementPermission,systemAdminAppVariavlesManagementPermission));

            ////////////////////////////////////backend admin permissions////////////////////////////////////////////////////////
           Permission backendAdminUserManagementPermission = this.saveNewPermission("User Management",  backendAdminManagementPriviledges);
            Permission merchantManagement = this.saveNewPermission("Merchant Management",  merchantManagementPriviledges);
            Permission merchantAccountManagement = this.saveNewPermission("Merchant Account Management",  merchantAccountManagementPriviledges);
            Permission financialInstitutionsManagement = this.saveNewPermission("Financial Institutions Management",  institutionManagementPriviledges);
            Permission currencyManagement = this.saveNewPermission("Currency Management",  currencyManagementPriviledges);
            Permission customerWalletManagement = this.saveNewPermission("Customer Wallet Management",  customerWalletManagementPriviledges);
            Permission transactionManagement = this.saveNewPermission("Transaction Management",  transactionManagementPriviledges);
           Permission merchantIncentiveManagement = this.saveNewPermission("Merchant Incentive Management",  incentivesAdminManagementPriviledges);
            Permission dashboardManagement = this.saveNewPermission("Dashboard Management",  backendAdminDashboardManagementPriviledges );
            Permission smsManagement = this.saveNewPermission("SMS Management",  backendAdminSMSManagementPriviledges );
            Permission reportManagement = this.saveNewPermission("Report Management",backendAdminReportsManagementPriviledges );
            Permission backendAdminMerchantWithdrawalsManagement = this.saveNewPermission("Merchant Withdrawals Management",backendAdminMerchantWithdrawalsManagementPriviledges );
            Permission backendAdminMerchantDepositsManagement = this.saveNewPermission("Merchant Deposits Management",backendAdminMerchantDepositsManagementPriviledges );


            final List<Permission> backendAdminPermissions =
                    new ArrayList<Permission>(Arrays.asList(backendAdminUserManagementPermission,merchantManagement,merchantAccountManagement,financialInstitutionsManagement,
                            currencyManagement,customerWalletManagement,transactionManagement,
                            merchantIncentiveManagement,
                            backendAdminMerchantWithdrawalsManagement,
                            backendAdminMerchantDepositsManagement,
                            dashboardManagement,smsManagement,reportManagement
                            ));

            ////////////////////////////////////backend Agent permissions////////////////////////////////////////////////////////
            Permission backendAgentUserManagementPermission = this.saveNewPermission("User Management",  backendAdminManagementPriviledges);
            Permission backendAgentMerchantManagement = this.saveNewPermission("Merchant Management",  merchantManagementPriviledges);
            Permission backendAgentMerchantAccountManagement = this.saveNewPermission("Merchant Account Management",  merchantAccountManagementPriviledges);
            Permission backendAgentFinancialInstitutionsManagement = this.saveNewPermission("Financial Institutions Management",  institutionManagementPriviledges);
            Permission backendAgentCurrencyManagement = this.saveNewPermission("Currency Management",  currencyManagementPriviledges);
            Permission backendAgentCustomerWalletManagement = this.saveNewPermission("Customer Wallet Management",  customerWalletManagementPriviledges);
            Permission backendAgentTransactionManagement = this.saveNewPermission("Transaction Management",  transactionManagementPriviledges);
            Permission backendAgentCustomerTransactionManagement = this.saveNewPermission("Customer Transaction Management",  customerTransactionManagementPriviledges);
            Permission backendAgentMerchantIncentiveManagement = this.saveNewPermission("Merchant Incentive Management",  incentivesAdminManagementPriviledges);
            Permission backendAgentDashboardManagement = this.saveNewPermission("Dashboard Management",  backendAdminDashboardManagementPriviledges );
            Permission backendAgentSmsManagement = this.saveNewPermission("SMS Management",  backendAdminSMSManagementPriviledges );
            Permission backendMerchantWithdrawalsManagement = this.saveNewPermission("Merchant Withdrawals Management",backendAdminMerchantWithdrawalsManagementPriviledges );
            Permission backendMerchantDepositsManagement = this.saveNewPermission("Merchant Deposits Management",backendAdminMerchantDepositsManagementPriviledges );

            Permission backendAgentReportManagement = this.saveNewPermission("Report Management",backendAdminReportsManagementPriviledges );
            final List<Permission> backendAgentPermissions =
                    new ArrayList<Permission>(Arrays.asList(backendAgentUserManagementPermission,
                            backendAgentMerchantManagement,backendAgentMerchantAccountManagement,backendAgentFinancialInstitutionsManagement,
                            backendAgentCurrencyManagement,backendAgentCustomerWalletManagement,backendAgentTransactionManagement,backendAgentCustomerTransactionManagement,
                            backendAgentMerchantIncentiveManagement,
                            backendMerchantWithdrawalsManagement,
                            backendMerchantDepositsManagement,
                            backendAgentDashboardManagement,backendAgentSmsManagement,backendAgentReportManagement
                            ));


            ////////////////////////////////////Merchant Admin permissions////////////////////////////////////////////////////////
            Permission supervisorUserManagementPermission = this.saveNewPermission("Merchant User Management",  cliendUserManagementPriviledges);
            Permission companyMerchantAccountManagement = this.saveNewPermission("Merchant Merchant Account Management",  companyAccountManagementPriviledges);
            Permission companyTransactionManagement = this.saveNewPermission("Merchant Transaction Management",  transactionManagementPriviledges);
            Permission companyMerchantIncentiveManagement = this.saveNewPermission("Merchant Merchant Incentive Management",  incentivesManagementPriviledges);
            Permission companyDashboardManagement = this.saveNewPermission("Merchant Dashboard Management",  backendAdminDashboardManagementPriviledges );
            Permission companyReportManagement = this.saveNewPermission("Merchant Report Management",companyAdminReportsManagementPriviledges );
            Permission merchantWithdrawalsManagement = this.saveNewPermission("Merchant Merchant Withdrawals Management",backendAdminMerchantWithdrawalsManagementPriviledges );
            Permission merchantDepositsManagement = this.saveNewPermission("Merchant Merchant Deposits Management",backendAdminMerchantDepositsManagementPriviledges );
            final List<Permission> merchantAdminPermissions =
                    new ArrayList<Permission>(Arrays.asList(supervisorUserManagementPermission, companyMerchantAccountManagement
                            ,companyTransactionManagement,merchantWithdrawalsManagement,merchantDepositsManagement,
                            companyMerchantIncentiveManagement,
                            companyDashboardManagement,companyReportManagement
                    ));
            ////////////////////////////////////Branch Admin permissions////////////////////////////////////////////////////////
            Permission companyBranchUserManagementPermission = this.saveNewPermission("Company Branch User Management",  branchUserManagementPriviledges);
           Permission companyBranchTransactionManagement = this.saveNewPermission("Company Branch Transaction Management",  transactionManagementPriviledges);
          Permission companyBranchDashboardManagement = this.saveNewPermission("Company Branch Dashboard Management",  backendAdminDashboardManagementPriviledges );
            Permission companyBranchReportManagement = this.saveNewPermission("Company Branch Report Management",branchReportsManagementPriviledges );
            final List<Permission> branchPermissions =
                    new ArrayList<Permission>(Arrays.asList(companyBranchUserManagementPermission
                            ,companyBranchTransactionManagement,

                            companyBranchDashboardManagement,companyBranchReportManagement
                    ));
            ////////////////////////////////////Account Manager permissions////////////////////////////////////////////////////////
            Permission AccountMerchantAccountManagement = this.saveNewPermission("Account Manager Merchant Account Management",  merchantAccountManagementPriviledges);
            Permission accountBranchReportManagement = this.saveNewPermission("Account Manager Report Management",accountAdminReportsManagementPriviledges );
            Permission accountBranchDashboardManagement = this.saveNewPermission("Account Manager Dashboard Management",  backendAdminDashboardManagementPriviledges );

            final List<Permission> accountManagerPermissions =
                    new ArrayList<Permission>(Arrays.asList(AccountMerchantAccountManagement,accountBranchReportManagement,accountBranchDashboardManagement));
            
            ////////////////////////////////////Cashier permissions////////////////////////////////////////////////////////
            Permission cashierReportManagement = this.saveNewPermission("Cashier Report Management",cashierReportsManagementPriviledges );
            Permission cashierDashboardManagement = this.saveNewPermission("Cashier Dashboard Management",  backendAdminDashboardManagementPriviledges );
            Permission cashierTransactionManagement = this.saveNewPermission("Cashier Transaction Management",  transactionManagementPriviledges);
            Permission cashierCustomerTransactionManagement = this.saveNewPermission("Cashier Customer Transaction Management",  companyCustomerTransactionManagementPriviledges);

            final List<Permission> cashierPermissions =
                    new ArrayList<Permission>(Arrays.asList(cashierReportManagement,cashierTransactionManagement,cashierCustomerTransactionManagement,cashierDashboardManagement));

            ////////////////////////////////////Customer permissions////////////////////////////////////////////////////////
            Permission customerReportManagement = this.saveNewPermission("Client Report Management",customerReportsManagementPriviledges );
            Permission customerClientTransactionManagement = this.saveNewPermission("Client Transaction Management",  transactionManagementPriviledges);
            Permission clientCustomerTransactionManagement = this.saveNewPermission("Client Customer Transaction Management",  customerTransactionManagementPriviledges);

            final List<Permission> customerPermissions =
                    new ArrayList<Permission>(Arrays.asList(customerReportManagement,customerClientTransactionManagement,clientCustomerTransactionManagement));
            ////////////////////////////////////Teller permissions////////////////////////////////////////////////////////
            Permission depositsManagement = this.saveNewPermission("Merchant Merchant Deposits Management",backendAdminTellerWithdrawalsManagementPriviledges );

            final List<Permission> tellerPermissions =
                    new ArrayList<Permission>(Arrays.asList(depositsManagement));
            ////////////////////////////////////Teller permissions////////////////////////////////////////////////////////
            Permission brandAmbassadorUserManagement = this.saveNewPermission("Brand Ambassador User Management",baUserManagementPriviledges );

            final List<Permission> baPermissions =
                    new ArrayList<Permission>(Arrays.asList(brandAmbassadorUserManagement));

            this.saveNewRole(RoleName.ROLE_SYSTEM, "ChangeMoney System Administrator", false, systemAdminPermissions);
            this.saveNewRole(RoleName.ROLE_BACK_OFFICE_ADMIN, "ChangeMoney Admin", false, backendAdminPermissions);
//            this.saveNewRole(RoleName.ROLE_MERCHANT_USER, "ChangeMoney Admin", false, backendAdminPermissions);
            this.saveNewRole(RoleName.ROLE_ACCOUNT_MANAGER, "ChangeMoney Account Manager", false, accountManagerPermissions);
            this.saveNewRole(RoleName.ROLE_MERCHANT_ADMIN, "ChangeMoney Merchant Admin", false, merchantAdminPermissions);
            this.saveNewRole(RoleName.ROLE_CASHIER, "ChangeMoney Cashier", false, cashierPermissions);
            this.saveNewRole(RoleName.ROLE_BACK_OFFICE_AGENT, "ChangeMoney Agent", false, backendAgentPermissions);
            this.saveNewRole(RoleName.ROLE_BRANCH_MANAGER, "ChangeMoney Branch Manager", false, branchPermissions);
            this.saveNewRole(RoleName.ROLE_CUSTOMER, "ChangeMoney Customer", true, customerPermissions);
            this.saveNewRole(RoleName.ROLE_TELLER, "ChangeMoney Teller", false, tellerPermissions);
            this.saveNewRole(RoleName.ROLE_BA, "ChangeMoney Brand Ambassador", false, baPermissions);
            this.saveNewRole(RoleName.ROLE_GUEST, "ChangeMoney Guest", false, customerPermissions);

}
}
}
