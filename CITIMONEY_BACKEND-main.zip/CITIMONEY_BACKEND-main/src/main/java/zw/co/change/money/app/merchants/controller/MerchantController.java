package zw.co.change.money.app.merchants.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.merchants.request.AddMerchantBranchRequest;
import zw.co.change.money.app.merchants.request.AddMerchantRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantBranchRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantRequest;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.util.model.SearchRequest;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/merchants")
public class MerchantController {
    @Autowired
    MerchantService productService;
    ////////////////////////////////////////////////////////////////////////////////Fuel Dealers////////////////////////////////////////////////////////////////////////////////////
    @PostMapping(value="/add", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(description="add Merchant")
    public ResponseEntity addMerchant(@Valid @RequestPart("request") AddMerchantRequest request, @RequestPart("proofOfResidence") MultipartFile proofOfResidence, @RequestPart("taxClearance") MultipartFile taxClearance) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.addMerchant(request,proofOfResidence,taxClearance,currentUser.getUserId());
    }
    @PostMapping(value="/selfRegister", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(description="add Merchant")
    public ResponseEntity selfRegisterMerchant(@Valid @RequestPart("request") AddMerchantRequest request, @RequestPart("proofOfResidence") MultipartFile proofOfResidence, @RequestPart("taxClearance") MultipartFile taxClearance) {
        return productService.selfRegisterMerchant(request,proofOfResidence,taxClearance);
    }

    @PostMapping("/update")
    @Operation(description="update Fuel Dealer")
    public ResponseEntity updateMerchant(@Valid @RequestBody UpdateMerchantRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateMerchant(request,currentUser.getUserId());
    }
    @PostMapping("/search/byName")
    @Operation(description="Search Merchant")
    public ResponseEntity searchMerchantsByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantsByName(request,currentUser.getUserId());
    }
    @GetMapping("/activation/{merchantId}/{status}")
    @Operation(description="Activate/Deactivate Merchant")
    public ResponseEntity ActivateOrDeactivateMerchant(@PathVariable String merchantId, @PathVariable Boolean status){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.ActivateOrDeactivateMerchant(merchantId,status,currentUser.getUserId());
    }
    @GetMapping("/view/active")
    public ResponseEntity getActiveMerchants() {
        return productService.getActiveMerchants();
    }

    @GetMapping("/accountManager/view/all")
    public ResponseEntity getAllAccountManagerMerchants() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAllAccountManagerMerchants(currentUser.getUserId());
    }
    @GetMapping("/view/all")
    public ResponseEntity getAllMerchants(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getAllMerchants(page, size);
    }
    @GetMapping("/view/byStatus/{status}")
    public ResponseEntity getMerchantsByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getMerchantsByStatus(status,page, size);
    }
    @GetMapping("/view/byMerchantId/{merchantId}")
    public ResponseEntity getMerchantById(@PathVariable String merchantId) {
        return productService.getMerchantById(merchantId);
    }
    ////////////////////////////////////////////////////////////////////////////////Fuel Dealers////////////////////////////////////////////////////////////////////////////////////
    @PostMapping(value="/branches/add")
    @Operation(description="add MerchantBranch")
    public ResponseEntity addMerchantBranch(@Valid @RequestBody AddMerchantBranchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.addMerchantBranch(request,currentUser.getUserId());
    }


    @PostMapping("/branches/update")
    @Operation(description="update Fuel Dealer")
    public ResponseEntity updateMerchantBranch(@Valid @RequestBody UpdateMerchantBranchRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateMerchantBranch(request,currentUser.getUserId());
    }
    @PostMapping("/branches/search/byName")
    @Operation(description="Search MerchantBranch")
    public ResponseEntity searchMerchantBranchesByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantBranchesByName(request,currentUser.getUserId());
    }
    @GetMapping("/branches/activation/{merchantBranchId}/{status}")
    @Operation(description="Activate/Deactivate MerchantBranch")
    public ResponseEntity ActivateOrDeactivateMerchantBranch(@PathVariable long merchantBranchId, @PathVariable Boolean status){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.ActivateOrDeactivateMerchantBranch(merchantBranchId,status,currentUser.getUserId());
    }
    @GetMapping("/branches/view/active/byMerchantId/{merchantId}")
    public ResponseEntity getActiveMerchantBranchesByMerchantId(@PathVariable String merchantId) {
        return productService.getActiveMerchantBranchesByMerchantId(merchantId);
    }
    @GetMapping("/branches/view/active")
    public ResponseEntity getActiveMerchantBranches() {
        return productService.getActiveMerchantBranches();
    }
    @GetMapping("/branches/merchant/view/all")
    public ResponseEntity getAllMerchantMerchantBranches(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAllMerchantMerchantBranches(page, size,currentUser.getUserId());
    }
    @GetMapping("/branches/view/all")
    public ResponseEntity getAllMerchantBranches(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getAllMerchantBranches(page, size);
    }
    @GetMapping("/branches/view/byStatus/{status}")
    public ResponseEntity getMerchantBranchesByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getMerchantBranchesByStatus(status,page, size);
    }
    @GetMapping("/branches/view/byStatusAndMerchantId/{status}/{merchantId}")
    public ResponseEntity getMerchantBranchesByStatusByMerchantId(@PathVariable boolean status,@PathVariable String merchantId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getMerchantBranchesByStatusByMerchantId(merchantId,status,page, size);
    }
    @GetMapping("/branches/view/byMerchantBranchId/{merchantBranchId}")
    public ResponseEntity getMerchantBranchById(@PathVariable long merchantBranchId) {
        return productService.getMerchantBranchById(merchantBranchId);
    }
    @GetMapping("/branches/view/byMerchantId/{merchantId}")
    public ResponseEntity getAllMerchantBranchesByMerchantId(@PathVariable String merchantId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getAllMerchantBranchesByMerchantId(merchantId,page, size);
    }
}
