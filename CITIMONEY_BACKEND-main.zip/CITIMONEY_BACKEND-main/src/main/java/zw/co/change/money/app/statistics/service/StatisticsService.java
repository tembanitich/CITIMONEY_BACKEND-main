package zw.co.change.money.app.statistics.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.model.MerchantAccountHistory;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.accounts.repository.MerchantAccountHistoryRepository;
import zw.co.change.money.app.accounts.response.MerchantAccountHistoryResponse;
import zw.co.change.money.app.accounts.service.AccountsService;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.response.MerchantTransactionTotalInterface;
import zw.co.change.money.app.notifications.sms.repository.SmsFailuresRepository;
import zw.co.change.money.app.statistics.model.StatisticsCounter;
import zw.co.change.money.app.statistics.model.StatisticsTopTen;
import zw.co.change.money.app.statistics.repository.StatisticsCounterRepository;
import zw.co.change.money.app.statistics.repository.StatisticsTopTenRepository;
import zw.co.change.money.app.statistics.response.*;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.response.TransactionResponse;
import zw.co.change.money.app.transactions.service.TransactionService;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.response.CustomerTransactionTotalInterface;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.numbers.NumbersUtil;
import zw.co.change.money.app.util.response.GenericApiError;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Service
public class StatisticsService {

    @Autowired
    private StatisticsTopTenRepository statisticsTopTenRepository;
    @Autowired
    private StatisticsCounterRepository statisticsCounterRepository;
    @Autowired
    MerchantRepository merchantRepository;
    @Autowired
    MerchantAccountHistoryRepository accountHistoryRepository;
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    MerchantBranchRepository merchantBranchRepository;
    @Autowired
    MerchantBranchRepository branchRepository;
    @Autowired
    private SmsFailuresRepository smsFailuresRepository;
    @Autowired
    private MerchantAccountHistoryRepository merchantAccountHistoryRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    MerchantCashierRepository merchantCashierRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private AccountsService accountsService;
    @Autowired
    DateUtil dateUtil;

    public ResponseEntity getDashboard(String loggedInUserId) {
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        AccountManager accountManager = accountManagerRepository.findById(loggedInUserId).orElse(null);
        BranchManager branchManager = branchManagerRepository.findById(loggedInUserId).orElse(null);
        MerchantCashier cashier = merchantCashierRepository.findById(loggedInUserId).orElse(null);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);

        if (backendAdmin == null && agent==null&& accountManager==null&& branchManager==null&& cashier==null&& merchantAdmin==null) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        if(agent!=null || backendAdmin!=null ){
            return  this.backendAdminsDashboard();
        }
        if(accountManager!=null  ){
            return  this.accountManagerDashboard(accountManager.getUserId());
        }  if(cashier!=null  ){
            return  this.cashierDashboard(cashier.getUserId());
        }
        if(branchManager!=null  ){
            if(branchManager.getMerchantBranch()==null){
                return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",102), HttpStatus.EXPECTATION_FAILED);
            }
            return  this.branchManagerDashboard(branchManager.getMerchantBranch().getId());
        }
        if(merchantAdmin!=null  ){
            if(merchantAdmin.getMerchant()==null){
                return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
            }
            return  this.merchantDashboard(merchantAdmin.getMerchant().getId());
        }
        return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
    }

    private ResponseEntity backendAdminsDashboard(){
        AdminDashboardResponse adminDashboardResponse = new AdminDashboardResponse();
        adminDashboardResponse.setAccountManagerCount(this.getAccountManagersCount());
        adminDashboardResponse.setActiveAccountManagerCount(this.getActiveAccountManagersCount());
        adminDashboardResponse.setInactiveAccountManagerCount(this.getInActiveAccountManagersCount());
        adminDashboardResponse.setBranchManagerCount(this.getBranchManagersCount());
        adminDashboardResponse.setActiveBranchManagerCount(this.getActiveBranchManagersCount());
        adminDashboardResponse.setInactiveBranchManagerCount(this.getInActiveBranchManagersCount());
        adminDashboardResponse.setBranchCount(this.getBranchesCount());
        adminDashboardResponse.setActiveBranchCount(this.getActiveBranchesCount());
        adminDashboardResponse.setInactiveBranchCount(this.getInActiveBranchesCount());
        adminDashboardResponse.setCustomerCount(this.getCustomersCount());
        adminDashboardResponse.setActiveCustomerCount(this.getActiveCustomersCount());
        adminDashboardResponse.setInactiveCustomerCount(this.getInActiveCustomersCount());
        adminDashboardResponse.setMerchantCount(this.getMerchantsCount());
        adminDashboardResponse.setActiveMerchantCount(this.getActiveMerchantsCount());
        adminDashboardResponse.setInactiveMerchantCount(this.getInActiveMerchantsCount());
        adminDashboardResponse.setMerchantAdminCount(this.getMerchantAdminsCount());
        adminDashboardResponse.setActiveMerchantAdminCount(this.getActiveMerchantAdminsCount());
        adminDashboardResponse.setInactiveMerchantAdminCount(this.getInActiveMerchantAdminsCount());
        adminDashboardResponse.setCashierCount(this.getCashiersCount());
        adminDashboardResponse.setActiveCashierCount(this.getActiveCashiersCount());
        adminDashboardResponse.setInactiveCashierCount(this.getInActiveCashiersCount());

        adminDashboardResponse.setTransactionCountersThisMonth(this.getTransactionsCountersThisMonth());
        adminDashboardResponse.setTransactionCountersThisWeek(this.getTransactionsCountersThisWeek());
        adminDashboardResponse.setTransactionCountersThisYear(this.getTransactionsCountersThisYear());

        adminDashboardResponse.setTransactionTypesPieChart(this.getTransactionTypesPieChart());

        adminDashboardResponse.setTopTenCashiers(this.getTop10Cashiers());
        adminDashboardResponse.setTopTenCustomers(this.getTop10Customers());
        adminDashboardResponse.setTopTenMerchants(this.getTop10Merchants());
        adminDashboardResponse.setLastTransactions(this.getLastTransactions());
        return   ResponseEntity.ok(adminDashboardResponse);
    }
    private ResponseEntity accountManagerDashboard(String userId){
        AccountManagerDashboardResponse adminDashboardResponse = new AccountManagerDashboardResponse();
        adminDashboardResponse.setAccountsCount(this.getAccountsCount(userId));

        adminDashboardResponse.setDepositsCountersThisMonth(this.getDepositsCountersThisMonth(userId));
        adminDashboardResponse.setDepositsCountersThisWeek(this.getDepositsCountersThisWeek(userId));
        adminDashboardResponse.setDepositsCountersThisYear(this.getDepositsCountersThisYear(userId));

        adminDashboardResponse.setLastDeposits(this.getLastDeposits(userId));
        return   ResponseEntity.ok(adminDashboardResponse);
    }
    private ResponseEntity cashierDashboard(String userId){
        CashierDashboardResponse adminDashboardResponse = new CashierDashboardResponse();
        adminDashboardResponse.setTransactionCountersThisMonth(this.getTransactionsCountersThisMonthCashier(userId));
        adminDashboardResponse.setTransactionCountersThisWeek(this.getTransactionsCountersThisWeekCashier(userId));
        adminDashboardResponse.setTransactionCountersThisYear(this.getTransactionsCountersThisYearCashier(userId));
        adminDashboardResponse.setTransactionTypesPieChart(this.getTransactionTypesPieChartCashier(userId));
        adminDashboardResponse.setLastTransactions(this.getLastTransactionsCashier(userId));
        return   ResponseEntity.ok(adminDashboardResponse);
    }
    private ResponseEntity merchantDashboard(String merchantId){
        MerchantAdminDashboardResponse adminDashboardResponse = new MerchantAdminDashboardResponse();
        adminDashboardResponse.setBranchManagerCount(this.getBranchManagersCountByMerchantId(merchantId));
        adminDashboardResponse.setActiveBranchManagerCount(this.getActiveBranchManagersCountByMerchantId(merchantId));
        adminDashboardResponse.setInactiveBranchManagerCount(this.getInActiveBranchManagersCountByMerchantId(merchantId));
        adminDashboardResponse.setBranchCount(this.getBranchesCountByMerchantId(merchantId));
        adminDashboardResponse.setActiveBranchCount(this.getActiveBranchesCountByMerchantId(merchantId));
        adminDashboardResponse.setInactiveBranchCount(this.getInActiveBranchesCountByMerchantId(merchantId));
        adminDashboardResponse.setMerchantAdminCount(this.getMerchantAdminsCountByMerchantId(merchantId));
        adminDashboardResponse.setActiveMerchantAdminCount(this.getActiveMerchantAdminsCountByMerchantId(merchantId));
        adminDashboardResponse.setInactiveMerchantAdminCount(this.getInActiveMerchantAdminsCountByMerchantId(merchantId));
        adminDashboardResponse.setCashierCount(this.getCashiersCountByMerchantId(merchantId));
        adminDashboardResponse.setActiveCashierCount(this.getActiveCashiersCountByMerchantId(merchantId));
        adminDashboardResponse.setInactiveCashierCount(this.getInActiveCashiersCountByMerchantId(merchantId));

        adminDashboardResponse.setTransactionCountersThisMonth(this.getTransactionsCountersThisMonthByMerchantId(merchantId));
        adminDashboardResponse.setTransactionCountersThisWeek(this.getTransactionsCountersThisWeekByMerchantId(merchantId));
        adminDashboardResponse.setTransactionCountersThisYear(this.getTransactionsCountersThisYearByMerchantId(merchantId));

        adminDashboardResponse.setTransactionTypesPieChart(this.getTransactionTypesPieChartByMerchantId(merchantId));

        adminDashboardResponse.setTopTenCashiers(this.getTop10CashiersByMerchantId(merchantId));
        adminDashboardResponse.setLastTransactions(this.getLastTransactionsByMerchantId(merchantId));
        return   ResponseEntity.ok(adminDashboardResponse);
    }
    private ResponseEntity branchManagerDashboard(long branchId){
        BranchManagerDashboardResponse adminDashboardResponse = new BranchManagerDashboardResponse();
        adminDashboardResponse.setBranchManagerCount(this.getBranchManagersCountByBranchId(branchId));
        adminDashboardResponse.setActiveBranchManagerCount(this.getActiveBranchManagersCountByBranchId(branchId));
        adminDashboardResponse.setInactiveBranchManagerCount(this.getInActiveBranchManagersCountByBranchId(branchId));
        adminDashboardResponse.setCashierCount(this.getCashiersCountByBranchId(branchId));
        adminDashboardResponse.setActiveCashierCount(this.getActiveCashiersCountByBranchId(branchId));
        adminDashboardResponse.setInactiveCashierCount(this.getInActiveCashiersCountByBranchId(branchId));

        adminDashboardResponse.setTransactionCountersThisMonth(this.getTransactionsCountersThisMonthByBranchId(branchId));
        adminDashboardResponse.setTransactionCountersThisWeek(this.getTransactionsCountersThisWeekByBranchId(branchId));
        adminDashboardResponse.setTransactionCountersThisYear(this.getTransactionsCountersThisYearByBranchId(branchId));

        adminDashboardResponse.setTransactionTypesPieChart(this.getTransactionTypesPieChartByBranchId(branchId));

        adminDashboardResponse.setTopTenCashiers(this.getTop10CashiersByBranchId(branchId));
        adminDashboardResponse.setLastTransactions(this.getLastTransactionsByBranchId(branchId));
        return   ResponseEntity.ok(adminDashboardResponse);
    }

    private long getAccountsCount(String accountManagerId){
        return accountRepository.countByAccountManagerUserId(accountManagerId);
    }
    private long getMerchantsCount(){
        return merchantRepository.count();
    }
    private long getActiveMerchantsCount(){
        return merchantRepository.countByActive(true);
    }
    private long getInActiveMerchantsCount(){
        return merchantRepository.countByActive(false);
    }
    private long getMerchantAdminsCount(){
        return merchantAdminRepository.count();
    }
    private long getActiveMerchantAdminsCount(){
        return merchantAdminRepository.countByEnabled(true);
    }
    private long getInActiveMerchantAdminsCount(){
        return merchantAdminRepository.countByEnabled(false);
    }
    private long getMerchantAdminsCountByMerchantId(String merchantId){
        return merchantAdminRepository.countByMerchantId(merchantId);
    }
    private long getActiveMerchantAdminsCountByMerchantId(String merchantId){
        return merchantAdminRepository.countByEnabledAndMerchantId(true,merchantId);
    }
    private long getInActiveMerchantAdminsCountByMerchantId(String merchantId){
        return merchantAdminRepository.countByEnabledAndMerchantId(false,merchantId);
    }
    private long getCustomersCount(){
        return userCustomerRepository.count();
    }
    private long getActiveCustomersCount(){
        return userCustomerRepository.countByEnabled(true);
    }
    private long getInActiveCustomersCount(){
        return userCustomerRepository.countByEnabled(false);
    }
    private long getCashiersCount(){
        return merchantCashierRepository.count();
    }
    private long getActiveCashiersCount(){
        return merchantCashierRepository.countByEnabled(true);
    }
    private long getInActiveCashiersCount(){
        return merchantCashierRepository.countByEnabled(false);
    }
    private long getCashiersCountByBranchId(long branchId){
        return merchantCashierRepository.countByMerchantBranchId(branchId);
    }
    private long getActiveCashiersCountByBranchId(long branchId){
        return merchantCashierRepository.countByEnabledAndMerchantBranchId(true,branchId);
    }
    private long getInActiveCashiersCountByBranchId(long branchId){
        return merchantCashierRepository.countByEnabledAndMerchantBranchId(false,branchId);
    }
    private long getBranchManagersCount(){
        return branchManagerRepository.count();
    }
    private long getActiveBranchManagersCount(){
        return branchManagerRepository.countByEnabled(true);
    }
    private long getInActiveBranchManagersCount(){
        return branchManagerRepository.countByEnabled(false);
    }
    private long getBranchesCount(){
        return branchRepository.count();
    }
    private long getActiveBranchesCount(){
        return branchRepository.countByActive(true);
    }
    private long getInActiveBranchesCount(){
        return branchRepository.countByActive(false);
    }
    private long getBranchesCountByMerchantId(String merchantId){
        return branchRepository.countByMerchantId(merchantId);
    }
    private long getActiveBranchesCountByMerchantId(String merchantId){
        return branchRepository.countByActiveAndMerchantId(true,merchantId);
    }
    private long getInActiveBranchesCountByMerchantId(String merchantId){
        return branchRepository.countByActiveAndMerchantId(false,merchantId);
    }
    private long getCashiersCountByMerchantId(String merchantId){
        return merchantCashierRepository.countByMerchantBranchMerchantId(merchantId);
    }
    private long getActiveCashiersCountByMerchantId(String merchantId){
        return merchantCashierRepository.countByEnabledAndMerchantBranchMerchantId(true,merchantId);
    }
    private long getInActiveCashiersCountByMerchantId(String merchantId){
        return merchantCashierRepository.countByEnabledAndMerchantBranchMerchantId(false,merchantId);
    }
    private long getBranchManagersCountByMerchantId(String merchantId){
        return branchManagerRepository.countByMerchantBranchMerchantId(merchantId);
    }
    private long getActiveBranchManagersCountByMerchantId(String merchantId){
        return branchManagerRepository.countByEnabledAndMerchantBranchMerchantId(true,merchantId);
    }
    private long getInActiveBranchManagersCountByMerchantId(String merchantId){
        return branchManagerRepository.countByEnabledAndMerchantBranchMerchantId(false,merchantId);
    }
    private long getBranchManagersCountByBranchId(long branchId){
        return branchManagerRepository.countByMerchantBranchId(branchId);
    }
    private long getActiveBranchManagersCountByBranchId(long branchId){
        return branchManagerRepository.countByEnabledAndMerchantBranchId(true,branchId);
    }
    private long getInActiveBranchManagersCountByBranchId(long branchId){
        return branchManagerRepository.countByEnabledAndMerchantBranchId(false,branchId);
    }

    private long getAccountManagersCount(){
        return accountManagerRepository.count();
    }
    private long getActiveAccountManagersCount(){
        return accountManagerRepository.countByEnabled(true);
    }
    private long getInActiveAccountManagersCount(){
        return accountManagerRepository.countByEnabled(false);
    }

    private List<CounterGraph> getDepositsCountersThisMonth(String accountManagerId){

        double depositMonthCount;

       StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndAccountManagerId("SUCCESS_DEPOSITS_THIS_MONTH",accountManagerId).orElse(null);

        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),accountManagerId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();

        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Month");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getDepositsCountersThisWeek(String accountManagerId){

        double depositMonthCount;

       StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndAccountManagerId("SUCCESS_DEPOSITS_THIS_WEEK",accountManagerId).orElse(null);

        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),accountManagerId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();

        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Week");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getDepositsCountersThisYear(String accountManagerId){

        double depositMonthCount;

       StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndAccountManagerId("SUCCESS_DEPOSITS_THIS_YEAR",accountManagerId).orElse(null);

        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),accountManagerId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();

        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Year");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }

    private List<CounterGraph> getTransactionsCountersThisMonthCashier(String cashierId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHINS_THIS_MONTH",cashierId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHOUTS_THIS_MONTH",cashierId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_PAYMENTS_THIS_MONTH",cashierId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_TRANSFERS_THIS_MONTH",cashierId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }

        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Month");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Month");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Month");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Month");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);

        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisWeekCashier(String cashierId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHINS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHOUTS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_PAYMENTS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_TRANSFERS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_DEPOSITS_THIS_WEEK",cashierId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }

        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Week");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Week");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Week");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Week");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);

        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisYearCashier(String cashierId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHINS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHOUTS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_PAYMENTS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_TRANSFERS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_DEPOSITS_THIS_YEAR",cashierId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }

        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Year");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Year");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Year");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Year");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);

        return counters;
    }


    private List<CounterGraph> getTransactionsCountersThisMonth(){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHINS_THIS_MONTH",true).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHOUTS_THIS_MONTH",true).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_PAYMENTS_THIS_MONTH",true).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_TRANSFERS_THIS_MONTH",true).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_DEPOSITS_THIS_MONTH",true).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()));
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Month");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Month");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Month");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Month");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Month");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisWeek(){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHINS_THIS_WEEK",true).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHOUTS_THIS_WEEK",true).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_PAYMENTS_THIS_WEEK",true).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_TRANSFERS_THIS_WEEK",true).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_DEPOSITS_THIS_WEEK",true).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()));
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Week");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Week");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Week");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Week");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Week");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisYear(){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHINS_THIS_YEAR",true).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHOUTS_THIS_YEAR",true).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_PAYMENTS_THIS_YEAR",true).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_TRANSFERS_THIS_YEAR",true).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_DEPOSITS_THIS_YEAR",true).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()));
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Year");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Year");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Year");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Year");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Year");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }

    private List<CounterGraph> getTransactionsCountersThisMonthByMerchantId(String merchantId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHINS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHOUTS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_PAYMENTS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_TRANSFERS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_DEPOSITS_THIS_MONTH",merchantId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),merchantId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Month");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Month");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Month");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Month");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Month");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisWeekByMerchantId(String merchantId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHINS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHOUTS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_PAYMENTS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_TRANSFERS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_DEPOSITS_THIS_WEEK",merchantId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),merchantId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Week");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Week");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Week");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Week");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Week");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisYearByMerchantId(String merchantId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHINS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHOUTS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_PAYMENTS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_TRANSFERS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_DEPOSITS_THIS_YEAR",merchantId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),merchantId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Year");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Year");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Year");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Year");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Year");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }

    private List<CounterGraph> getTransactionsCountersThisMonthByBranchId(long branchId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHINS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHOUTS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_PAYMENTS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_TRANSFERS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_DEPOSITS_THIS_MONTH",branchId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),branchId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Month");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Month");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Month");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Month");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Month");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisWeekByBranchId(long branchId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHINS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHOUTS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_PAYMENTS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_TRANSFERS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_DEPOSITS_THIS_WEEK",branchId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),branchId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Week");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Week");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Week");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Week");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Week");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }
    private List<CounterGraph> getTransactionsCountersThisYearByBranchId(long branchId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHINS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHOUTS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_PAYMENTS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_TRANSFERS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_DEPOSITS_THIS_YEAR",branchId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =cashinCounter.getCount();
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =cashoutCounter.getCount();
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =paymentCounter.getCount();
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount =transferCounter.getCount();
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),branchId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount =depositCounter.getCount();
        }
        List<CounterGraph> counters = new ArrayList<>();
        CounterGraph counterGraph = new CounterGraph();
        counterGraph.setLabel("Cashin Transactions This Year");
        counterGraph.setValue(NumbersUtil.round(ecocashMonthCount,2));
        counters.add(counterGraph);
        CounterGraph counterGraph2 = new CounterGraph();
        counterGraph2.setLabel("Cashout Transactions This Year");
        counterGraph2.setValue(NumbersUtil.round(oneMoneyMonthCount,2));
        counters.add(counterGraph2);
        CounterGraph counterGraph3 = new CounterGraph();
        counterGraph3.setLabel("Payment Transactions This Year");
        counterGraph3.setValue(NumbersUtil.round(zipitMonthCount,2));
        counters.add(counterGraph3);
        CounterGraph counterGraph4 = new CounterGraph();
        counterGraph4.setLabel("Transfer Transactions This Year");
        counterGraph4.setValue(NumbersUtil.round(visaMonthCount,2));
        counters.add(counterGraph4);
        CounterGraph counterGraph5 = new CounterGraph();
        counterGraph5.setLabel("Deposit Transactions This Year");
        counterGraph5.setValue(NumbersUtil.round(depositMonthCount,2));
        counters.add(counterGraph5);
        return counters;
    }

    private PieChartGraph getTransactionTypesPieChart(){
        PieChartGraph pieChartGraph = new PieChartGraph();
        pieChartGraph.setPieChartName("SMS Pie Chart");
        List<PieChartCategory> categories = new ArrayList<>();

        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;
            double transfersMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_CASHINS_PIE_CHART_MONTH",i,true).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,true).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,true).orElse(null);
            StatisticsCounter transfersCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_TRANSFERS_PIE_CHART_MONTH",i,true).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setForAll(true);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =cashinsCounter.getCount();
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setForAll(true);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =cashoutCounter.getCount();
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setForAll(true);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =paymentsCounter.getCount();
            }
            if(transfersCounter==null){
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER);
                transfersCounter = new StatisticsCounter();
                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setForAll(true);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }else{
                transfersMonthCount =transfersCounter.getCount();
            }
            List<PieChartItem> items = new ArrayList<>();
            ///////////////Ecocash Pie Chart////////////////////
            PieChartItem ecocashItem = new PieChartItem();
            ecocashItem.setLabel("Cashins Transactions");
            if(cashinsMonthCount!=0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                ecocashItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                ecocashItem.setPercentage(0);
            }else{
                ecocashItem.setPercentage(NumbersUtil.round((cashinsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(ecocashItem);
            ///////////////One Money Pie Chart////////////////////
            PieChartItem oneMoneyItem = new PieChartItem();
            oneMoneyItem.setLabel("Cashouts Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount!=0&& paymentsMonthCount==0&& transfersMonthCount==0){
                oneMoneyItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                oneMoneyItem.setPercentage(0);
            }else{
                oneMoneyItem.setPercentage(NumbersUtil.round((cashoutsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(oneMoneyItem);
            ///////////////Zipit Pie Chart////////////////////
            PieChartItem zipitItem = new PieChartItem();
            zipitItem.setLabel("Payments Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount!=0&& transfersMonthCount==0){
                zipitItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                zipitItem.setPercentage(0);
            }else{
                zipitItem.setPercentage(NumbersUtil.round((paymentsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(zipitItem);
            ///////////////Visa Pie Chart////////////////////
            PieChartItem visaItem = new PieChartItem();
            visaItem.setLabel("Transfers Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount!=0){
                visaItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                visaItem.setPercentage(0);
            }else{
                visaItem.setPercentage(NumbersUtil.round((transfersMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(visaItem);

            pieChartCategory.setItems(items);
            pieChartCategory.setLabel(dateUtil.getMonthName(i));
            categories.add(pieChartCategory);
        }
        pieChartGraph.setCategories(categories);
        return pieChartGraph;
    }
    private PieChartGraph getTransactionTypesPieChartByMerchantId(String merchantId){
        PieChartGraph pieChartGraph = new PieChartGraph();
        pieChartGraph.setPieChartName("SMS Pie Chart");
        List<PieChartCategory> categories = new ArrayList<>();

        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;
            double transfersMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_CASHINS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            StatisticsCounter transfersCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_TRANSFERS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,merchantId);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setMerchantId(merchantId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =cashinsCounter.getCount();
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,merchantId);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setMerchantId(merchantId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =cashoutCounter.getCount();
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,merchantId);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setMerchantId(merchantId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =paymentsCounter.getCount();
            }
            if(transfersCounter==null){
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER,merchantId);
                transfersCounter = new StatisticsCounter();
                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setMerchantId(merchantId);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }else{
                transfersMonthCount =transfersCounter.getCount();
            }
            List<PieChartItem> items = new ArrayList<>();
            ///////////////Ecocash Pie Chart////////////////////
            PieChartItem ecocashItem = new PieChartItem();
            ecocashItem.setLabel("Cashins Transactions");
            if(cashinsMonthCount!=0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                ecocashItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                ecocashItem.setPercentage(0);
            }else{
                ecocashItem.setPercentage(NumbersUtil.round((cashinsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(ecocashItem);
            ///////////////One Money Pie Chart////////////////////
            PieChartItem oneMoneyItem = new PieChartItem();
            oneMoneyItem.setLabel("Cashouts Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount!=0&& paymentsMonthCount==0&& transfersMonthCount==0){
                oneMoneyItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                oneMoneyItem.setPercentage(0);
            }else{
                oneMoneyItem.setPercentage(NumbersUtil.round((cashoutsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(oneMoneyItem);
            ///////////////Zipit Pie Chart////////////////////
            PieChartItem zipitItem = new PieChartItem();
            zipitItem.setLabel("Payments Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount!=0&& transfersMonthCount==0){
                zipitItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                zipitItem.setPercentage(0);
            }else{
                zipitItem.setPercentage(NumbersUtil.round((paymentsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(zipitItem);
            ///////////////Visa Pie Chart////////////////////
            PieChartItem visaItem = new PieChartItem();
            visaItem.setLabel("Transfers Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount!=0){
                visaItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                visaItem.setPercentage(0);
            }else{
                visaItem.setPercentage(NumbersUtil.round((transfersMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(visaItem);

            pieChartCategory.setItems(items);
            pieChartCategory.setLabel(dateUtil.getMonthName(i));
            categories.add(pieChartCategory);
        }
        pieChartGraph.setCategories(categories);
        return pieChartGraph;
    }
    private PieChartGraph getTransactionTypesPieChartByBranchId(long branchId){
        PieChartGraph pieChartGraph = new PieChartGraph();
        pieChartGraph.setPieChartName("SMS Pie Chart");
        List<PieChartCategory> categories = new ArrayList<>();

        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;
            double transfersMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_CASHINS_PIE_CHART_MONTH",i,branchId).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,branchId).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,branchId).orElse(null);
            StatisticsCounter transfersCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_TRANSFERS_PIE_CHART_MONTH",i,branchId).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,branchId);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setBranchId(branchId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =cashinsCounter.getCount();
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,branchId);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setBranchId(branchId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =cashoutCounter.getCount();
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,branchId);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setBranchId(branchId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =paymentsCounter.getCount();
            }
            if(transfersCounter==null){
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER,branchId);
                transfersCounter = new StatisticsCounter();
                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setBranchId(branchId);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }else{
                transfersMonthCount =transfersCounter.getCount();
            }
            List<PieChartItem> items = new ArrayList<>();
            ///////////////Ecocash Pie Chart////////////////////
            PieChartItem ecocashItem = new PieChartItem();
            ecocashItem.setLabel("Cashins Transactions");
            if(cashinsMonthCount!=0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                ecocashItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                ecocashItem.setPercentage(0);
            }else{
                ecocashItem.setPercentage(NumbersUtil.round((cashinsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(ecocashItem);
            ///////////////One Money Pie Chart////////////////////
            PieChartItem oneMoneyItem = new PieChartItem();
            oneMoneyItem.setLabel("Cashouts Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount!=0&& paymentsMonthCount==0&& transfersMonthCount==0){
                oneMoneyItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                oneMoneyItem.setPercentage(0);
            }else{
                oneMoneyItem.setPercentage(NumbersUtil.round((cashoutsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(oneMoneyItem);
            ///////////////Zipit Pie Chart////////////////////
            PieChartItem zipitItem = new PieChartItem();
            zipitItem.setLabel("Payments Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount!=0&& transfersMonthCount==0){
                zipitItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                zipitItem.setPercentage(0);
            }else{
                zipitItem.setPercentage(NumbersUtil.round((paymentsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(zipitItem);
            ///////////////Visa Pie Chart////////////////////
            PieChartItem visaItem = new PieChartItem();
            visaItem.setLabel("Transfers Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount!=0){
                visaItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0&& transfersMonthCount==0){
                visaItem.setPercentage(0);
            }else{
                visaItem.setPercentage(NumbersUtil.round((transfersMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount+transfersMonthCount)*100),2));
            }
            items.add(visaItem);

            pieChartCategory.setItems(items);
            pieChartCategory.setLabel(dateUtil.getMonthName(i));
            categories.add(pieChartCategory);
        }
        pieChartGraph.setCategories(categories);
        return pieChartGraph;
    }
    private PieChartGraph getTransactionTypesPieChartCashier(String cashierId){
        PieChartGraph pieChartGraph = new PieChartGraph();
        pieChartGraph.setPieChartName("SMS Pie Chart");
        List<PieChartCategory> categories = new ArrayList<>();

        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndCashierId("SUCCESS_CASHINS_PIE_CHART_MONTH",i,cashierId).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndCashierId("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,cashierId).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndCashierId("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,cashierId).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,cashierId);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setCashierId(cashierId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =cashinsCounter.getCount();
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,cashierId);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setCashierId(cashierId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =cashoutCounter.getCount();
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,cashierId);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setCashierId(cashierId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =paymentsCounter.getCount();
            }

            List<PieChartItem> items = new ArrayList<>();
            ///////////////Ecocash Pie Chart////////////////////
            PieChartItem ecocashItem = new PieChartItem();
            ecocashItem.setLabel("Cashins Transactions");
            if(cashinsMonthCount!=0 && cashoutsMonthCount==0&& paymentsMonthCount==0){
                ecocashItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0){
                ecocashItem.setPercentage(0);
            }else{
                ecocashItem.setPercentage(NumbersUtil.round((cashinsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount)*100),2));
            }
            items.add(ecocashItem);
            ///////////////One Money Pie Chart////////////////////
            PieChartItem oneMoneyItem = new PieChartItem();
            oneMoneyItem.setLabel("Cashouts Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount!=0&& paymentsMonthCount==0){
                oneMoneyItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0){
                oneMoneyItem.setPercentage(0);
            }else{
                oneMoneyItem.setPercentage(NumbersUtil.round((cashoutsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount)*100),2));
            }
            items.add(oneMoneyItem);
            ///////////////Zipit Pie Chart////////////////////
            PieChartItem zipitItem = new PieChartItem();
            zipitItem.setLabel("Payments Transactions");
            if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount!=0){
                zipitItem.setPercentage(100);
            }else if(cashinsMonthCount==0 && cashoutsMonthCount==0&& paymentsMonthCount==0){
                zipitItem.setPercentage(0);
            }else{
                zipitItem.setPercentage(NumbersUtil.round((paymentsMonthCount/(cashinsMonthCount+cashoutsMonthCount+paymentsMonthCount)*100),2));
            }
            items.add(zipitItem);


            pieChartCategory.setItems(items);
            pieChartCategory.setLabel(dateUtil.getMonthName(i));
            categories.add(pieChartCategory);
        }
        pieChartGraph.setCategories(categories);
        return pieChartGraph;
    }

    
    private TopTenGraph getTop10Merchants(){
        double totalCount =0;
        TopTenGraph topTenGraph = new TopTenGraph();
        topTenGraph.setTopTenGraphLabel("Top 10 Merchants");
        List<TopTenGraphItem> items = new ArrayList<>();
        List<StatisticsTopTen> topTens = statisticsTopTenRepository.findByNameAndGlobalOrderByPositionAsc("TOP_10_MERCHANTS",true);
        if(topTens.isEmpty() || topTens.size()<10) {
            int index = 0;
            for (MerchantTransactionTotalInterface i : merchantRepository.getTop10Merchants()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndGlobal("TOP_10_MERCHANTS", index + 1,true).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_MERCHANTS");
                    topTen.setGlobal(true);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
                totalCount =totalCount+NumbersUtil.round(i.getTotal(),2);
                items.add(topTenGraphItem);
            }
        }else{
            for(StatisticsTopTen s: topTens){
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(s.getLabel());
                topTenGraphItem.setValue(NumbersUtil.round(s.getValue(),2));
                items.add(topTenGraphItem);
                totalCount =totalCount+s.getValue();
            }

        }

        topTenGraph.setItems(items);
        topTenGraph.setTotal(NumbersUtil.round(totalCount,2));
        return  topTenGraph;

    }
    private TopTenGraph getTop10Customers(){
        double totalCount =0;
        TopTenGraph topTenGraph = new TopTenGraph();
        topTenGraph.setTopTenGraphLabel("Top 10 Customers");
        List<TopTenGraphItem> items = new ArrayList<>();
        List<StatisticsTopTen> topTens = statisticsTopTenRepository.findByNameAndGlobalOrderByPositionAsc("TOP_10_CUSTOMERS",true);
        if(topTens.isEmpty() || topTens.size()<10) {
            int index = 0;
            for (CustomerTransactionTotalInterface i : userCustomerRepository.getTop10Customers()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndGlobal("TOP_10_CUSTOMERS", index + 1,true).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CUSTOMERS");
                    topTen.setGlobal(true);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
                totalCount =totalCount+NumbersUtil.round(i.getTotal(),2);
                items.add(topTenGraphItem);
            }
        }else{
            for(StatisticsTopTen s: topTens){
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(s.getLabel());
                topTenGraphItem.setValue(NumbersUtil.round(s.getValue(),2));
                items.add(topTenGraphItem);
                totalCount =totalCount+s.getValue();
            }

        }

        topTenGraph.setItems(items);
        topTenGraph.setTotal(NumbersUtil.round(totalCount,2));
        return  topTenGraph;

    }
    private TopTenGraph getTop10Cashiers(){
        double totalCount =0;
        TopTenGraph topTenGraph = new TopTenGraph();
        topTenGraph.setTopTenGraphLabel("Top 10 Cashiers");
        List<TopTenGraphItem> items = new ArrayList<>();
        List<StatisticsTopTen> topTens = statisticsTopTenRepository.findByNameAndGlobalOrderByPositionAsc("TOP_10_CASHIERS",true);
        if(topTens.isEmpty() || topTens.size()<10) {
            int index = 0;
            for (CustomerTransactionTotalInterface i : merchantCashierRepository.getTop10Cashiers()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndGlobal("TOP_10_CASHIERS", index + 1,true).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CASHIERS");
                    topTen.setGlobal(true);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
                totalCount =totalCount+NumbersUtil.round(i.getTotal(),2);
                items.add(topTenGraphItem);
            }
        }else{
            for(StatisticsTopTen s: topTens){
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(s.getLabel());
                topTenGraphItem.setValue(NumbersUtil.round(s.getValue(),2));
                items.add(topTenGraphItem);
                totalCount =totalCount+s.getValue();
            }

        }

        topTenGraph.setItems(items);
        topTenGraph.setTotal(NumbersUtil.round(totalCount,2));
        return  topTenGraph;

    }
    private TopTenGraph getTop10CashiersByBranchId(long branchId){
        double totalCount =0;
        TopTenGraph topTenGraph = new TopTenGraph();
        topTenGraph.setTopTenGraphLabel("Top 10 Cashiers");
        List<TopTenGraphItem> items = new ArrayList<>();
        List<StatisticsTopTen> topTens = statisticsTopTenRepository.findByNameAndBranchIdOrderByPositionAsc("TOP_10_CASHIERS",branchId);
        if(topTens.isEmpty() || topTens.size()<10) {
            int index = 0;
            for (CustomerTransactionTotalInterface i : merchantCashierRepository.getTop10Cashiers()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndBranchId("TOP_10_CASHIERS", index + 1,branchId).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CASHIERS");
                    topTen.setBranchId(branchId);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
                totalCount =totalCount+NumbersUtil.round(i.getTotal(),2);
                items.add(topTenGraphItem);
            }
        }else{
            for(StatisticsTopTen s: topTens){
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(s.getLabel());
                topTenGraphItem.setValue(NumbersUtil.round(s.getValue(),2));
                items.add(topTenGraphItem);
                totalCount =totalCount+s.getValue();
            }

        }

        topTenGraph.setItems(items);
        topTenGraph.setTotal(NumbersUtil.round(totalCount,2));
        return  topTenGraph;

    }
    private TopTenGraph getTop10CashiersByMerchantId(String merchantId){
        double totalCount =0;
        TopTenGraph topTenGraph = new TopTenGraph();
        topTenGraph.setTopTenGraphLabel("Top 10 Cashiers");
        List<TopTenGraphItem> items = new ArrayList<>();
        List<StatisticsTopTen> topTens = statisticsTopTenRepository.findByNameAndMerchantIdOrderByPositionAsc("TOP_10_CASHIERS",merchantId);
        if(topTens.isEmpty() || topTens.size()<10) {
            int index = 0;
            for (CustomerTransactionTotalInterface i : merchantCashierRepository.getTop10CashiersByMerchantId(merchantId)) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndMerchantId("TOP_10_CASHIERS", index + 1,merchantId).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CASHIERS");
                    topTen.setMerchantId(merchantId);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
                totalCount =totalCount+NumbersUtil.round(i.getTotal(),2);
                items.add(topTenGraphItem);
            }
        }else{
            for(StatisticsTopTen s: topTens){
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(s.getLabel());
                topTenGraphItem.setValue(NumbersUtil.round(s.getValue(),2));
                items.add(topTenGraphItem);
                totalCount =totalCount+s.getValue();
            }

        }

        topTenGraph.setItems(items);
        topTenGraph.setTotal(NumbersUtil.round(totalCount,2));
        return  topTenGraph;

    }
    private List<TransactionResponse> getLastTransactions(){
        return transactionRepository.findFirst10ByStatusOrderByCreatedAtDesc(TransactionStatus.SUCCESS).stream().map(transactionService::mapEntityToTransactionResponse).collect(toList());
    }
    private List<MerchantAccountHistoryResponse> getLastDeposits(String accountManagerId){
        return accountHistoryRepository.findFirst10ByAccountAccountManagerUserIdOrderByCreatedAtDesc(accountManagerId).stream().map(accountsService::mapEntityToAccountHistoryResponse).collect(toList());
    }
    private List<TransactionResponse> getLastTransactionsByMerchantId(String merchantId){
        return transactionRepository.findFirst10ByStatusAndMerchantIdOrderByCreatedAtDesc(TransactionStatus.SUCCESS,merchantId).stream().map(transactionService::mapEntityToTransactionResponse).collect(toList());
    }
    private List<TransactionResponse> getLastTransactionsByBranchId(long branchId){
        return transactionRepository.findFirst10ByStatusAndCashierMerchantBranchIdOrderByCreatedAtDesc(TransactionStatus.SUCCESS,branchId).stream().map(transactionService::mapEntityToTransactionResponse).collect(toList());
    }
    private List<TransactionResponse> getLastTransactionsCashier(String cashierId){
        return transactionRepository.findFirst10ByStatusAndCashierUserIdOrderByCreatedAtDesc(TransactionStatus.SUCCESS,cashierId).stream().map(transactionService::mapEntityToTransactionResponse).collect(toList());
    }


    private StatisticsCounter saveStatisticsCounterForAll(String name, double count){
        StatisticsCounter lastMonthCounter = new StatisticsCounter();
        lastMonthCounter.setCount(NumbersUtil.round(count,2));
        lastMonthCounter.setName(name);
        lastMonthCounter.setForAll(true);
        return statisticsCounterRepository.save(lastMonthCounter);
    }
    private StatisticsCounter saveStatisticsCounterForAllWithMonth(String name, double count,int month){
        StatisticsCounter lastMonthCounter = new StatisticsCounter();
        lastMonthCounter.setCount(NumbersUtil.round(count,2));
        lastMonthCounter.setName(name);
        lastMonthCounter.setMonth(month);
        lastMonthCounter.setForAll(true);
        return statisticsCounterRepository.save(lastMonthCounter);
    }
    private StatisticsCounter saveStatisticsCounterForAllWithDay(String name, double count, LocalDate day){
        StatisticsCounter lastMonthCounter = new StatisticsCounter();
        lastMonthCounter.setCount(NumbersUtil.round(count,2));
        lastMonthCounter.setName(name);
        lastMonthCounter.setDay(day);
        lastMonthCounter.setForAll(true);
        return statisticsCounterRepository.save(lastMonthCounter);
    }

    private StatisticsCounter saveStatisticsCounterForMerchant(String name, double count,String merchantId){
        StatisticsCounter lastMonthCounter = new StatisticsCounter();
        lastMonthCounter.setCount(NumbersUtil.round(count,2));
        lastMonthCounter.setName(name);
        lastMonthCounter.setMerchantId(merchantId);
        lastMonthCounter.setForAll(false);
        return statisticsCounterRepository.save(lastMonthCounter);
    }
    private StatisticsCounter saveStatisticsCounterForMerchantWithMonth(String name, double count,int month,String merchantId){
        StatisticsCounter lastMonthCounter = new StatisticsCounter();
        lastMonthCounter.setCount(NumbersUtil.round(count,2));
        lastMonthCounter.setName(name);
        lastMonthCounter.setMerchantId(merchantId);
        lastMonthCounter.setMonth(month);
        lastMonthCounter.setForAll(true);
        return statisticsCounterRepository.save(lastMonthCounter);
    }
    private StatisticsCounter saveStatisticsCounterForMerchantWithDay(String name, double count,LocalDate day,String merchantId){
        StatisticsCounter lastMonthCounter = new StatisticsCounter();
        lastMonthCounter.setCount(NumbersUtil.round(count,2));
        lastMonthCounter.setName(name);
        lastMonthCounter.setMerchantId(merchantId);
        lastMonthCounter.setDay(day);
        lastMonthCounter.setForAll(false);
        return statisticsCounterRepository.save(lastMonthCounter);
    }

}
