package zw.co.change.money.app.legacy.request;

import lombok.Data;

@Data
public class CashierAuthenticateRequest {
    private String msisdn;
    private String pin;
}
