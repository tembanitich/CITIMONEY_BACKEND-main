package zw.co.change.money.app.notifications.websocket.response;

import lombok.Data;

@Data
public class WebSocketNotificationResponse {
    private long id;
    private String userId;
    private String time;
    private String message;
    private ResponseType responseType;
    private boolean readStatus;
    private String title;
}
