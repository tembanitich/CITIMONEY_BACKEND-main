package zw.co.change.money.app.authentication.request;

import lombok.Data;

@Data
public class ResetPasswordRequest {
   private String mobileNumber;
   private String userId;
   private String appSignature;
}
