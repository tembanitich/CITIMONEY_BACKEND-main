package zw.co.change.money.app.authentication.model;

import lombok.Data;
import zw.co.change.money.app.util.audit.DateAudit;

import javax.persistence.*;

@Entity
@Data
@Table(name="registrationOtp",uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "id","userId"
        })
})
public class RegistrationOtp extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String otp;
    private String appSignature;
    private String userId;
}
