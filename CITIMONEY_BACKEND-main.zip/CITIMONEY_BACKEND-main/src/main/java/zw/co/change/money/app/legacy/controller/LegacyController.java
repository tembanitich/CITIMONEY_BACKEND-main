package zw.co.change.money.app.legacy.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.legacy.request.*;
import zw.co.change.money.app.legacy.response.*;
import zw.co.change.money.app.legacy.service.LegacyService;
import zw.co.change.money.app.security.user.UserPrincipal;

import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/api/")
public class LegacyController {
    @Autowired
    private LegacyService legacyService;
//
//    @GetMapping(value="role", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getRoles() {
//        return legacyService.getRoles();
//    }
//    @GetMapping(value="branchManagers", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getBranchManagers() {
//        return legacyService.getBranchManagers();
//    }
//    @GetMapping(value="branchManagers/{merchantBranchId}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getBranchManagersByMerchantBranchId(@PathVariable("merchantBranchId") long merchantId) {
//        return legacyService.getBranchManagersByMerchantBranchId(merchantId);
//    }
//    @GetMapping(value="merchantAdmins", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getMerchantAdmins() {
//        return legacyService.getMerchantAdmins();
//    }
//    @GetMapping(value="merchantCashiers", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getMerchantCashier() {
//        return legacyService.getMerchantCashier();
//    }
//    @GetMapping(value="merchantCashiersByMerchantId/{merchantId}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getMerchantCashierByMerchantId(@PathVariable("merchantId") String merchantId) {
//        return legacyService.getMerchantCashierByMerchantId(merchantId);
//    }
//    @GetMapping(value="accountManagers", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getAccountManagers() {
//        return legacyService.getAccountManagers();
//    }
//    @GetMapping(value="currency", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity saveMerchantUser(@RequestParam Map<String, String> additionalData, Pageable pageable) {
//       return legacyService.saveMerchantUser(additionalData);
//    }
//
//
//    @GetMapping(value = "currency/{currency-code}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getCurrencies(
//            @PathVariable("currency-code") String currencyCode,
//            @RequestParam Map<String, String> additionalData,
//            Pageable pageable) {
//        return legacyService.getCurrencies(currencyCode);
//    }
//
//    @PostMapping(value = "account-managers/assign-merchant", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity assignMerchant(
//            @RequestBody AccountManagerAssignRequest request) {
//        return legacyService.assignMerchant(request);
//    }
//
//    @GetMapping(value = "account-managers/{id}/merchants", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getMerchantById(@PathVariable("id") String id,
//                                                    @RequestParam(value = "query", required = false)
//                                                            String query) {
//        return legacyService.getMerchantById(id);
//    }
//
//    @GetMapping(value = "cashier-user/check-cashier/{msisdn}", produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity checkMerchantUser(
//            @PathVariable("msisdn") String msisdn,
//            @RequestParam Map<String, String> additionalData,
//            Pageable pageable) {
//        return legacyService.checkMerchantUser(msisdn);
//    }
//
//
//    @PostMapping(value = "cashier-user/authenticate", produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity authenticate(
//            @RequestBody CashierAuthenticateRequest cashierAuthenticateRequest,
//            Pageable pageable) {
//        return legacyService.authenticate(cashierAuthenticateRequest);
//    }
//
//    @PostMapping(value = "cashier-user/change-pin", produces = {MediaType.APPLICATION_JSON_VALUE})
//
//    public ResponseEntity changePin(
//            @RequestBody ChangePinRequest changePinRequest) {
//        return legacyService.changePin(changePinRequest);
//    }
//
//    @PostMapping(value="cashier-user",consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//
//    public ResponseEntity saveOrUpdateMerchantCashier(@RequestBody MerchantUserDto userDto) {
//        return legacyService.saveOrUpdateMerchantCashier(userDto);
//    }
//    @GetMapping(value="cashier-user")
//    public ResponseEntity getCashiers() {
//        return legacyService.getCashiers();
//    }
//    @PostMapping(value = "cashier-user/upload-cashier", consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//
//    public ResponseEntity saveMerchantUsersFile(@RequestBody FileUploadRequestDto userDto) {
//        return legacyService.saveMerchantUsersFile(userDto);
//    }
//
//    @GetMapping(value="cashier-user/",produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity queryCashier(@RequestParam(value = "query", required = false) String query,@RequestParam Map<String, String> additionalData) {
//        return legacyService.queryCashier(query,additionalData);
//    }
//
//    @GetMapping(value = "cashier-user/reset-pin/{msisdn}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity resetPin(@PathVariable("msisdn") String msisdn) {
//        return legacyService.resetPin(msisdn);
//    }
//
//    @GetMapping(value = "financial-institution",produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity getActiveFinancialInstitutions() {
//        return legacyService.getActiveFinancialInstitutions();
//    }
//
//    @GetMapping(value="merchant-branch",produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity queryMerchantBranch(
//            @RequestParam(value = "query", required = false) String query) {
//        return legacyService.queryMerchantBranch(query);
//    }
//
//    @GetMapping(value = "merchants/updateFloatLimit/{merchantId}/{floatLimit}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity updateMerchantFloat( @PathVariable("merchantId") String merchantId,@PathVariable("floatLimit") double floatLimit) {
//        return legacyService.updateMerchantFloat(merchantId,floatLimit);
//    }
//    @GetMapping(value = "merchant-branch/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getMerchantBranchById(
//            @PathVariable("id") long id) {
//        return legacyService.getMerchantBranchById(id);
//    }
//
//    @PostMapping(value = "merchant",consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity saveOrUpdateMerchant(@RequestBody MerchantDto merchantDto) {
//        return legacyService.saveOrUpdateMerchant(merchantDto);
//    }
//
//    @PostMapping(value = "merchant/{id}/currency", consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity saveOrUpdateCurrency(@PathVariable("id") String id, @RequestBody CurrencyDto currencyDto) {
//        return legacyService.saveOrUpdateCurrency(id,currencyDto);
//    }
//
//    @GetMapping(value = "merchant/{id}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getMerchantById(@PathVariable("id") String id,
//                                                    Pageable pageable) {
//        return legacyService.getMerchantById(id,pageable);
//    }
//    @GetMapping(value = "accountManagers/search/{query}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity searchAccountManagers(@PathVariable("query") String query) {
//        return legacyService.searchAccountManagers(query);
//    }
//    @GetMapping(value = "branchManagers/search/{query}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity searchBranchManagers(@PathVariable("query") String query) {
//        return legacyService.searchBranchManagers(query);
//    }    @GetMapping(value = "cashiers/search/{query}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity searchCashiers(@PathVariable("query") String query) {
//        return legacyService.searchCashiers(query);
//    }
//    @GetMapping(value = "merchantAdmins/search/{query}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity searchMerchantAdmin(@PathVariable("query") String query) {
//        return legacyService.searchMerchantAdmin(query);
//    }
//
//    @GetMapping(value="merchant",produces = {MediaType.APPLICATION_JSON_VALUE})
//
//    public ResponseEntity queryMerchant(@RequestParam(value = "query", required = false) String query) {
//        return legacyService.queryMerchant(query);
//    }
//
//    @PostMapping(value = "merchant/deposit-float-balance", consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity depositFloatBalance(@RequestBody MerchantDepositRequest merchantDepositRequest) {
//        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//        return legacyService.depositFloatBalance(merchantDepositRequest, currentUser.getUserId());
//    }
//    @GetMapping(value = "user/users-by-branch/{branchId}", produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity getCashiersByBranchId(@PathVariable("branchId") long branchId) {
//        return legacyService.getCashiersByBranchId(branchId);
//    }
//    @GetMapping(value = "merchant/{id}/branches", produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity getMerchantBranches(@PathVariable("id") String id,
//                                              @RequestParam(value = "query", required = false)
//                                                      String query,
//                                              Pageable pageable) {
//        return legacyService.getMerchantBranches(id,query,pageable);
//    }
//
//    @PostMapping(value = "merchant/{id}/branches", consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
////    @PreAuthorize("isAuthenticated()")
//    public ResponseEntity saveOrUpdateMerchantBranch(@PathVariable("id") String id
//            , @RequestBody MerchantBranchDto merchantDto) {
//        return legacyService.saveOrUpdateMerchantBranch(id,merchantDto);
//    }
//
//
//    @GetMapping(value = "reports/merchant-tranactions", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity merchantTransactions(@RequestParam(value = "merchantId")
//                                                                    String merchantId,
//                                                            @RequestParam(value = "startDate")
//                                                                    String startDate,
//
//                                                            @RequestParam(value = "endDate")
//                                                                    String endDate,@RequestParam Map<String, String> additionalData) {
//        return legacyService.merchantTransactions(merchantId,startDate,endDate,additionalData);
//    }
//
//
//    @GetMapping(value = "reports/branch-tranactions", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity branchTansactions(@RequestParam(value = "branchId")
//                                                                 long branchId,
//                                                         @RequestParam(value = "startDate")
//                                                                 String startDate,
//                                                         @RequestParam(value = "endDate")
//                                                                 String endDate) {
//        return legacyService.branchTansactions(branchId,startDate,endDate);
//    }
//
//    @GetMapping(value = "reports/cashier-tranactions", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity cashieransactions(@RequestParam(value = "msisidn")
//                                                                 String msisidn,
//                                                         @RequestParam(value = "startDate")
//                                                                 String startDate,
//                                                         @RequestParam(value = "endDate")
//                                                                 String endDate) {
//        return legacyService.cashieransactions(msisidn,startDate,endDate);
//    }
//
//
//    @PostMapping(value="self-reg",consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity selfRegister(@RequestBody SubscriberKycDetailsDto subscriberKycDetailsDto,@RequestParam Map<String, String> additionalData) {
//        return legacyService.selfRegister(subscriberKycDetailsDto,additionalData);
//    }
//
//    @PostMapping(value="transaction",consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity issueChange(@RequestBody IssueChangeLegacyRequest issueChangeLegacyRequest) {
//        return legacyService.issueChange(issueChangeLegacyRequest);
//    }
//
//    @GetMapping(value = "transaction/check-balance/{merchantId}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity chechMerchantBalance(
//            @PathVariable("merchantId") String merchantId,
//            @RequestParam Map<String, String> additionalData,
//            Pageable pageable) {
//        return legacyService.chechMerchantBalance(merchantId,additionalData,pageable);
//    }
//
//
//
//    @GetMapping(value = "ussd/check-cashier/{msisdn}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity checkUssdMerchantUser(
//            @PathVariable("msisdn") String msisdn,
//            @RequestParam Map<String, String> additionalData,
//            Pageable pageable) {
//        return legacyService.checkUssdMerchantUser(msisdn,additionalData,pageable);
//    }
//
//    @PostMapping(value = "ussd/authenticate", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity authenticateUssd(
//            @RequestBody CashierAuthenticateRequest cashierAuthenticateRequest,
//            Pageable pageable) {
//        return legacyService.authenticateUssd(cashierAuthenticateRequest,pageable);
//    }
//
//    @GetMapping(value = "ussd/financial-institution", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity getUssdActiveFinancialInstitutions() {
//        return legacyService.getUssdActiveFinancialInstitutions();
//    }
//
//    @GetMapping(value = "ussd/currency", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity saveUssdMerchantUser(@RequestParam Map<String, String> additionalData,
//                                                     Pageable pageable) {
//        return legacyService.saveUssdMerchantUser(additionalData,pageable);
//    }
//
//    @PostMapping(value = "ussd/transaction", consumes = {MediaType.APPLICATION_JSON_VALUE},
//            produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity issueUssdChange(@RequestBody IssueChangeLegacyRequest issueChangeLegacyRequest) {
//        return legacyService.issueUssdChange(issueChangeLegacyRequest);
//    }
//
//    @GetMapping(value = "ussd/check-balance/{merchantId}", produces = {MediaType.APPLICATION_JSON_VALUE})
//    public ResponseEntity chechUssdMerchantBalance(
//            @PathVariable("merchantId") String merchantId,
//            @RequestParam Map<String, String> additionalData,
//            Pageable pageable) {
//        return legacyService.chechUssdMerchantBalance(merchantId,additionalData,pageable);
//    }
}
