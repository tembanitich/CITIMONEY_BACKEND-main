package zw.co.change.money.app.notifications.websocket.request;

import lombok.Data;

import java.util.List;
@Data
public class MultipleNotificationsMarkAsReadRequest {
    private List<Long> notificationIds;
}
