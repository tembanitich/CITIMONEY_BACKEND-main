package zw.co.change.money.app.notifications.sms;

import lombok.Data;

@Data
public class SmsResponse {
    private String apiMessageId;
    private String to;
    private boolean accepted;
    private String errorCode;
    private String error;
    private String errorDescription;

}
