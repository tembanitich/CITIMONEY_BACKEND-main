package zw.co.change.money.app.statistics.response;

import lombok.Data;

import java.util.List;
@Data
public class BarGraph {
    private List<BarGraphItem> thisMonth;
    private List<BarGraphItem> thisYear;
    private List<BarGraphItem> thisWeek;
    private String xAxisLabel;
    private String yAxisLabel;
    private double totalThisMonth;
    private double totalThisYear;
    private double totalThisWeek;
    private double percentageLastYear;
    private double percentageLastMonth;
    private double percentageLastWeek;
}
