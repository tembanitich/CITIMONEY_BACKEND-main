package zw.co.change.money.app.transactions.response;

import lombok.Data;

@Data
public class CheckCustomerResponse {
    private String msisdn;
    private String id;
    private double currentBalance;
    private WalletResponse wallet;
}
