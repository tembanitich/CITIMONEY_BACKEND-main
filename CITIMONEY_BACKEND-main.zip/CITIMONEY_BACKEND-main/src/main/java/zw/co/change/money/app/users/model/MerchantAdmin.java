package zw.co.change.money.app.users.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;

import javax.persistence.*;

@Entity
@Table(name = "merchant_users")
@Data
@EqualsAndHashCode(callSuper = true)
@PrimaryKeyJoinColumn(name = "userId")
@DiscriminatorValue("6")
public class MerchantAdmin extends User {
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "merchant")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Merchant merchant;

}
