package zw.co.change.money.app.storage.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@Data
@ConfigurationProperties(prefix = "file")
public class FileStorageProperties {
    private String userDocuments;
    private String merchantDocuments;
    private String repositoryDocuments;
    private String reportTemplates;
}