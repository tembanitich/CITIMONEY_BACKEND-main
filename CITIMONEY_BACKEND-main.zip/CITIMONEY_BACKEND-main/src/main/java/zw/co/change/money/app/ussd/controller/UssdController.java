package zw.co.change.money.app.ussd.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.authentication.request.LoginRequest;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.transactions.request.*;
import zw.co.change.money.app.ussd.request.UssdAfterRegistrationChangePasswordRequest;
import zw.co.change.money.app.ussd.request.UssdConfirmOTPRequest;
import zw.co.change.money.app.ussd.request.UssdLoginRequest;
import zw.co.change.money.app.ussd.request.UssdResetPasswordRequest;
import zw.co.change.money.app.ussd.service.UssdService;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/ussd")
public class UssdController {

    @Autowired
    UssdService ussdService;

    @GetMapping("/customer/checkBalance")
    @Operation(description="logged in Customer Checks Balance")
    public ResponseEntity checkBalance() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.checkBalance(currentUser.getUserId());
    }
    @GetMapping("/customer/selfRegister/{mobileNumber}")
    @Operation(description="New Customer Self Register")
    public ResponseEntity ussdCustomerSignUp(@PathVariable String mobileNumber) {
        return ussdService.ussdCustomerSignUp(mobileNumber);
    }
    @GetMapping("/brandAmbassador/registerCustomer/{mobileNumber}")
    @Operation(description="BA Register New Customer ")
    public ResponseEntity ussdBARegister(@PathVariable String mobileNumber) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.ussdBARegister(mobileNumber,currentUser.getUserId());
    }
    @GetMapping("/checkUser/{mobileNumber}")
    @Operation(description="Check User Status")
    public ResponseEntity checkUser(@PathVariable String mobileNumber) {
        return ussdService.checkUser(mobileNumber);
    }
    @GetMapping("/get/currencies")
    @Operation(description="get list of active currencies ")
    public ResponseEntity ussdGetCurrencies() {
        return ussdService.ussdGetCurrencies();
    }
    @PostMapping("/brandAmbassador/login")
    @Operation(description="authenticate and fetch access token for brand ambassadors")
    public ResponseEntity ussdBALogin(@Valid @RequestBody UssdLoginRequest request) {
        return ussdService.ussdBALogin(request);
    }
    @PostMapping("/customer/login")
    @Operation(description="authenticate and fetch access token for customers")
    public ResponseEntity ussdCustomerLogin(@Valid @RequestBody UssdLoginRequest request) {
        return ussdService.ussdCustomerLogin(request);
    }
    @PostMapping("/resetPassword")
    @Operation(description="user resets password ")
    public ResponseEntity ussdResetPassword(@Valid @RequestBody UssdResetPasswordRequest request) {
        return ussdService.ussdResetPassword(request);
    }
    @PostMapping("/confirmOTP")
    @Operation(description="user confirms otp and sets new password ")
    public ResponseEntity ussdConfirmOTP(@Valid @RequestBody UssdConfirmOTPRequest request) {
        return ussdService.ussdConfirmOTP(request);
    }
    @PostMapping("/firstTimeLoginActivation")
    @Operation(description="user activates account first time using the platform")
    public ResponseEntity ussdFirstTimeLogin(@Valid @RequestBody UssdAfterRegistrationChangePasswordRequest request) {
        return ussdService.ussdFirstTimeLogin(request);
    }

    @PostMapping("/transactions/checkCashout")
    @Operation(description="customer check cashout")
    public ResponseEntity checkCashoutRequest(@Valid @RequestBody CheckCashoutRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.checkCashoutRequest(request,currentUser.getUserId());
    }
    @PostMapping("/transactions/confirmCashout")
    @Operation(description="customer confirm cashout")
    public ResponseEntity cashOut(@Valid @RequestBody CashOutRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.cashOut(request,currentUser.getUserId());
    }

    @PostMapping("/transactions/checkPayment")
    @Operation(description="customer check Payment")
    public ResponseEntity checkPaymentRequest(@Valid @RequestBody CheckPaymentRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.checkPaymentRequest(request,currentUser.getUserId());
    }
    @PostMapping("/transactions/confirmPayment")
    @Operation(description="customer confirm Payment")
    public ResponseEntity makePayment(@Valid @RequestBody CustomerPaymentRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.makePayment(request,currentUser.getUserId());
    }

    @PostMapping("/transactions/checkTransfer")
    @Operation(description="customer check Transfer")
    public ResponseEntity checkTransferRequest(@Valid @RequestBody CheckTransferRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.checkTransferRequest(request,currentUser.getUserId());
    }
    @PostMapping("/transactions/confirmTransfer")
    @Operation(description="customer confirm Transfer")
    public ResponseEntity TransferCredit(@Valid @RequestBody CustomerTransferRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return ussdService.TransferCredit(request,currentUser.getUserId());
    }


}
