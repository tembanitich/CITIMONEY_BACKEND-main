package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.merchants.response.MerchantResponse;
import zw.co.change.money.app.users.response.MerchantCashierResponse;

@Data
public class CheckPaymentResponse {
    private MerchantResponse merchant;
    private MerchantCashierResponse cashier;
    private CurrencyResponse currency;
    private double amount;
    private double customerBalance;
    private double amountInUsd;
}
