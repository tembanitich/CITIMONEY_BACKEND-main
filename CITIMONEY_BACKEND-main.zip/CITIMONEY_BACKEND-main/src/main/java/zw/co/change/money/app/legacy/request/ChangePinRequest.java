package zw.co.change.money.app.legacy.request;

import lombok.Data;

@Data
public class ChangePinRequest {

    private String oldPin;
    private String msisdn;
    private String newPin;
    private String confirmPin;
}
