package zw.co.change.money.app.reports.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.reports.model.ReportColumnConfiguration;
import zw.co.change.money.app.reports.model.ReportTemplateName;

import java.util.List;
import java.util.Optional;

public interface ReportColumnConfigurationRepository extends JpaRepository<ReportColumnConfiguration, Long> {
    List<ReportColumnConfiguration> findByReportName(ReportTemplateName reportTemplateName);
    Optional<ReportColumnConfiguration> findByReportNameAndId(ReportTemplateName reportTemplateName, long id);
}
