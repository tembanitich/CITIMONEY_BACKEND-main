package zw.co.change.money.app.notifications.websocket.model;

public enum WebSocketMessageGroup {
    CUSTOMERS,BACKEND_ADMINS,GUEST,BACKEND_AGENT,SYSTEM_ADMINS,ACCOUNT_MANAGERS,TELLERS,BA
}
