package zw.co.change.money.app.chat.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.chat.service.ChatService;
import zw.co.change.money.app.security.user.UserPrincipal;

@RestController
@RequestMapping("/api/chatMessages")
public class ChatController {
    @Autowired
    ChatService chatService;

    @GetMapping("/view/groupedChat")
    public ResponseEntity getChatMessagesGroupedByUser() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return chatService.getChatMessagesGroupedByUser(currentUser.getUserId());
    }
    @GetMapping("/view/all")
    public ResponseEntity getAllProducts(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                         @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return chatService.getAllChatMessages(page, size,currentUser.getUserId());
    }
    @GetMapping("/view/byCustomerId/{customerId}")
    public ResponseEntity getAllProducts(@PathVariable String customerId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                         @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return chatService.getChatMessageByCustomerId(customerId,page, size,currentUser.getUserId());
    }
    @GetMapping("/view/byId/{chatMessageId}")
    public ResponseEntity getProductById(@PathVariable long chatMessageId) {
        return chatService.getChatMessageById(chatMessageId);
    }
    @GetMapping("/view/me")
    public ResponseEntity getMyChatMessages(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return chatService.getMyChatMessages(currentUser.getUserId(),page, size);
    }
    @GetMapping("/sendTestChatToCustomer/{customerId}/{message}")
    public ResponseEntity sendMessageToCustomerSpecific(@PathVariable String customerId,@PathVariable String message) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return chatService.sendMessageToCustomerSpecific(message,customerId,currentUser.getUserId());
    }
}
