package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CashInRequest {
    private String receiverPhoneNumber;
    private String pin;
    private double amount;
}
