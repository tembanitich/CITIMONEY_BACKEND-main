package zw.co.change.money.app.currencies.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;

@Entity
@EqualsAndHashCode(callSuper = true)
@Data
public class ExchangeRateHistory extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String responsibleUser;
    private double previousExchangeRate;
    private double newExchangeRate;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "currency")
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JsonIgnore
    private Currency currency;
}