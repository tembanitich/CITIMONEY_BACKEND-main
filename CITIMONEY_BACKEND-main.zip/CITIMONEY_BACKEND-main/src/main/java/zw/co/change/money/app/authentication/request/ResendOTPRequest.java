package zw.co.change.money.app.authentication.request;

import lombok.Data;

@Data
public class ResendOTPRequest {
    private String mobileNumber;
    private String appSignature;
}
