package zw.co.change.money.app.legacy.request;

import lombok.Data;

@Data
public class IssueChangeLegacyRequest {
    private String msisdn;
    private String merchantId;
    private double tenderedAmount;
    private String currency;
    private String destinationAccount;
    private String receipt;
    private double changeIssued;
    private double changeRequired;
    private String acquiringFinancialInstitutionNumber;
    private String notificationMsisdn;
}
