package zw.co.change.money.app.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.security.roles.model.Permission;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.roles.repository.PermissionRepository;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component("initUsers")
@DependsOn({"initRoles"})
public class InitUsers {
    @Autowired
    private PermissionRepository permissionRepository;
    @Autowired
    UserSystemAdminRepository userSystemAdminRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    UserGuestRepository userGuestRepository;

    @Autowired
    UserRepository userRepository;
    @Autowired
    StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    PasswordEncoder passwordEncoder;

    private void saveUserBackend(String firstName, String surname,  String email, RoleName roleName) {

        Role role = roleRepository.findByName(roleName).orElse(null);

        //===save admin
        if (roleName.equals(RoleName.ROLE_SYSTEM)) {

            UserSystemAdmin admin = new UserSystemAdmin();
            admin.setUserId(stringGeneratorUtility.fetchValidUserId(roleName));
            admin.setFirstName(firstName);
            admin.setSurname(surname);
            admin.setEmail(email);
            admin.setResetPin(false);
            admin.setMessageGroup(WebSocketMessageGroup.BACKEND_ADMINS);

            admin.setPassword(passwordEncoder.encode("#Pass2022"));
            admin.setRoles(Collections.singletonList(role));
            admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            admin.setUsername(stringGeneratorUtility.generateStaffNumber());
            UserSystemAdmin savedAdmin =userSystemAdminRepository.save(admin);
            //////////////////////assign Permissions////////////////////////
            assignPermissionsByRoleToUser(RoleName.ROLE_SYSTEM,savedAdmin);
        }
        if (roleName.equals(RoleName.ROLE_GUEST)) {

            UserGuest admin = new UserGuest();
            admin.setUserId(stringGeneratorUtility.fetchValidUserId(roleName));
            admin.setFirstName(firstName);
            admin.setSurname(surname);
            admin.setEmail(email);
            admin.setResetPin(false);
            admin.setMobileNumber("N/A");
            admin.setMobileNumberCountryCode("N/A");
            admin.setMessageGroup(WebSocketMessageGroup.GUEST);
            admin.setPassword(passwordEncoder.encode("#Pass2022"));
            admin.setRoles(Collections.singletonList(role));
            admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            admin.setUsername(stringGeneratorUtility.generateStaffNumber());
            UserGuest savedAdmin = userGuestRepository.save(admin);
            //////////////////////assign Permissions////////////////////////
            assignPermissionsByRoleToUser(RoleName.ROLE_GUEST,savedAdmin);
        }
        if (roleName.equals(RoleName.ROLE_BACK_OFFICE_AGENT)) {

            UserBackendAgent admin = new UserBackendAgent();
            admin.setUserId(stringGeneratorUtility.fetchValidUserId(roleName));
            admin.setFirstName(firstName);
            admin.setSurname(surname);
            admin.setEmail(email);
            admin.setResetPin(false);
            admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
            admin.setPassword(passwordEncoder.encode("#Pass2022"));
            admin.setRoles(Collections.singletonList(role));
            admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            admin.setUsername(stringGeneratorUtility.generateStaffNumber());
            UserBackendAgent savedAdmin = userBackendAgentRepository.save(admin);
            //////////////////////assign Permissions////////////////////////
            assignPermissionsByRoleToUser(RoleName.ROLE_BACK_OFFICE_AGENT,savedAdmin);
        }

        if (roleName.equals(RoleName.ROLE_BACK_OFFICE_ADMIN)) {

            UserBackendAdmin admin = new UserBackendAdmin();
            admin.setUserId(stringGeneratorUtility.fetchValidUserId(roleName));
            admin.setFirstName(firstName);
            admin.setSurname(surname);
            admin.setEmail(email);
            admin.setResetPin(false);
            admin.setMessageGroup(WebSocketMessageGroup.BACKEND_ADMINS);
            admin.setPassword(passwordEncoder.encode("#Pass2022"));
            admin.setRoles(Collections.singletonList(role));
            admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            admin.setUsername(stringGeneratorUtility.generateStaffNumber());
            UserBackendAdmin savedAdmin =userBackendAdminRepository.save(admin);
            //////////////////////assign Permissions////////////////////////
            assignPermissionsByRoleToUser(RoleName.ROLE_BACK_OFFICE_ADMIN,savedAdmin);
        }
        if (roleName.equals(RoleName.ROLE_ACCOUNT_MANAGER)) {

            AccountManager admin = new AccountManager();
            admin.setUserId(stringGeneratorUtility.fetchValidUserId(roleName));
            admin.setFirstName(firstName);
            admin.setSurname(surname);
            admin.setEmail(email);
            admin.setResetPin(false);
            admin.setMessageGroup(WebSocketMessageGroup.ACCOUNT_MANAGERS);
            admin.setPassword(passwordEncoder.encode("#Pass2022"));
            admin.setRoles(Collections.singletonList(role));
            admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            admin.setUsername(stringGeneratorUtility.generateStaffNumber());
            AccountManager savedAdmin =accountManagerRepository.save(admin);
            //////////////////////assign Permissions////////////////////////
            assignPermissionsByRoleToUser(RoleName.ROLE_ACCOUNT_MANAGER,savedAdmin);
        }


    }

    @PostConstruct
    private void InitializeUsers(){

        if (userRepository.findAll().isEmpty()) {
            //===system
            this.saveUserBackend("Guest", "User", "guest@changemoney.com",
                    RoleName.ROLE_GUEST);
            this.saveUserBackend("Agent", "Office", "backendAgent@changemoney.com",RoleName.ROLE_BACK_OFFICE_AGENT);
            this.saveUserBackend("Admin", "Office",  "admin@changemoney.com", RoleName.ROLE_BACK_OFFICE_ADMIN);

            this.saveUserBackend("System", "Admin", "systemadmin@changemoney.com",
                  RoleName.ROLE_SYSTEM);
            this.saveUserBackend("Default", "Account Manager", "accountmanager@changemoney.com",
                    RoleName.ROLE_ACCOUNT_MANAGER);

        }


    }


    public void assignPermissionsByRoleToUser(RoleName roleName, User user) {
        Role role = roleRepository.findByName(roleName).orElse(null);
        List<Privilege> privileges = new ArrayList<>();

        List<Permission> permissions = permissionRepository.findByRoles_Id(role.getId());
        for(Permission p: permissions){

            for(Privilege privilege: p.getPrivileges()){
                if(!privileges.contains(privilege)){
                    privileges.add(privilege);
                }
            }

        }
        user.setPermissions(permissions);
        user.setPrivileges(privileges);
        userRepository.save(user);

    }

}
