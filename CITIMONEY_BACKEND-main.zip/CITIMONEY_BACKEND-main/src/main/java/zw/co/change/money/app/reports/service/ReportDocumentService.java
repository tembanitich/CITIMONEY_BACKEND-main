package zw.co.change.money.app.reports.service;

import fr.opensagres.xdocreport.converter.ConverterTypeTo;
import fr.opensagres.xdocreport.converter.Options;
import fr.opensagres.xdocreport.core.XDocReportException;
import fr.opensagres.xdocreport.document.IXDocReport;
import fr.opensagres.xdocreport.document.registry.XDocReportRegistry;
import fr.opensagres.xdocreport.template.IContext;
import fr.opensagres.xdocreport.template.TemplateEngineKind;
import fr.opensagres.xdocreport.converter.ConverterTypeVia;
import fr.opensagres.xdocreport.core.document.DocumentKind;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.model.MerchantAccountHistory;
import zw.co.change.money.app.accounts.model.MerchantAccountHistoryType;
import zw.co.change.money.app.accounts.repository.MerchantAccountHistoryRepository;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.notifications.sms.model.SmsFailures;
import zw.co.change.money.app.notifications.sms.model.SmsResponses;
import zw.co.change.money.app.notifications.sms.repository.PendingSmsRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsFailuresRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsResponsesRepository;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.reports.model.ReportColumnConfiguration;
import zw.co.change.money.app.reports.model.ReportTemplateName;
import zw.co.change.money.app.reports.repository.ReportColumnConfigurationRepository;
import zw.co.change.money.app.reports.request.*;
import zw.co.change.money.app.reports.response.*;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.transactions.model.*;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.repository.WalletHistoryRepository;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.response.UserAuditTrailResponse;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.numbers.NumbersUtil;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.EmailConfigRepository;
import zw.co.change.money.app.variables.repository.InAppMessageConfigRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;
import zw.co.change.money.app.notifications.sms.model.PendingSms;
import zw.co.change.money.app.util.format.FormatUtility;


import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.util.stream.Collectors.toList;
@Service
public class ReportDocumentService {
    @Autowired
    ReportColumnConfigurationRepository reportColumnConfigurationRepository;
    @Autowired
    PendingSmsRepository pendingSmsRepository;
    @Autowired
    SmsFailuresRepository smsFailuresRepository;
    @Autowired
    SmsResponsesRepository smsResponsesRepository;
    @Autowired
    EmailConfigRepository emailConfigRepository;
    @Autowired
    InAppMessageConfigRepository inAppMessageConfigRepository;
    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    TransactionRepository transactionRepository;
    @Autowired
    WalletHistoryRepository walletHistoryRepository;
    @Autowired
    MerchantAccountHistoryRepository merchantAccountHistoryRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    UserCustomerRepository customerRepository;
    @Autowired
    MerchantRepository merchantRepository;
    @Autowired
    MerchantBranchRepository merchantBranchRepository;
    @Autowired
    MerchantCashierRepository cashierRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    UserAuditTrailRepository userAuditTrailRepository;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    DateUtil dateUtil;
    @Autowired
    UserService userService;



    public ResponseEntity getReportFieldsByTemplateName(ReportTemplateName reportTemplateName){

        List<ReportColumnConfigurationResponse> columnConfigurations = reportColumnConfigurationRepository.findByReportName(reportTemplateName).stream().map(this::mapReportConfiguration).collect(toList());
        return  ResponseEntity.ok(columnConfigurations);
    }
    //backend reports
    public ResponseEntity generateAuditTrailReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.AUDIT_TRAIL_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardAuditTrailReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomAuditTrailReport(request,start,end);
        }


    }
    private ResponseEntity processStandardAuditTrailReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{


        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.AUDIT_TRAIL_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Columns For The Report",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserAuditTrailResponse> auditTrails = this.getAuditTrailData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomAuditTrailReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{


        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.AUDIT_TRAIL_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserAuditTrailResponse> auditTrails = this.getAuditTrailData(request,start,end);
        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserAuditTrailResponse> getAuditTrailData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate){
        List<UserAuditTrailResponse> auditTrails = null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            auditTrails = userAuditTrailRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList());
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            auditTrails = userAuditTrailRepository.findByUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getFilterValue(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList());
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                auditTrails = new ArrayList<>();
                return  auditTrails;
            }
            List<User> users = userRepository.findByRolesIn(new ArrayList<Role>(Arrays.asList(role)));
            auditTrails = new ArrayList<>();
            for(User u: users){
                auditTrails .addAll(userAuditTrailRepository.findByUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(u.getUserId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList()));
            }

        }
        return auditTrails;
    }

    public ResponseEntity generateMerchantAuditTrailReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.AUDIT_TRAIL_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantAuditTrailReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantAuditTrailReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantAuditTrailReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{


        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.AUDIT_TRAIL_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Columns For The Report",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserAuditTrailResponse> auditTrails = this.getMerchantAuditTrailData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantAuditTrailReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{


        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.AUDIT_TRAIL_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserAuditTrailResponse> auditTrails = this.getMerchantAuditTrailData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserAuditTrailResponse> getMerchantAuditTrailData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,Merchant merchant){
        List<UserAuditTrailResponse> auditTrails = null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            auditTrails = userAuditTrailRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList());

        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            auditTrails = userAuditTrailRepository.findByUserIdAndMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getFilterValue(),merchant.getId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList());
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                auditTrails = new ArrayList<>();
                return  auditTrails;
            }
            List<User> users = userRepository.findByRolesIn(new ArrayList<Role>(Arrays.asList(role)));
            auditTrails = new ArrayList<>();
            for(User u: users){
                auditTrails .addAll(userAuditTrailRepository.findByUserIdAndMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(u.getUserId(),merchant.getId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList()));
            }

        }
        return auditTrails;
    }

    public ResponseEntity generateMerchantBranchAuditTrailReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = cashier.getMerchantBranch();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.AUDIT_TRAIL_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantBranchAuditTrailReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantBranchAuditTrailReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantBranchAuditTrailReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{


        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.AUDIT_TRAIL_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Columns For The Report",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserAuditTrailResponse> auditTrails = this.getMerchantBranchAuditTrailData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantBranchAuditTrailReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{


        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.AUDIT_TRAIL_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserAuditTrailResponse> auditTrails = this.getMerchantBranchAuditTrailData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Audit Trail Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserAuditTrailResponse> getMerchantBranchAuditTrailData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,MerchantBranch merchant){
        List<UserAuditTrailResponse> auditTrails = null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            auditTrails = userAuditTrailRepository.findByBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList());

        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            auditTrails = userAuditTrailRepository.findByUserIdAndBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getFilterValue(),merchant.getId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList());
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                auditTrails = new ArrayList<>();
                return  auditTrails;
            }
            List<User> users = userRepository.findByRolesIn(new ArrayList<Role>(Arrays.asList(role)));
            auditTrails = new ArrayList<>();
            for(User u: users){
                auditTrails .addAll(userAuditTrailRepository.findByUserIdAndBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(u.getUserId(),merchant.getId(),startDate,endDate).stream().map(userService::mapUserAuditTrailEntityToResponse).collect(toList()));
            }

        }
        return auditTrails;
    }


    public ResponseEntity generateSystemUserActivityReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardSystemUserActivityReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomSystemUserActivityReport(request,start,end);
        }


    }
    private ResponseEntity processStandardSystemUserActivityReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserActivityReportData> auditTrails = this.getSystemUserActivityData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomSystemUserActivityReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserActivityReportData> data = this.getSystemUserActivityData(request,start,end);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserActivityReportData> getSystemUserActivityData(ReportGenerationDTO request, LocalDateTime startDate, LocalDateTime endDate){
        List<UserActivityReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
          List<User>  users = userRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate);
            for(User u: users){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            List<User>    users = new ArrayList<>();
            User user =userRepository.findById(request.getFilterValue()).orElse(null);
            if(user!=null){

                    userPermissionsReportData.add(this.convertToUserActivityReportData(user));

            }

        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                List<User>     users = new ArrayList<>();
             return userPermissionsReportData;
            }
            List<User>       users = userRepository.findByRolesInAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(new ArrayList<Role>(Arrays.asList(role)),startDate,endDate);
            for(User u: users){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }

        }
        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantSystemUserActivityReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantSystemUserActivityReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantSystemUserActivityReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantSystemUserActivityReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserActivityReportData> auditTrails = this.getMerchantSystemUserActivityData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantSystemUserActivityReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserActivityReportData> data = this.getMerchantSystemUserActivityData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserActivityReportData> getMerchantSystemUserActivityData(ReportGenerationDTO request, LocalDateTime startDate, LocalDateTime endDate,Merchant merchant){
        List<UserActivityReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
            List<MerchantAdmin> admins  = merchantAdminRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            for(User u: admins){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }
            for(User u: cashiers){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }
            for(User u: branchManagers){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            userPermissionsReportData = new ArrayList<>();
            MerchantAdmin admin =merchantAdminRepository.findById(request.getFilterValue()).orElse(null);
            MerchantCashier cashier =cashierRepository.findById(request.getFilterValue()).orElse(null);
            BranchManager branchManager =branchManagerRepository.findById(request.getFilterValue()).orElse(null);
            if(admin!=null){
                userPermissionsReportData.add(this.convertToUserActivityReportData(admin));
            }
            if(cashier!=null){
                userPermissionsReportData.add(this.convertToUserActivityReportData(cashier));
            }
            if(branchManager!=null){
                userPermissionsReportData.add(this.convertToUserActivityReportData(branchManager));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                userPermissionsReportData = new ArrayList<>();
                return  userPermissionsReportData;
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_MERCHANT_ADMIN)){
                List<MerchantAdmin> admins  = merchantAdminRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: admins){
                    userPermissionsReportData.add(this.convertToUserActivityReportData(u));
                }
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_CASHIER)){
                List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: cashiers){
                    userPermissionsReportData.add(this.convertToUserActivityReportData(u));
                }
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_BRANCH_MANAGER)){
                List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: branchManagers){
                    userPermissionsReportData.add(this.convertToUserActivityReportData(u));
                }
            }
        }

        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantBranchSystemUserActivityReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = cashier.getMerchantBranch();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantBranchSystemUserActivityReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantBranchSystemUserActivityReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantBranchSystemUserActivityReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserActivityReportData> auditTrails = this.getMerchantBranchSystemUserActivityData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantBranchSystemUserActivityReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.SYSTEM_USER_ACTIVITY_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserActivityReportData> data = this.getMerchantBranchSystemUserActivityData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "System User Activity Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserActivityReportData> getMerchantBranchSystemUserActivityData(ReportGenerationDTO request, LocalDateTime startDate, LocalDateTime endDate,MerchantBranch merchant){
        List<UserActivityReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
            List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);

            for(User u: cashiers){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }
            for(User u: branchManagers){
                userPermissionsReportData.add(this.convertToUserActivityReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            userPermissionsReportData = new ArrayList<>();
           MerchantCashier cashier =cashierRepository.findById(request.getFilterValue()).orElse(null);
            BranchManager branchManager =branchManagerRepository.findById(request.getFilterValue()).orElse(null);

            if(cashier!=null){
                userPermissionsReportData.add(this.convertToUserActivityReportData(cashier));
            }
            if(branchManager!=null){
                userPermissionsReportData.add(this.convertToUserActivityReportData(branchManager));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                userPermissionsReportData = new ArrayList<>();
                return  userPermissionsReportData;
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_CASHIER)){
                List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: cashiers){
                    userPermissionsReportData.add(this.convertToUserActivityReportData(u));
                }
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_BRANCH_MANAGER)){
                List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: branchManagers){
                    userPermissionsReportData.add(this.convertToUserActivityReportData(u));
                }
            }
        }


        return userPermissionsReportData;
    }


    public ResponseEntity generateSmsReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.SMS_MESSAGES_REPORTS,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardSmsReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomSmsReport(request,start,end);
        }


    }
    private ResponseEntity processStandardSmsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.SMS_MESSAGES_REPORTS);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.NOT_FOUND);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<SmsMessageReportData> auditTrails = this.getSmsData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages  Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages  Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomSmsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.SMS_MESSAGES_REPORTS,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.NOT_FOUND);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<SmsMessageReportData> data = this.getSmsData(request,start,end);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages  Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages  Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "SMS Messages  Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<SmsMessageReportData> getSmsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate){
        List<SmsMessageReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
            List<PendingSms> pendingSms  = pendingSmsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate);
            List<SmsFailures> smsFailures  = smsFailuresRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate);
            List<SmsResponses> successSms  = smsResponsesRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate);
            for(SmsResponses u: successSms){
                userPermissionsReportData.add(this.convertSuccessSMSToSmsReportData(u));
            }
            //add Pending SMS
            for(PendingSms u: pendingSms){
                userPermissionsReportData.add(this.convertPendingSMSToSmsReportData(u));
            }
            //add Failed SMS
            for(SmsFailures u: smsFailures){
                userPermissionsReportData.add(this.convertFailedSMSToSmsReportData(u));
            }
        }


        return userPermissionsReportData;
    }


    public ResponseEntity generateUserPermissionsReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.USER_PERMISSIONS_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardUserPermissionsReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomUserPermissionsReport(request,start,end);
        }


    }
    private ResponseEntity processStandardUserPermissionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.USER_PERMISSIONS_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserPermissionsReportData> auditTrails = this.getUserPermissionsData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomUserPermissionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.USER_PERMISSIONS_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserPermissionsReportData> data = this.getUserPermissionsData(request,start,end);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserPermissionsReportData> getUserPermissionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate){
        List<UserPermissionsReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
            List<User> users  = userRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate);
            for(User u: users){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            userPermissionsReportData = new ArrayList<>();
            User user =userRepository.findById(request.getFilterValue()).orElse(null);
            if(user!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(user));
            }

        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                userPermissionsReportData = new ArrayList<>();
                return  userPermissionsReportData;
            }
            List<User> users  = userRepository.findByRolesInAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(new ArrayList<Role>(Arrays.asList(role)),startDate,endDate);
            for(User u: users){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }

        }
        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantUserPermissionsReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.USER_PERMISSIONS_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantUserPermissionsReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantUserPermissionsReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantUserPermissionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.USER_PERMISSIONS_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserPermissionsReportData> auditTrails = this.getMerchantUserPermissionsData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantUserPermissionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.USER_PERMISSIONS_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserPermissionsReportData> data = this.getMerchantUserPermissionsData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserPermissionsReportData> getMerchantUserPermissionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,Merchant merchant){
        List<UserPermissionsReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
            List<MerchantAdmin> admins  = merchantAdminRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            for(User u: admins){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }
            for(User u: cashiers){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }
            for(User u: branchManagers){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            userPermissionsReportData = new ArrayList<>();
            MerchantAdmin admin =merchantAdminRepository.findById(request.getFilterValue()).orElse(null);
            MerchantCashier cashier =cashierRepository.findById(request.getFilterValue()).orElse(null);
            BranchManager branchManager =branchManagerRepository.findById(request.getFilterValue()).orElse(null);
            if(admin!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(admin));
            }
            if(cashier!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(cashier));
            }
            if(branchManager!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(branchManager));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                userPermissionsReportData = new ArrayList<>();
                return  userPermissionsReportData;
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_MERCHANT_ADMIN)){
                List<MerchantAdmin> admins  = merchantAdminRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: admins){
                    userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
                }
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_CASHIER)){
                List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: cashiers){
                    userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
                }
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_BRANCH_MANAGER)){
                List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: branchManagers){
                    userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
                }
            }
        }
        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantBranchUserPermissionsReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = cashier.getMerchantBranch();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.USER_PERMISSIONS_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantBranchUserPermissionsReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantBranchUserPermissionsReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantBranchUserPermissionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.USER_PERMISSIONS_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserPermissionsReportData> auditTrails = this.getMerchantBranchUserPermissionsData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantBranchUserPermissionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.USER_PERMISSIONS_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<UserPermissionsReportData> data = this.getMerchantBranchUserPermissionsData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<UserPermissionsReportData> getMerchantBranchUserPermissionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,MerchantBranch merchant){
        List<UserPermissionsReportData> userPermissionsReportData = new ArrayList<>();
        if(request.getFilter().equals(ReportFilter.ALL)){
            List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);

            for(User u: cashiers){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }
            for(User u: branchManagers){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            userPermissionsReportData = new ArrayList<>();
            MerchantAdmin admin =merchantAdminRepository.findById(request.getFilterValue()).orElse(null);
            MerchantCashier cashier =cashierRepository.findById(request.getFilterValue()).orElse(null);
            BranchManager branchManager =branchManagerRepository.findById(request.getFilterValue()).orElse(null);
            if(admin!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(admin));
            }
            if(cashier!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(cashier));
            }
            if(branchManager!=null){
                userPermissionsReportData.add(this.convertToUserPermissionsReportData(branchManager));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                userPermissionsReportData = new ArrayList<>();
                return  userPermissionsReportData;
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_CASHIER)){
                List<MerchantCashier> cashiers  = cashierRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: cashiers){
                    userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
                }
            }
            if(RoleName.valueOf(request.getFilterValue()).equals(RoleName.ROLE_BRANCH_MANAGER)){
                List<BranchManager> branchManagers  = branchManagerRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                for(User u: branchManagers){
                    userPermissionsReportData.add(this.convertToUserPermissionsReportData(u));
                }
            }
        }
        return userPermissionsReportData;
    }


    public ResponseEntity generateTransactionsReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.TRANSACTION_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardTransactionsReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomTransactionsReport(request,start,end);
        }


    }
    private ResponseEntity processStandardTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> auditTrails = this.getTransactionsData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> data = this.getTransactionsData(request,start,end);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<TransactionsReportData> getTransactionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate){
        List<TransactionsReportData> userPermissionsReportData = new ArrayList<>();

        if(request.getFilter().equals(ReportFilter.ALL)){
            List<Transaction> users  = transactionRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate,endDate);
            for(Transaction u: users){
                userPermissionsReportData.add(this.convertToTransactionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_STATUS)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionStatus status = TransactionStatus.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_TYPE)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionType status = TransactionType.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_MERCHANT)){
            userPermissionsReportData = new ArrayList<>();
            try{
                Merchant merchant = merchantRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant!=null){
                    List<Transaction> users  = transactionRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                    for(Transaction u: users){
                        userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_MERCHANT_BRANCH)){
            userPermissionsReportData = new ArrayList<>();
            try{
                long merchantBranchId = Long.parseLong(request.getFilterValue());
                MerchantBranch merchant = merchantBranchRepository.findById(merchantBranchId).orElse(null);
                if(merchant!=null){
                    List<Transaction> users  = transactionRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
                    for(Transaction u: users){
                        userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_CASHIER)){
            userPermissionsReportData = new ArrayList<>();
            try{
                MerchantCashier merchant = cashierRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant!=null){
                    List<Transaction> users  = transactionRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getUserId(),startDate,endDate);
                    for(Transaction u: users){
                        userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantTransactionsReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.TRANSACTION_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantTransactionsReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantTransactionsReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> auditTrails = this.getMerchantTransactionsData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> data = this.getMerchantTransactionsData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<TransactionsReportData> getMerchantTransactionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,Merchant merchant){
        List<TransactionsReportData> userPermissionsReportData = new ArrayList<>();

        if(request.getFilter().equals(ReportFilter.ALL)){
            List<Transaction> users  = transactionRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            for(Transaction u: users){
                userPermissionsReportData.add(this.convertToTransactionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_STATUS)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionStatus status = TransactionStatus.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByMerchantIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_TYPE)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionType status = TransactionType.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByMerchantIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_MERCHANT_BRANCH)){
            userPermissionsReportData = new ArrayList<>();
            try{
                long merchantBranchId = Long.parseLong(request.getFilterValue());
                MerchantBranch merchantBranch = merchantBranchRepository.findById(merchantBranchId).orElse(null);
                if(merchant!=null){
                    List<Transaction> users  = transactionRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantBranch.getId(),startDate,endDate);
                    for(Transaction u: users){
                        userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_CASHIER)){
            userPermissionsReportData = new ArrayList<>();
            try{
                MerchantCashier cashier = cashierRepository.findById(request.getFilterValue()).orElse(null);
                if(cashier!=null){
                    List<Transaction> users  = transactionRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),startDate,endDate);
                    for(Transaction u: users){
                        userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantBranchTransactionsReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantBranch merchant = cashier.getMerchantBranch();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.TRANSACTION_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantBranchTransactionsReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantBranchTransactionsReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantBranchTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> auditTrails = this.getMerchantBranchTransactionsData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantBranchTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantBranch merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> data = this.getMerchantBranchTransactionsData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<TransactionsReportData> getMerchantBranchTransactionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,MerchantBranch merchant){
        List<TransactionsReportData> userPermissionsReportData = new ArrayList<>();

        if(request.getFilter().equals(ReportFilter.ALL)){
            List<Transaction> users  = transactionRepository.findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),startDate,endDate);
            for(Transaction u: users){
                userPermissionsReportData.add(this.convertToTransactionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_STATUS)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionStatus status = TransactionStatus.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByMerchantBranchIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_TYPE)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionType status = TransactionType.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByMerchantBranchIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getId(),status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_CASHIER)){
            userPermissionsReportData = new ArrayList<>();
            try{
                MerchantCashier cashier = cashierRepository.findById(request.getFilterValue()).orElse(null);
                if(cashier!=null){
                    List<Transaction> users  = transactionRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),startDate,endDate);
                    for(Transaction u: users){
                        userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }

    public ResponseEntity generateCashierTransactionsReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.TRANSACTION_REPORT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardCashierTransactionsReport(request,start,end,cashier);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomCashierTransactionsReport(request,start,end,cashier);
        }


    }
    private ResponseEntity processStandardCashierTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantCashier merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> auditTrails = this.getCashierTransactionsData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomCashierTransactionsReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,MerchantCashier merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.TRANSACTION_REPORT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<TransactionsReportData> data = this.getCashierTransactionsData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "User Roles Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Transactions Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<TransactionsReportData> getCashierTransactionsData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,MerchantCashier merchant){
        List<TransactionsReportData> userPermissionsReportData = new ArrayList<>();

        if(request.getFilter().equals(ReportFilter.ALL)){
            List<Transaction> users  = transactionRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getUserId(),startDate,endDate);
            for(Transaction u: users){
                userPermissionsReportData.add(this.convertToTransactionsReportData(u));
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_STATUS)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionStatus status = TransactionStatus.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByCashierUserIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getUserId(),status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_TYPE)){
            userPermissionsReportData = new ArrayList<>();
            try{
                TransactionType status = TransactionType.valueOf(request.getFilterValue());
                List<Transaction> users  = transactionRepository.findByCashierUserIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchant.getUserId(),status,startDate,endDate);
                for(Transaction u: users){
                    userPermissionsReportData.add(this.convertToTransactionsReportData(u));
                }
            }catch(Exception e){
                e.printStackTrace();
            }
        }


        return userPermissionsReportData;
    }


    public ResponseEntity generateMerchantAccountReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.MERCHANT_ACCOUNT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantAccountReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantAccountReport(request,start,end);
        }


    }
    private ResponseEntity processStandardMerchantAccountReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.MERCHANT_ACCOUNT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<MerchantAccountReportData> auditTrails = this.getMerchantAccountData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantAccountReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.MERCHANT_ACCOUNT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<MerchantAccountReportData> data = this.getMerchantAccountData(request,start,end);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<MerchantAccountReportData> getMerchantAccountData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate){
        List<MerchantAccountReportData> userPermissionsReportData = new ArrayList<>();


        if(request.getFilter().equals(ReportFilter.BY_MERCHANT)){
            userPermissionsReportData = new ArrayList<>();
            try{
                Merchant merchant = merchantRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant!=null){
                    List<MerchantAccountHistory> users  = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startDate,endDate,merchant.getId());
                    for(MerchantAccountHistory u: users){
                        userPermissionsReportData.add(this.convertToMerchantAccountReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }

    public ResponseEntity generateMerchantMerchantAccountReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = cashier.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",102), HttpStatus.EXPECTATION_FAILED);
        }
        if(!merchant.isActive()){
            return new ResponseEntity<>(new GenericApiError("Merchant Deactivated",102), HttpStatus.EXPECTATION_FAILED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.MERCHANT_ACCOUNT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardMerchantMerchantAccountReport(request,start,end,merchant);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomMerchantMerchantAccountReport(request,start,end,merchant);
        }


    }
    private ResponseEntity processStandardMerchantMerchantAccountReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.MERCHANT_ACCOUNT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<MerchantAccountReportData> auditTrails = this.getMerchantMerchantAccountData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomMerchantMerchantAccountReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,Merchant merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.MERCHANT_ACCOUNT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<MerchantAccountReportData> data = this.getMerchantMerchantAccountData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<MerchantAccountReportData> getMerchantMerchantAccountData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,Merchant merchant){
        List<MerchantAccountReportData> userPermissionsReportData = new ArrayList<>();


        if(request.getFilter().equals(ReportFilter.ALL)){
            userPermissionsReportData = new ArrayList<>();
            try{

                    List<MerchantAccountHistory> users  = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startDate,endDate,merchant.getId());
                    for(MerchantAccountHistory u: users){
                        userPermissionsReportData.add(this.convertToMerchantAccountReportData(u));
                    }


            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }

    public ResponseEntity generateAccountManagerMerchantAccountReport(ReportGenerationDTO request,String loggedInUserId) throws IOException, XDocReportException {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager cashier = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.MERCHANT_ACCOUNT,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardAccountManagerMerchantAccountReport(request,start,end,cashier);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomAccountManagerMerchantAccountReport(request,start,end,cashier);
        }


    }
    private ResponseEntity processStandardAccountManagerMerchantAccountReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,AccountManager merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.MERCHANT_ACCOUNT);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<MerchantAccountReportData> auditTrails = this.getAccountManagerMerchantAccountData(request,start,end,merchant);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomAccountManagerMerchantAccountReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end,AccountManager merchant) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.MERCHANT_ACCOUNT,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<MerchantAccountReportData> data = this.getAccountManagerMerchantAccountData(request,start,end,merchant);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Merchant Account History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<MerchantAccountReportData> getAccountManagerMerchantAccountData(ReportGenerationDTO request,LocalDateTime startDate,LocalDateTime endDate,AccountManager accountManager){
        List<MerchantAccountReportData> userPermissionsReportData = new ArrayList<>();


        if(request.getFilter().equals(ReportFilter.BY_MERCHANT)){
            userPermissionsReportData = new ArrayList<>();
            try{
                Merchant merchant = merchantRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant!=null){
                    List<MerchantAccountHistory> users  = merchantAccountHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndAccountMerchantId(startDate,endDate,merchant.getId());
                    for(MerchantAccountHistory u: users){
                        userPermissionsReportData.add(this.convertToMerchantAccountReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }


    public ResponseEntity generateCustomerWalletReport(ReportGenerationDTO request) throws IOException, XDocReportException {

        LocalDateTime start = null;
        LocalDateTime end = null;
        if(request.getDateFilter().equals(ReportDateFilter.ALL)){
            LocalDateTime todayDateTime =LocalDateTime.now();
            start = LocalDateTime.of(2020,1,1,0,0);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.TODAY)){

            LocalDateTime todayDateTime =LocalDateTime.now();
            start = todayDateTime.toLocalDate().atTime(LocalTime.MIN);
            end = todayDateTime.toLocalDate().atTime(LocalTime.MAX);
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_WEEK)){

            start = dateUtil.getFirstDayOfThisWeekTime();
            end = dateUtil.getLastDayOfThisWeekTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_MONTH)){

            start = dateUtil.getFirstDayOfThisMonthTime();
            end = dateUtil.getLastDayOfThisMonthTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.THIS_YEAR)){

            start = dateUtil.getFirstDayOfThisYearTime();
            end = dateUtil.getLastDayOfThisYearTime();
        }
        if(request.getDateFilter().equals(ReportDateFilter.CUSTOM)){
            Boolean validationResponse =  formatUtility.isValidDateTime(request.getStartDateTime());
            if (!validationResponse) {
                return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            Boolean validationResponse2 =  formatUtility.isValidDateTime(request.getEndDateTime());
            if (!validationResponse2) {
                return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
            }
            start = LocalDateTime.parse(request.getStartDateTime());
            end = LocalDateTime.parse(request.getEndDateTime());
        }


        ResponseEntity responseEntity = this.validateFilter(ReportTemplateName.CUSTOMER_WALLET,request);
        if(responseEntity.getStatusCodeValue()!=200){
            return responseEntity;
        }
        // 2) Create context Java model

        if(request.getReportType().equals(ReportType.STANDARD)){
            //process Standard Report
            return this.processStandardCustomerWalletReport(request,start,end);
        }else{
            //process custom report
            if(request.getFields()==null || request.getFields().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Custom Fields Cannot Be Empty For Customized Report",105),HttpStatus.EXPECTATION_FAILED);
            }
            return this.processCustomCustomerWalletReport(request,start,end);
        }


    }
    private ResponseEntity processStandardCustomerWalletReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getStandardTemplateHeaderNames(ReportTemplateName.CUSTOMER_WALLET);
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<CustomerWalletReportData> auditTrails = this.getCustomerWalletData(request,start,end);

        List<TableRow> tableRows =this.createRows(auditTrails,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }

        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private ResponseEntity processCustomCustomerWalletReport(ReportGenerationDTO request,LocalDateTime start,LocalDateTime end) throws IOException, XDocReportException{

        List<ReportColumnConfiguration> headerNames =this.getCustomTemplateHeaderNames(ReportTemplateName.CUSTOMER_WALLET,request.getFields());
        if(headerNames.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",110),HttpStatus.EXPECTATION_FAILED);
        }
        List<TableHeader> tableHeaders = this.createTableHeaders(headerNames);
        List<CustomerWalletReportData> data = this.getCustomerWalletData(request,start,end);
        List<TableRow> tableRows =this.createRows(data,tableHeaders);
        File generatedDocument=null;
        if(request.getFilter().equals(ReportFilter.ALL)){
            generatedDocument= this.createWordDocument(tableHeaders,tableRows);
        }else{
            generatedDocument= this.createWordDocumentWithFilter(tableHeaders,tableRows);
        }
        if (request.getFormat().equals(ReportFormat.CSV)) {
            //process headers
            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createCSV(context,report);
            }

        }
        if (request.getFormat().equals(ReportFormat.EXCEL)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createExcel(context,report);

            }

        }
        if (request.getFormat().equals(ReportFormat.PDF)) {
            if(generatedDocument!=null){
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream("create_table.docx"), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createPdf(context,report);

            }else{
                return new ResponseEntity<>(new GenericApiError("Something Went Wrong Compiling The Report",114),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if (request.getFormat().equals(ReportFormat.WORD)) {

            if(generatedDocument!=null) {
                IXDocReport report = XDocReportRegistry.getRegistry().loadReport(new FileInputStream(generatedDocument), TemplateEngineKind.Velocity);
                IContext context = report.createContext();

                String formattedStartDate = start.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String formattedEndDate = end.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                String createdDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));

                context.put("startDate", formattedStartDate);
                context.put("endDate", formattedEndDate);
                context.put("createdDate", createdDate);
                context.put("totalRecords", tableRows.size());
                context.put("reportName", "Customer Wallet History Report");
                if(!request.getFilter().equals(ReportFilter.ALL)){
                    if(request.getFilter().equals(ReportFilter.BY_AGE)){
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", request.getFilterValue() +" - " + request.getFilterValueMax());
                    }else{
                        context.put("filterName", request.getFilter());
                        context.put("filterValue", this.getFilterValue( request.getFilter(),request.getFilterValue()));
                    }

                }
                return this.createWord(context,report);


            }

        }
        return new ResponseEntity<>(new GenericApiError("Report Format Is not supported",115),HttpStatus.EXPECTATION_FAILED);
    }
    private List<CustomerWalletReportData> getCustomerWalletData(ReportGenerationDTO request, LocalDateTime startDate, LocalDateTime endDate){
        List<CustomerWalletReportData> userPermissionsReportData = new ArrayList<>();


        if(request.getFilter().equals(ReportFilter.BY_CUSTOMER)){
            userPermissionsReportData = new ArrayList<>();
            try{
                UserCustomer merchant = customerRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant!=null){
                    List<WalletHistory> users  = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndWalletCustomerUserId(startDate,endDate,merchant.getUserId());
                    for(WalletHistory u: users){
                        userPermissionsReportData.add(this.convertToCustomerWalletReportData(u));
                    }
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }

        return userPermissionsReportData;
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    private String getFilterValue(ReportFilter filter, String filterValue){
        if(filter.equals(ReportFilter.BY_CUSTOMER)){
            UserCustomer customer = customerRepository.findById(filterValue).orElse(null);
            if(customer!=null){
                return customer.getFirstName()+ " "+ customer.getSurname();
            }else{
                return filterValue;
            }
        }else  if(filter.equals(ReportFilter.BY_ACCOUNT_MANAGER)){
            AccountManager customer = accountManagerRepository.findById(filterValue).orElse(null);
            if(customer!=null){
                return customer.getFirstName()+ " "+ customer.getSurname();
            }else{
                return filterValue;
            }
        }else  if(filter.equals(ReportFilter.BY_MERCHANT_BRANCH)){
            try{
                long id= Long.parseLong(filterValue);
                MerchantBranch customer = merchantBranchRepository.findById(id).orElse(null);
                if(customer!=null){
                    return customer.getName();
                }else{
                    return filterValue;
                } 
            }catch(Exception e){
                return filterValue;
            }
            
        }else  if(filter.equals(ReportFilter.BY_CASHIER)){
            MerchantCashier customer = cashierRepository.findById(filterValue).orElse(null);
            if(customer!=null){
                return customer.getFirstName()+ " "+ customer.getSurname();
            }else{
                return filterValue;
            }
        }else  if(filter.equals(ReportFilter.BY_USER_ID)){
            User customer = userRepository.findById(filterValue).orElse(null);
            if(customer!=null){
                return customer.getFirstName()+ " "+ customer.getSurname();
            }else{
                return filterValue;
            }
        }else  if(filter.equals(ReportFilter.BY_MERCHANT)){
            Merchant customer = merchantRepository.findById(filterValue).orElse(null);
            if(customer!=null){
                return customer.getName();
            }else{
                return filterValue;
            }
        }else{
            return filterValue;
        }
    }

    private ResponseEntity validateCustomerWalletReportFilter(ReportGenerationDTO request){
        if( !request.getFilter().equals(ReportFilter.BY_CUSTOMER)){
            return new ResponseEntity<>(new GenericApiError("Filter Is Not Allowed For This Report",122),HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getFilter().equals(ReportFilter.BY_CUSTOMER)){
            try{
                UserCustomer merchant = customerRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant==null){
                    return new ResponseEntity<>(new GenericApiError("Could Not Load Customer",110),HttpStatus.EXPECTATION_FAILED);
                }
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Role",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok("VALID!");
    }

    private ResponseEntity validateMerchantAccountReportFilter(ReportGenerationDTO request){
        if( !request.getFilter().equals(ReportFilter.BY_MERCHANT) &&!request.getFilter().equals(ReportFilter.ALL)){
            return new ResponseEntity<>(new GenericApiError("Filter Is Not Allowed For This Report",122),HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getFilter().equals(ReportFilter.BY_MERCHANT)){
            try{
                Merchant merchant = merchantRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant==null){
                    return new ResponseEntity<>(new GenericApiError("Could Not Load Merchant",110),HttpStatus.EXPECTATION_FAILED);
                }
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Role",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok("VALID!");
    }
    private ResponseEntity validateTransactionReportFilter(ReportGenerationDTO request){
        if(!request.getFilter().equals(ReportFilter.ALL) && !request.getFilter().equals(ReportFilter.BY_ACCOUNT_MANAGER)&& !request.getFilter().equals(ReportFilter.BY_MERCHANT_BRANCH)&& !request.getFilter().equals(ReportFilter.BY_CASHIER)&& !request.getFilter().equals(ReportFilter.BY_MERCHANT)&& !request.getFilter().equals(ReportFilter.BY_TRANSACTION_STATUS) && !request.getFilter().equals(ReportFilter.BY_TRANSACTION_TYPE)){
            return new ResponseEntity<>(new GenericApiError("Filter Is Not Allowed For This Report",122),HttpStatus.EXPECTATION_FAILED);
        }
        if(!request.getFilter().equals(ReportFilter.ALL)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Filter value cannot be empty",105),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if(request.getFilter().equals(ReportFilter.BY_MERCHANT)){
            try{
                Merchant merchant = merchantRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant==null){
                    return new ResponseEntity<>(new GenericApiError("Could Not Load Merchant",110),HttpStatus.EXPECTATION_FAILED);
                }
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Role",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_CASHIER)){
            try{
                MerchantCashier merchant = cashierRepository.findById(request.getFilterValue()).orElse(null);
                if(merchant==null){
                    return new ResponseEntity<>(new GenericApiError("Could Not Load Merchant Cashier",110),HttpStatus.EXPECTATION_FAILED);
                }
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Role",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_MERCHANT_BRANCH)){
            try{
                long merchantBranchId = Long.parseLong(request.getFilterValue());
                MerchantBranch merchant = merchantBranchRepository.findById(merchantBranchId).orElse(null);
                if(merchant==null){
                    return new ResponseEntity<>(new GenericApiError("Could Not Load Merchant Branch",110),HttpStatus.EXPECTATION_FAILED);
                }
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Merchant Branch Id",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_STATUS)){
            try{
                TransactionStatus status = TransactionStatus.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Status",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_TRANSACTION_TYPE)){
            try{
                TransactionType status = TransactionType.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Type",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok("VALID!");
    }
    private ResponseEntity validateBackendReportFilter(ReportGenerationDTO request){
        if(!request.getFilter().equals(ReportFilter.ALL) && !request.getFilter().equals(ReportFilter.BY_ROLE) && !request.getFilter().equals(ReportFilter.BY_USER_ID)){
            return new ResponseEntity<>(new GenericApiError("Filter Is Not Allowed For This Report",122),HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE) || request.getFilter().equals(ReportFilter.BY_USER_ID)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Filter value cannot be empty",105),HttpStatus.EXPECTATION_FAILED);
            }

        }
        if(request.getFilter().equals(ReportFilter.BY_ROLE)){
            try{
                RoleName.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Role",110),HttpStatus.EXPECTATION_FAILED);
            }

            Role role = roleRepository.findByName(RoleName.valueOf(request.getFilterValue())).orElse(null);
            if(role==null){
                return new ResponseEntity<>(new GenericApiError("Could Not Load Role",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        if(request.getFilter().equals(ReportFilter.BY_USER_ID)){
            User user = userRepository.findById(request.getFilterValue()).orElse(null);
            if(user==null){
                return new ResponseEntity<>(new GenericApiError("Could Not Load User",110),HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok("VALID!");
    }

    private UserActivityReportData convertToUserActivityReportData(User customer){
        UserActivityReportData userDetailsReportData = new UserActivityReportData();
        userDetailsReportData.setLastLogin(customer.getLastLogin());

        userDetailsReportData.setLoginChannel(customer.getLoginChannel());
        userDetailsReportData.setLoginCount(customer.getLoginCount());

        if(customer.getRoles().stream().filter(x-> x.getName().equals(RoleName.ROLE_CUSTOMER)).toList().isEmpty() &&customer.getRoles().stream().filter(x-> x.getName().equals(RoleName.ROLE_CASHIER)).toList().isEmpty()&&customer.getRoles().stream().filter(x-> x.getName().equals(RoleName.ROLE_TELLER)).toList().isEmpty()){
            userDetailsReportData.setUsername(customer.getEmail());
        }else{
            userDetailsReportData.setUsername(customer.getUsername());
        }

        return userDetailsReportData;
    }
    private UserPermissionsReportData convertToUserPermissionsReportData(User customer){
        UserPermissionsReportData userDetailsReportData = new UserPermissionsReportData();
        userDetailsReportData.setLastLogin(customer.getLastLogin());

        userDetailsReportData.setCreatedDate(customer.getCreatedAt());
        if(customer.getEnabled()){
            userDetailsReportData.setStatus("ACTIVE");
        }else{
            userDetailsReportData.setStatus("INACTIVE");
        }

        if(customer.getCreatedBy()!=null){
            User customer1= userRepository.findById(customer.getCreatedBy()).orElse(null);

            if(customer1==null){
                userDetailsReportData.setCreatedBy("N/A");
            }
            if(customer1!=null){
                userDetailsReportData.setCreatedBy(customer1.getUsername());
            }
        }
        String roles ="";
        for(Role role : customer.getRoles()){
            if(roles.isEmpty()){
                roles = role.getName().name();
            }else{
                roles= roles+", "+role.getName().name();
            }


        }
        userDetailsReportData.setRoles(roles);
        if(customer.getRoles().stream().filter(x-> x.getName().equals(RoleName.ROLE_CUSTOMER)).toList().isEmpty() &&customer.getRoles().stream().filter(x-> x.getName().equals(RoleName.ROLE_CASHIER)).toList().isEmpty()&&customer.getRoles().stream().filter(x-> x.getName().equals(RoleName.ROLE_TELLER)).toList().isEmpty()){
            userDetailsReportData.setUsername(customer.getEmail());
        }else{
            userDetailsReportData.setUsername(customer.getUsername());
        }

        return userDetailsReportData;
    }
    private TransactionsReportData convertToTransactionsReportData(Transaction transaction){
        TransactionsReportData userDetailsReportData = new TransactionsReportData();
        userDetailsReportData.setId(transaction.getId());
        userDetailsReportData.setDate(transaction.getCreatedAt());
        userDetailsReportData.setAmount(transaction.getAmount());
        userDetailsReportData.setAmountInUsd(transaction.getAmountInUsd());
        userDetailsReportData.setBaseExchangeRateUsed(transaction.getBaseExchangeRateUsed());
        userDetailsReportData.setMerchantIncentiveUsed(transaction.getMerchantIncentiveUsed());
        userDetailsReportData.setTotalExchangeRateUsed(transaction.getTotalExchangeRateUsed());
        if(transaction.getTransactionType()!=null){
            userDetailsReportData.setTransactionType(transaction.getTransactionType().name());
            if(transaction.getTransactionType().equals(TransactionType.CASH_IN)){
                userDetailsReportData.setDestinationAccount(transaction.getCustomer().getFirstName()+" "+ transaction.getCustomer().getSurname());
                userDetailsReportData.setSenderAccount(transaction.getCashier().getFirstName()+" "+ transaction.getCashier().getSurname() + " - "+ transaction.getCashier().getMerchantBranch().getMerchant().getName());
            }
            if(transaction.getTransactionType().equals(TransactionType.CHANGE)){
                userDetailsReportData.setDestinationAccount(transaction.getCustomer().getFirstName()+" "+ transaction.getCustomer().getSurname());
                userDetailsReportData.setSenderAccount(transaction.getCashier().getFirstName()+" "+ transaction.getCashier().getSurname() + " - "+ transaction.getCashier().getMerchantBranch().getMerchant().getName());
            }
            if(transaction.getTransactionType().equals(TransactionType.CASH_OUT)){
                userDetailsReportData.setDestinationAccount(transaction.getCashier().getFirstName()+" "+ transaction.getCashier().getSurname() + " - "+ transaction.getCashier().getMerchantBranch().getMerchant().getName());
                userDetailsReportData.setSenderAccount(transaction.getCustomer().getFirstName()+" "+ transaction.getCustomer().getSurname());
            }
            if(transaction.getTransactionType().equals(TransactionType.PAYMENT)){
                userDetailsReportData.setDestinationAccount(transaction.getCashier().getFirstName()+" "+ transaction.getCashier().getSurname() + " - "+ transaction.getCashier().getMerchantBranch().getMerchant().getName());
                userDetailsReportData.setSenderAccount(transaction.getCustomer().getFirstName()+" "+ transaction.getCustomer().getSurname());
            }
            if(transaction.getTransactionType().equals(TransactionType.CHECK_BALANCE)){
                userDetailsReportData.setDestinationAccount("N/A");
                userDetailsReportData.setSenderAccount(transaction.getCustomer().getFirstName()+" "+ transaction.getCustomer().getSurname());
            }
            if(transaction.getTransactionType().equals(TransactionType.TRANSFER)){
                userDetailsReportData.setDestinationAccount(transaction.getReceiver().getFirstName()+" "+ transaction.getReceiver().getSurname());
                userDetailsReportData.setSenderAccount(transaction.getCustomer().getFirstName()+" "+ transaction.getCustomer().getSurname());
            }
            if(transaction.getTransactionType().equals(TransactionType.WITHDRAWAL)){
                userDetailsReportData.setDestinationAccount("Teller :"+transaction.getTeller().getFirstName()+" "+ transaction.getTeller().getSurname());
                userDetailsReportData.setSenderAccount(transaction.getMerchant().getName());
            }
        }
        if(transaction.getStatus()!=null){
            userDetailsReportData.setStatus(transaction.getStatus().name());
        }

        if(transaction.getCurrency()!=null){
            userDetailsReportData.setCurrency(transaction.getCurrency().getName());
        }else{
            userDetailsReportData.setCurrency("N/A");
        }

        return userDetailsReportData;
    }
    private MerchantAccountReportData convertToMerchantAccountReportData(MerchantAccountHistory transaction){
        MerchantAccountReportData userDetailsReportData = new MerchantAccountReportData();

        userDetailsReportData.setId(transaction.getId());
        userDetailsReportData.setDateOfEntry(transaction.getDateOfEntry());
        userDetailsReportData.setAmount(transaction.getAmount());
        userDetailsReportData.setBalanceAfter(transaction.getBalanceAfter());
        userDetailsReportData.setBalanceBefore(transaction.getBalanceBefore());
        String merchantName ="N/A";
        if(transaction.getAccount()!=null &&transaction.getAccount().getMerchant()!=null){
             merchantName =transaction.getAccount().getMerchant().getName();
        }

        if(transaction.getHistoryType()!=null){
            userDetailsReportData.setHistoryType(transaction.getHistoryType().name());
            if(transaction.getHistoryType().equals(MerchantAccountHistoryType.CREDIT)){
                userDetailsReportData.setReceiver(merchantName);
                userDetailsReportData.setSender(transaction.getSender().getFirstName()+" "+ transaction.getSender().getSurname());
            }
            if(transaction.getHistoryType().equals(MerchantAccountHistoryType.DEBIT)){
                userDetailsReportData.setReceiver(transaction.getReceiver().getFirstName()+" "+ transaction.getReceiver().getSurname());
                userDetailsReportData.setSender(merchantName);
            }
            if(transaction.getHistoryType().equals(MerchantAccountHistoryType.DEPOSIT)){
                userDetailsReportData.setReceiver(merchantName);
                userDetailsReportData.setSender(transaction.getAccount().getAccountManager().getFirstName()+" "+ transaction.getAccount().getAccountManager().getSurname());
            }

        }


        return userDetailsReportData;
    }
    private CustomerWalletReportData convertToCustomerWalletReportData(WalletHistory transaction){
        CustomerWalletReportData userDetailsReportData = new CustomerWalletReportData();

        userDetailsReportData.setId(transaction.getId());
        userDetailsReportData.setDateOfEntry(transaction.getDateOfEntry());
        userDetailsReportData.setAmount(transaction.getAmount());
        userDetailsReportData.setBalanceAfter(transaction.getBalanceAfter());
        userDetailsReportData.setBalanceBefore(transaction.getBalanceBefore());
        String merchantName ="N/A";
        if(transaction.getWallet()!=null &&transaction.getWallet().getCustomer()!=null){
             merchantName =transaction.getWallet().getCustomer().getFirstName() +" "+ transaction.getWallet().getCustomer().getSurname();
        }

        if(transaction.getHistoryType()!=null){
            userDetailsReportData.setHistoryType(transaction.getHistoryType().name());
            if(transaction.getHistoryType().equals(WalletHistoryType.CREDIT)){
                userDetailsReportData.setReceiver(merchantName);
                userDetailsReportData.setSender(transaction.getSender().getFirstName()+" "+ transaction.getSender().getSurname());
            }
            if(transaction.getHistoryType().equals(WalletHistoryType.DEBIT)){
                userDetailsReportData.setReceiver(transaction.getReceiver().getFirstName()+" "+ transaction.getReceiver().getSurname());
                userDetailsReportData.setSender(merchantName);
            }
            if(transaction.getHistoryType().equals(WalletHistoryType.DEPOSIT)){
                userDetailsReportData.setReceiver(merchantName);
                userDetailsReportData.setSender(transaction.getWallet().getCustomer().getFirstName()+" "+ transaction.getWallet().getCustomer().getSurname());
            }

        }


        return userDetailsReportData;
    }
    private SmsMessageReportData convertSuccessSMSToSmsReportData(SmsResponses successSms){
        SmsMessageReportData data = new SmsMessageReportData();


        if(successSms.getTimeDelivered()!=null){
            data.setDate(successSms.getTimeDelivered());
        }else{
            data.setDate(successSms.getCreatedAt());
        }
        data.setMessage(successSms.getMessage());
        String phonenumbers ="";

        data.setReceiverPhoneNumber(successSms.getPhoneNumber());
        return data;
    }
    private SmsMessageReportData convertFailedSMSToSmsReportData(SmsFailures smsFailures){
        SmsMessageReportData data = new SmsMessageReportData();

        data.setDate(smsFailures.getCreatedAt());

        data.setMessage(smsFailures.getContent());
        String phonenumbers ="";
        for(String s: smsFailures.getPhoneNumbers()){
            phonenumbers = phonenumbers+ ", "+s;
        }
        data.setReceiverPhoneNumber(phonenumbers);
        return data;
    }
    private SmsMessageReportData convertPendingSMSToSmsReportData(PendingSms pendingSms){
        SmsMessageReportData data = new SmsMessageReportData();


        data.setDate(pendingSms.getCreatedAt());

        data.setMessage(pendingSms.getMessage());
        String phonenumbers ="";
        for(String s: pendingSms.getPhoneNumbers()){
            phonenumbers = phonenumbers+ ", "+s;
        }
        data.setReceiverPhoneNumber(phonenumbers);
        return data;
    }
    private ResponseEntity validateSmsMessagesReportFilter(ReportGenerationDTO request){
        if(!request.getFilter().equals(ReportFilter.ALL) ){
            return new ResponseEntity<>(new GenericApiError("Filter Is Not Allowed For This Report",122),HttpStatus.EXPECTATION_FAILED);
        }


        return ResponseEntity.ok("VALID!");
    }

    public static File readWordDocumentToCSV(File wodDocumentFile) {
        try {

            FileInputStream in = new FileInputStream(wodDocumentFile);
            XWPFDocument doc = new XWPFDocument(in);

            List<XWPFTable> table = doc.getTables();

            if(doc.getTables() !=null && !doc.getTables().isEmpty()){
                //get first Table
                XWPFTable foundTable = doc.getTables().get(0);


                List<XWPFTableRow> wordTableRow = foundTable.getRows();
                File outputFile = new File( "book_new.csv");
                BufferedWriter writer = Files.newBufferedWriter(outputFile.toPath());

                List<String> headers = new ArrayList<>();
                for( XWPFTableCell cell: wordTableRow.get(0).getTableCells()){
                    headers.add(cell.getText());
                }
                CSVPrinter csvPrinter = new CSVPrinter(writer, CSVFormat.EXCEL);
                for (XWPFTableRow xwpfTableRow : wordTableRow) {
                    List<String> data = new ArrayList<>();
                    List<XWPFTableCell> cell = xwpfTableRow.getTableCells();
                    for (XWPFTableCell xwpfTableCell : cell) {
                        if(xwpfTableCell!=null)
                        {
                            System.out.println("Im Writing Form The First  "+xwpfTableCell.getText());
                            data.add(xwpfTableCell.getText());
                            List<XWPFTable> itable = xwpfTableCell.getTables();
                            if(itable.size()!=0)
                            {
                                for (XWPFTable xwpfiTable : itable) {
                                    List<XWPFTableRow> irow = xwpfiTable.getRows();
                                    for (XWPFTableRow xwpfiTableRow : irow) {
                                        List<XWPFTableCell> icell = xwpfiTableRow.getTableCells();
                                        for (XWPFTableCell xwpfiTableCell : icell) {
                                            if(xwpfiTableCell!=null)
                                            {
                                                System.out.println(xwpfiTableCell.getText());
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    //print record
                    csvPrinter.printRecord(data);
                }
                csvPrinter.flush();
                csvPrinter.close();
                writer.close();
                return outputFile;
            }


        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  null;
    }
    public static File csvToExcel(File csvFile) throws IOException {
        ArrayList arList=null;
        ArrayList al=null;
        String thisLine;
        int count=0;
        FileInputStream fis = new FileInputStream(csvFile);
        DataInputStream myInput = new DataInputStream(fis);
        int i=0;
        arList = new ArrayList();
        while ((thisLine = myInput.readLine()) != null)
        {
            al = new ArrayList();
            String strar[] = thisLine.split(",");
            for(int j=0;j<strar.length;j++)
            {
                al.add(strar[j]);
            }
            arList.add(al);
            System.out.println(arList.size());
            i++;
        }
        System.out.println("AR List Size:  "+arList.size());
        try
        {
            XSSFWorkbook hwb = new XSSFWorkbook();
            XSSFSheet sheet = hwb.createSheet("new sheet");
            for(int k=0;k<arList.size();k++)
            {
                ArrayList ardata = (ArrayList)arList.get(k);
                XSSFRow row = sheet.createRow((short) 0+k);
                for(int p=0;p<ardata.size();p++)
                {
                    XSSFCell cell = row.createCell((short) p);
                    String data = ardata.get(p).toString();
                    if(data.startsWith("=")){
                        cell.setCellType(CellType.STRING);
                        data=data.replaceAll("\"", "");
                        data=data.replaceAll("=", "");
                        cell.setCellValue(data);
                    }else if(data.startsWith("\"")){
                        data=data.replaceAll("\"", "");
                        cell.setCellType(CellType.STRING);
                        cell.setCellValue(data);
                    }else{
                        data=data.replaceAll("\"", "");
                        cell.setCellType(CellType.NUMERIC);
                        cell.setCellValue(data);
                    }
                    //*/
                    // cell.setCellValue(ardata.get(p).toString());
                }
                //autosize width
                for(int colNum = 0; colNum<row.getLastCellNum();colNum++){
                    hwb.getSheetAt(0).autoSizeColumn(colNum);
                }

                System.out.println();
            }
            File outputFile = new File( "test.xls");
            FileOutputStream fileOut = new FileOutputStream(outputFile);
//            sheet.autoSizeColumn(columnNumber)
            hwb.write(fileOut);
            fileOut.close();
            System.out.println("Your excel file has been generated");
            return outputFile;

        } catch ( Exception ex ) {
            ex.printStackTrace();
        } //main method ends
        return  null;
    }
    private ResponseEntity createCSV(IContext context,IXDocReport report) throws IOException, XDocReportException {


        File outputFile = new File( "test_Out9.docx");
        outputFile.deleteOnExit();
        // 3) Generate report by merging Java model with the Docx
        OutputStream out = new FileOutputStream(outputFile);
        report.process(context, out);
        // convert Word To CSV
//        File csvFile =this.readWordDocumentToCSV(outputFile);
        File csvFile = new File( "book_new.csv");
        byte[] data = Files.readAllBytes(csvFile.toPath());

        InputStream targetStream = new ByteArrayInputStream(data);
        InputStreamResource resource = new InputStreamResource(targetStream);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"test.csv\"");
        Files.delete(outputFile.toPath());
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(csvFile.length())
                .contentType(new MediaType("text", "csv"))
                .body(resource);
    }
    private ResponseEntity createExcel(IContext context,IXDocReport report) throws IOException, XDocReportException {
        File outputFile = new File( "test_Out9.docx");

        // 3) Generate report by merging Java model with the Docx
        OutputStream out = new FileOutputStream(outputFile);
        report.process(context, out);
        // convert Word To CSV
        File csvFile =this.readWordDocumentToCSV(outputFile);
        if(csvFile==null){
            return new ResponseEntity<>(new GenericApiError("Something Went Wrong Generating Report",114),HttpStatus.EXPECTATION_FAILED);
        }
        File excelFile = this.csvToExcel(csvFile);
        if(excelFile==null){
            return new ResponseEntity<>(new GenericApiError("Something Went Wrong Generating Report",114),HttpStatus.EXPECTATION_FAILED);
        }
        byte[] data = Files.readAllBytes(excelFile.toPath());

        InputStream targetStream = new ByteArrayInputStream(data);
        InputStreamResource resource = new InputStreamResource(targetStream);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Audit_Trail_Report.xlsx");
        Files.delete(outputFile.toPath());
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(targetStream.available())
                .contentType(new MediaType("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(resource);
    }
    private ResponseEntity createPdf(IContext context,IXDocReport report) throws IOException, XDocReportException {
        //process PDF
        Options options = Options.getTo(ConverterTypeTo.PDF);
        options.from(DocumentKind.DOCX);
        options.via(ConverterTypeVia.XWPF);
        File outputFile = new File( "test_Out9.pdf");

        // 3) Generate report by merging Java model with the Docx
        OutputStream out = new FileOutputStream(outputFile);
        report.convert(context, options,out);
        byte[] data = Files.readAllBytes(outputFile.toPath());
        InputStream targetStream = new ByteArrayInputStream(data);
        InputStreamResource resource = new InputStreamResource(targetStream);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Audit_Trail_Report.pdf");
//        Files.delete(outputFile.toPath());
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(targetStream.available())
                .contentType( MediaType.APPLICATION_PDF)
                .body(resource);
    }
    private ResponseEntity createWord(IContext context, IXDocReport report) throws IOException, XDocReportException {
        File outputFile = new File( "test_Out9.docx");

        // 3) Generate report by merging Java model with the Docx
        OutputStream out = new FileOutputStream(outputFile);
        report.process(context, out);
        // convert Word To CSV

        byte[] data = Files.readAllBytes(outputFile.toPath());

        InputStream targetStream = new ByteArrayInputStream(data);
        InputStreamResource resource = new InputStreamResource(targetStream);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=Audit_Trail_Report.docx");
        Files.delete(outputFile.toPath());
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(targetStream.available())
                .contentType(new MediaType("application","vnd.openxmlformats-officedocument.wordprocessingml.document"))
                .body(resource);
    }
    private File createWordDocument(List<TableHeader> tableHeaders, List<TableRow> tableRows) throws IOException {
        InputStream in = new ClassPathResource("report_templates/backend/templateWithoutFilter.docx").getInputStream();
        XWPFDocument document = new XWPFDocument(in);

        //Write the Document in file system
        File outputFile = new File( "create_table.docx");
        FileOutputStream out = new FileOutputStream(outputFile);

        //create table
        XWPFTable table = document.createTable(tableRows.size()+1,tableHeaders.size()); //add one extra row for headers



        for (int row = 0; row < 1; row++) {
            for (int col = 0; col < tableHeaders.size(); col++) {
                XWPFRun run =  table.getRow(row).getCell(col).addParagraph().createRun();
                run.setBold(true);
                run.setText(tableHeaders.get(col).getName());
                table.getRow(row).getCell(col).setColor("D9D9D9");
            }
        }
        for (int row = 0; row < tableRows.size(); row++) {
            for (int col = 0; col < tableRows.get(row).getCells().size(); col++) {
                table.getRow(row+1).getCell(col).setText(tableRows.get(row).getCells().get(col).getText());
//                if (row < 3) table.getRow(row).getCell(col).setColor("D9D9D9");
            }
        }

        //defining the column widths for the grid
        //column width values are in unit twentieths of a point (1/1440 of an inch)
        int defaultColWidth = 1*1440*9/tableHeaders.size(); // 9 columns fits to 6 inches
        int[] colunmWidths = new int[tableHeaders.size()];
        for(int i=0;i<tableHeaders.size();i++){
            colunmWidths[i]= defaultColWidth;
        }

        //create CTTblGrid for this table with widths of the 8 columns.
        //necessary for Libreoffice/Openoffice to accept the column widths.
        //add Table Grid
        table.getCTTbl().addNewTblGrid();
        //other columns
        for (int col = 0; col < colunmWidths.length; col++) {
            table.getCTTbl().getTblGrid().addNewGridCol().setW(BigInteger.valueOf(colunmWidths[col]));
        }

        document.createNumbering();
        document.write(out);
        out.close();
        document.close();
        System.out.println("create_table.docx written successully");

        return outputFile;
    }
    private File createWordDocumentWithFilter(List<TableHeader> tableHeaders, List<TableRow> tableRows) throws IOException {
        InputStream in = new ClassPathResource("report_templates/backend/templateWithFilter.docx").getInputStream();
        XWPFDocument document = new XWPFDocument(in);

        //Write the Document in file system
        File outputFile = new File( "create_table.docx");
        FileOutputStream out = new FileOutputStream(outputFile);

        //create table
        XWPFTable table = document.createTable(tableRows.size()+1,tableHeaders.size()); //add one extra row for headers



        for (int row = 0; row < 1; row++) {
            for (int col = 0; col < tableHeaders.size(); col++) {
                XWPFRun run =  table.getRow(row).getCell(col).addParagraph().createRun();
                run.setBold(true);
                run.setText(tableHeaders.get(col).getName());
                table.getRow(row).getCell(col).setColor("D9D9D9");
            }
        }
        for (int row = 0; row < tableRows.size(); row++) {
            for (int col = 0; col < tableRows.get(row).getCells().size(); col++) {
                table.getRow(row+1).getCell(col).setText(tableRows.get(row).getCells().get(col).getText());
//                if (row < 3) table.getRow(row).getCell(col).setColor("D9D9D9");
            }
        }

        //defining the column widths for the grid
        //column width values are in unit twentieths of a point (1/1440 of an inch)
        int defaultColWidth = 1*1440*9/tableHeaders.size(); // 9 columns fits to 6 inches
        int[] colunmWidths = new int[tableHeaders.size()];
        for(int i=0;i<tableHeaders.size();i++){
            colunmWidths[i]= defaultColWidth;
        }

        //create CTTblGrid for this table with widths of the 8 columns.
        //necessary for Libreoffice/Openoffice to accept the column widths.
        //add Table Grid
        table.getCTTbl().addNewTblGrid();
        //other columns
        for (int col = 0; col < colunmWidths.length; col++) {
            table.getCTTbl().getTblGrid().addNewGridCol().setW(BigInteger.valueOf(colunmWidths[col]));
        }

        document.createNumbering();
        document.write(out);
        out.close();
        document.close();
        System.out.println("create_table.docx written successully");
        return outputFile;
    }
    private List<TableHeader> createTableHeaders(List<ReportColumnConfiguration> headerNames){
        List<TableHeader> tableHeaders =new ArrayList<>();
        int i=0;
        for (ReportColumnConfiguration entry : headerNames) {
            TableHeader tableHeader = new TableHeader();
            tableHeader.setName(entry.getName());
            tableHeader.setFieldName(entry.getFieldName());
            tableHeader.setFieldType(entry.getFieldType());
            tableHeader.setPosition(i);
            tableHeaders.add(tableHeader);
            i++;
        }
        return tableHeaders;
    }
    public  <T> List<TableRow> createRows(List<T> data,List<TableHeader> tableHeaders) {
        List<TableRow> tableRows = new ArrayList<>();

        for(Object object : data){
            TableRow tableRow = new TableRow();
            List<TableCell> tableCells = new ArrayList<>();
            for(TableHeader tableHeader: tableHeaders){
                TableCell tableCell = new TableCell();
                tableCell.setPosition(tableHeader.getPosition());
                String text = null;
                try {
                    if(tableHeader.getFieldType().equalsIgnoreCase("STRING")){
                        text = BeanUtils.getProperty(object,tableHeader.getFieldName());
                        if(text==null){
                            text  ="N/A";
                        }
                    }
                    if(tableHeader.getFieldType().equalsIgnoreCase("LONG")){
                        text  = BeanUtils.getProperty(object,tableHeader.getFieldName());
                    }
                    if(tableHeader.getFieldType().equalsIgnoreCase("DOUBLE")){
                        text    = BeanUtils.getProperty(object,tableHeader.getFieldName());
                        if(text==null){
                            text  ="N/A";
                        }else{
                            double value= NumbersUtil.round(Double.parseDouble(text),2);
                            text  =  value+"";
                        }

                    }
                    if(tableHeader.getFieldType().equalsIgnoreCase("INTEGER")){
                        text  = BeanUtils.getProperty(object,tableHeader.getFieldName());
                    }
                    if(tableHeader.getFieldType().equalsIgnoreCase("DATE")){
                        text  = BeanUtils.getProperty(object,tableHeader.getFieldName());
                        if(text==null){
                            text  ="N/A";
                        }else{
                            LocalDate date = LocalDate.parse(text);
                            text  =  date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
                        }

                    }
                    if(tableHeader.getFieldType().equalsIgnoreCase("DATETIME")){
                        text  = BeanUtils.getProperty(object,tableHeader.getFieldName());
                        if(text==null){
                            text  ="N/A";
                        }else{
                            LocalDateTime date = LocalDateTime.parse(text);
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
                            text  =  date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + " " +date.format(formatter) ;
                        }

                    }
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                }
                tableCell.setText(text);
                tableCells.add(tableCell);
            }
            tableRow.setCells(tableCells);
            tableRows.add(tableRow);
        }
        return tableRows;
    }
    private List<ReportColumnConfiguration> getStandardTemplateHeaderNames(ReportTemplateName reportTemplateName){
        List<ReportColumnConfiguration> columnConfigurations = reportColumnConfigurationRepository.findByReportName(reportTemplateName);
        return columnConfigurations ;
    }
    private List<ReportColumnConfiguration> getCustomTemplateHeaderNames(ReportTemplateName reportTemplateName,List<Long> fields){
        List<ReportColumnConfiguration> columnConfigurations = new ArrayList<>();
        for(Long id: fields){
            ReportColumnConfiguration columnConfiguration = reportColumnConfigurationRepository.findById(id).orElse(null);
            if(columnConfiguration!=null){
                columnConfigurations.add(columnConfiguration);
            }
        }

        return columnConfigurations ;
    }
    private ResponseEntity validateFilter(ReportTemplateName reportName,ReportGenerationDTO request){
        ResponseEntity responseEntity = ResponseEntity.ok("VALID!");
        switch (reportName) {

            case AUDIT_TRAIL_REPORT:
                responseEntity = validateBackendReportFilter(request);
                break;
            case SYSTEM_USER_ACTIVITY_REPORT:
                responseEntity = validateBackendReportFilter(request);
                break;
            case CUSTOMER_WALLET:
                responseEntity = validateCustomerWalletReportFilter(request);
                break;
            case MERCHANT_ACCOUNT:
                responseEntity = validateMerchantAccountReportFilter(request);
                break;
            case TRANSACTION_REPORT:
                responseEntity = validateTransactionReportFilter(request);
                break;
            case USER_DETAILS_REPORT:
                responseEntity = validateBackendReportFilter(request);
                break;
            case USER_PERMISSIONS_REPORT:
                responseEntity = validateBackendReportFilter(request);
                break;
            case SMS_CONFIG_REPORT:
                return ResponseEntity.ok("Zvaita");
            case IN_APP_CONFIG_REPORT:
                return ResponseEntity.ok("Zvaita");
            case EMAIL_CONFIG_REPORT:
                return ResponseEntity.ok("Zvaita");
            default:
                return new ResponseEntity<>(new GenericApiError("Report Is Not Supported",115),HttpStatus.EXPECTATION_FAILED);
        }
        return  responseEntity;


    }

    private boolean isLoggedInUserMerchantUser(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantAdmin(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }

    private boolean isLoggedInUserBranchManager(String loggedInUserId){
        BranchManager backendAdmin = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantCashier(String loggedInUserId){
        MerchantCashier backendAdmin = cashierRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserAccountManager(String loggedInUserId){
        AccountManager backendAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private ReportColumnConfigurationResponse mapReportConfiguration(ReportColumnConfiguration reportColumnConfiguration){
        ReportColumnConfigurationResponse reportColumnConfigurationResponse = new ReportColumnConfigurationResponse();
        reportColumnConfigurationResponse.setFieldName(reportColumnConfiguration.getFieldName());
        reportColumnConfigurationResponse.setFieldType(reportColumnConfiguration.getFieldType());
        reportColumnConfigurationResponse.setId(reportColumnConfiguration.getId());
        reportColumnConfigurationResponse.setName(reportColumnConfiguration.getName());
        reportColumnConfigurationResponse.setReportName(reportColumnConfiguration.getReportName());
        return  reportColumnConfigurationResponse;
    }


}
