package zw.co.change.money.app.util.files;

import org.springframework.stereotype.Service;
import zw.co.change.money.app.util.numbers.NumbersUtil;

@Service
public class FilesUtility {
    public static double convertToMb(long value) {
        double mbSize =value* 0.00000095367432;
        return NumbersUtil.round(mbSize,2);
    }
    public static double convertToKb(long value) {
        double mbSize =value* 0.0009765625;
        return NumbersUtil.round(mbSize,2);
    }
}
