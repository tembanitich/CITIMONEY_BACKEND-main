package zw.co.change.money.app.security.roles.response;

import lombok.Data;

import java.util.List;
@Data
public class PermissionResponse {
    private String name;
    private long id;
    private List<PrivilegeResponse> priviledges;
}
