package zw.co.change.money.app.ussd.request;

import lombok.Data;

@Data
public class UssdLoginRequest {
    private String mobileNumber;
    private String pin;
}
