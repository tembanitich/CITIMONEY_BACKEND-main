package zw.co.change.money.app.users.request;

import lombok.Data;
import zw.co.change.money.app.users.model.Gender;

import javax.validation.constraints.NotNull;

@Data
public class ClientUpdateProfileRequest {
    private String firstName;
    private String surname;
    @NotNull
    private String mobileNumber;
    private String email;
    @NotNull
    private Gender gender;
}
