package zw.co.change.money.app.chat.request;

import lombok.Data;

@Data
public class ChatMessageRequest {
    private String message;
    private boolean fromCustomer;
    private boolean fromDriver;
    private String senderId;
    private String receiverId;
}
