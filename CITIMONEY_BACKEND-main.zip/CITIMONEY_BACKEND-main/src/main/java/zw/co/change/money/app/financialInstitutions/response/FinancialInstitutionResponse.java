package zw.co.change.money.app.financialInstitutions.response;

import lombok.Data;

@Data
public class FinancialInstitutionResponse {
    private Long id;
    private String institutionNumber;
    private String name;
    private String displayName;
    private boolean active;
    private boolean isMobileMoney;
    private String url;
}
