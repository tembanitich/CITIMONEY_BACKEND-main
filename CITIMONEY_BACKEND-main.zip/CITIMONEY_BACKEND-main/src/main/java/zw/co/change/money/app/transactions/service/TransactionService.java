package zw.co.change.money.app.transactions.service;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.model.*;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.accounts.repository.MerchantAccountHistoryRepository;
import zw.co.change.money.app.accounts.request.ChangeMerchantDepositStatusRequest;
import zw.co.change.money.app.accounts.response.MerchantAccountDepositRequestResponse;
import zw.co.change.money.app.accounts.response.MerchantAccountHistoryResponse;
import zw.co.change.money.app.accounts.response.MerchantAccountResponse;
import zw.co.change.money.app.accounts.service.AccountsService;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.currencies.model.MerchantIncentive;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.currencies.repository.MerchantIncentiveRepository;
import zw.co.change.money.app.currencies.service.CurrencyService;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.financialInstitutions.service.FinancialInstitutionService;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.notifications.mail.executor.MailExecutor;
import zw.co.change.money.app.notifications.mail.request.Mail;
import zw.co.change.money.app.notifications.sms.executors.SmsExecutor;
import zw.co.change.money.app.notifications.websocket.service.WebSocketService;
import zw.co.change.money.app.transactions.model.*;
import zw.co.change.money.app.transactions.repository.MerchantWithdrawalRequestRepository;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.repository.WalletHistoryRepository;
import zw.co.change.money.app.transactions.repository.WalletRepository;
import zw.co.change.money.app.transactions.request.*;
import zw.co.change.money.app.transactions.response.*;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.response.UserCustomerResponse;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.numbers.NumbersUtil;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.util.response.PagedResponse;
import zw.co.change.money.app.validation.ValidateTransactionProperties;
import zw.co.change.money.app.variables.model.AppVariable;
import zw.co.change.money.app.variables.model.SmsConfig;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.EmailConfigRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;
import zw.co.change.money.app.variables.service.AppVariableService;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.util.stream.Collectors.toList;

@Service
public class TransactionService {
    @Autowired
    private TransactionRepository transactionsRepository;
    @Autowired
    private WalletHistoryRepository walletHistoryRepository;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private MerchantAccountHistoryRepository merchantAccountHistoryRepository;
    @Autowired
    private MerchantWithdrawalRequestRepository merchantWithdrawalRequestRepository;
    @Autowired
    private AccountRepository merchantAccountRepository;
    @Autowired
    private AccountManagerRepository accountManagerRepository;
    @Autowired
    private UserCustomerRepository customerRepository;
    @Autowired
    private UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    private UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private BranchManagerRepository branchManagerRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private TellerUserRepository tellerUserRepository;
    @Autowired
    private MerchantIncentiveRepository merchantIncentiveRepository;
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    private FinancialInstitutionRepository financialInstitutionRepository;
    @Autowired
    private MerchantCashierRepository cashierRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private AppVariableRepository appVariableRepository;
    @Autowired
    private AppVariableService appVariableService;
    @Autowired
    private MerchantService merchantService;
    @Autowired
    private FinancialInstitutionService financialInstitutionService;
    @Autowired
    private AccountsService accountsService;
    @Autowired
    private AuthenticationService authenticationService;
    @Autowired
    private CurrencyService currencyService;
    @Autowired
    private MailExecutor mailExecutor;
    @Autowired
    private UserService userService;
    @Autowired
    private EmailConfigRepository emailConfigRepository;
    @Autowired
    private SmsConfigRepository smsConfigRepository;
    @Autowired
    SmsExecutor smsExecutor;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    private WebSocketService webSocketService;
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private DateUtil dateUtil;
    @Autowired
    private StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    private ValidateTransactionProperties validateTransactionProperties;

    public ResponseEntity checkPaymentRequest(CheckPaymentRequest request, String loggedInUserId){
        UserCustomer loggedInUser = customerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCheckPaymentRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        double merchantIncentiveAmount=0;
        Merchant merchant=cashier.getMerchantBranch().getMerchant();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        double totalExchangeRate = currency.getExchangeRate()+ merchantIncentive.getAmount();
        double walletBalance = loggedInUser.getWallet().getBalance();
        double amountInUsd = request.getAmount()* totalExchangeRate;
        if(walletBalance<amountInUsd){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance",105), HttpStatus.EXPECTATION_FAILED);
        }
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountInUsd);
        response.setCustomerBalance(walletBalance);
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);
    }
    public ResponseEntity checkCashoutRequest(CheckCashoutRequest request, String loggedInUserId){
        UserCustomer loggedInUser = customerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCheckCashoutRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        double merchantIncentiveAmount=0;
        Merchant merchant=cashier.getMerchantBranch().getMerchant();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        double totalExchangeRate = currency.getExchangeRate()+ merchantIncentive.getAmount();
        double walletBalance = loggedInUser.getWallet().getBalance();
        double amountInUsd = (request.getAmount()* totalExchangeRate)+(request.getAmount()* totalExchangeRate)*0.05;
        if(walletBalance<amountInUsd){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance",105), HttpStatus.EXPECTATION_FAILED);
        }
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountInUsd);
        response.setCustomerBalance(walletBalance);
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);
    }
    public ResponseEntity checkTransferRequest(CheckTransferRequest request, String loggedInUserId){
        UserCustomer loggedInUser = customerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCheckTransferRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer receiver = customerRepository.findByMobileNumber(request.getReceiverNumber()).orElse(null);
        if(receiver==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receiver",105), HttpStatus.EXPECTATION_FAILED);
        }

        double walletBalance = loggedInUser.getWallet().getBalance();
        double amountInUsd =request.getAmount()+ (request.getAmount()*0.01);
        if(walletBalance<amountInUsd){
            return new ResponseEntity<>(new GenericApiError("Insufficient Balance",105), HttpStatus.EXPECTATION_FAILED);
        }
        CheckTransferResponse response = new CheckTransferResponse();
        response.setReceiver(userService.mapCustomerEntityToResponse(receiver));
        response.setAmount(request.getAmount());
        response.setCustomerBalance(walletBalance);
        response.setReference(request.getReference());
        return ResponseEntity.ok(response);
    }

    public ResponseEntity checkIssueChange(IssueChangeRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidIssueChangeRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer customer = customerRepository.findByMobileNumber(request.getAccountPhoneNumber()).orElse(null);

        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }


        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        if(request.getIssueChangeType().equals(IssueChangeType.DIRECT)){
            FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(request.getAcquiringFinancialInstitutionNumber()).orElse(null);
            if(financialInstitution==null){
                return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",105), HttpStatus.EXPECTATION_FAILED);
            }
            CheckIssueChangeResponse response = new CheckIssueChangeResponse();
            response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
            response.setAmount(request.getChangeRequired());
            response.setCustomerBalance(0);
            response.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
            return ResponseEntity.ok(response);
        }else{

            if(!customerRepository.existsByMobileNumber(request.getAccountPhoneNumber())) {
                // create Customer account from phone Number
                customer=   userService.addCustomerInternal(request.getDestinationAccount());
            }
            if(customer==null){
                customer= customerRepository.findByMobileNumber(request.getAccountPhoneNumber()).orElse(null);
            }

            CheckIssueChangeResponse response = new CheckIssueChangeResponse();
            if(customer!=null){
                response.setCustomer(userService.mapCustomerEntityToResponse(customer));
            }else{
                UserCustomerResponse customerResponse = new UserCustomerResponse();
                customerResponse.setActive(true);
                customerResponse.setFirstName(request.getAccountPhoneNumber());
                customerResponse.setGender(Gender.NOT_SET);
                customerResponse.setSurname("");
                customerResponse.setCustomerId("N/A");
                customerResponse.setMobileNumber(request.getAccountPhoneNumber());
                customerResponse.setContactMobileNumber(request.getAccountPhoneNumber());
                customerResponse.setContactMobileNumberCountryCode("ZW");
                customerResponse.setMobileNumberCountryCode("ZW");
                response.setCustomer(customerResponse);
            }

            response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
            response.setAmount(request.getChangeRequired());
            response.setCustomerBalance(0);
            response.setChangeAlreadyIssued(request.getChangeAlreadyIssued());
            response.setChangeRequired(request.getChangeRequired());
            response.setReceiptNumber(request.getReceiptNumber());
            response.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
            return ResponseEntity.ok(response);
        }


    }
    public ResponseEntity issueChange(IssueChangeRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidIssueChangeRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        UserCustomer customer = customerRepository.findByMobileNumber(request.getAccountPhoneNumber()).orElse(null);
        if(customer==null){
            customer =  userService.addCustomerInternal(request.getAccountPhoneNumber());
        }
        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(cashier.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            cashier.setBlocked(false);
            cashier.setEnabled(true);
            cashier.setPinTryCount(0);
            cashierRepository.save(cashier);
        }catch (BadCredentialsException e){
            if(cashier.getPinTryCount()==2){
                cashier.setPinTryCount(cashier.getPinTryCount() +1);
                cashier.setBlocked(true);
                cashier.setEnabled(false);
                cashierRepository.save(cashier);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= cashier.getPinTryCount()+1;
                cashier.setPinTryCount(count);
                cashierRepository.save(cashier);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }


        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        if(request.getIssueChangeType().equals(IssueChangeType.DIRECT)){
            FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(request.getAcquiringFinancialInstitutionNumber()).orElse(null);
            if(financialInstitution==null){
                return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",105), HttpStatus.EXPECTATION_FAILED);
            }
            // create transaction
            Transaction transaction = new Transaction();
            transaction.setId(stringGeneratorUtility.generateTransactionId());
            transaction.setStatus(TransactionStatus.SUCCESS);
            transaction.setTransactionType(TransactionType.CHANGE);
            transaction.setAmount(request.getChangeRequired());
            transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            transaction.setMerchant(merchant);
            transaction.setCashier(cashier);
            transaction.setMerchantBranch(cashier.getMerchantBranch());
            transaction.setCurrency(currency);
            transaction.setCustomer(null);
            transaction.setNotificationMsisdn(request.getNotificationMsisdn());
            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
            transaction.setDestinationAccount(request.getDestinationAccount());
            transaction.setFinancialInstitution(financialInstitution);
            transaction.setRequiredChange(request.getChangeRequired());
            transaction.setRequiredChangeInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            transaction.setChangeAlreadyIssued(request.getChangeAlreadyIssued());
            transaction.setChangeAlreadyIssuedInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeAlreadyIssued());
            transaction.setReference(request.getReceiptNumber());
            transactionsRepository.save(transaction);

            //Deduct from Merchant Account Balance
            MerchantAccount merchantAccount = merchant.getMerchantAccount();
            double amountToDeduct =(merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired();
            double balanceBefore = merchantAccount.getAccountBalance();
            merchantAccount.setAccountBalance(balanceBefore-amountToDeduct);
            //create Merchant Account History
            MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
            merchantAccountHistory.setAccount(merchantAccount);
            merchantAccountHistory.setBalanceAfter(merchantAccount.getAccountBalance());
            merchantAccountHistory.setBalanceBefore(balanceBefore);
            merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
            merchantAccountHistoryRepository.save(merchantAccountHistory);
            merchantAccountRepository.save(merchantAccount);
            // send change to Account
            //.........................................
            //send SMS to customer
            this.processIssueChangeSuccessCustomer(request.getNotificationMsisdn(),transaction);
            //send SMS to Cashier
            this.processIssueChangeSuccessCashier(cashier.getMobileNumber(),transaction);
            return ResponseEntity.ok(new GenericApiResponse("Issued Change Successfully"));
        }else{

            if(!customerRepository.existsByMobileNumber(request.getAccountPhoneNumber())) {
                // create Customer account from phone Number
                customer=   userService.addCustomerInternal(request.getDestinationAccount());
            }
            if(customer==null){
                customer= customerRepository.findByMobileNumber(request.getAccountPhoneNumber()).orElse(null);
            }
            // create transaction
            Transaction transaction = new Transaction();
            transaction.setId(stringGeneratorUtility.generateTransactionId());
            transaction.setStatus(TransactionStatus.SUCCESS);
            transaction.setTransactionType(TransactionType.CHANGE);
            transaction.setAmount(request.getChangeRequired());
            transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            transaction.setMerchant(merchant);
            transaction.setMerchantBranch(cashier.getMerchantBranch());
            transaction.setCurrency(currency);
            transaction.setCashier(cashier);
            transaction.setCustomer(customer);
            transaction.setNotificationMsisdn(customer.getMobileNumber());
            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
            transaction.setDestinationAccount(request.getDestinationAccount());
            transaction.setRequiredChange(request.getChangeRequired());
            transaction.setRequiredChangeInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            transaction.setChangeAlreadyIssued(request.getChangeAlreadyIssued());
            transaction.setChangeAlreadyIssuedInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeAlreadyIssued());
            transaction.setReference(request.getReceiptNumber());
            transactionsRepository.save(transaction);

            //Deduct from Merchant Account Balance
            MerchantAccount merchantAccount = merchant.getMerchantAccount();
            double amountToDeduct =(merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired();
            double balanceBefore = merchantAccount.getAccountBalance();
            merchantAccount.setAccountBalance(balanceBefore-amountToDeduct);
            //create Merchant Account History
            MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
            merchantAccountHistory.setAccount(merchantAccount);
            merchantAccountHistory.setReceiver(customer);
            merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.DEBIT);
            merchantAccountHistory.setAmount(amountToDeduct);
            merchantAccountHistory.setBalanceAfter(merchantAccount.getAccountBalance());
            merchantAccountHistory.setBalanceBefore(balanceBefore);
            merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
            merchantAccountHistoryRepository.save(merchantAccountHistory);
            merchantAccountRepository.save(merchantAccount);
            // Add To Customer Wallet
            Wallet wallet = customer.getWallet();
            double amountToAdd =(merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired();
            double walletBalanceBefore = wallet.getBalance();
            wallet.setBalance(walletBalanceBefore+amountToAdd);
            //create Merchant Account History
            WalletHistory walletHistory = new WalletHistory();
            walletHistory.setWallet(wallet);
            walletHistory.setHistoryType(WalletHistoryType.CREDIT);
            walletHistory.setAmount(amountToAdd);
            walletHistory.setSender(cashier);
            walletHistory.setReceiver(customer);
            walletHistory.setBalanceAfter(wallet.getBalance());
            walletHistory.setBalanceBefore(balanceBefore);
            walletHistory.setDateOfEntry(LocalDateTime.now());
            walletHistoryRepository.save(walletHistory);
            walletRepository.save(wallet);
            //send SMS to customer
            this.processIssueChangeSuccessCustomer(customer.getMobileNumber(),transaction);
            //send SMS to Cashier
            this.processIssueChangeSuccessCashier(cashier.getMobileNumber(),transaction);
            CheckIssueChangeResponse response = new CheckIssueChangeResponse();
            response.setCustomer(userService.mapCustomerEntityToResponse(customer));
            response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
            response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
            response.setAmount(request.getChangeRequired());
            response.setChangeAlreadyIssued(request.getChangeAlreadyIssued());
            response.setChangeRequired(request.getChangeRequired());
            response.setReceiptNumber(request.getReceiptNumber());
            response.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getChangeRequired());
            response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
            return ResponseEntity.ok(response);
        }


    }
    public ResponseEntity TransferCredit(CustomerTransferRequest request, String loggedInUserId){

        ResponseEntity theResponse = validateTransactionProperties.isValidTransferRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        UserCustomer loggedInUser = customerRepository.findById(loggedInUserId).orElse(null);
        if(loggedInUser==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loggedInUser.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            loggedInUser.setBlocked(false);
            loggedInUser.setEnabled(true);
            loggedInUser.setPinTryCount(0);
            customerRepository.save(loggedInUser);
        }catch (BadCredentialsException e){
            if(loggedInUser.getPinTryCount()==2){
                loggedInUser.setPinTryCount(loggedInUser.getPinTryCount() +1);
                loggedInUser.setBlocked(true);
                loggedInUser.setEnabled(false);
                customerRepository.save(loggedInUser);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= loggedInUser.getPinTryCount()+1;
                loggedInUser.setPinTryCount(count);
                customerRepository.save(loggedInUser);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        if(loggedInUser.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = customerRepository.findByMobileNumber(request.getReceiverNumber()).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Receivers Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        double transactionCharge =NumbersUtil.round(((1/100)* request.getAmount()),2);
        double totalAmount =transactionCharge+ request.getAmount();
        // create transaction
        Transaction transaction = new Transaction();
        transaction.setId(stringGeneratorUtility.generateTransactionId());
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setTransactionType(TransactionType.TRANSFER);
        transaction.setAmount(request.getAmount());
        transaction.setAmountInUsd(request.getAmount());
        transaction.setMerchant(null);
        transaction.setMerchantBranch(null);
        transaction.setCurrency(currency);
        transaction.setCustomer(customer);
        transaction.setNotificationMsisdn(customer.getMobileNumber());
        transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
        transaction.setMerchantIncentiveUsed(0);
        transaction.setTotalExchangeRateUsed(currency.getExchangeRate());
        transaction.setTransactionCharge(transactionCharge);
        transaction.setTransactionCharge(NumbersUtil.round(((1/100)* request.getAmount()),2));
        transaction.setSender(loggedInUser);
        transaction.setReceiver(customer);
        transaction.setReference(request.getReference());
        transactionsRepository.save(transaction);

        // Deduct from Sender Wallet
        Wallet senderWallet = loggedInUser.getWallet();
        double amountToDeduct =totalAmount;
        double senderWalletBalanceBefore = senderWallet.getBalance();
        senderWallet.setBalance(senderWalletBalanceBefore-amountToDeduct);
        //create Merchant Account History
        WalletHistory senderWalletHistory = new WalletHistory();
        senderWalletHistory.setWallet(senderWallet);
        senderWalletHistory.setHistoryType(WalletHistoryType.DEBIT);
        senderWalletHistory.setAmount(amountToDeduct);
        senderWalletHistory.setSender(loggedInUser);
        senderWalletHistory.setReceiver(customer);
        senderWalletHistory.setBalanceAfter(senderWallet.getBalance());
        senderWalletHistory.setBalanceBefore(senderWalletBalanceBefore);
        senderWalletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistoryRepository.save(senderWalletHistory);
        walletRepository.save(senderWallet);
        // Add To Customer Wallet
        Wallet wallet = customer.getWallet();
        double amountToAdd =totalAmount;
        double walletBalanceBefore = wallet.getBalance();
        wallet.setBalance(walletBalanceBefore+amountToAdd);
        //create Merchant Account History
        WalletHistory walletHistory = new WalletHistory();
        walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.CREDIT);
        walletHistory.setAmount(amountToAdd);
        walletHistory.setSender(loggedInUser);
        walletHistory.setReceiver(customer);
        walletHistory.setBalanceAfter(wallet.getBalance());
        walletHistory.setBalanceBefore(walletBalanceBefore);
        walletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistoryRepository.save(walletHistory);
        walletRepository.save(wallet);
        //send SMS to Sender
        this.processTransferSuccessSender(loggedInUser.getMobileNumber(),transaction,senderWallet.getBalance());
        //send SMS to Receiver
        this.processTransferSuccessReceiver(customer.getMobileNumber(),transaction,wallet.getBalance());
        CheckTransferResponse response = new CheckTransferResponse();
        response.setReceiver(userService.mapCustomerEntityToResponse(customer));
        response.setAmount(request.getAmount());
        response.setCustomerBalance(wallet.getBalance());
        response.setReference(request.getReference());
        return ResponseEntity.ok(response);

    }
    public ResponseEntity makePayment(CustomerPaymentRequest request,String loggedInUserId){

        ResponseEntity theResponse = validateTransactionProperties.isValidPaymentRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }

        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(customer.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            customer.setBlocked(false);
            customer.setEnabled(true);
            customer.setPinTryCount(0);
            customerRepository.save(customer);
        }catch (BadCredentialsException e){
            if(customer.getPinTryCount()==2){
                customer.setPinTryCount(customer.getPinTryCount() +1);
                customer.setBlocked(true);
                customer.setEnabled(false);
                customerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= customer.getPinTryCount()+1;
                customer.setPinTryCount(count);
                customerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }

        Currency currency = currencyRepository.findByCode(request.getCurrencyCode()).orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
//        if(request.getPaymentType().equals(IssueChangeType.WALLET)){
            // create transaction
            Transaction transaction = new Transaction();
            transaction.setId(stringGeneratorUtility.generateTransactionId());
            transaction.setStatus(TransactionStatus.SUCCESS);
            transaction.setTransactionType(TransactionType.PAYMENT);
            transaction.setAmount(request.getAmount());
            transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
            transaction.setMerchant(merchant);
            transaction.setCashier(cashier);
            transaction.setMerchantBranch(cashier.getMerchantBranch());
            transaction.setCurrency(currency);
            transaction.setCustomer(customer);
            transaction.setCashier(cashier);
            transaction.setNotificationMsisdn(customer.getMobileNumber());
            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
            transactionsRepository.save(transaction);

        double amountToRemove =(merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount();
            //Add Amount to merchant
            double merchantBalanceBefore = merchantAccount.getAccountBalance();
            MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
            merchantAccountHistory.setAccount(merchantAccount);
        merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.CREDIT);
        merchantAccountHistory.setAmount(amountToRemove);
        merchantAccountHistory.setSender(customer);
            merchantAccountHistory.setBalanceBefore(merchantBalanceBefore);
            merchantAccountHistory.setBalanceAfter(merchantBalanceBefore+amountToRemove);
            merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
            merchantAccountHistoryRepository.save(merchantAccountHistory);
            merchantAccount.setAccountBalance(merchantBalanceBefore+amountToRemove);
            merchantAccountRepository.save(merchantAccount);
            // Add To Customer Wallet
            Wallet wallet = customer.getWallet();

            double walletBalanceBefore = wallet.getBalance();
            wallet.setBalance(walletBalanceBefore-amountToRemove);
            //create Merchant Account History
            WalletHistory walletHistory = new WalletHistory();
            walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.DEBIT);
        walletHistory.setAmount(amountToRemove);
            walletHistory.setBalanceAfter(wallet.getBalance());
            walletHistory.setBalanceBefore(walletBalanceBefore);
            walletHistory.setDateOfEntry(LocalDateTime.now());
        walletHistory.setSender(customer);
        walletHistory.setReceiver(cashier);
            walletHistoryRepository.save(walletHistory);
            walletRepository.save(wallet);
            //send SMS to customer
            this.processPaymentSuccessCustomer(customer.getMobileNumber(),transaction);
            //send SMS to Cashier
            this.processPaymentSuccessCashier(cashier.getMobileNumber(),transaction);
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountToRemove);
        response.setCustomerBalance(wallet.getBalance());
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);
//        }else{
//            FinancialInstitution financialInstitution = financialInstitutionRepository.findByInstitutionNumber(request.getAcquiringFinancialInstitutionNumber()).orElse(null);
//            if(financialInstitution==null){
//                return new ResponseEntity<>(new GenericApiError("Could not load Financial Institution",105), HttpStatus.EXPECTATION_FAILED);
//            }
//            // create transaction
//            Transaction transaction = new Transaction();
//            transaction.setId(stringGeneratorUtility.generateTransactionId());
//            transaction.setStatus(TransactionStatus.SUCCESS);
//            transaction.setTransactionType(TransactionType.PAYMENT);
//            transaction.setAmount(request.getAmount());
//            transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
//            transaction.setMerchant(merchant);
//            transaction.setMerchantBranch(cashier.getMerchantBranch());
//            transaction.setCurrency(currency);
//            transaction.setCustomer(customer);
//            transaction.setNotificationMsisdn(request.getNotificationMsisdn());
//            transaction.setSenderAccount(request.getAccountNumber());
//            transaction.setCashier(cashier);
//            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
//            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
//            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
//            transactionsRepository.save(transaction);
//
//            //Add Amount to merchant
//            //..................................
//
//
//            //send SMS to customer
//            this.processPaymentSuccessCustomer(request.getNotificationMsisdn(),transaction);
//            //send SMS to Cashier
//            this.processPaymentSuccessCashier(cashier.getMobileNumber(),transaction);
//            return ResponseEntity.ok(new GenericApiResponse("Payment Done Successfully"));
//        }

    }
    public ResponseEntity cashOut(CashOutRequest request, String loggedInUserId){
        ResponseEntity theResponse = validateTransactionProperties.isValidCashOutRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findByCode(request.getCashierCode()).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Cashier",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(customer.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            customer.setBlocked(false);
            customer.setEnabled(true);
            customer.setPinTryCount(0);
            customerRepository.save(customer);
        }catch (BadCredentialsException e){
            if(customer.getPinTryCount()==2){
                customer.setPinTryCount(customer.getPinTryCount() +1);
                customer.setBlocked(true);
                customer.setEnabled(false);
                customerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= customer.getPinTryCount()+1;
                customer.setPinTryCount(count);
                customerRepository.save(customer);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }
        if(customer.getWallet()==null){
            return new ResponseEntity<>(new GenericApiError("Could not load your Wallet",105), HttpStatus.EXPECTATION_FAILED);
        }

        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        double transactionCharge =NumbersUtil.round(((5/100)* request.getAmount()),2);
        double totalAmount =transactionCharge+ request.getAmount();
            // create transaction
            Transaction transaction = new Transaction();
            transaction.setId(stringGeneratorUtility.generateTransactionId());
            transaction.setStatus(TransactionStatus.SUCCESS);
            transaction.setTransactionType(TransactionType.CASH_OUT);
            transaction.setAmount(request.getAmount());
            transaction.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
            transaction.setMerchant(merchant);
            transaction.setCashier(cashier);
            transaction.setMerchantBranch(cashier.getMerchantBranch());
            transaction.setCurrency(currency);
            transaction.setCustomer(customer);
            transaction.setTransactionCharge(transactionCharge);
            transaction.setTransactionChargeInUsd(transactionCharge);
            transaction.setCashier(cashier);
            transaction.setNotificationMsisdn(customer.getMobileNumber());
            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
            transactionsRepository.save(transaction);

            //Add Amount to merchant
        double merchantBalanceBefore = merchantAccount.getAccountBalance();
            MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
            merchantAccountHistory.setAccount(merchantAccount);
            merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.CREDIT);
            merchantAccountHistory.setAmount(totalAmount);
        merchantAccountHistory.setSender(customer);
            merchantAccountHistory.setBalanceBefore(merchantBalanceBefore);
            merchantAccountHistory.setBalanceAfter(merchantBalanceBefore+totalAmount);
            merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
            merchantAccountHistoryRepository.save(merchantAccountHistory);
            merchantAccount.setAccountBalance(merchantBalanceBefore+totalAmount);
            merchantAccountRepository.save(merchantAccount);

            //..................................
            // Add To Customer Wallet
            Wallet wallet = customer.getWallet();
            double amountToRemove =totalAmount;
            double walletBalanceBefore = wallet.getBalance();
            wallet.setBalance(walletBalanceBefore-amountToRemove);
            //create Merchant Account History
            WalletHistory walletHistory = new WalletHistory();
            walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.DEBIT);
        walletHistory.setSender(customer);
        walletHistory.setReceiver(cashier);
        walletHistory.setAmount(amountToRemove);
            walletHistory.setBalanceAfter(wallet.getBalance());
            walletHistory.setBalanceBefore(walletBalanceBefore);
            walletHistory.setDateOfEntry(LocalDateTime.now());
            walletHistoryRepository.save(walletHistory);
            walletRepository.save(wallet);
            //send SMS to customer
            this.processCashOutSuccessCustomer(customer.getMobileNumber(),transaction);
            //send SMS to Cashier
            this.processCashOutSuccessCashier(cashier.getMobileNumber(),transaction);
        CheckPaymentResponse response = new CheckPaymentResponse();
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmountInUsd(amountToRemove);
        response.setCustomerBalance(wallet.getBalance());
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        response.setAmount(request.getAmount());
        return ResponseEntity.ok(response);


    }
    public ResponseEntity checkCashIn(CashInRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCashInRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }


        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }

            UserCustomer customer=customerRepository.findByMobileNumber(request.getReceiverPhoneNumber()).orElse(null);

        CheckIssueChangeResponse response = new CheckIssueChangeResponse();
        response.setCustomer(userService.mapCustomerEntityToResponse(customer));
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmount(request.getAmount());
        response.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        return ResponseEntity.ok(response);



    }
    public ResponseEntity cashIn(CashInRequest request, String loggedInUserId){
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidCashInRequest(request,loggedInUserId);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        try{
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(cashier.getUsername(), request.getPin()));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            cashier.setBlocked(false);
            cashier.setEnabled(true);
            cashier.setPinTryCount(0);
            cashierRepository.save(cashier);
        }catch (BadCredentialsException e){
            if(cashier.getPinTryCount()==2){
                cashier.setPinTryCount(cashier.getPinTryCount() +1);
                cashier.setBlocked(true);
                cashier.setEnabled(false);
                cashierRepository.save(cashier);
                return new ResponseEntity<>(new GenericApiError("Your Pin Has been Blocked. Please visit our nearest Shop to Unblock",110), HttpStatus.UNAUTHORIZED);
            }else{
                long count= cashier.getPinTryCount()+1;
                cashier.setPinTryCount(count);
                cashierRepository.save(cashier);
                return new ResponseEntity<>(new GenericApiError("Incorrect Pin Please try again. You have "+(3-count)+" Attempts Left before Pin Is Blocked",110), HttpStatus.UNAUTHORIZED);
            }
        }

        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }


        Merchant merchant =cashier.getMerchantBranch().getMerchant();
        double merchantIncentiveAmount=0;
        MerchantAccount merchantAccount= merchant.getMerchantAccount();
        MerchantIncentive merchantIncentive = merchantIncentiveRepository.findByMerchantIdAndCurrencyCode(merchant.getId(),currency.getCode()).orElse(null);
        if(merchantIncentive!=null){
            merchantIncentiveAmount=merchantIncentive.getAmount();
        }

            UserCustomer customer=customerRepository.findByMobileNumber(request.getReceiverPhoneNumber()).orElse(null);

            // create transaction
            Transaction transaction = new Transaction();
            transaction.setId(stringGeneratorUtility.generateTransactionId());
            transaction.setStatus(TransactionStatus.SUCCESS);
            transaction.setTransactionType(TransactionType.CASH_IN);
            transaction.setAmount(request.getAmount());
            transaction.setAmountInUsd(request.getAmount());
            transaction.setMerchant(merchant);
            transaction.setCashier(cashier);
            transaction.setMerchantBranch(cashier.getMerchantBranch());
            transaction.setCurrency(currency);
            transaction.setCustomer(customer);
            transaction.setNotificationMsisdn(customer.getMobileNumber());
            transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
            transaction.setMerchantIncentiveUsed(merchantIncentiveAmount);
            transaction.setTotalExchangeRateUsed(merchantIncentiveAmount+currency.getExchangeRate());
            transactionsRepository.save(transaction);

        double amountToAdd = request.getAmount();

        double merchantBalanceBefore = merchantAccount.getAccountBalance();
        MerchantAccountHistory merchantAccountHistory = new MerchantAccountHistory();
        merchantAccountHistory.setAccount(merchantAccount);
        merchantAccountHistory.setHistoryType(MerchantAccountHistoryType.DEBIT);
        merchantAccountHistory.setAmount(amountToAdd);
        merchantAccountHistory.setReceiver(customer);
        merchantAccountHistory.setBalanceBefore(merchantBalanceBefore);
        merchantAccountHistory.setBalanceAfter(merchantBalanceBefore-amountToAdd);
        merchantAccountHistory.setDateOfEntry(LocalDateTime.now());
        merchantAccountHistoryRepository.save(merchantAccountHistory);
        merchantAccount.setAccountBalance(merchantBalanceBefore-amountToAdd);
        merchantAccountRepository.save(merchantAccount);
            // Add To Customer Wallet
            Wallet wallet = customer.getWallet();

            double walletBalanceBefore = wallet.getBalance();
            wallet.setBalance(walletBalanceBefore+amountToAdd);
            //create Merchant Account History
            WalletHistory walletHistory = new WalletHistory();
            walletHistory.setWallet(wallet);
        walletHistory.setHistoryType(WalletHistoryType.CREDIT);
        walletHistory.setAmount(amountToAdd);
        walletHistory.setSender(cashier);
        walletHistory.setReceiver(customer);
            walletHistory.setBalanceAfter(wallet.getBalance());
            walletHistory.setBalanceBefore(walletBalanceBefore);
            walletHistory.setDateOfEntry(LocalDateTime.now());
            walletHistoryRepository.save(walletHistory);
            walletRepository.save(wallet);
            //send SMS to customer
            this.processCashInSuccessCustomer(customer.getMobileNumber(),transaction);
            //send SMS to Cashier
            this.processCashInSuccessCashier(cashier.getMobileNumber(),transaction);
        CheckIssueChangeResponse response = new CheckIssueChangeResponse();
        response.setCustomer(userService.mapCustomerEntityToResponse(customer));
        response.setCashier(userService.mapMerchantCashierEntityToResponse(cashier));
        response.setAmount(request.getAmount());
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setAmountInUsd((merchantIncentiveAmount+currency.getExchangeRate())* request.getAmount());
        response.setCurrency(currencyService.mapEntityToCurrencyResponse(currency));
        return ResponseEntity.ok(response);

    }

    public ResponseEntity checkTransactionStatus(String reference, String loggedInUserId){
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Transaction payment = transactionsRepository.findById(reference).orElse(null);
        if(payment==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Transaction",110), HttpStatus.NOT_FOUND);
        }
        return ResponseEntity.ok(this.mapCheckTransactionStatusResponse(payment));
    }
    public ResponseEntity getTransactionByReference(String reference){

        Transaction platform =  transactionsRepository.findById(reference).orElse(null);
        if (platform == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Transaction",110), HttpStatus.NOT_FOUND);
        }
        TransactionResponse response= this.mapEntityToTransactionResponse(platform);
        return  ResponseEntity.ok(response);
    }
    public ResponseEntity getAllTransactions(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findAll(pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getTransactionsByTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByStatus(status,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getTransactionsByTransactionType(TransactionType paymentMethodType, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByTransactionType(paymentMethodType,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchTransactionsByCustomerName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            try {
                TransactionType paymentMethodType = TransactionType.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCustomerSurnameContainingIgnoreCaseAndTransactionType(request.getSearchQuery(),paymentMethodType, request.getSearchQuery(),paymentMethodType, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)) {
            try {
                TransactionStatus paymentStatus = TransactionStatus.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseAndStatusOrCustomerSurnameContainingIgnoreCaseAndStatus(request.getSearchQuery(),paymentStatus,request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else {
            failures = transactionsRepository.findByCustomerFirstNameContainingIgnoreCaseOrCustomerSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<TransactionResponse> responses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity getAllTransactionsByCustomerId(String customerId, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        UserCustomer customer = customerRepository.findById(customerId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",110),HttpStatus.NOT_FOUND);
        }
        Page<Transaction> failures =  transactionsRepository.findByCustomerUserId(customer.getUserId(), pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getPaymentTransactionsByCustomerId( int page, int size,String loggedInUserId) {
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCustomerUserIdAndTransactionType(customer.getUserId(),TransactionType.PAYMENT, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCashoutTransactionsByCustomerId( int page, int size,String loggedInUserId) {
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCustomerUserIdAndTransactionType(customer.getUserId(),TransactionType.CASH_OUT, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCashinTransactionsByCustomerId( int page, int size,String loggedInUserId) {
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCustomerUserIdAndTransactionType(customer.getUserId(),TransactionType.CASH_IN, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getTransferTransactionsByCustomerId( int page, int size,String loggedInUserId) {
        UserCustomer customer = customerRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCustomerUserIdAndTransactionTypeOrReceiverUserIdAndTransactionType(customer.getUserId(),TransactionType.TRANSFER,customer.getUserId(),TransactionType.TRANSFER, pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity getAllTransactionsByCashierId(String customerId, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        MerchantCashier customer = cashierRepository.findById(customerId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",110),HttpStatus.NOT_FOUND);
        }
        Page<Transaction> failures =  transactionsRepository.findByCashierUserId(customer.getUserId(), pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getPaymentTransactionsByCashierId( int page, int size,String loggedInUserId) {
        MerchantCashier customer = cashierRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCashierUserIdAndTransactionType(customer.getUserId(),TransactionType.PAYMENT, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getWithdrawalTransactionsByTellerId( int page, int size,String loggedInUserId) {
        TellerUser customer = tellerUserRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByTellerUserIdAndTransactionType(customer.getUserId(),TransactionType.WITHDRAWAL, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCashoutTransactionsByCashierId( int page, int size,String loggedInUserId) {
        MerchantCashier customer = cashierRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCashierUserIdAndTransactionType(customer.getUserId(),TransactionType.CASH_OUT, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCashinTransactionsByCashierId( int page, int size,String loggedInUserId) {
        MerchantCashier customer = cashierRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCashierUserIdAndTransactionType(customer.getUserId(),TransactionType.CASH_IN, pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getIssuedChangeTransactionsByCashierId( int page, int size,String loggedInUserId) {
        MerchantCashier customer = cashierRepository.findById(loggedInUserId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");

        Page<Transaction> failures =  transactionsRepository.findByCashierUserIdAndTransactionType(customer.getUserId(),TransactionType.CHANGE, pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity getTransactionsByCustomerIdAndTransactionStatus(String customerId, TransactionStatus status, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        UserCustomer customer = customerRepository.findById(customerId).orElse(null);
        if(customer==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Customer",110),HttpStatus.NOT_FOUND);
        }
        Page<Transaction> failures =  transactionsRepository.findByCustomerUserIdAndStatus(customer.getUserId(), status,pageable);

        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsThisWeekAndTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatus(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),status,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsTodayAndTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatus(startOfDay,endOfDay,status,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsThisMonthAndTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatus(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),status,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsFromRangeAndTransactionStatus(TransactionStatus status,String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDateTime(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDateTime(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDateTime startDate = LocalDateTime.parse(startDateTimeString);
        LocalDateTime endDate = LocalDateTime.parse(endDateTimeString);
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatus(startDate,endDate,status,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsThisWeekAndTransactionType(TransactionType paymentMethodType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndTransactionType(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),paymentMethodType,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsTodayAndTransactionType(TransactionType paymentMethodType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndTransactionType(startOfDay,endOfDay,paymentMethodType,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsThisMonthAndTransactionType(TransactionType paymentMethodType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndTransactionType(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),paymentMethodType,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetTransactionsFromRangeAndTransactionType(TransactionType paymentMethodType,String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDateTime(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDateTime(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDateTime startDate = LocalDateTime.parse(startDateTimeString);
        LocalDateTime endDate = LocalDateTime.parse(endDateTimeString);
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndTransactionType(startDate,endDate,paymentMethodType,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }


    public ResponseEntity GetCashierTransactionsThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Page<Transaction> failures = transactionsRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetCashierTransactionsToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<Transaction> failures = transactionsRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),startOfDay,endOfDay,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetCashierTransactionsThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetCashierTransactionsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllCashierTransactions(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByCashierUserId(cashier.getUserId(),pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCashierTransactionsByTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByCashierUserIdAndStatus(cashier.getUserId(),status,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCashierTransactionsByTransactionType(TransactionType paymentMethodType, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByCashierUserIdAndTransactionType(cashier.getUserId(),paymentMethodType,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchCashierTransactionsByCustomerName(SearchRequest request, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantCashier(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        MerchantCashier cashier = cashierRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            try {
                TransactionType paymentMethodType = TransactionType.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndTransactionType(cashier.getUserId(),request.getSearchQuery(),paymentMethodType,cashier.getUserId(), request.getSearchQuery(),paymentMethodType, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)) {
            try {
                TransactionStatus paymentStatus = TransactionStatus.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndStatusOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndStatus(cashier.getUserId(),request.getSearchQuery(),paymentStatus,cashier.getUserId(),request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),cashier.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),cashier.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), cashier.getUserId(),request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), cashier.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else {
            failures = transactionsRepository.findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseOrCashierUserIdAndCustomerSurnameContainingIgnoreCase(cashier.getUserId(),request.getSearchQuery(),cashier.getUserId(),request.getSearchQuery(), pageable);
        }
        List<TransactionResponse> responses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }


    public ResponseEntity GetMerchantTransactionsThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Page<Transaction> failures = transactionsRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantTransactionsToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<Transaction> failures = transactionsRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),startOfDay,endOfDay,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantTransactionsThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantTransactionsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllMerchantTransactions(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByMerchantId(cashier.getUserId(),pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantTransactionsByTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByMerchantIdAndStatus(cashier.getUserId(),status,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getMerchantTransactionsByTransactionType(TransactionType paymentMethodType, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByMerchantIdAndTransactionType(cashier.getUserId(),paymentMethodType,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchMerchantTransactionsByCustomerName(SearchRequest request, String loggedInUserId) {
        if(!this.isLoggedInUserMerchantAdmin(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        MerchantAdmin cashier = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            try {
                TransactionType paymentMethodType = TransactionType.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndTransactionType(cashier.getUserId(),request.getSearchQuery(),paymentMethodType,cashier.getUserId(), request.getSearchQuery(),paymentMethodType, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)) {
            try {
                TransactionStatus paymentStatus = TransactionStatus.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndStatusOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndStatus(cashier.getUserId(),request.getSearchQuery(),paymentStatus,cashier.getUserId(),request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),cashier.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),cashier.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), cashier.getUserId(),request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), cashier.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else {
            failures = transactionsRepository.findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseOrMerchantIdAndCustomerSurnameContainingIgnoreCase(cashier.getUserId(),request.getSearchQuery(),cashier.getUserId(),request.getSearchQuery(), pageable);
        }
        List<TransactionResponse> responses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }

    public ResponseEntity GetBranchTransactionsThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        Page<Transaction> failures = transactionsRepository.findByCashierMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetBranchTransactionsToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<Transaction> failures = transactionsRepository.findByCashierMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),startOfDay,endOfDay,pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetBranchTransactionsThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCashierMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetBranchTransactionsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<Transaction> failures = transactionsRepository.findByCashierMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),startDate.atTime(LocalTime.MIN),endDate.atTime(LocalTime.MAX),pageable);

        List<TransactionResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getAllBranchTransactions(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByCashierMerchantBranchId(cashier.getMerchantBranch().getId(),pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBranchTransactionsByTransactionStatus(TransactionStatus status,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByCashierMerchantBranchIdAndStatus(cashier.getMerchantBranch().getId(),status,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getBranchTransactionsByTransactionType(TransactionType paymentMethodType, int page, int size, String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures =  transactionsRepository.findByCashierMerchantBranchIdAndTransactionType(cashier.getMerchantBranch().getId(),paymentMethodType,pageable);
        List<TransactionResponse> regions= failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(regions, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity searchBranchTransactionsByCustomerName(SearchRequest request, String loggedInUserId) {
        if(!this.isLoggedInUserBranchManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        ResponseEntity theResponse = validateTransactionProperties.isValidSearchRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        BranchManager cashier = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if(cashier==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Transaction> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            try {
                TransactionType paymentMethodType = TransactionType.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndTransactionType(cashier.getMerchantBranch().getId(),request.getSearchQuery(),paymentMethodType,cashier.getMerchantBranch().getId(), request.getSearchQuery(),paymentMethodType, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)) {
            try {
                TransactionStatus paymentStatus = TransactionStatus.valueOf(request.getFilterValue());
                failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndStatusOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndStatus(cashier.getMerchantBranch().getId(),request.getSearchQuery(),paymentStatus,cashier.getMerchantBranch().getId(),request.getSearchQuery(), paymentStatus, pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Transaction Method", 110), HttpStatus.NOT_FOUND);
            }

        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),cashier.getMerchantBranch().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),cashier.getMerchantBranch().getId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), cashier.getMerchantBranch().getId(),request.getSearchQuery(),LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(cashier.getMerchantBranch().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), cashier.getMerchantBranch().getId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        }
        else {
            failures = transactionsRepository.findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCase(cashier.getMerchantBranch().getId(),request.getSearchQuery(),cashier.getMerchantBranch().getId(),request.getSearchQuery(), pageable);
        }
        List<TransactionResponse> responses = failures.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    
    /////////////////////////////////////////////////////////Merchant Withdrawal ///////////////////////////////////////////////
    public  ResponseEntity sendWithdrawalRequest(ApplyMerchantWithdrawalRequest request, String loggedInUserId){
        if (!this.isLoggedInUserMerchantAdmin(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin admin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAccount account = admin.getMerchant().getMerchantAccount();
        if(account==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account", 102), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getAmount()> account.getAccountBalance()){
            return new ResponseEntity<>(new GenericApiError("Insufficient balance", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantWithdrawalRequest depositRequest = new MerchantWithdrawalRequest();
        depositRequest.setAccount(account);
        depositRequest.setRequestedBy(admin);
        depositRequest.setStatus(DepositRequestStatus.PENDING);
        depositRequest.setAmount(request.getAmount());
        merchantWithdrawalRequestRepository.save(depositRequest);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Withdrwal Request Submitted Successfully"));
    }
    public  ResponseEntity approveWithdrawalRequest(ApproveMerchantWithdrawalRequest request, String loggedInUserId){
        if (!this.isLoggedInUserMerchantAdmin(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantWithdrawalRequest depositRequest = merchantWithdrawalRequestRepository.findById(request.getRequestId()).orElse(null);
        if(depositRequest==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Withdrawal Request", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAdmin admin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = admin.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccount account = admin.getMerchant().getMerchantAccount();
        if(account==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account", 102), HttpStatus.EXPECTATION_FAILED);
        }
        if(depositRequest.getAmount()> account.getAccountBalance()){
            return new ResponseEntity<>(new GenericApiError("Insufficient balance", 102), HttpStatus.EXPECTATION_FAILED);
        }
        if(depositRequest.getStatus().equals(DepositRequestStatus.APPROVED)){
            return new ResponseEntity<>(new GenericApiError("Withdrawal Already Approved", 102), HttpStatus.EXPECTATION_FAILED);
        }

        depositRequest.setStatus(DepositRequestStatus.APPROVED);
        depositRequest.setApprovalCode(stringGeneratorUtility.generateWithdrawalApprovalCode(merchant.getId()));
        depositRequest.setApprovedBy(admin.getUserId());
        depositRequest.setApprovedDate(LocalDateTime.now());
        merchantWithdrawalRequestRepository.save(depositRequest);
        this.processSuccessfulWithdrawalApproval(merchant.getWithdrawalEmail(),merchant.getWithdrawalPhoneNumber(),depositRequest.getApprovalCode(),merchant.getCode(),merchant.getName());
        return ResponseEntity.ok(new GenericApiResponse("Merchant Withdrawal Request Declined Successfully"));
    }
    public  ResponseEntity completeWithdrawalRequest(CompleteMerchantWithdrawalRequest request, String loggedInUserId){
        if (!this.isLoggedInUserTellerUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        TellerUser admin = tellerUserRepository.findById(loggedInUserId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = merchantRepository.findByCode(request.getCode()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccount account = merchant.getMerchantAccount();
        if(account==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantWithdrawalRequest depositRequest = merchantWithdrawalRequestRepository.findByAccountMerchantIdAndApprovalCode(merchant.getId(),request.getApproval()).orElse(null);
        if(depositRequest==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Withdrawal Request", 102), HttpStatus.EXPECTATION_FAILED);
        }
        Currency currency= currencyRepository.findByName("USD").stream().findFirst().orElse(null);
        if(currency==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Currency",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(depositRequest.getAmount()> account.getAccountBalance()){
            return new ResponseEntity<>(new GenericApiError("Insufficient balance", 102), HttpStatus.EXPECTATION_FAILED);
        }
        if(depositRequest.getStatus().equals(DepositRequestStatus.COMPLETED)){
            return new ResponseEntity<>(new GenericApiError("Withdrawal Already Completed", 102), HttpStatus.EXPECTATION_FAILED);
        }
        depositRequest.setStatus(DepositRequestStatus.COMPLETED);
        depositRequest.setCompletedBy(admin.getUserId());
        depositRequest.setCompletedDate(LocalDateTime.now());
        merchantWithdrawalRequestRepository.save(depositRequest);

        Transaction transaction = new Transaction();
        transaction.setId(stringGeneratorUtility.generateTransactionId());
        transaction.setStatus(TransactionStatus.SUCCESS);
        transaction.setTransactionType(TransactionType.WITHDRAWAL);
        transaction.setAmount(depositRequest.getAmount());
        transaction.setAmountInUsd(depositRequest.getAmount());
        transaction.setMerchant(merchant);
        transaction.setCurrency(currency);
        transaction.setTeller(admin);
        transaction.setApprovalCode(request.getApproval());
        transaction.setBaseExchangeRateUsed(currency.getExchangeRate());
        transaction.setTotalExchangeRateUsed(currency.getExchangeRate());
        Transaction savedTransaction = transactionsRepository.save(transaction);
        this.processSuccessfulWithdrawalComplete(merchant.getWithdrawalEmail(),merchant.getWithdrawalPhoneNumber(),merchant.getCode(),merchant.getName(),savedTransaction);
        CheckWithdrawalResponse response = new CheckWithdrawalResponse();
        response.setAmountInUsd(depositRequest.getAmount());
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setAmount(depositRequest.getAmount());
        response.setApprovalCode(request.getApproval());
        response.setCode(request.getCode());
        response.setTellerName(admin.getFirstName() +" "+ admin.getSurname());
        return ResponseEntity.ok(response);
    }
    public  ResponseEntity checkCompleteWithdrawalRequest(CompleteMerchantWithdrawalRequest request, String loggedInUserId){
        if (!this.isLoggedInUserTellerUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        TellerUser admin = tellerUserRepository.findById(loggedInUserId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = merchantRepository.findByCode(request.getCode()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccount account = merchant.getMerchantAccount();
        if(account==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantWithdrawalRequest depositRequest = merchantWithdrawalRequestRepository.findByAccountMerchantIdAndApprovalCode(merchant.getId(),request.getApproval()).orElse(null);
        if(depositRequest==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Withdrawal Request", 102), HttpStatus.EXPECTATION_FAILED);
        }
        if(depositRequest.getAmount()> account.getAccountBalance()){
            return new ResponseEntity<>(new GenericApiError("Insufficient balance", 102), HttpStatus.EXPECTATION_FAILED);
        }
        if(depositRequest.getStatus().equals(DepositRequestStatus.COMPLETED)){
            return new ResponseEntity<>(new GenericApiError("Withdrawal Already Completed", 102), HttpStatus.EXPECTATION_FAILED);
        }


        CheckWithdrawalResponse response = new CheckWithdrawalResponse();
        response.setAmountInUsd(depositRequest.getAmount());
        response.setMerchant(merchantService.mapEntityToMerchantResponse(merchant));
        response.setAmount(depositRequest.getAmount());
        response.setApprovalCode(request.getApproval());
        response.setCode(request.getCode());

        return ResponseEntity.ok(response);
    }
    public  ResponseEntity declineWithdrawalRequest(ApproveMerchantWithdrawalRequest request, String loggedInUserId){
        if (!this.isLoggedInUserMerchantAdmin(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantWithdrawalRequest depositRequest = merchantWithdrawalRequestRepository.findById(request.getRequestId()).orElse(null);
        if(depositRequest==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Withdrawal Request", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAdmin admin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(admin==null){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = admin.getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant", 102), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantAccount account = admin.getMerchant().getMerchantAccount();
        if(account==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Account", 102), HttpStatus.EXPECTATION_FAILED);
        }

        if(depositRequest.getStatus().equals(DepositRequestStatus.DECLINED)){
            return new ResponseEntity<>(new GenericApiError("Withdrawal Already Approved", 102), HttpStatus.EXPECTATION_FAILED);
        }

        depositRequest.setStatus(DepositRequestStatus.DECLINED);
        depositRequest.setDeclinedBy(admin.getUserId());
        depositRequest.setDeclinedDate(LocalDateTime.now());
        merchantWithdrawalRequestRepository.save(depositRequest);
        return ResponseEntity.ok(new GenericApiResponse("Merchant Withdrawal Request Declined Successfully"));
    }
    public ResponseEntity searchMerchantWithdrawalRequestsByMerchantName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantWithdrawalRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantWithdrawalRequestRepository.findByStatusAndAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantWithdrawalRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantWithdrawalRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantWithdrawalRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantWithdrawalRequestRepository.findByAccountMerchantNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantWithdrawalRequestRepository.findByAccountMerchantNameContainingIgnoreCase(request.getSearchQuery(), pageable);
        }
        List<MerchantWithdrawalRequestResponse> responses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity searchMerchantWithdrawalRequestsByMerchantId(String merchantId,SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantWithdrawalRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_DEPOSIT_REQUEST_STATUS)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantWithdrawalRequestRepository.findByStatusAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrStatusAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),pageable);
        } else {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseOrRequestedBySurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<MerchantWithdrawalRequestResponse> responses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetMerchantWithdrawalRequestsThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantWithdrawalRequests(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findAll(pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantWithdrawalRequestsByMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByAccountMerchantId(merchantId,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsByMerchantIdAndStatus(String merchantId,DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByAccountMerchantIdAndStatus(merchantId,transactionType,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsByStatus(DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByStatus(transactionType,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllMerchantWithdrawalRequestsByAccountId(long accountId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByAccountId(accountId,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startOfDay,endOfDay,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsThisWeekAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Merchant merchant = merchantRepository.findById(merchantId).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantId,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsTodayAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startOfDay,endOfDay,merchantId,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsThisMonthAndMerchantId(String merchantId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantId,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMerchantWithdrawalRequestsFromRangeAndMerchantId(String merchantId,String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantId,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity searchMerchantWithdrawalRequestsByMerchantId(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserMerchantUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantWithdrawalRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_DEPOSIT_REQUEST_STATUS)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantWithdrawalRequestRepository.findByStatusAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrStatusAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantWithdrawalRequestRepository.findByRequestedByFirstNameContainingIgnoreCaseOrRequestedBySurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<MerchantWithdrawalRequestResponse> responses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetMyMerchantWithdrawalRequestsByMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByAccountMerchantId(merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantWithdrawalRequestsByMerchantIdAndStatus(DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByAccountMerchantIdAndStatus(merchantAdmin.getMerchant().getId(),transactionType,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantWithdrawalRequestsThisWeekAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantWithdrawalRequestsTodayAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startOfDay,endOfDay,merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantWithdrawalRequestsThisMonthAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetMyMerchantWithdrawalRequestsFromRangeAndMerchantId(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserMerchantUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndAccountMerchantId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantAdmin.getMerchant().getId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }

    public ResponseEntity searchRequestedByMerchantWithdrawalRequestsByMerchantId(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserAccountManager(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<MerchantWithdrawalRequest> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_DEPOSIT_REQUEST_STATUS)) {
            DepositRequestStatus filter = DepositRequestStatus.valueOf(request.getFilterValue());
            failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndStatusAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndStatusAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndRequestedByFirstNameContainingIgnoreCaseOrRequestedByUserIdAndRequestedBySurnameContainingIgnoreCase(merchantAdmin.getUserId(),request.getSearchQuery(),merchantAdmin.getUserId(),request.getSearchQuery(), pageable);
        }
        List<MerchantWithdrawalRequestResponse> responses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsByMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByRequestedByUserId(merchantAdmin.getUserId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsByMerchantIdAndStatus(DepositRequestStatus transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByRequestedByUserIdAndStatus(merchantAdmin.getUserId(),transactionType,pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsThisWeekAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndRequestedByUserId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),merchantAdmin.getUserId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsTodayAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndRequestedByUserId(startOfDay,endOfDay,merchantAdmin.getUserId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsThisMonthAndMerchantId(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndRequestedByUserId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),merchantAdmin.getUserId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetRequestedByMerchantWithdrawalRequestsFromRangeAndMerchantId(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserAccountManager(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        AccountManager merchantAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if(merchantAdmin==null){
            return new ResponseEntity<>(new GenericApiError("You are not allowed to perform this action",102), HttpStatus.UNAUTHORIZED);
        }
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<MerchantWithdrawalRequest> failures = merchantWithdrawalRequestRepository.findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndRequestedByUserId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),merchantAdmin.getUserId(),pageable);

        List<MerchantWithdrawalRequestResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountWithdrawalRequestResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }


    ///////////////////////////////////////////////Customer Wallets /////////////////////////////////////////////////////////////


    public ResponseEntity getAllCustomerWallets(int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<Wallet> failures = walletRepository.findAll(pageable);

        List<WalletResponse> productResponses = failures.stream().map(this::mapWalletEntityToResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(productResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getCustomerWalletById(long accountId) {

        Wallet admin = walletRepository.findById(accountId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Wallet",110), HttpStatus.NOT_FOUND);
        }
        WalletResponse response = this.mapWalletEntityToResponse(admin);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getCustomerWalletByCustomerId(String customerId) {

        Wallet admin = walletRepository.findByCustomerUserId(customerId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Wallet",110), HttpStatus.NOT_FOUND);
        }
        WalletResponse response = this.mapWalletEntityToResponse(admin);

        return   ResponseEntity.ok(response);

    }
    public ResponseEntity changeCustomerWalletStatus(long accountId, WalletStatus status, String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        Wallet merchant = walletRepository.findById(accountId).orElse(null);
        if (merchant == null) {
            return new ResponseEntity<>(new GenericApiError("could not load Wallet",110), HttpStatus.NOT_FOUND);
        }

        merchant.setStatus(status);
        walletRepository.save(merchant);

        return ResponseEntity.ok(new GenericApiResponse("Wallet status updated"));
    }
    public ResponseEntity getCustomerWalletsByStatus(WalletStatus status, int page, int size) {
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Page<Wallet> failures =  walletRepository.findByStatus(status,pageable);

        List<WalletResponse> ticketFailureResponses = failures.stream().map(this::mapWalletEntityToResponse).collect(toList());

        return  ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity getActiveCustomerWallets() {
        List<Wallet> failures =  walletRepository.findByStatus(WalletStatus.ACTIVE);

        List<WalletResponse> ticketFailureResponses = failures.stream().map(this::mapWalletEntityToResponse).collect(toList());

        return  ResponseEntity.ok(ticketFailureResponses);

    }
    public ResponseEntity searchCustomerWalletsByCustomerName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<Wallet> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_WALLET_STATUS)) {
            try {
                WalletStatus paymentStatus = WalletStatus.valueOf(request.getFilterValue());
                failures = walletRepository.findByCustomerFirstNameIgnoreCaseContainingAndStatusOrCustomerSurnameIgnoreCaseContainingAndStatus(request.getSearchQuery(), paymentStatus,request.getSearchQuery(), paymentStatus,  pageable);
            } catch (Exception e) {
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method", 110), HttpStatus.NOT_FOUND);
            }

        }else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = walletRepository.findByCustomerFirstNameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = walletRepository.findByCustomerFirstNameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = walletRepository.findByCustomerFirstNameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = walletRepository.findByCustomerFirstNameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),  pageable);
        } else {
            failures = walletRepository.findByCustomerFirstNameIgnoreCaseContainingOrCustomerSurnameIgnoreCaseContaining(request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<WalletResponse> responses = failures.stream().map(this::mapWalletEntityToResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }

    public ResponseEntity getRecentCustomerTransactions(String customerId) {

        UserCustomer customer = customerRepository.findById(customerId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        List<Transaction> transactions = transactionsRepository.findFirst10ByCustomerUserIdOrReceiverUserIdOrderByCreatedAtDesc(customer.getUserId(),customer.getUserId());
        List<TransactionResponse> productResponses = transactions.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return   ResponseEntity.ok(productResponses);

    }
    public ResponseEntity getRecentCashiersTransactions(String customerId) {

        MerchantCashier customer = cashierRepository.findById(customerId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Cashier",110), HttpStatus.NOT_FOUND);
        }
        List<Transaction> transactions = transactionsRepository.findFirst10ByCashierUserIdOrderByCreatedAtDesc(customer.getUserId());
        List<TransactionResponse> productResponses = transactions.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return   ResponseEntity.ok(productResponses);

    }
    public ResponseEntity getRecentTellerTransactions(String tellerId) {

        TellerUser customer = tellerUserRepository.findById(tellerId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Cashier",110), HttpStatus.NOT_FOUND);
        }
        List<Transaction> transactions = transactionsRepository.findFirst10ByTellerUserIdOrderByCreatedAtDesc(customer.getUserId());
        List<TransactionResponse> productResponses = transactions.stream().map(this::mapEntityToTransactionResponse).collect(toList());
        return   ResponseEntity.ok(productResponses);

    }
    public ResponseEntity getCheckCustomer(String customerId) {
        CheckCustomerResponse response = new CheckCustomerResponse();
        Wallet admin = walletRepository.findByCustomerUserId(customerId).orElse(null);
        if (admin == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Wallet",110), HttpStatus.NOT_FOUND);
        }
        UserCustomer customer = customerRepository.findById(customerId).orElse(null);
        if (customer == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Customer",110), HttpStatus.NOT_FOUND);
        }
        WalletResponse walletResponse = this.mapWalletEntityToResponse(admin);
        response.setMsisdn(customer.getMobileNumber());
        response.setId(customer.getUserId());
        response.setCurrentBalance(admin.getBalance());
        response.setWallet(walletResponse);
        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getCheckCashier(String cashierId) {
        CheckCashierResponse response = new CheckCashierResponse();

        MerchantCashier merchantCashier = cashierRepository.findById(cashierId).orElse(null);
        if (merchantCashier == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Cashier",110), HttpStatus.NOT_FOUND);
        }
        Merchant merchant = merchantCashier.getMerchantBranch().getMerchant();
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Find Merchant",110), HttpStatus.NOT_FOUND);
        }
        MerchantAccount account = merchant.getMerchantAccount();
        if(account==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Find Account",110), HttpStatus.NOT_FOUND);
        }
        double totalChangeIssued = transactionsRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(LocalDate.now().atTime(LocalTime.MIN)),java.sql.Timestamp.valueOf(LocalDate.now().atTime(LocalTime.MAX)),"SUCCESS","CHANGE",cashierId);
        response.setMsisdn(merchantCashier.getMobileNumber());
        response.setId(merchantCashier.getUserId());
        response.setCurrentBalance(account.getAccountBalance());
        response.setTotalChangeIssuedBalance(totalChangeIssued);
//        response.setWallet(walletResponse);
        return   ResponseEntity.ok(response);

    }
    public ResponseEntity getCheckTeller(String tellerId) {
        CheckTellerResponse response = new CheckTellerResponse();

        TellerUser merchantCashier = tellerUserRepository.findById(tellerId).orElse(null);
        if (merchantCashier == null) {
            return new ResponseEntity<>(new GenericApiError("Could Not Find Cashier",110), HttpStatus.NOT_FOUND);
        }

        double totalChangeIssued = transactionsRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndTellerId(java.sql.Timestamp.valueOf(LocalDate.now().atTime(LocalTime.MIN)),java.sql.Timestamp.valueOf(LocalDate.now().atTime(LocalTime.MAX)),"SUCCESS","WITHDRAWAL",tellerId);
        response.setMsisdn(merchantCashier.getMobileNumber());
        response.setId(merchantCashier.getUserId());
        response.setTotalWithdrawal(totalChangeIssued);
//        response.setWallet(walletResponse);
        return   ResponseEntity.ok(response);

    }

    public ResponseEntity searchWalletHistoriesByMerchantName(SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<WalletHistory> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            WalletHistoryType filter = WalletHistoryType.valueOf(request.getFilterValue());
            failures = walletHistoryRepository.findByHistoryTypeAndWalletCustomerFirstNameContainingIgnoreCaseOrHistoryTypeAndWalletCustomerFirstNameContainingIgnoreCase(filter,request.getSearchQuery(),filter,request.getSearchQuery(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = walletHistoryRepository.findByWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = walletHistoryRepository.findByWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = walletHistoryRepository.findByWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = walletHistoryRepository.findByWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrWalletCustomerFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = walletHistoryRepository.findByWalletCustomerFirstNameContainingIgnoreCaseOrWalletCustomerFirstNameContainingIgnoreCase(request.getSearchQuery(), request.getSearchQuery(), pageable);
        }
        List<WalletHistoryResponse> responses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity searchWalletHistoriesByCustomerId(String customerId,SearchRequest request, String loggedInUserId) {
        if (!this.isLoggedInUserBackendUser(loggedInUserId)) {
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action", 102), HttpStatus.UNAUTHORIZED);
        }

        formatUtility.validatePageNumberAndSize(request.getPage(), request.getSize());
        // Retrieve events
        Pageable pageable = PageRequest.of(request.getPage(), request.getSize(), Sort.Direction.DESC, "createdAt");
        Page<WalletHistory> failures;
        if (request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)) {
            WalletHistoryType filter = WalletHistoryType.valueOf(request.getFilterValue());
            failures = walletHistoryRepository.findByHistoryTypeAndSenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrHistoryTypeAndReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),filter,request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        }
        else if (request.getSearchFilter().equals(SearchFilter.THIS_MONTH)) {
            failures = walletHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),request.getSearchQuery(),dateUtil.getFirstDayOfThisMonth(), dateUtil.getLastDayOfThisMonth(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.THIS_WEEK)) {
            failures = walletHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),request.getSearchQuery(), dateUtil.getFirstDayOfThisWeek(), dateUtil.getLastDayOfThisWeek(),pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.TODAY)) {
            failures = walletHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX),request.getSearchQuery(), LocalDate.now().atStartOfDay(), LocalDate.now().atTime(LocalTime.MAX), pageable);
        } else if (request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)) {
            LocalDate startDate = LocalDate.parse(request.getFilterValue());
            LocalDate endDate = LocalDate.parse(request.getFilterValueMax());
            failures = walletHistoryRepository.findBySenderFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrSenderSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverFirstNameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualOrReceiverSurnameContainingIgnoreCaseAndDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX),request.getSearchQuery(),startDate.atTime(LocalTime.MIN), endDate.atTime(LocalTime.MAX), pageable);
        } else {
            failures = walletHistoryRepository.findBySenderFirstNameContainingIgnoreCaseOrSenderSurnameContainingIgnoreCaseOrReceiverFirstNameContainingIgnoreCaseOrReceiverSurnameContainingIgnoreCase(request.getSearchQuery(),request.getSearchQuery(),request.getSearchQuery(),request.getSearchQuery(), pageable);
        }
        List<WalletHistoryResponse> responses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());
        return ResponseEntity.ok(new PagedResponse<>(responses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));
    }
    public ResponseEntity GetWalletHistoriesThisWeek(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllWalletHistories(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findAll(pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllWalletHistoriesByCustomerId(String customerId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByWalletCustomerUserId(customerId,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesByCustomerIdAndStatus(String customerId,WalletHistoryType transactionType,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByWalletCustomerUserIdAndHistoryType(customerId,transactionType,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetAllWalletHistoriesByWalletId(long accountId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByWalletId(accountId,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesToday(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(startOfDay,endOfDay,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesThisMonth(int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesFromRange(String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqual(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesThisWeekAndCustomerId(String customerId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        UserCustomer merchant = customerRepository.findById(customerId).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",110), HttpStatus.NOT_FOUND);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndWalletCustomerUserId(dateUtil.getFirstDayOfThisWeek(),dateUtil.getLastDayOfThisWeek(),customerId,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesTodayAndCustomerId(String customerId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events
        LocalDate today = LocalDate.now();
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndWalletCustomerUserId(startOfDay,endOfDay,customerId,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return  ResponseEntity.ok( new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesThisMonthAndCustomerId(String customerId,int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndWalletCustomerUserId(dateUtil.getFirstDayOfThisMonth(),dateUtil.getLastDayOfThisMonth(),customerId,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return   ResponseEntity.ok(new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }
    public ResponseEntity GetWalletHistoriesFromRangeAndCustomerId(String customerId,String  startDateTimeString, String  endDateTimeString, int page, int size,String loggedInUserId) {
        if(!this.isLoggedInUserBackendUser(loggedInUserId)){
            return new ResponseEntity<>(new GenericApiError("You are not Authorised To Perform This Action",102), HttpStatus.UNAUTHORIZED);
        }
        formatUtility.validatePageNumberAndSize(page, size);
        // Retrieve events
        Pageable pageable = PageRequest.of(page, size, Sort.Direction.DESC, "createdAt");
        Boolean validationResponse =  formatUtility.isValidDate(startDateTimeString);
        if (!validationResponse) {
            return new ResponseEntity<>("Start DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        Boolean validationResponse2 =  formatUtility.isValidDate(endDateTimeString);
        if (!validationResponse2) {
            return new ResponseEntity<>("End DateTime Is Not Valid", HttpStatus.FAILED_DEPENDENCY);
        }
        LocalDate startDate = LocalDate.parse(startDateTimeString);
        LocalDate endDate = LocalDate.parse(endDateTimeString);
        // Retrieve events

        Page<WalletHistory> failures = walletHistoryRepository.findByDateOfEntryGreaterThanEqualAndDateOfEntryLessThanEqualAndWalletCustomerUserId(startDate.atTime(LocalTime.MAX),endDate.atTime(LocalTime.MAX),customerId,pageable);

        List<WalletHistoryResponse> ticketFailureResponses = failures.stream().map(this::mapEntityToAccountHistoryResponse).collect(toList());

        return ResponseEntity.ok(  new PagedResponse<>(ticketFailureResponses, failures.getNumber(),
                failures.getSize(), failures.getTotalElements(), failures.getTotalPages(), failures.isLast()));

    }


    private void processCashInSuccessCustomer(String mobileNumber, Transaction transaction){
        String smsMessage = this.processCashInSuccessMessageCustomer("CASH_IN_SUCCESS_CUSTOMER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processCashInSuccessMessageCustomer(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("cashierCode",transaction.getCashier().getCode());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private void processCashInSuccessCashier(String mobileNumber, Transaction transaction){
        String smsMessage = this.processCashInSuccessMessageCashier("CASH_IN_SUCCESS_CASHIER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processCashInSuccessMessageCashier(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("receiverPhoneNumber",transaction.getCustomer().getMobileNumber());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void processCashOutSuccessCustomer(String mobileNumber, Transaction transaction){
        String smsMessage = this.processCashOutSuccessMessageCustomer("CASH_OUT_SUCCESS_CUSTOMER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processCashOutSuccessMessageCustomer(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("cashierCode",transaction.getCashier().getCode());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void processCashOutSuccessCashier(String mobileNumber, Transaction transaction){
        String smsMessage = this.processCashOutSuccessMessageCashier("CASH_OUT_SUCCESS_CASHIER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processCashOutSuccessMessageCashier(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("receiverPhoneNumber",transaction.getCustomer().getMobileNumber());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void processPaymentSuccessCustomer(String mobileNumber, Transaction transaction){
        String smsMessage = this.processPaymentSuccessMessageCustomer("PAYMENT_SUCCESS_CUSTOMER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processPaymentSuccessMessageCustomer(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("cashierCode",transaction.getCashier().getCode());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void processPaymentSuccessCashier(String mobileNumber, Transaction transaction){
        String smsMessage = this.processPaymentSuccessMessageCashier("PAYMENT_SUCCESS_CASHIER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processPaymentSuccessMessageCashier(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("senderPhoneNumber",transaction.getCustomer().getMobileNumber());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void processTransferSuccessSender(String mobileNumber, Transaction transaction,double balance){
        String smsMessage = this.processTransferSuccessMessageSender("TRANSFER_CREDIT_SUCCESS_SENDER",transaction,balance);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processTransferSuccessMessageSender(String smsMessageCode, Transaction transaction,double balance){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("receiverPhoneNumber",transaction.getReceiver().getMobileNumber());
            values.put("balance",NumbersUtil.round(balance,2)+"");
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public void processTransferSuccessReceiver(String mobileNumber, Transaction transaction,double balance){
        String smsMessage = this.processTransferSuccessMessageReceiver("TRANSFER_CREDIT_SUCCESS_RECEIVER",transaction,balance);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processTransferSuccessMessageReceiver(String smsMessageCode, Transaction transaction,double balance){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("senderPhoneNumber",transaction.getSender().getMobileNumber());
            values.put("balance",NumbersUtil.round(balance,2)+"");
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private void processIssueChangeSuccessCustomer(String mobileNumber, Transaction transaction){
        String smsMessage = this.processIssueChangeSuccessMessage("ISSUE_CHANGE_SUCCESS",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processIssueChangeSuccessMessage(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("cashierCode",transaction.getCashier().getCode());
            values.put("code",transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private void processIssueChangeSuccessCashier(String mobileNumber, Transaction transaction){
        String smsMessage = this.processIssueChangeSuccessCashierMessage("ISSUE_CHANGE_SUCCESS_CASHIER",transaction);
        this.sendSMS(mobileNumber,smsMessage);
    }
    private String processIssueChangeSuccessCashierMessage(String smsMessageCode, Transaction transaction){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("amount", NumbersUtil.round(transaction.getAmount(),2)+"");
            values.put("currency",transaction.getCurrency().getName());
            values.put("code",transaction.getId());
            values.put("receiverPhoneNumber",transaction.getNotificationMsisdn());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private void processSuccessfulWithdrawalApproval(String emailAddress,String mobileNumber,String approvalCode,String merchantCode,String receiverName){
        String smsMessage = this.processSuccessfulWithdrawalApprovalMessage("SUCCESS_WITHDRAWAL_APPROVAL",approvalCode,merchantCode);
        this.sendSMS(mobileNumber,smsMessage);
        this.processSuccessfulWithdrawalApprovalEmail(emailAddress,approvalCode,merchantCode,receiverName);
    }
    private void processSuccessfulWithdrawalComplete(String emailAddress,String mobileNumber,String merchantCode,String receiverName,Transaction transaction){
        String smsMessage = this.processSuccessfulWithdrawalCompleteMessage("SUCCESS_WITHDRAWAL_COMPLETE",merchantCode,transaction);
        this.sendSMS(mobileNumber,smsMessage);
        this.processSuccessfulWithdrawalCompleteEmail(emailAddress,merchantCode,receiverName);
    }
    private String processSuccessfulWithdrawalCompleteMessage(String smsMessageCode,String merchantCode,Transaction transaction){

        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("merchantCode", merchantCode);
            values.put("code", transaction.getId());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Withdrawal has been approval Code is ";
        }
    }
    private String processSuccessfulWithdrawalApprovalMessage(String smsMessageCode,String approvalCode,String merchantCode){

        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("approvalCode", approvalCode);
            values.put("merchantCode", merchantCode);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "Withdrawal has been approval Code is "+ approvalCode;
        }
    }
    public void processSuccessfulWithdrawalApprovalEmail(String emailAddress,String pin,String merchantCode,String receiverName){
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(emailAddress);//replace with your desired email
        mail.setSubject("Your ChangeMoney Withdrawal is ready!");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Your ChangeMoney Withdrawal is ready!");
        model.put("pin",pin);
        model.put("merchantCode",merchantCode);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );

        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
        model.put("supportEmail", appVariableRepository.findByCodeAndActive("SUPPORT_EMAIL", true).getValue());
        model.put("receiverName",receiverName);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"withdrawal_code",1);
    }
    public void processSuccessfulWithdrawalCompleteEmail(String emailAddress,String merchantCode,String receiverName){
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(emailAddress);//replace with your desired email
        mail.setSubject("Your ChangeMoney Withdrawal is Complete!");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Your ChangeMoney Withdrawal is Complete!");
        model.put("merchantCode",merchantCode);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue());

        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
        model.put("supportEmail", appVariableRepository.findByCodeAndActive("SUPPORT_EMAIL", true).getValue());
        model.put("receiverName",receiverName);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"withdrawal_complete",1);
    }
    private void sendSMS(String mobileNumber, String smsMessage){
        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
    }
    public WalletResponse mapWalletEntityToResponse(Wallet transaction){
        WalletResponse response = new WalletResponse();
        response.setBalance(transaction.getBalance());
        response.setStatus(transaction.getStatus());
        response.setEcocashAccount(transaction.getEcocashAccount());
        response.setTelecashAccount(transaction.getTelecashAccount());
        response.setOneMoneyAccount(transaction.getOneMoneyAccount());
        response.setId(transaction.getId());
        if(transaction.getCustomer()!=null){
            response.setCustomer(userService.mapCustomerEntityToResponse(transaction.getCustomer()));
        }
        return  response;
    }
    public WalletHistoryResponse mapEntityToAccountHistoryResponse(WalletHistory merchantAccount){
        WalletHistoryResponse response = new WalletHistoryResponse();
        response.setId(merchantAccount.getId());
        if(merchantAccount.getWallet()!=null){
            response.setWallet(this.mapWalletEntityToResponse(merchantAccount.getWallet()));
        }
        if(merchantAccount.getReceiver()!=null){
            response.setReceiver(authenticationService.mapUserEntityToSpecificSummary(merchantAccount.getReceiver()));
        }
        if(merchantAccount.getSender()!=null){
            response.setSender(authenticationService.mapUserEntityToSpecificSummary(merchantAccount.getSender()));
        }
        if(merchantAccount.getHistoryType()!=null){
            response.setTransactionType(merchantAccount.getHistoryType());
        }
        response.setBalanceAfter(merchantAccount.getBalanceAfter());
        response.setAmount(merchantAccount.getAmount());
        response.setBalanceBefore(merchantAccount.getBalanceBefore());
        if(merchantAccount.getDateOfEntry()!=null){
            response.setDateOfEntry(merchantAccount.getDateOfEntry().toString());
        }

        return response;
    }
    private CheckTransactionStatusResponse mapCheckTransactionStatusResponse(Transaction transaction){
       CheckTransactionStatusResponse response = new CheckTransactionStatusResponse();
       response.setReference(transaction.getId());
       response.setStatus(transaction.getStatus());
       response.setTransactionType(transaction.getTransactionType());
       response.setAmount(transaction.getAmount());
       if(transaction.getCustomer()!=null){
           response.setCustomer(userService.mapCustomerEntityToResponse(transaction.getCustomer()));
       }
       return  response;
   }
    public TransactionResponse mapEntityToTransactionResponse(Transaction paymentRequest){
        TransactionResponse paymentRequestResponse = new TransactionResponse();
        if(paymentRequest.getCustomer()!=null){
            paymentRequestResponse.setCustomer(userService.mapCustomerEntityToResponse(paymentRequest.getCustomer()));
        }
        if(paymentRequest.getTeller()!=null){
            paymentRequestResponse.setTeller(userService.mapTellerEntityToResponse(paymentRequest.getTeller()));
        }
        if(paymentRequest.getReceiver()!=null){
            paymentRequestResponse.setReceiver(userService.mapCustomerEntityToResponse(paymentRequest.getReceiver()));
        }
        paymentRequestResponse.setId(paymentRequest.getId());
        paymentRequestResponse.setAmount(paymentRequest.getAmount());
        paymentRequestResponse.setAmountInUsd(paymentRequest.getAmountInUsd());
        if(paymentRequest.getCurrency()!=null){
            paymentRequestResponse.setCurrency(currencyService.mapEntityToCurrencyResponse(paymentRequest.getCurrency()));
        }
        paymentRequestResponse.setDestinationAccount(paymentRequest.getDestinationAccount());
        paymentRequestResponse.setBaseExchangeRateUsed(paymentRequest.getBaseExchangeRateUsed());
        paymentRequestResponse.setMerchantIncentiveUsed(paymentRequest.getMerchantIncentiveUsed());
        paymentRequestResponse.setTotalExchangeRateUsed(paymentRequest.getTotalExchangeRateUsed());
        if(paymentRequest.getFinancialInstitution()!=null){
            paymentRequestResponse.setFinancialInstitution(financialInstitutionService.mapEntityToFinancialInstitutionResponse(paymentRequest.getFinancialInstitution()));
        }
        if(paymentRequest.getMerchant()!=null){
            paymentRequestResponse.setMerchant(merchantService.mapEntityToMerchantResponse(paymentRequest.getMerchant()));
        }
        paymentRequestResponse.setTransactionType(paymentRequest.getTransactionType());
        paymentRequestResponse.setTransactionCharge(paymentRequest.getTransactionCharge());
        paymentRequestResponse.setTransactionChargeInUsd(paymentRequest.getTransactionChargeInUsd());
        paymentRequestResponse.setRequiredChange(paymentRequest.getRequiredChange());
        paymentRequestResponse.setRequiredChangeInUsd(paymentRequest.getRequiredChangeInUsd());
        paymentRequestResponse.setChangeAlreadyIssued(paymentRequest.getChangeAlreadyIssued());
        paymentRequestResponse.setChangeAlreadyIssuedInUsd(paymentRequest.getChangeAlreadyIssuedInUsd());
        if(paymentRequest.getMerchantBranch()!=null){
            paymentRequestResponse.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(paymentRequest.getMerchantBranch()));
        };
        paymentRequestResponse.setNotificationMsisdn(paymentRequest.getNotificationMsisdn());
        paymentRequestResponse.setStatus(paymentRequest.getStatus());
        if(paymentRequest.getCashier()!=null){
            paymentRequestResponse.setCashier(userService.mapMerchantCashierEntityToResponse(paymentRequest.getCashier()));
        }


        if(paymentRequest.getCreatedAt()!=null){
            paymentRequestResponse.setDateOfTransaction(paymentRequest.getCreatedAt().toString());
        }


        return  paymentRequestResponse;
    }
    public MerchantWithdrawalRequestResponse mapEntityToAccountWithdrawalRequestResponse(MerchantWithdrawalRequest merchantAccount){
        MerchantWithdrawalRequestResponse response = new MerchantWithdrawalRequestResponse();
        response.setId(merchantAccount.getId());
        response.setApprovalCode(merchantAccount.getApprovalCode());
        if(merchantAccount.getAccount()!=null){
            response.setAccount(accountsService.mapEntityToAccountResponse(merchantAccount.getAccount()));
        }
        if(merchantAccount.getApprovedBy()!=null){
            User user = userRepository.findById(merchantAccount.getApprovedBy()).orElse(null);
            if(user!=null){
                response.setApprovedBy(authenticationService.mapUserEntityToSpecificSummary(user));
            }
        }
        if(merchantAccount.getCompletedBy()!=null){
            User user = userRepository.findById(merchantAccount.getApprovedBy()).orElse(null);
            if(user!=null){
                response.setCompletedBy(authenticationService.mapUserEntityToSpecificSummary(user));
            }
        }
        if(merchantAccount.getDeclinedBy()!=null){
            User user = userRepository.findById(merchantAccount.getDeclinedBy()).orElse(null);
            if(user!=null){
                response.setDeclinedBy(authenticationService.mapUserEntityToSpecificSummary(user));
            }
        }
        if(merchantAccount.getRequestedBy()!=null){
            response.setRequestedBy(userService.mapMerchantUserEntityToResponse(merchantAccount.getRequestedBy()));
        }
        if(merchantAccount.getStatus()!=null){
            response.setStatus(merchantAccount.getStatus());
        }
        response.setAmount(merchantAccount.getAmount());
        if(merchantAccount.getCreatedAt()!=null){
            response.setDateOfEntry(merchantAccount.getCreatedAt().toString());
        }
        if(merchantAccount.getApprovedDate()!=null){
            response.setApprovedDate(merchantAccount.getApprovedDate().toString());
        }
        if(merchantAccount.getDeclinedDate()!=null){
            response.setDeclinedDate(merchantAccount.getDeclinedDate().toString());
        }
        if(merchantAccount.getCompletedDate()!=null){
            response.setCompletedDate(merchantAccount.getCompletedDate().toString());
        }
        return response;
    }
    private boolean isLoggedInUserBackendUser(String loggedInUserId){
        UserBackendAdmin backendAdmin = userBackendAdminRepository.findById(loggedInUserId).orElse(null);
        UserBackendAgent agent = userBackendAgentRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null && agent==null) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantUser(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantAdmin(String loggedInUserId){
        MerchantAdmin backendAdmin = merchantAdminRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserTellerUser(String loggedInUserId){
        TellerUser backendAdmin = tellerUserRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserBranchManager(String loggedInUserId){
        BranchManager backendAdmin = branchManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserMerchantCashier(String loggedInUserId){
        MerchantCashier backendAdmin = cashierRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }
    private boolean isLoggedInUserAccountManager(String loggedInUserId){
        AccountManager backendAdmin = accountManagerRepository.findById(loggedInUserId).orElse(null);
        if (backendAdmin == null ) {
            return false;
        }else{
            return  true;
        }
    }

}
