package zw.co.change.money.app.util.dates;

import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.*;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class DateUtil {
    private final static ZoneId TZ = ZoneId.of("Africa/Harare");
    public LocalDateTime getFirstDayOfThisWeekTime(){
        DayOfWeek firstDayOfWeek = WeekFields.of(Locale.US).getFirstDayOfWeek();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay.with(TemporalAdjusters.previousOrSame(firstDayOfWeek));
    }
    public LocalDateTime getLastDayOfThisWeekTime(){
        DayOfWeek firstDayOfWeek = WeekFields.of(Locale.US).getFirstDayOfWeek();
        DayOfWeek  lastDayOfWeek = DayOfWeek.of(((firstDayOfWeek.getValue() + 5) % DayOfWeek.values().length) + 1);
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.with(TemporalAdjusters.nextOrSame(lastDayOfWeek));
    }
    public LocalDateTime getFirstDayOfThisMonthTime(){
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay
                .with( TemporalAdjusters.firstDayOfMonth() );
    }
    public LocalDateTime getLastDayOfThisMonthTime(){
        ValueRange range = LocalDate.now().range(ChronoField.DAY_OF_MONTH);
        Long max = range.getMaximum();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.withDayOfMonth(max.intValue());

    }
    public LocalDateTime getFirstDayOfThisYearTime(){
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay
                .with( TemporalAdjusters.firstDayOfYear());
    }
    public LocalDateTime getLastDayOfThisYearTime(){
        ValueRange range = LocalDate.now().range(ChronoField.DAY_OF_YEAR);
        Long max = range.getMaximum();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.withDayOfYear(max.intValue());

    }

    public LocalDateTime getFirstDayOfThisWeek(){
        DayOfWeek firstDayOfWeek = WeekFields.of(Locale.US).getFirstDayOfWeek();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay.with(TemporalAdjusters.previousOrSame(firstDayOfWeek));
    }
    public LocalDateTime getLastDayOfThisWeek(){
        DayOfWeek  firstDayOfWeek = WeekFields.of(Locale.US).getFirstDayOfWeek();
        DayOfWeek  lastDayOfWeek = DayOfWeek.of(((firstDayOfWeek.getValue() + 5) % DayOfWeek.values().length) + 1);
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.with(TemporalAdjusters.nextOrSame(lastDayOfWeek));
    }
    public LocalDateTime getFirstDayOfThisMonth(){
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay
                .with( TemporalAdjusters.firstDayOfMonth() );
    }
    public LocalDateTime getLastDayOfThisMonth(){
        ValueRange range = LocalDate.now().range(ChronoField.DAY_OF_MONTH);
        Long max = range.getMaximum();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.withDayOfMonth(max.intValue());

    }
    public LocalDate getFirstDateOfThisWeek(){
        DayOfWeek firstDayOfWeek = WeekFields.of(Locale.US).getFirstDayOfWeek();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay.with(TemporalAdjusters.previousOrSame(firstDayOfWeek)).toLocalDate();
    }
    public LocalDate getLastDateOfThisMonth(){
        ValueRange range = LocalDate.now().range(ChronoField.DAY_OF_MONTH);
        Long max = range.getMaximum();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.withDayOfMonth(max.intValue()).toLocalDate();

    }
    public LocalDate getLastDateOfThisWeek(){
        DayOfWeek  firstDayOfWeek = WeekFields.of(Locale.US).getFirstDayOfWeek();
        DayOfWeek  lastDayOfWeek = DayOfWeek.of(((firstDayOfWeek.getValue() + 5) % DayOfWeek.values().length) + 1);
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.with(TemporalAdjusters.nextOrSame(lastDayOfWeek)).toLocalDate();
    }
    public LocalDate getFirstDateOfThisMonth(){
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay
                .with( TemporalAdjusters.firstDayOfMonth() ).toLocalDate();
    }
    public LocalDateTime getFirstDayOfThisYear(){
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        return startOfDay
                .with( TemporalAdjusters.firstDayOfYear());
    }
    public LocalDateTime getLastDayOfThisYear() {
        ValueRange range = LocalDate.now().range(ChronoField.DAY_OF_YEAR);
        Long max = range.getMaximum();
        LocalDate today = LocalDate.now(TZ);
        LocalDateTime startOfDay = today.atStartOfDay();
        LocalDateTime endOfDay = startOfDay
                .toLocalDate().atTime(LocalTime.MAX);
        return endOfDay.withDayOfYear(max.intValue());
    }
        public static List<LocalDate> getDatesBetween(LocalDate startDate, LocalDate endDate) {

        long numOfDaysBetween = ChronoUnit.DAYS.between(startDate, endDate);
        return IntStream.iterate(0, i -> i + 1)
                .limit(numOfDaysBetween)
                .mapToObj(i -> startDate.plusDays(i))
                .collect(Collectors.toList());
    }
    public static List<LocalDateTime> getDaysBetween(LocalDateTime startDate, LocalDateTime endDate) {

        long numOfDaysBetween = ChronoUnit.DAYS.between(startDate, endDate);
        return IntStream.iterate(0, i -> i + 1)
                .limit(numOfDaysBetween)
                .mapToObj(i -> startDate.plusDays(i))
                .collect(Collectors.toList());
    }
    public static String getDayofTheWeek(LocalDate date) {
        DayOfWeek day = date.getDayOfWeek();
        return day.getDisplayName(TextStyle.FULL, Locale.US);
    }
    public  static  String getMonthName(int month){
        String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"};
        return monthNames[month-1];
    }
    public  String getFormattedDate(LocalDate date){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEE, d MMM yyyy");
        String formattedString = date.format(formatter);
        return formattedString;

    }
    public LocalDateTime getLastDayOfMonth(int year,int month){
        return  LocalDate.of(year,month,1)
                .with(TemporalAdjusters.lastDayOfMonth()).atTime(LocalTime.MAX);
    }
    public LocalDateTime getFirstDayOfMonth(int year,int month){
        return  LocalDate.of(year,month,1)
                .with(TemporalAdjusters.firstDayOfMonth()).atTime(LocalTime.MIN);
    }
}
