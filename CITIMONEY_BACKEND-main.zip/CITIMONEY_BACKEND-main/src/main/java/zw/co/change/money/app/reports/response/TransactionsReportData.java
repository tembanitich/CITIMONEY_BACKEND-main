package zw.co.change.money.app.reports.response;


import lombok.Data;


import java.time.LocalDateTime;

@Data
public class TransactionsReportData {
    private String id;
    private double amount;
    private double amountInUsd;
    private double baseExchangeRateUsed;
    private double merchantIncentiveUsed;
    private double totalExchangeRateUsed;
    private String destinationAccount;
    private String senderAccount;
    private String currency;
    private LocalDateTime date;
    private String transactionType;
    private String status;

}
