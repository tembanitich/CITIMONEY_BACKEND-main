package zw.co.change.money.app.reports.response;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class CustomerWalletReportData {
    private Long id;
    private double balanceBefore;
    private double amount;
    private String receiver;
    private String sender;
    private String historyType;
    private double balanceAfter;
    private LocalDateTime dateOfEntry;
}
