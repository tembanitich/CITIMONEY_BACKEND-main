package zw.co.change.money.app.merchants.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.documents.model.MerchantProofOfResidenceDocument;
import zw.co.change.money.app.documents.model.MerchantTaxClearanceDocument;
import zw.co.change.money.app.users.model.MerchantAdmin;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;
import java.util.Set;

@Entity
@EqualsAndHashCode(callSuper = true,exclude = {"merchantAccount","proofOfResidence","taxclearence","merchantAdmins"})
@Data
public class Merchant extends UserDateAudit {
    @Id
    private String id;
    private String name;
    private String code;
    private String tradingAs;
    private String companyRegNumber;
    private String officeAddress;
    private String contactPersonName;
    private String contactPersonSurname;
    private String contactPersonNumber;
    private String contactPersonEmail;
    private String withdrawalEmail;
    private String withdrawalPhoneNumber;
    private String contactPersonDesignation;
    private double minFloatLimit;
    private int numberOfBranches;
    private int projectedCashiers;
    private int projectedAdmins;
    private double projectedDailyFloatBalance;
    private double projectedNumberOfProducts;
    private boolean active;
    @OneToOne(fetch = FetchType.LAZY, optional = true)
    @JoinColumn(name = "merchantAccount", nullable = true)
    private MerchantAccount merchantAccount;
    @OneToMany(mappedBy="merchant")
    private Set<MerchantAdmin> merchantAdmins;

    @OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "merchant")
    private MerchantProofOfResidenceDocument proofOfResidence;
    @OneToOne(fetch = FetchType.LAZY,
            cascade =  CascadeType.ALL,
            mappedBy = "merchant")
    private MerchantTaxClearanceDocument taxclearence;
}
