package zw.co.change.money.app.chat.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import zw.co.change.money.app.chat.model.ChatMessage;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    Page<ChatMessage> findByCustomerUserId(String userId,Pageable pageable);
    List<ChatMessage> findByCustomerUserId(String userId);
    @Query(value ="select po.client from chat_message po group by po.client", nativeQuery = true)
    List<String> getCustomers();
}
