package zw.co.change.money.app.authentication.service;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.authentication.repository.RegistrationOtpRepository;
import zw.co.change.money.app.authentication.request.*;
import zw.co.change.money.app.authentication.response.JwtAuthenticationResponse;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.legacy.response.PageResponseDto;
import zw.co.change.money.app.legacy.response.ResponseDto;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.transactions.model.Wallet;
import zw.co.change.money.app.transactions.model.WalletStatus;
import zw.co.change.money.app.transactions.repository.WalletRepository;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.aop.annotation.AuditTrail;
import zw.co.change.money.app.authentication.model.RegistrationOtp;
import zw.co.change.money.app.notifications.sms.executors.SmsExecutor;
import zw.co.change.money.app.security.jwt.JwtTokenProvider;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.roles.response.PermissionResponse;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.variables.model.AppVariable;
import zw.co.change.money.app.variables.repository.EmailConfigRepository;
import zw.co.change.money.app.notifications.mail.executor.MailExecutor;
import zw.co.change.money.app.notifications.mail.request.Mail;
import zw.co.change.money.app.security.roles.model.Permission;
import zw.co.change.money.app.security.roles.repository.PermissionRepository;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.security.roles.response.PrivilegeResponse;
import zw.co.change.money.app.security.roles.response.RoleResponse;
import zw.co.change.money.app.util.encoders.EncodeDecodeUtility;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.validation.ValidateUserProperties;
import zw.co.change.money.app.variables.model.EmailConfig;
import zw.co.change.money.app.variables.model.SmsConfig;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

import static java.util.stream.Collectors.toList;

@Service
public class AuthenticationService {

    @Autowired
    RegistrationOtpRepository registrationOtpRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    UserBrandAmbassadorRepository userBrandAmbassadorRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    MerchantCashierRepository merchantCashierRepository;

    @Autowired
    TellerUserRepository tellerUserRepository;
    @Autowired
    UserSystemAdminRepository userSystemAdminRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    AuthenticationManager authenticationManager;
    @Autowired
    JwtTokenProvider tokenProvider;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    EmailConfigRepository emailConfigRepository;
    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    EncodeDecodeUtility encodeDecodeUtility;
    @Autowired
    MailExecutor mailExecutor;
    @Autowired
    FormatUtility formatUtility;
    @Autowired
    private WalletRepository walletRepository;
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    PermissionRepository permissionRepository;
    @Autowired
    SmsExecutor smsExecutor;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    ValidateUserProperties validateUserProperties;
    @Autowired
    UserService userService;
    @Autowired
    MerchantService merchantService;
    public ResponseEntity Login(LoginRequest loginRequest) {

        String decodedPassword = encodeDecodeUtility.ThreefoldBase64Decode(loginRequest.getPassword());

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getMobileNumberOrEmail(), decodedPassword));
        SecurityContextHolder.getContext().setAuthentication(authentication);


        User theUser = userRepository.findByUsernameOrEmail(loginRequest.getMobileNumberOrEmail(), loginRequest.getMobileNumberOrEmail()).orElse(null);
        if(theUser==null){
            JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
            myAuthResponse.setMessage("Something's happened!");
            return new ResponseEntity<>(myAuthResponse, HttpStatus.EXPECTATION_FAILED);
        }


        UserCustomer userCustomer =userCustomerRepository.findById(theUser.getUserId()).orElse(null);

        if(userCustomer!=null){
            if(!userCustomer.getVerified()){
                RegistrationOtp registrationOtp = registrationOtpRepository.findByUserId(userCustomer.getUserId()).orElse(null);
                if(registrationOtp==null){

                }else{
                    userService.sendSuccessfulRegistrationSMSWithOTP(userCustomer.getMobileNumber(),registrationOtp.getOtp(),registrationOtp.getAppSignature());
                }

            }
        }
        if (theUser.getEnabled()) {
            String jwt = tokenProvider.generateToken(authentication);
            UserSummary summary = this.mapUserEntityToSpecificSummary(theUser);
            if(summary==null){
                return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
            }
            summary.setAccessToken("Bearer " + jwt);
            theUser.setLoginChannel(loginRequest.getChannel());
            theUser.setLoginCount(theUser.getLoginCount()+1);
            theUser.setLastLogin(LocalDateTime.now());
            userRepository.save(theUser);
            return ResponseEntity.ok(summary);
        }


        JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
        myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
        return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
    }

    public ResponseEntity LoginLegacy(String username, String decodedPassword ) {


        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, decodedPassword));
        SecurityContextHolder.getContext().setAuthentication(authentication);


        User theUser = userRepository.findByUsernameOrEmail(username,username).orElse(null);
        if(theUser==null){
            JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
            myAuthResponse.setMessage("Something's happened!");
            return new ResponseEntity<>(myAuthResponse, HttpStatus.EXPECTATION_FAILED);
        }


        UserCustomer userCustomer =userCustomerRepository.findById(theUser.getUserId()).orElse(null);

        if(userCustomer!=null){
            if(!userCustomer.getVerified()){
                RegistrationOtp registrationOtp = registrationOtpRepository.findByUserId(userCustomer.getUserId()).orElse(null);
                if(registrationOtp==null){

                }else{
                    userService.sendSuccessfulRegistrationSMSWithOTP(userCustomer.getMobileNumber(),registrationOtp.getOtp(),registrationOtp.getAppSignature());
                }

            }
        }
        if (theUser.getEnabled()) {
            String jwt = tokenProvider.generateToken(authentication);
            UserSummary summary = this.mapUserEntityToSpecificSummary(theUser);
            if(summary==null){
                return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
            }
            summary.setAccessToken("Bearer " + jwt);
            theUser.setLoginChannel("WEB");
            theUser.setLoginCount(theUser.getLoginCount()+1);
            theUser.setLastLogin(LocalDateTime.now());
            userRepository.save(theUser);
            return ResponseEntity.ok(summary);
        }


        JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
        myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
        return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
    }
    public ResponseEntity resetPasswordWithBothEmailAndMobileNumber(ResetPasswordRequest request){
        User theUser = userRepository.findById(request.getUserId()).orElse(null);
        if(theUser==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load User",110), HttpStatus.NOT_FOUND);
        }
        String pin = RandomStringUtils.random(6,false,true);
        theUser.setPassword(passwordEncoder.encode(pin));
        theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        theUser.setResetPin(true);
        userRepository.save(theUser);
        MerchantAdmin merchantAdmin = merchantAdminRepository.findById(request.getUserId()).orElse(null);
        MerchantCashier merchantCashier = merchantCashierRepository.findById(request.getUserId()).orElse(null);
        AccountManager accountManager = accountManagerRepository.findById(request.getUserId()).orElse(null);
        BranchManager branchManager = branchManagerRepository.findById(request.getUserId()).orElse(null);
        if(merchantAdmin !=null){
                RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(merchantAdmin.getUserId()).orElse(null);
                if(oldOtp!=null){
                    registrationOtpRepository.delete(oldOtp);
                }
                RegistrationOtp registrationOtp = new RegistrationOtp();
                registrationOtp.setOtp(pin);
                registrationOtp.setUserId(merchantAdmin.getUserId());
                registrationOtpRepository.save(registrationOtp);
                String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
                String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
                this.processResetPasswordNotificationsForClient(merchantAdmin.getEmail().toLowerCase(),emailMessage, merchantAdmin.getContactMobileNumber(),smsMessage);
                return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }
        if(merchantCashier!=null){
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(merchantCashier.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(merchantCashier.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
            this.processResetPasswordNotificationsForClient(merchantCashier.getEmail().toLowerCase(),emailMessage,merchantCashier.getMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }
        if(accountManager!=null){
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(accountManager.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(accountManager.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
            this.processResetPasswordNotificationsForClient(accountManager.getEmail().toLowerCase(),emailMessage,accountManager.getContactMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }
        if(branchManager!=null){
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(branchManager.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(branchManager.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
            this.processResetPasswordNotificationsForClient(branchManager.getEmail().toLowerCase(),emailMessage,branchManager.getContactMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }else{

            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            this.processResetPasswordNotifications(theUser.getEmail().toLowerCase(),pin,theUser.getFirstName()+" "+theUser.getSurname());
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }

    }
    public ResponseEntity resetPasswordWithEmail(String email){
        if(!formatUtility.isValidEmail(email)){
            return new ResponseEntity<>(new GenericApiError("Invalid Email",106), HttpStatus.EXPECTATION_FAILED);
        }
        User theUser = userRepository.findByEmail(email).orElse(null);
        if(theUser==null){
            return new ResponseEntity<>(new GenericApiError("Email is not registered on this platform",110), HttpStatus.EXPECTATION_FAILED);
        }
        String pin = RandomStringUtils.random(4,true,false)+RandomStringUtils.random(1,true,false).toUpperCase() +"@changemoney"+ LocalDate.now().getYear();
        theUser.setPassword(passwordEncoder.encode(pin));
        theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        theUser.setResetPin(true);
        userRepository.save(theUser);
        String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
        this.processResetPasswordNotifications(theUser.getEmail().toLowerCase(),pin,theUser.getFirstName()+" "+theUser.getSurname());
        return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
    }
    public ResponseEntity cashierResetPasswordWithMobileNumber(String email){
        if(!formatUtility.isValidPhoneNumber(email)){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",106), HttpStatus.EXPECTATION_FAILED);
        }
        MerchantCashier theUser = merchantCashierRepository.findByMobileNumber(email).orElse(null);
        if(theUser==null){
            return new ResponseEntity<>(new GenericApiError("Cashier Mobile Number is not registered on this platform",110), HttpStatus.EXPECTATION_FAILED);
        }
        String pin = RandomStringUtils.random(6,false,true);
        theUser.setPassword(passwordEncoder.encode(pin));
        theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        theUser.setResetPin(true);
        merchantCashierRepository.save(theUser);
        String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
        this.sendSMS(theUser.getMobileNumber(),emailMessage);
        return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
    }
    public ResponseEntity resetPasswordWithMobileNumber(ResetPasswordRequest request){
        if(!formatUtility.isValidPhoneNumber(request.getMobileNumber())){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",107), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        MerchantCashier cashier = merchantCashierRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        TellerUser tellerUser = tellerUserRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        if(customer==null &&cashier==null&&tellerUser==null){
            return new ResponseEntity<>(new GenericApiError("Mobile Number is not registered on this platform",110), HttpStatus.NOT_FOUND);
        }
        if(customer!=null){
            String pin = RandomStringUtils.random(6,false,true);

//            customer.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            customer.setResetPin(true);
            userRepository.save(customer);
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(customer.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(customer.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
            this.processResetPasswordNotificationsForClient(customer.getEmail(),emailMessage,customer.getMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }
        if(cashier!=null){
            String pin = RandomStringUtils.random(6,false,true);

//            customer.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            cashier.setResetPin(true);
            userRepository.save(cashier);
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(cashier.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(cashier.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
            this.processResetPasswordNotificationsForClient(cashier.getEmail(),emailMessage,cashier.getMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }
        if(tellerUser!=null){
            String pin = RandomStringUtils.random(6,false,true);

//            customer.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            tellerUser.setResetPin(true);
            userRepository.save(tellerUser);
            RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(tellerUser.getUserId()).orElse(null);
            if(oldOtp!=null){
                registrationOtpRepository.delete(oldOtp);
            }
            RegistrationOtp registrationOtp = new RegistrationOtp();
            registrationOtp.setOtp(pin);
            registrationOtp.setUserId(tellerUser.getUserId());
            registrationOtpRepository.save(registrationOtp);
            String emailMessage = this.processResetPasswordEmailMessage("RESET_PIN",pin);
            String smsMessage = this.processResetPasswordSMSMessage("RESET_PIN",pin,request.getAppSignature());
            this.processResetPasswordNotificationsForClient(tellerUser.getEmail(),emailMessage,tellerUser.getMobileNumber(),smsMessage);
            return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));
        }
        return ResponseEntity.ok(new GenericApiResponse("Password Reset Successfully"));

    }
    public  ResponseEntity customerSignUp(CustomerSignUpRequest request){

        ResponseEntity theResponse = validateUserProperties.isValidSignUpCustomerRequest(request);
        if (theResponse.getStatusCode().value() != 200) {
            return theResponse;
        }
        Role role = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("could not load users Role",110), HttpStatus.NOT_FOUND);
        }
        String decodedPassword = encodeDecodeUtility.ThreefoldBase64Decode(request.getPassword());
        UserCustomer admin = new UserCustomer();
        admin.setFirstName(request.getFirstName());
        admin.setSurname(request.getSurname());
        admin.setMobileNumber(request.getMobileNumber());
        admin.setMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setContactMobileNumber(request.getMobileNumber());
        admin.setContactMobileNumberCountryCode(request.getMobileNumberCountryCode());
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
        admin.setResetPin(false);
        admin.setFirstTime(true);
        admin.setPassword(passwordEncoder.encode(decodedPassword));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(request.getMobileNumber());
        UserCustomer savedAdmin =userCustomerRepository.save(admin);
        Wallet wallet = new Wallet();
        wallet.setCustomer(savedAdmin);
        wallet.setBalance(0D);
        wallet.setStatus(WalletStatus.ACTIVE);
        Wallet savedWallet =walletRepository.save(wallet);
        savedAdmin.setWallet(savedWallet);
        userCustomerRepository.save(savedAdmin);
        //////////////////////assign Permissions////////////////////////
        userService.assignPermissionsByRoleToUser(RoleName.ROLE_CUSTOMER,savedAdmin);
        //send Email with Pin
        ////////////////////////////////create OTP/////////////////////
        String otp = RandomStringUtils.random(6,false,true);
        RegistrationOtp oldOtp = registrationOtpRepository.findByUserId(savedAdmin.getUserId()).orElse(null);
        if(oldOtp!=null){
            registrationOtpRepository.delete(oldOtp);
        }
        RegistrationOtp registrationOtp = new RegistrationOtp();
        registrationOtp.setOtp(otp);
        registrationOtp.setAppSignature(request.getAppSignature());
        registrationOtp.setUserId(savedAdmin.getUserId());
        registrationOtpRepository.save(registrationOtp);
        //send Email with Pin

        userService.sendSuccessfulRegistrationSMSWithOTP(admin.getMobileNumber(),otp,request.getAppSignature());
        if(savedAdmin.getEmail()!=null&& !savedAdmin.getEmail().toLowerCase().isEmpty()){
            userService.sendSuccessfulRegistrationEmailWithOTP(savedAdmin.getEmail().toLowerCase(),otp);
        }


        return ResponseEntity.ok(new GenericApiResponse("Customer Created Successfully"));

    }
    public ResponseEntity confirmOTP(String mobileNumber, String otp){
        if(!formatUtility.isValidPhoneNumber(mobileNumber)){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(otp==null || otp.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("OTP cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(mobileNumber).orElse(null);
        MerchantCashier cashier = merchantCashierRepository.findByMobileNumber(mobileNumber).orElse(null);
        TellerUser tellerUser = tellerUserRepository.findByMobileNumber(mobileNumber).orElse(null);
        if(customer==null&&cashier==null&&tellerUser==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load Customer",110), HttpStatus.NOT_FOUND);
        }
        RegistrationOtp registrationOtp = registrationOtpRepository.findByOtp(otp).orElse(null);
        if(registrationOtp==null){
            return new ResponseEntity<>(new GenericApiError("Invalid OTP",127), HttpStatus.EXPECTATION_FAILED);
        }
        if(customer!=null){
            if (customer.getEnabled()) {
                String jwt = tokenProvider.generateTokenWithUser(customer);
                UserSummary summary = this.mapUserEntityToSpecificSummary(customer);
                if(summary==null){
                    return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
                }
                summary.setAccessToken("Bearer " + jwt);
                customer.setLoginChannel("MOBILE");
                customer.setLoginCount(customer.getLoginCount()+1);
                customer.setLastLogin(LocalDateTime.now());
                customer.setVerified(true);
                userRepository.save(customer);
                //send Successfully Registered SMS to Customer
                //send Email with Pin

                userService.sendCustomerSuccessfulRegistrationSMS(customer);
                registrationOtpRepository.delete(registrationOtp);
                return ResponseEntity.ok(summary);
            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }else if(tellerUser!=null){

            if (tellerUser.getEnabled()) {
                String jwt = tokenProvider.generateTokenWithUser(tellerUser);
                UserSummary summary = this.mapUserEntityToSpecificSummary(tellerUser);
                if(summary==null){
                    return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
                }
                summary.setAccessToken("Bearer " + jwt);
                tellerUser.setLoginChannel("MOBILE");
                tellerUser.setLoginCount(tellerUser.getLoginCount()+1);
                tellerUser.setLastLogin(LocalDateTime.now());

                userRepository.save(tellerUser);
                //send Successfully Registered SMS to Customer
                //send Email with Pin

//                userService.sendCustomerSuccessfulRegistrationSMS(cashier);
                registrationOtpRepository.delete(registrationOtp);
                return ResponseEntity.ok(summary);
            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }else{

            if (cashier.getEnabled()) {
                String jwt = tokenProvider.generateTokenWithUser(cashier);
                UserSummary summary = this.mapUserEntityToSpecificSummary(cashier);
                if(summary==null){
                    return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
                }
                summary.setAccessToken("Bearer " + jwt);
                cashier.setLoginChannel("MOBILE");
                cashier.setLoginCount(cashier.getLoginCount()+1);
                cashier.setLastLogin(LocalDateTime.now());

                userRepository.save(cashier);
                //send Successfully Registered SMS to Customer
                //send Email with Pin

//                userService.sendCustomerSuccessfulRegistrationSMS(cashier);
                registrationOtpRepository.delete(registrationOtp);
                return ResponseEntity.ok(summary);
            }else{
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }


    }
    public ResponseEntity confirmOTPResetPassword(String mobileNumber, String otp){
        if(!formatUtility.isValidPhoneNumber(mobileNumber)){
            return new ResponseEntity<>(new GenericApiError("Invalid Mobile Number",107), HttpStatus.EXPECTATION_FAILED);
        }
        if(otp==null || otp.isEmpty()){
            return new ResponseEntity<>(new GenericApiError("OTP cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        UserCustomer customer = userCustomerRepository.findByMobileNumber(mobileNumber).orElse(null);
        MerchantCashier cashier = merchantCashierRepository.findByMobileNumber(mobileNumber).orElse(null);
        TellerUser tellerUser = tellerUserRepository.findByMobileNumber(mobileNumber).orElse(null);
        if(customer==null &&cashier==null&&tellerUser==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load User",110), HttpStatus.NOT_FOUND);
        }
        RegistrationOtp registrationOtp = registrationOtpRepository.findByOtp(otp).orElse(null);
        if(registrationOtp==null){
            return new ResponseEntity<>(new GenericApiError("Invalid OTP",127), HttpStatus.EXPECTATION_FAILED);
        }if(customer!=null){
            if (customer.getEnabled()) {
                String jwt = tokenProvider.generateTokenWithUser(customer);
                UserSummary summary = this.mapUserEntityToSpecificSummary(customer);
                if(summary==null){
                    return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
                }
                summary.setAccessToken("Bearer " + jwt);
                customer.setLoginChannel("MOBILE");
                customer.setLoginCount(customer.getLoginCount()+1);
                customer.setLastLogin(LocalDateTime.now());
                userRepository.save(customer);
                //send Successfully Registered SMS to Customer
                //send Email with Pin
                registrationOtpRepository.delete(registrationOtp);
                return ResponseEntity.ok(summary);
            }else {
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }else if(tellerUser!=null){
            if (tellerUser.getEnabled()) {
                String jwt = tokenProvider.generateTokenWithUser(tellerUser);
                UserSummary summary = this.mapUserEntityToSpecificSummary(tellerUser);
                if(summary==null){
                    return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
                }
                summary.setAccessToken("Bearer " + jwt);
                tellerUser.setLoginChannel("MOBILE");
                tellerUser.setLoginCount(tellerUser.getLoginCount()+1);
                tellerUser.setLastLogin(LocalDateTime.now());
                userRepository.save(tellerUser);
                //send Successfully Registered SMS to Customer
                //send Email with Pin
                registrationOtpRepository.delete(registrationOtp);
                return ResponseEntity.ok(summary);
            }else {
                JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
                return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
            }
        }else{
                if (cashier.getEnabled()) {
                    String jwt = tokenProvider.generateTokenWithUser(cashier);
                    UserSummary summary = this.mapUserEntityToSpecificSummary(cashier);
                    if(summary==null){
                        return new ResponseEntity<>(new GenericApiError("User MerchantAccount Is Corrupted Please Contact Administrator",113), HttpStatus.EXPECTATION_FAILED);
                    }
                    summary.setAccessToken("Bearer " + jwt);
                    cashier.setLoginChannel("MOBILE");
                    cashier.setLoginCount(cashier.getLoginCount()+1);
                    cashier.setLastLogin(LocalDateTime.now());
                    userRepository.save(cashier);
                    //send Successfully Registered SMS to Customer
                    //send Email with Pin
                    registrationOtpRepository.delete(registrationOtp);
                    return ResponseEntity.ok(summary);
                }else {
                    JwtAuthenticationResponse myAuthResponse = new JwtAuthenticationResponse();
                    myAuthResponse.setMessage("MerchantAccount locked, contact admin.");
                    return new ResponseEntity<>(myAuthResponse, HttpStatus.LOCKED);
                }
            }




    }
    public ResponseEntity resendOTP(ResendOTPRequest request){
        UserCustomer customer = userCustomerRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        MerchantCashier cashier = merchantCashierRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        TellerUser tellerUser = tellerUserRepository.findByMobileNumber(request.getMobileNumber()).orElse(null);
        if(customer==null&&cashier==null&&tellerUser==null){
            return new ResponseEntity<>(new GenericApiError("Could Not Load User",110), HttpStatus.NOT_FOUND);
        }
            if(customer!=null){
                RegistrationOtp registrationOtp = registrationOtpRepository.findByUserId(customer.getUserId()).orElse(null);
                if(registrationOtp==null){
                    return new ResponseEntity<>(new GenericApiError("Invalid OTP",127), HttpStatus.EXPECTATION_FAILED);
                }
                userService.sendSuccessfulRegistrationSMSWithOTP(customer.getMobileNumber(),registrationOtp.getOtp(),request.getAppSignature());


                return ResponseEntity.ok(new GenericApiResponse("OTP Resent Successfully"));
            }else if(cashier!=null){
                RegistrationOtp registrationOtp = registrationOtpRepository.findByUserId(cashier.getUserId()).orElse(null);
                if(registrationOtp==null){
                    return new ResponseEntity<>(new GenericApiError("Invalid OTP",127), HttpStatus.EXPECTATION_FAILED);
                }
                userService.sendSuccessfulRegistrationSMSWithOTP(cashier.getMobileNumber(),registrationOtp.getOtp(),request.getAppSignature());


                return ResponseEntity.ok(new GenericApiResponse("OTP Resent Successfully"));
            }else{
                RegistrationOtp registrationOtp = registrationOtpRepository.findByUserId(tellerUser.getUserId()).orElse(null);
                if(registrationOtp==null){
                    return new ResponseEntity<>(new GenericApiError("Invalid OTP",127), HttpStatus.EXPECTATION_FAILED);
                }
                userService.sendSuccessfulRegistrationSMSWithOTP(tellerUser.getMobileNumber(),registrationOtp.getOtp(),request.getAppSignature());


                return ResponseEntity.ok(new GenericApiResponse("OTP Resent Successfully"));
            }

    }


    @AuditTrail(action = "Changed Password",expression ="",middleStatement ="",expression2 ="")
    public ResponseEntity ChangePassword(ChangePasswordRequest changePasswordRequest, String userId) {

        String decodedOldPassword = encodeDecodeUtility.ThreefoldBase64Decode(changePasswordRequest.getOldPassword());
        String decodedNewPassword = encodeDecodeUtility.ThreefoldBase64Decode(changePasswordRequest.getNewPassword());

        User theUser = userRepository.findById(userId).orElse(null);
        if (theUser == null) {
            return new ResponseEntity<>(new GenericApiError("Error Loading Profile",110), HttpStatus.EXPECTATION_FAILED);
        }
        if (passwordEncoder.matches(decodedNewPassword, theUser.getPassword())) {
            return new ResponseEntity<>(new GenericApiError("New Password Cannot be the same as Old Password",111), HttpStatus.EXPECTATION_FAILED);
        }
        if (passwordEncoder.matches(decodedOldPassword, theUser.getPassword())) {
//            theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
            theUser.setPassword(passwordEncoder.encode(decodedNewPassword));
            theUser.setResetPin(false);
            userRepository.save(theUser);
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(theUser.getUsername(), decodedNewPassword));
            SecurityContextHolder.getContext().setAuthentication(authentication);
            String jwt = tokenProvider.generateToken(authentication);
            UserSummary summary = this.mapUserEntityToSpecificSummary(theUser);
            summary.setAccessToken("Bearer " + jwt);
            // send success password change
            String emailMessage = this.processSuccessPasswordChangeEmailMessage("SUCCESS_RESET_PIN");

            this.processSuccessPasswordChangeNotifications(theUser.getEmail(),theUser.getFirstName()+" "+ theUser.getSurname());
            UserCustomer customer = userCustomerRepository.findById(theUser.getUserId()).orElse(null);
            if(!(customer==null )){

                    String smsMessage = this.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
                    this.sendSuccessfullyChangePassword(customer.getMobileNumber(),smsMessage);



            }


            return ResponseEntity.ok(summary);
        } else {
            return new ResponseEntity<>(new GenericApiError("Incorrect Old Password",112),
                    HttpStatus.EXPECTATION_FAILED);
        }
    }
    @AuditTrail(action = "Changed Password",expression ="",middleStatement ="",expression2 ="")
    public ResponseEntity InstantPasswordUpdate(UpdatePasswordRequest changePasswordRequest, String userId) {
        String newPasswordDecoded = encodeDecodeUtility.ThreefoldBase64Decode(changePasswordRequest.getNewPassword());
        User theUser = userRepository.findById(userId).orElse(null);
        if (theUser == null) {
            return new ResponseEntity<>(new GenericApiError("Error Loading Profile",110), HttpStatus.EXPECTATION_FAILED);
        }
        if (passwordEncoder.matches(newPasswordDecoded, theUser.getPassword())) {
            return new ResponseEntity<>(new GenericApiError("New Password Cannot be the same as old Password",111), HttpStatus.EXPECTATION_FAILED);
        }
        theUser.setPassword(passwordEncoder.encode(newPasswordDecoded));
//        theUser.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        theUser.setResetPin(false);
        userRepository.save(theUser);
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(theUser.getUsername(), newPasswordDecoded));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = tokenProvider.generateToken(authentication);
        UserSummary summary = this.mapUserEntityToSpecificSummary(theUser);
        summary.setAccessToken("Bearer " + jwt);
        String emailMessage = this.processSuccessPasswordChangeEmailMessage("SUCCESS_RESET_PIN");
        this.processSuccessPasswordChangeNotifications(theUser.getEmail(),theUser.getFirstName()+" "+ theUser.getSurname());
        UserCustomer customer = userCustomerRepository.findByEmail(theUser.getEmail()).orElse(null);
        if(!(customer==null)){

                String smsMessage = this.processSuccessPasswordChangeSmsMessage("SUCCESS_RESET_PIN");
                this.sendSuccessfullyChangePassword(customer.getMobileNumber(),smsMessage);



        }
        return ResponseEntity.ok(summary);
    }

    public ResponseEntity GetManagedRoles() {
        List<RoleResponse> roleList = new ArrayList<>();
        for (Role role : roleRepository.findBySelfRegEnabled(false)) {
            RoleResponse roleDTO = new RoleResponse();
            roleDTO.setRoleName(String.valueOf(role.getName()));
            roleDTO.setRoleDescription(role.getDescription());
            roleList.add(roleDTO);
        }
        return ResponseEntity.ok(roleList);
    }
    public ResponseEntity GetPermissionsByRole(RoleName roleName) {
        Role role = roleRepository.findByName(roleName).orElse(null);
        if(role==null){
            return new ResponseEntity<>(new GenericApiError("Could not Find Role",110), HttpStatus.EXPECTATION_FAILED);
        }
        List<Permission> permissions = permissionRepository.findByRoles_Id(role.getId());
        List<PermissionResponse> responses = new ArrayList<PermissionResponse>();
        for(Permission p: permissions){
            List<PrivilegeResponse> privs= new ArrayList<>();
            for(Privilege pr: p.getPrivileges()){
                PrivilegeResponse privilegeResponse= new PrivilegeResponse();
                privilegeResponse.setId(pr.getId());
                privilegeResponse.setName(pr.getName());
                privs.add(privilegeResponse);
            }
            PermissionResponse response = new PermissionResponse();
            response.setName(p.getName());
            response.setId(p.getId());
            response.setPriviledges(privs);
            responses.add(response);
        }

        return ResponseEntity.ok(responses);
    }
    public ResponseEntity getUserByUserId(String userId) {
        User theUser = userRepository.findById(userId).orElse(null);
        if (theUser == null) {
            return new ResponseEntity<>(new GenericApiError("Could not load users profile",110), HttpStatus.NOT_FOUND);
        }

        return ResponseEntity.ok(this.mapUserEntityToSpecificSummary(theUser));
    }
    public UserSummary mapUserEntityToSpecificSummary(User theUser) {
        //== respond to customer
        UserSummary userSummary = this.SetBasicSummary(theUser);
        if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_CUSTOMER))) {
            UserCustomer specificUser = userCustomerRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }
            userSummary.setMobileNumber(specificUser.getMobileNumber());
            userSummary.setVerified(specificUser.getVerified());
            userSummary.setMobileNumberCountryCode(specificUser.getMobileNumberCountryCode());
        }
        if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_BA))) {
            UserBrandAmbassador specificUser = userBrandAmbassadorRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }
            userSummary.setMobileNumber(specificUser.getMobileNumber());
            userSummary.setVerified(specificUser.getVerified());
            userSummary.setMobileNumberCountryCode(specificUser.getMobileNumberCountryCode());
        }
        if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_MERCHANT_ADMIN))) {
            MerchantAdmin specificUser = merchantAdminRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }
            if(specificUser.getMerchant()!=null ){

                userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchant()));
            }

        }
        if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_ACCOUNT_MANAGER))) {
            AccountManager specificUser = accountManagerRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }


        }
        if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_BRANCH_MANAGER))) {
            BranchManager specificUser = branchManagerRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }

            if(specificUser.getMerchantBranch()!=null && specificUser.getMerchantBranch().getMerchant()!=null){

                userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchantBranch().getMerchant()));
                userSummary.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(specificUser.getMerchantBranch()));
            }

        }
        if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_CASHIER))) {
            MerchantCashier specificUser = merchantCashierRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }
            userSummary.setMobileNumber(specificUser.getMobileNumber());
            if(specificUser.getMerchantBranch()!=null && specificUser.getMerchantBranch().getMerchant()!=null){
                userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchantBranch().getMerchant()));
            }
            if(specificUser.getMerchantBranch()!=null ){
                userSummary.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(specificUser.getMerchantBranch()));
            }
            userSummary.setVerified(true);
        }  if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_TELLER))) {
            TellerUser specificUser = tellerUserRepository.findById(theUser.getUserId()).orElse(null);
            if(specificUser==null){
                return null;
            }
            userSummary.setMobileNumber(specificUser.getMobileNumber());
            userSummary.setVerified(true);
        }

        return userSummary;
    }
    public ResponseDto<UserSummary> mapUserEntityToSpecificSummaryDto(List<User> theUsers) {
        ResponseDto<UserSummary> responseDto = new ResponseDto<>();
        responseDto.setSuccess(true);
        responseDto.setNarrative("Success");
        List<UserSummary> dtos = new ArrayList<>();
        if(theUsers!=null && !theUsers.isEmpty()){
            if(theUsers.size()==1) {
                UserSummary userSummary = this.SetBasicSummary(theUsers.get(0));
                if (theUsers.get(0).getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_CUSTOMER))) {
                    UserCustomer specificUser = userCustomerRepository.findById(theUsers.get(0).getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                    userSummary.setMobileNumber(specificUser.getMobileNumber());
                    userSummary.setVerified(specificUser.getVerified());
                    userSummary.setMobileNumberCountryCode(specificUser.getMobileNumberCountryCode());
                }
                if (theUsers.get(0).getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_MERCHANT_ADMIN))) {
                    MerchantAdmin specificUser = merchantAdminRepository.findById(theUsers.get(0).getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                    if(specificUser.getMerchant()!=null){

                        userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchant()));
                    }
                }
                if (theUsers.get(0).getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_ACCOUNT_MANAGER))) {
                    AccountManager specificUser = accountManagerRepository.findById(theUsers.get(0).getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }


                }
                if (theUsers.get(0).getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_BRANCH_MANAGER))) {
                    BranchManager specificUser = branchManagerRepository.findById(theUsers.get(0).getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }

                    if(specificUser.getMerchantBranch()!=null && specificUser.getMerchantBranch().getMerchant()!=null){

                        userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchantBranch().getMerchant()));
                        userSummary.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(specificUser.getMerchantBranch()));
                    }

                }
                if (theUsers.get(0).getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_CASHIER))) {
                    MerchantCashier specificUser = merchantCashierRepository.findById(theUsers.get(0).getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                    userSummary.setMobileNumber(specificUser.getMobileNumber());
                    if(specificUser.getMerchantBranch()!=null && specificUser.getMerchantBranch().getMerchant()!=null){
                        userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchantBranch().getMerchant()));
                    }
                    if(specificUser.getMerchantBranch()!=null ){
                        userSummary.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(specificUser.getMerchantBranch()));
                    }
                }
                responseDto.setDto(userSummary);
            }
            for(User theUser :theUsers){
                UserSummary userSummary = this.SetBasicSummary(theUser);
                if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_CUSTOMER))) {
                    UserCustomer specificUser = userCustomerRepository.findById(theUser.getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                    userSummary.setMobileNumber(specificUser.getMobileNumber());
                    userSummary.setVerified(specificUser.getVerified());
                    userSummary.setMobileNumberCountryCode(specificUser.getMobileNumberCountryCode());
                }
                if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_MERCHANT_ADMIN))) {
                    MerchantAdmin specificUser = merchantAdminRepository.findById(theUser.getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                    if(specificUser.getMerchant()!=null ){

                        userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchant()));
                    }
                }
                if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_ACCOUNT_MANAGER))) {
                    AccountManager specificUser = accountManagerRepository.findById(theUser.getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                }
                if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_BRANCH_MANAGER))) {
                    BranchManager specificUser = branchManagerRepository.findById(theUser.getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }

                    if(specificUser.getMerchantBranch()!=null && specificUser.getMerchantBranch().getMerchant()!=null){

                        userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchantBranch().getMerchant()));
                        userSummary.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(specificUser.getMerchantBranch()));
                    }

                }
                if (theUser.getRoles().stream().anyMatch(str -> str.getName().equals(RoleName.ROLE_CASHIER))) {
                    MerchantCashier specificUser = merchantCashierRepository.findById(theUser.getUserId()).orElse(null);
                    if(specificUser==null){
                        return null;
                    }
                    userSummary.setMobileNumber(specificUser.getMobileNumber());
                    if(specificUser.getMerchantBranch()!=null && specificUser.getMerchantBranch().getMerchant()!=null){
                        userSummary.setMerchant(merchantService.mapEntityToMerchantResponse(specificUser.getMerchantBranch().getMerchant()));
                    }
                    if(specificUser.getMerchantBranch()!=null ){
                        userSummary.setMerchantBranch(merchantService.mapEntityToMerchantBranchResponse(specificUser.getMerchantBranch()));
                    }
                }
                dtos.add(userSummary);
            }
            PageResponseDto pageResponseDto = new PageResponseDto();
            pageResponseDto.setFirst(true);
            pageResponseDto.setLast(true);
            pageResponseDto.setTotalPages(1);
            pageResponseDto.setTotalElements(theUsers.size());
            pageResponseDto.setSize(theUsers.size());
            pageResponseDto.setNumber(1);
            pageResponseDto.setNumberOfElements(theUsers.size());
            responseDto.setPageResponseDto(pageResponseDto);
            responseDto.setDtos(dtos);

        }
        return responseDto;
        //== respond to customer

    }
    public UserSummary SetBasicSummaryWithUserId(String userId) {
        User myUser = userRepository.findById(userId).orElse(null);
        UserSummary baseSummary = new UserSummary();
        if(myUser!=null){
            List<GrantedAuthority> userRoles = myUser.getRoles().stream().map(role ->
                    new SimpleGrantedAuthority(String.valueOf(role.getName()))
            ).collect(toList());


            baseSummary.setUserId(myUser.getUserId());
            baseSummary.setEmail(myUser.getEmail().toLowerCase());
            baseSummary.setResetPin(myUser.getResetPin());
            baseSummary.setFirstName(myUser.getFirstName());
            baseSummary.setSurname(myUser.getSurname());
            baseSummary.setUsername(myUser.getUsername());
            baseSummary.setEnabled(myUser.getEnabled());
            baseSummary.setUserGroup(String.valueOf(myUser.getRoles().stream().findAny().get().getName()));
            baseSummary.setUserRoles(userRoles);
            baseSummary.setPermissions(this.getPermissions(myUser));
        }



        return baseSummary;
    }
    public UserSummary SetBasicSummary(User myUser) {

        List<GrantedAuthority> userRoles = myUser.getRoles().stream().map(role ->
                new SimpleGrantedAuthority(String.valueOf(role.getName()))
        ).collect(toList());

        UserSummary baseSummary = new UserSummary();
        baseSummary.setUserId(myUser.getUserId());
        if(myUser.getEmail()!=null){
            baseSummary.setEmail(myUser.getEmail().toLowerCase());
        }

        baseSummary.setResetPin(myUser.getResetPin());
        baseSummary.setFirstName(myUser.getFirstName());
        baseSummary.setSurname(myUser.getSurname());
        baseSummary.setUsername(myUser.getUsername());
        baseSummary.setEnabled(myUser.getEnabled());
        baseSummary.setContactMobileNumber(myUser.getContactMobileNumber());
        baseSummary.setContactMobileNumberCountryCode(myUser.getContactMobileNumberCountryCode());
        baseSummary.setWebSocketMessageGroup(myUser.getMessageGroup());
        baseSummary.setUserGroup(String.valueOf(myUser.getRoles().stream().findAny().get().getName()));
        baseSummary.setUserRoles(userRoles);
        baseSummary.setPermissions(this.getPermissions(myUser));
        baseSummary.setAvailable(myUser.getEnabled());
        if(myUser.getCreatedAt()!=null){
            baseSummary.setDateCreated(myUser.getCreatedAt().toString());
        }
        if(myUser.getUpdatedAt()!=null){
            baseSummary.setDateUpdated(myUser.getUpdatedAt().toString());
        }



        return baseSummary;
    }
    private  List<PermissionResponse> getPermissions(User user) {

        final List<PermissionResponse> responses = new ArrayList<PermissionResponse>();
        final Collection<Permission> collection = user.getPermissions();

        for (final Permission item : collection) {
            List<Privilege> privileges =item.getPrivileges().stream().filter(x -> user.getPrivileges().contains(x)).collect(toList());
            List<PrivilegeResponse> privs= new ArrayList<>();
            for(Privilege p: privileges){
                PrivilegeResponse privilegeResponse= new PrivilegeResponse();
                privilegeResponse.setId(p.getId());
                privilegeResponse.setName(p.getName());
                privs.add(privilegeResponse);
            }
            PermissionResponse response = new PermissionResponse();
            response.setName(item.getName());
            response.setId(item.getId());
            response.setPriviledges(privs);
            responses.add(response);
        }

        return responses;
    }
    private void processSuccessPasswordChangeNotifications(String email,String receiverName) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("Your ChangeMoney password was successfully reset");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Your ChangeMoney password was successfully reset");
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );

        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
        model.put("supportEmail", appVariableRepository.findByCodeAndActive("SUPPORT_EMAIL", true).getValue());
        model.put("receiverName",receiverName);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"changed_password_successfully",1);

    }
    private void sendSMS(String mobileNumber,String smsMessage ){
        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,1);
    }
    private void processResetPasswordNotifications(String email,String pin,String receiverName) {
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("Your request to change your ChangeMoney password has been processed");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "Your request to change your ChangeMoney password has been processed");
        model.put("pin",pin);
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );

        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
        model.put("supportEmail", appVariableRepository.findByCodeAndActive("SUPPORT_EMAIL", true).getValue());
        model.put("receiverName",receiverName);
        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"reset_password",1);

    }
    private void processResetPasswordNotificationsForClient(String email,String emailMessage,String mobileNumber,String smsMessage) {

        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
        Mail mail = new Mail();//replace with your desired email
        mail.setMailTo(email);//replace with your desired email
        mail.setSubject("Rapid Fuel Reset Password");

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("headerText", "You Have Successfully Reset Your Password");
        AppVariable appName = appVariableRepository.findByCodeAndActive("APP_NAME",true);
        AppVariable footerText = appVariableRepository.findByCodeAndActive("EMAIL_FOOTER_TEXT",true);
        if(appName!=null){
            model.put("appName",appName.getValue() );
            mail.setSubject("Password Changed Successfully For "+ appName.getValue());
        }
        if(footerText!=null){
            model.put("footerText",footerText.getValue() );
        }
        model.put("emailText",emailMessage);

        mail.setProps(model);
        mailExecutor.ScheduledMailExecutor(mail,"general",1);

    }
    private void sendSuccessfullyChangePassword(String mobileNumber, String smsMessage){
        smsExecutor.ScheduledSmsExecutor(mobileNumber,smsMessage,3);
    }
    private String processSuccessPasswordChangeEmailMessage(String emailMessageCode){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public String processSuccessPasswordChangeSmsMessage(String smsMessageCode){
        EmailConfig emailConfig = emailConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    private String processResetPasswordSMSMessage(String smsMessageCode,String pin,String appSignature){
        SmsConfig emailConfig = smsConfigRepository.findByCode(smsMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin",pin);
            values.put("appSignature",appSignature);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully CHanged Your Password";
        }
    }
    public String processResetPasswordEmailMessage(String emailMessageCode,String pin){
        EmailConfig emailConfig = emailConfigRepository.findByCode(emailMessageCode).orElse(null);
        if(emailConfig!=null){
            Map<String, String> values = new HashMap<>();
            values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
            values.put("pin",pin);
            StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
            String textMessage = sub.replace(emailConfig.getContent());
            return textMessage;
        }else{
            return "You Have Successfully Reset Your Password  Your new Pin Is "+ pin;
        }
    }
}
