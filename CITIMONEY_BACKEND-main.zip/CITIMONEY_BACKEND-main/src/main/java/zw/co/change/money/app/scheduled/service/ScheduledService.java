package zw.co.change.money.app.scheduled.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.accounts.repository.MerchantAccountHistoryRepository;
import zw.co.change.money.app.accounts.response.MerchantAccountHistoryResponse;
import zw.co.change.money.app.accounts.service.AccountsService;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.response.MerchantTransactionTotalInterface;
import zw.co.change.money.app.notifications.sms.executors.SmsExecutor;
import zw.co.change.money.app.notifications.sms.repository.SmsFailuresRepository;
import zw.co.change.money.app.statistics.model.StatisticsCounter;
import zw.co.change.money.app.statistics.model.StatisticsTopTen;
import zw.co.change.money.app.statistics.repository.StatisticsCounterRepository;
import zw.co.change.money.app.statistics.repository.StatisticsTopTenRepository;
import zw.co.change.money.app.statistics.response.*;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.transactions.repository.TransactionRepository;
import zw.co.change.money.app.transactions.response.TransactionResponse;
import zw.co.change.money.app.transactions.service.TransactionService;
import zw.co.change.money.app.users.model.AccountManager;
import zw.co.change.money.app.users.model.BranchManager;
import zw.co.change.money.app.users.model.MerchantAdmin;
import zw.co.change.money.app.users.model.MerchantCashier;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.users.response.CustomerTransactionTotalInterface;
import zw.co.change.money.app.util.dates.DateUtil;
import zw.co.change.money.app.util.numbers.NumbersUtil;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.InAppMessageConfigRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;
import zw.co.change.money.app.util.format.FormatUtility;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static java.util.stream.Collectors.toList;

@Component
@Transactional
public class ScheduledService {

    @Autowired
    private StatisticsTopTenRepository statisticsTopTenRepository;
    @Autowired
    private StatisticsCounterRepository statisticsCounterRepository;
    @Autowired
    MerchantRepository merchantRepository;
    @Autowired
    MerchantAccountHistoryRepository accountHistoryRepository;
    @Autowired
    AccountRepository accountRepository;
    @Autowired
    MerchantBranchRepository merchantBranchRepository;
    @Autowired
    MerchantBranchRepository branchRepository;
    @Autowired
    private SmsFailuresRepository smsFailuresRepository;
    @Autowired
    private MerchantAccountHistoryRepository merchantAccountHistoryRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    AccountManagerRepository accountManagerRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    MerchantCashierRepository merchantCashierRepository;
    @Autowired
    MerchantAdminRepository merchantAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendAgentRepository;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private AccountsService accountsService;
    @Autowired
    DateUtil dateUtil;
    @Scheduled(fixedRate = 2*60*60*1000,initialDelay  =5*1000  )
    private void updateDashboard(){
        this.updateGlobalDashboard();
        this.updateAccountManagerDashboards();
        this.updateMerchantAdminDashboards();
        this.updateCashierDashboards();
        this.updateBranchManagerDashboards();
    }
    private void updateCashierDashboards(){
        List<MerchantCashier> cashiers = merchantCashierRepository.findByEnabled(true);
        for(MerchantCashier cashier : cashiers){
            this.getTransactionsCountersThisMonthCashier(cashier.getUserId());
            this.getTransactionsCountersThisWeekCashier(cashier.getUserId());
            this.getTransactionsCountersThisYearCashier(cashier.getUserId());
            this.getTransactionTypesPieChartCashier(cashier.getUserId());
        }
    }
    private void updateAccountManagerDashboards(){
        List<AccountManager> accountManagers = accountManagerRepository.findByEnabled(true);
        for(AccountManager cashier : accountManagers){

            this.getDepositsCountersThisMonth(cashier.getUserId());
            this.getDepositsCountersThisWeek(cashier.getUserId());
            this.getDepositsCountersThisYear(cashier.getUserId());
        }
    }
    private void updateMerchantAdminDashboards(){
        List<MerchantAdmin> merchantAdmins = merchantAdminRepository.findByEnabled(true);
        for(MerchantAdmin cashier : merchantAdmins){
            if(cashier.getMerchant()!=null){
                this.getTransactionsCountersThisMonthByMerchantId(cashier.getMerchant().getId());
                this.getTransactionsCountersThisWeekByMerchantId(cashier.getMerchant().getId());
                this.getTransactionsCountersThisYearByMerchantId(cashier.getMerchant().getId());
                this.getTransactionTypesPieChartByMerchantId(cashier.getMerchant().getId());
                this.getTop10CashiersByMerchantId(cashier.getMerchant().getId());
            }

        }
    }
    private void updateBranchManagerDashboards(){
        List<BranchManager> branchManagers = branchManagerRepository.findByEnabled(true);
        for(BranchManager cashier : branchManagers){

            if(cashier.getMerchantBranch()!=null){
                this.getTransactionsCountersThisMonthByBranchId(cashier.getMerchantBranch().getId());
                this.getTransactionsCountersThisWeekByBranchId(cashier.getMerchantBranch().getId());
                this.getTransactionsCountersThisYearByBranchId(cashier.getMerchantBranch().getId());
                this.getTransactionTypesPieChartByBranchId(cashier.getMerchantBranch().getId());
                this.getTop10CashiersByBranchId(cashier.getMerchantBranch().getId());
            }

        }
    }
    private void updateGlobalDashboard(){
        this.getTransactionsCountersThisMonth();
        this.getTransactionsCountersThisWeek();
        this.getTransactionsCountersThisYear();
        this.getTransactionTypesPieChart();
        this.getTop10Cashiers();
        this.getTop10Customers();
        this.getTop10Merchants();
    }


    private void getDepositsCountersThisMonth(String accountManagerId){

        double depositMonthCount;

        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndAccountManagerId("SUCCESS_DEPOSITS_THIS_MONTH",accountManagerId).orElse(null);

        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),accountManagerId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),accountManagerId);
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getDepositsCountersThisWeek(String accountManagerId){

        double depositMonthCount;

        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndAccountManagerId("SUCCESS_DEPOSITS_THIS_WEEK",accountManagerId).orElse(null);

        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),accountManagerId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),accountManagerId);
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getDepositsCountersThisYear(String accountManagerId){

        double depositMonthCount;

        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndAccountManagerId("SUCCESS_DEPOSITS_THIS_YEAR",accountManagerId).orElse(null);

        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),accountManagerId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByAccountManagerId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),accountManagerId);
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setAccountManagerId(accountManagerId);
            statisticsCounterRepository.save(depositCounter);
        }

    }

    private void getTransactionsCountersThisMonthCashier(String cashierId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHINS_THIS_MONTH",cashierId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHOUTS_THIS_MONTH",cashierId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_PAYMENTS_THIS_MONTH",cashierId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_TRANSFERS_THIS_MONTH",cashierId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }

    }
    private void getTransactionsCountersThisWeekCashier(String cashierId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHINS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHOUTS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_PAYMENTS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_TRANSFERS_THIS_WEEK",cashierId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_DEPOSITS_THIS_WEEK",cashierId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }

    }
    private void getTransactionsCountersThisYearCashier(String cashierId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHINS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_CASHOUTS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_PAYMENTS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_TRANSFERS_THIS_YEAR",cashierId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndCashierId("SUCCESS_DEPOSITS_THIS_YEAR",cashierId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),cashierId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),cashierId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),cashierId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),cashierId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setCashierId(cashierId);
            statisticsCounterRepository.save(transferCounter);
        }

    }


    private void getTransactionsCountersThisMonth(){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHINS_THIS_MONTH",true).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHOUTS_THIS_MONTH",true).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_PAYMENTS_THIS_MONTH",true).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_TRANSFERS_THIS_MONTH",true).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_DEPOSITS_THIS_MONTH",true).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()));
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()));

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getTransactionsCountersThisWeek(){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHINS_THIS_WEEK",true).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHOUTS_THIS_WEEK",true).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_PAYMENTS_THIS_WEEK",true).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_TRANSFERS_THIS_WEEK",true).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_DEPOSITS_THIS_WEEK",true).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()));
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()));

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getTransactionsCountersThisYear(){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHINS_THIS_YEAR",true).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_CASHOUTS_THIS_YEAR",true).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_PAYMENTS_THIS_YEAR",true).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_TRANSFERS_THIS_YEAR",true).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndForAll("SUCCESS_DEPOSITS_THIS_YEAR",true).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name());

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setForAll(true);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name());

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setForAll(true);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name());

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setForAll(true);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionType(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name());

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setForAll(true);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()));
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRange(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()));

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setForAll(true);
            statisticsCounterRepository.save(depositCounter);
        }

    }

    private void getTransactionsCountersThisMonthByMerchantId(String merchantId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHINS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHOUTS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_PAYMENTS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_TRANSFERS_THIS_MONTH",merchantId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_DEPOSITS_THIS_MONTH",merchantId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),merchantId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),merchantId);

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getTransactionsCountersThisWeekByMerchantId(String merchantId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHINS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHOUTS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_PAYMENTS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_TRANSFERS_THIS_WEEK",merchantId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_DEPOSITS_THIS_WEEK",merchantId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),merchantId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),merchantId);
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getTransactionsCountersThisYearByMerchantId(String merchantId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHINS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_CASHOUTS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_PAYMENTS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_TRANSFERS_THIS_YEAR",merchantId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndMerchantId("SUCCESS_DEPOSITS_THIS_YEAR",merchantId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),merchantId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),merchantId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),merchantId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),merchantId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),merchantId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByMerchantId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),merchantId);

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setMerchantId(merchantId);
            statisticsCounterRepository.save(depositCounter);
        }

    }

    private void getTransactionsCountersThisMonthByBranchId(long branchId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHINS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHOUTS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_PAYMENTS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_TRANSFERS_THIS_MONTH",branchId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_DEPOSITS_THIS_MONTH",branchId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_MONTH");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_MONTH");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_MONTH");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_MONTH");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),branchId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisMonth()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisMonth()),branchId);

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_MONTH");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getTransactionsCountersThisWeekByBranchId(long branchId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHINS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHOUTS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_PAYMENTS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_TRANSFERS_THIS_WEEK",branchId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_DEPOSITS_THIS_WEEK",branchId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_WEEK");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_WEEK");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_WEEK");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_WEEK");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),branchId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisWeek()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisWeek()),branchId);

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_WEEK");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }

    }
    private void getTransactionsCountersThisYearByBranchId(long branchId){
        double ecocashMonthCount;
        double oneMoneyMonthCount;
        double zipitMonthCount;
        double visaMonthCount;
        double depositMonthCount;

        StatisticsCounter cashinCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHINS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_CASHOUTS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter paymentCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_PAYMENTS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter transferCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_TRANSFERS_THIS_YEAR",branchId).orElse(null);
        StatisticsCounter depositCounter = statisticsCounterRepository.findByNameAndBranchId("SUCCESS_DEPOSITS_THIS_YEAR",branchId).orElse(null);
        if(cashinCounter==null){
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);
            cashinCounter = new StatisticsCounter();
            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }else{
            ecocashMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_IN.name(),branchId);

            cashinCounter.setCount(NumbersUtil.round(ecocashMonthCount,2));
            cashinCounter.setName("SUCCESS_CASHINS_THIS_YEAR");
            cashinCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashinCounter);
        }
        if(cashoutCounter==null){
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);
            cashoutCounter = new StatisticsCounter();
            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }else{
            oneMoneyMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.CASH_OUT.name(),branchId);

            cashoutCounter.setCount(NumbersUtil.round(oneMoneyMonthCount,2));
            cashoutCounter.setName("SUCCESS_CASHOUTS_THIS_YEAR");
            cashoutCounter.setBranchId(branchId);
            statisticsCounterRepository.save(cashoutCounter);
        }
        if(paymentCounter==null){
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);
            paymentCounter = new StatisticsCounter();
            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }else{
            zipitMonthCount =transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.PAYMENT.name(),branchId);

            paymentCounter.setCount(NumbersUtil.round(zipitMonthCount,2));
            paymentCounter.setName("SUCCESS_PAYMENTS_THIS_YEAR");
            paymentCounter.setBranchId(branchId);
            statisticsCounterRepository.save(paymentCounter);
        }
        if(transferCounter==null){
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);
            transferCounter = new StatisticsCounter();
            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }else{
            visaMonthCount = transactionRepository.sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()), TransactionStatus.SUCCESS.name(), TransactionType.TRANSFER.name(),branchId);

            transferCounter.setCount(NumbersUtil.round(visaMonthCount,2));
            transferCounter.setName("SUCCESS_TRANSFERS_THIS_YEAR");
            transferCounter.setBranchId(branchId);
            statisticsCounterRepository.save(transferCounter);
        }
        if(depositCounter==null){
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),branchId);
            depositCounter = new StatisticsCounter();
            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }else{
            depositMonthCount = merchantAccountHistoryRepository.sumDepositByDateRangeByBranchId(java.sql.Timestamp.valueOf(dateUtil.getFirstDayOfThisYear()),java.sql.Timestamp.valueOf(dateUtil.getLastDayOfThisYear()),branchId);

            depositCounter.setCount(NumbersUtil.round(depositMonthCount,2));
            depositCounter.setName("SUCCESS_DEPOSITS_THIS_YEAR");
            depositCounter.setBranchId(branchId);
            statisticsCounterRepository.save(depositCounter);
        }

    }

    private void getTransactionTypesPieChart(){


        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;
            double transfersMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_CASHINS_PIE_CHART_MONTH",i,true).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,true).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,true).orElse(null);
            StatisticsCounter transfersCounter = statisticsCounterRepository.findByNameAndMonthAndForAll("SUCCESS_TRANSFERS_PIE_CHART_MONTH",i,true).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setForAll(true);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN);

                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setForAll(true);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setForAll(true);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT);

                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setForAll(true);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setForAll(true);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT);

                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setForAll(true);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }
            if(transfersCounter==null){
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER);
                transfersCounter = new StatisticsCounter();
                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setForAll(true);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }else{
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER);

                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setForAll(true);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }

        }

    }
    private void getTransactionTypesPieChartByMerchantId(String merchantId){


        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;
            double transfersMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_CASHINS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            StatisticsCounter transfersCounter = statisticsCounterRepository.findByNameAndMonthAndMerchantId("SUCCESS_TRANSFERS_PIE_CHART_MONTH",i,merchantId).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,merchantId);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setMerchantId(merchantId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,merchantId);

                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setMerchantId(merchantId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,merchantId);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setMerchantId(merchantId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,merchantId);

                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setMerchantId(merchantId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,merchantId);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setMerchantId(merchantId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,merchantId);

                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setMerchantId(merchantId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }
            if(transfersCounter==null){
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER,merchantId);
                transfersCounter = new StatisticsCounter();
                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setMerchantId(merchantId);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }else{
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER,merchantId);

                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setMerchantId(merchantId);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }

        }

    }
    private void getTransactionTypesPieChartByBranchId(long branchId){

        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;
            double transfersMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_CASHINS_PIE_CHART_MONTH",i,branchId).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,branchId).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,branchId).orElse(null);
            StatisticsCounter transfersCounter = statisticsCounterRepository.findByNameAndMonthAndBranchId("SUCCESS_TRANSFERS_PIE_CHART_MONTH",i,branchId).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,branchId);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setBranchId(branchId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,branchId);

                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setBranchId(branchId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,branchId);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setBranchId(branchId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,branchId);

                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setBranchId(branchId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,branchId);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setBranchId(branchId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,branchId);

                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setBranchId(branchId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }
            if(transfersCounter==null){
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER,branchId);
                transfersCounter = new StatisticsCounter();
                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setBranchId(branchId);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }else{
                transfersMonthCount = transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.TRANSFER,branchId);

                transfersCounter.setCount(NumbersUtil.round(transfersMonthCount,2));
                transfersCounter.setName("SUCCESS_TRANSFERS_PIE_CHART_MONTH");
                transfersCounter.setBranchId(branchId);
                transfersCounter.setMonth(i);
                statisticsCounterRepository.save(transfersCounter);
            }

        }

    }
    private void getTransactionTypesPieChartCashier(String cashierId){

        LocalDate today = LocalDate.now();
        for(int i=1; i<13;i++){
            PieChartCategory pieChartCategory =new PieChartCategory();
            double cashinsMonthCount;
            double cashoutsMonthCount;
            double paymentsMonthCount;


            StatisticsCounter cashinsCounter = statisticsCounterRepository.findByNameAndMonthAndCashierId("SUCCESS_CASHINS_PIE_CHART_MONTH",i,cashierId).orElse(null);
            StatisticsCounter cashoutCounter = statisticsCounterRepository.findByNameAndMonthAndCashierId("SUCCESS_CASHOUTS_PIE_CHART_MONTH",i,cashierId).orElse(null);
            StatisticsCounter paymentsCounter = statisticsCounterRepository.findByNameAndMonthAndCashierId("SUCCESS_PAYMENTS_PIE_CHART_MONTH",i,cashierId).orElse(null);
            if(cashinsCounter==null){
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,cashierId);
                cashinsCounter = new StatisticsCounter();
                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setCashierId(cashierId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }else{
                cashinsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_IN,cashierId);

                cashinsCounter.setCount(NumbersUtil.round(cashinsMonthCount,2));
                cashinsCounter.setName("SUCCESS_CASHINS_PIE_CHART_MONTH");
                cashinsCounter.setCashierId(cashierId);
                cashinsCounter.setMonth(i);
                statisticsCounterRepository.save(cashinsCounter);
            }
            if(cashoutCounter==null){
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,cashierId);
                cashoutCounter = new StatisticsCounter();
                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setCashierId(cashierId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }else{
                cashoutsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.CASH_OUT,cashierId);

                cashoutCounter.setCount(NumbersUtil.round(cashoutsMonthCount,2));
                cashoutCounter.setName("SUCCESS_CASHOUTS_PIE_CHART_MONTH");
                cashoutCounter.setCashierId(cashierId);
                cashoutCounter.setMonth(i);
                statisticsCounterRepository.save(cashoutCounter);
            }
            if(paymentsCounter==null){
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,cashierId);
                paymentsCounter = new StatisticsCounter();
                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setCashierId(cashierId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }else{
                paymentsMonthCount =transactionRepository.countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(dateUtil.getFirstDayOfMonth(today.getYear(),i),dateUtil.getLastDayOfMonth(today.getYear(),i), TransactionStatus.SUCCESS, TransactionType.PAYMENT,cashierId);

                paymentsCounter.setCount(NumbersUtil.round(paymentsMonthCount,2));
                paymentsCounter.setName("SUCCESS_PAYMENTS_PIE_CHART_MONTH");
                paymentsCounter.setCashierId(cashierId);
                paymentsCounter.setMonth(i);
                statisticsCounterRepository.save(paymentsCounter);
            }


        }

    }


    private void getTop10Merchants(){
            int index = 0;
            for (MerchantTransactionTotalInterface i : merchantRepository.getTop10Merchants()) {
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndGlobal("TOP_10_MERCHANTS", index + 1,true).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_MERCHANTS");
                    topTen.setGlobal(true);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }

            }



    }
    private void getTop10Customers(){
            int index = 0;
            for (CustomerTransactionTotalInterface i : userCustomerRepository.getTop10Customers()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndGlobal("TOP_10_CUSTOMERS", index + 1,true).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CUSTOMERS");
                    topTen.setGlobal(true);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }

            }




    }
    private void getTop10Cashiers(){
            int index = 0;
            for (CustomerTransactionTotalInterface i : merchantCashierRepository.getTop10Cashiers()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndGlobal("TOP_10_CASHIERS", index + 1,true).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CASHIERS");
                    topTen.setGlobal(true);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }

            }



    }
    private void getTop10CashiersByBranchId(long branchId){


            int index = 0;
            for (CustomerTransactionTotalInterface i : merchantCashierRepository.getTop10Cashiers()) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndBranchId("TOP_10_CASHIERS", index + 1,branchId).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CASHIERS");
                    topTen.setBranchId(branchId);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
            }



    }
    private void getTop10CashiersByMerchantId(String merchantId){

            int index = 0;
            for (CustomerTransactionTotalInterface i : merchantCashierRepository.getTop10CashiersByMerchantId(merchantId)) {
                TopTenGraphItem topTenGraphItem = new TopTenGraphItem();
                topTenGraphItem.setLabel(i.getName());
                topTenGraphItem.setValue(NumbersUtil.round(i.getTotal(),2));
                /////////////////////save Top Tens ////////////////////
                StatisticsTopTen topTen = statisticsTopTenRepository.findByNameAndPositionAndMerchantId("TOP_10_CASHIERS", index + 1,merchantId).orElse(null);
                if (topTen == null) {
                    topTen = new StatisticsTopTen();
                    topTen.setLabel(i.getName() );
                    topTen.setValue(NumbersUtil.round(i.getTotal(), 2));
                    topTen.setName("TOP_10_CASHIERS");
                    topTen.setMerchantId(merchantId);
                    topTen.setPosition(index + 1);
                    statisticsTopTenRepository.save(topTen);

                } else {
                    topTen.setValue(NumbersUtil.round(i.getTotal(),2));
                    statisticsTopTenRepository.save(topTen);
                }
            }



    }

}
