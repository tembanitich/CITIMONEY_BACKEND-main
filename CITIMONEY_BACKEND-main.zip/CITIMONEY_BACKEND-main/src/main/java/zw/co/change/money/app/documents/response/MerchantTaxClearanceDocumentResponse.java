package zw.co.change.money.app.documents.response;

import lombok.Data;

@Data
public class MerchantTaxClearanceDocumentResponse {
    private Long id;
    private String fileName;
    private String fileUrl;
    private String fileType;
    private String blurHash;
    private long fileSize;
    private String merchantId;
}
