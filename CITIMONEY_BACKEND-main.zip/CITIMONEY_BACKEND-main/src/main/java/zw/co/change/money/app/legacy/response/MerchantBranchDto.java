package zw.co.change.money.app.legacy.response;

import lombok.Data;

@Data
public class MerchantBranchDto extends BaseDto {
    private String branchName;
    private String branchManagerName;
    private String branchEmail;
    private String contactNumber;
    private MerchantDto merchant;
}
