package zw.co.change.money.app.users.request;

import lombok.Data;
import zw.co.change.money.app.users.model.Gender;

import javax.validation.constraints.NotNull;

@Data
public class BackendUpdateProfileRequest {
    private String firstName;
    private String surname;
    @NotNull
    private String email;
    @NotNull
    private Gender gender;
}
