package zw.co.change.money.app.notifications.websocket.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.notifications.websocket.response.ResponseType;
import zw.co.change.money.app.util.audit.BaseUserDateAudit;


import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
@Entity
@Table(name = "web_socket_messages")
@Data
@EqualsAndHashCode(callSuper = true)
public class WebSocketMessage extends BaseUserDateAudit {
    private String userId;
    @NotNull
    private String message;
    private String title;
    private boolean readStatus;
    private ResponseType responseType;
}
