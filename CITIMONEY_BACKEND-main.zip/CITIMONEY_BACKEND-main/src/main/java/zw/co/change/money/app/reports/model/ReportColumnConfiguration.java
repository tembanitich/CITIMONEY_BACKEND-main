package zw.co.change.money.app.reports.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.BaseDateAudit;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "reportColumnConfigurations")
@Data
@EqualsAndHashCode(callSuper = true,exclude = {})
public class ReportColumnConfiguration extends BaseDateAudit {
    private String name;
    private ReportTemplateName reportName;
    private String fieldName;
    private String fieldType;
}
