package zw.co.change.money.app.statistics.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import zw.co.change.money.app.util.audit.UserDateAudit;

import javax.persistence.*;

@Entity
@Table(uniqueConstraints = {
        @UniqueConstraint(columnNames = {
                "id"
        })
})
@EqualsAndHashCode(callSuper = true)
@Data
public class StatisticsTopTen extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String label;
    private String merchantId;
    private long branchId;
    private boolean global=false;
    private double value;
    private int position;
}
