package zw.co.change.money.app.reports.request;

public enum ReportType {
    STANDARD,CUSTOM
}
