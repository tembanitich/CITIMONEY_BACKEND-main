package zw.co.change.money.app.accounts.model;
public enum DepositRequestStatus {
    PENDING, APPROVED, DECLINED,COMPLETED
}
