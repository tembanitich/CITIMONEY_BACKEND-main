package zw.co.change.money.app.legacy.response;

import lombok.Data;

@Data
public class TransactionDto extends BaseDto {
    private String reference;
    private String tranType;
    private double amount;
    private double rtgsAmt;
    private double issuedChange;
    private String destinationAccount;
    private double balanceBefore;
    private double balanceAfter;
    private double transactionCharge;
    private String notificationMsisdn;
    private AccountDto account;
    private CurrencyDto currency;
    private MerchantDto merchant;
    private MerchantUserDto merchantUser;
    private FinancialInstitutionDto financialInstitution;
}
