package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.merchants.response.MerchantResponse;
import zw.co.change.money.app.users.response.MerchantCashierResponse;
import zw.co.change.money.app.users.response.UserCustomerResponse;
@Data
public class CheckIssueChangeResponse {
    private MerchantResponse merchant;
    private MerchantCashierResponse cashier;
    private UserCustomerResponse customer;
    private CurrencyResponse currency;
    private double amount;
    private double changeAlreadyIssued;
    private double changeRequired;
    private String receiptNumber;
    private double amountInUsd;
    private double customerBalance;
}
