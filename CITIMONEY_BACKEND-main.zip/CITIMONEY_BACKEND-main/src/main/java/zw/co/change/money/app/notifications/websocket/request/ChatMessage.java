package zw.co.change.money.app.notifications.websocket.request;

import lombok.Data;

@Data
public class ChatMessage {
    private int userID;
    private int fromUserID;
    private String message;
}
