package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.BranchManager;
import zw.co.change.money.app.users.model.MerchantAdmin;
import zw.co.change.money.app.users.model.User;

import java.time.LocalDateTime;
import java.util.List;

public interface MerchantAdminRepository extends JpaRepository<MerchantAdmin, String> {
    List<MerchantAdmin> findByEnabled(boolean status);
    Page<MerchantAdmin> findByEnabled(boolean status, Pageable pageable);
    List<MerchantAdmin> findByMerchantId(String merchantBranchId);
    Page<MerchantAdmin> findByMerchantId(String merchantBranchId, Pageable pageable);
    Long countByEnabled(boolean status);
    Long countByEnabledAndMerchantId(boolean status,String merchantId);
    Long countByMerchantId(String merchantId);
    Page<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName, String  surname, Pageable pageable);
    List<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName, String  surname);
    List<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseAndMerchantIdOrSurnameContainingIgnoreCaseAndMerchantId(String  firstName, String branchId, String  surname, String branchId2);
    Page<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseAndMerchantIdOrSurnameContainingIgnoreCaseAndMerchantId(String  firstName, String branchId, String  surname, String branchId2, Pageable pageable);
    Page<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status, String  surname, boolean status2, Pageable pageable);

    List<MerchantAdmin> findByEnabledAndMerchantId(boolean status, String merchantId);
    Page<MerchantAdmin> findByEnabledAndMerchantId(boolean status,String merchantId, Pageable pageable);
    Page<MerchantAdmin> findDistinctByMerchantIdAndFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantIdAndSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd,String merchantId2, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<MerchantAdmin> findDistinctByMerchantIdAndFirstNameContainingIgnoreCaseAndEnabledOrMerchantIdAndSurnameContainingIgnoreCaseAndEnabled(String merchantId,String  firstName, boolean status,String merchantId2, String  surname, boolean status2, Pageable pageable);
    Page<MerchantAdmin> findDistinctByMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantIdAndSurnameContainingIgnoreCase(String merchantId,String  firstName,String merchantId2,String  surname, Pageable pageable);
    List<MerchantAdmin> findDistinctByMerchantIdAndFirstNameContainingIgnoreCaseOrMerchantIdAndSurnameContainingIgnoreCase(String merchantId,String  firstName,String merchantId2,String  surname);
    List<MerchantAdmin> findDistinctByFirstNameContainingIgnoreCaseAndEnabledAndMerchantIdOrSurnameContainingIgnoreCaseAndEnabledAndMerchantId(String  firstName, boolean status,String merchantId, String  surname, boolean status2,String merchantId2);

    List<MerchantAdmin> findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);


}
