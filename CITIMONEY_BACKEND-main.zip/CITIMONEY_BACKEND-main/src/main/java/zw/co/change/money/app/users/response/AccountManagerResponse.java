package zw.co.change.money.app.users.response;

import lombok.Data;
import zw.co.change.money.app.legacy.response.MerchantBranchDto;
import zw.co.change.money.app.security.roles.response.PermissionResponse;
import zw.co.change.money.app.users.model.Gender;

import java.util.List;
@Data
public class AccountManagerResponse {
    private String userId;
    private String firstName;
    private boolean active;
    private String surname;
    private String email;
    private Gender gender;
    private String contactMobileNumber;
    private String contactMobileNumberCountryCode;
    private List<PermissionResponse> permissions;
}
