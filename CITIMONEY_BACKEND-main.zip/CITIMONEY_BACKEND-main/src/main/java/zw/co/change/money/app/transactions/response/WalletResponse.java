package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.transactions.model.WalletStatus;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.users.response.UserCustomerResponse;
@Data
public class WalletResponse {
    private long id;
    private double balance;
    private WalletStatus status;
    private UserCustomerResponse customer;
    private String ecocashAccount;
    private String oneMoneyAccount;
    private String telecashAccount;
}
