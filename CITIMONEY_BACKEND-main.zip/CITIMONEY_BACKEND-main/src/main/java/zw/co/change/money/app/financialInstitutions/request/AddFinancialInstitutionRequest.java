package zw.co.change.money.app.financialInstitutions.request;

import lombok.Data;

@Data
public class AddFinancialInstitutionRequest {
    private String name;
    private String displayName;
    private boolean isMobileMoney;
    private String url;
}
