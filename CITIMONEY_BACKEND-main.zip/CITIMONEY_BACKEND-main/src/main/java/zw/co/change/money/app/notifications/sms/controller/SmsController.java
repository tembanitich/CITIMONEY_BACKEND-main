package zw.co.change.money.app.notifications.sms.controller;


import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.notifications.sms.service.SmsService;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/sms")
public class SmsController {
    @Autowired
    private SmsService smsFailureService;
    ////////////////////////////Sms Failures///////////////////////////////////////////////

    @GetMapping("/sendTest/{mesage}/{mobileNumber}")
    public ResponseEntity sendSMSTest(@PathVariable String mesage,@PathVariable String mobileNumber) {
        return smsFailureService.sendSMSTest(mesage,mobileNumber);
    }
    @GetMapping("/summary/")
    public ResponseEntity getSmsSummaryStatistics() {
        return smsFailureService.getSmsSummaryStatistics();
    }

    @GetMapping("/failures/view/reason/{failureReason}")
    public ResponseEntity GetTicketFailuresByFailureReason(@PathVariable String failureReason, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsFailureByFailureReason(failureReason,page, size);
    }
    @PostMapping("/successes/search/byPhoneNumber")
    @Operation(description="Search Success SMS")
    public ResponseEntity searchSmsSuccessesByPhoneNumber(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return smsFailureService.searchSmsSuccessesByPhoneNumber(request,currentUser.getUserId());

    }
    @PostMapping("/failures/search/byPhoneNumber")
    @Operation(description="Search Failures SMS")
    public ResponseEntity searchSmsFailuresByPhoneNumber(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return smsFailureService.searchSmsFailuresByPhoneNumber(request,currentUser.getUserId());

    }
    @PostMapping("/pending/search/byPhoneNumber")
    @Operation(description="Search Pending SMS")
    public ResponseEntity searchPendingSmsByPhoneNumber(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return smsFailureService.searchPendingSmsByPhoneNumber(request,currentUser.getUserId());

    }
    @GetMapping("/failures/view/thisWeek")
    public ResponseEntity GetTicketFailuresThisWeek(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsFailuresThisWeek(page, size);
    }
    @GetMapping("/pending/view/thisWeek")
    public ResponseEntity GetPendingSmsThisWeek(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetPendingSmsThisWeek(page, size);
    }
    @GetMapping("/pending/view/today")
    public ResponseEntity GetPendingSmsToday(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetPendingSmsToday(page, size);
    }
    @GetMapping("/pending/view/thisMonth")
    public ResponseEntity GetPendingSmsThisMonth(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetPendingSmsThisMonth(page, size);
    }
    @GetMapping("/pending/view/byRange/{startDate}/{endDate}")
    public ResponseEntity GetPendingSmsFromRange(@PathVariable String startDate, @PathVariable String endDate, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetPendingSmsFromRange(startDate,endDate,page, size);
    }
    @GetMapping("/pending/view/all")
    public ResponseEntity GetAllPendingSms(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetAllPendingSms(page, size);
    }
    @GetMapping("/failures/view/all")
    public ResponseEntity GetAllSmsFailures(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetAllSmsFailures(page, size);
    }
    @GetMapping("/failures/view/today")
    public ResponseEntity GetTicketFailuresToday(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsFailuresToday(page, size);
    }
    @GetMapping("/failures/view/thisMonth")
    public ResponseEntity GetTicketFailuresThisMonth(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                       @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsFailuresThisMonth(page, size);
    }
    @GetMapping("/failures/view/byRange/{startDate}/{endDate}")
    public ResponseEntity GetTicketFailuresFromRange(@PathVariable String startDate, @PathVariable String endDate, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsFailuresFromRange(startDate,endDate,page, size);
    }
    @GetMapping("/failures/view/byRangeAndPhoneNumber/{phoneNumber}/{startDate}/{endDate}")
    public ResponseEntity GetTicketFailuresByPhoneNumberFromRange(@PathVariable String phoneNumber,@PathVariable String startDate,@PathVariable String endDate,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                  @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsFailuresByPhoneNumberFromRange(phoneNumber,startDate,endDate,page, size);
    }

    @GetMapping("/successes/view/thisWeek")
    public ResponseEntity GetSmsSuccessesThisWeek(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsSuccessesThisWeek(page, size);
    }
    @GetMapping("/successes/view/all")
    public ResponseEntity GetAllSmsSuccesses(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetAllSmsSuccesses(page, size);
    }
    @GetMapping("/successes/view/today")
    public ResponseEntity GetSmsSuccessesToday(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsSuccessesToday(page, size);
    }
    @GetMapping("/successes/view/thisMonth")
    public ResponseEntity GetSmsSuccessesThisMonth(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                       @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsSuccessesThisMonth(page, size);
    }
    @GetMapping("/successes/view/byRange/{startDate}/{endDate}")
    public ResponseEntity GetSmsSuccessesFromRange(@PathVariable String startDate, @PathVariable String endDate, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return smsFailureService.GetSmsSuccessesFromRange(startDate,endDate,page, size);
    }




}
