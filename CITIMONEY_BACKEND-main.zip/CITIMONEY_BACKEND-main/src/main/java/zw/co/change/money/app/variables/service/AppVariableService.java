package zw.co.change.money.app.variables.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.response.AppVariableResponse;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.variables.model.AppVariable;
import zw.co.change.money.app.variables.request.AppVariableRequest;

import java.util.ArrayList;
import java.util.List;

@Service
public class AppVariableService {
    @Autowired
    AppVariableRepository appVariableRepository;

    public ResponseEntity UpdateOrCreateAppVariable(AppVariableRequest appVariableRequest) {
        if (appVariableRepository.count() > 300L) {
            return new ResponseEntity<>(new GenericApiError("Maximum number of App Variables reached",126), HttpStatus.EXPECTATION_FAILED);
        }
        AppVariable theVariable = appVariableRepository.findByCodeAndActive(appVariableRequest.getCode().toUpperCase(), true);
        if (theVariable != null) {
            theVariable.setValue(appVariableRequest.getValue());
            appVariableRepository.save(theVariable);
            return ResponseEntity.ok(new GenericApiResponse("App Variable Updated"));
        }

        AppVariable newVariable = new AppVariable();
        newVariable.setCode(appVariableRequest.getCode().toUpperCase());
        newVariable.setValue(appVariableRequest.getValue());
        appVariableRepository.save(newVariable);

        return ResponseEntity.ok(new GenericApiResponse("App Variable Added"));
    }

    public ResponseEntity changeStatusAppVariable(String code,boolean status) {
        AppVariable theVariable = appVariableRepository.findByCode(code).orElse(null);
        if(theVariable==null){
            return new ResponseEntity<>(new GenericApiError("App Variable Is not found",110), HttpStatus.NOT_FOUND);
        }
        theVariable.setActive(status);
        appVariableRepository.save(theVariable);
        return ResponseEntity.ok(new GenericApiResponse("App Variable Status Updated"));
    }

    public ResponseEntity GetAllAppVariables() {

        List<AppVariableResponse> variableResponses = new ArrayList<>();
        for (AppVariable appVariable : appVariableRepository.findAll()) {
            AppVariableResponse appVariableResponse = this.mapEntityToVariableResponse(appVariable);
            variableResponses.add(appVariableResponse);
        }
        return ResponseEntity.ok(variableResponses);
    }


    public AppVariableResponse mapEntityToVariableResponse(AppVariable appVariable) {
        AppVariableResponse theResponse = new AppVariableResponse();
        theResponse.setCode(appVariable.getCode());
        theResponse.setActive(appVariable.isActive());
        theResponse.setValue(appVariable.getValue());
        return theResponse;
    }

//    public <Any> Any getAppVariableValue(AppVariable appVariable){
//        switch(appVariable.getType()){
//            case DOUBLE :return Double.parseDouble(appVariable.getValue());
//            case STRING::return Double.parseDouble(appVariable.getValue());
//            case INTEGER :return Double.parseDouble(appVariable.getValue());
//            case BOOLEAN :return Double.parseDouble(appVariable.getValue());
//            default:return Double.parseDouble(appVariable.getValue());
//        }
//    }
}
