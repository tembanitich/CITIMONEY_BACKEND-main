package zw.co.change.money.app.transactions.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.transactions.model.Transaction;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.TransactionType;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, String> {
    List<Transaction> findByMerchantId(String merchantId);
    List<Transaction> findByFinancialInstitutionId(long financialInstitutionId);

    @Query(value = "SELECT COALESCE(SUM(company_amount), 0) FROM transactions WHERE merchant = :merchantId", nativeQuery = true)
    Double totalRevenueByCustomer(@Param("merchantId") String merchantId);
    List<Transaction> findByMerchantIdOrderByCreatedAtDesc(String userId);
    long countByMerchantId(String userId);
    Page<Transaction> findByMerchantId(String userId, Pageable pageable);
    Page<Transaction> findByTransactionType(TransactionType transactionType, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndTransactionType(String userId,TransactionType transactionType, Pageable pageable);
    Page<Transaction> findByTellerUserIdAndTransactionType(String userId,TransactionType transactionType, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndStatus(String userId,TransactionStatus transactionType, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndTransactionType(String userId,TransactionType transactionType, Pageable pageable);

    Page<Transaction> findByMerchantIdAndStatus(String userId,TransactionStatus transactionType, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndStatus(long userId,TransactionStatus transactionType, Pageable pageable);
    Page<Transaction> findByMerchantIdAndTransactionType(String userId,TransactionType transactionType, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndTransactionType(long userId,TransactionType transactionType, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndTransactionTypeOrReceiverUserIdAndTransactionType(String userId,TransactionType transactionType,String userId2,TransactionType transactionType2, Pageable pageable);
    Page<Transaction> findByReceiverUserIdAndTransactionType(String userId,TransactionType transactionType, Pageable pageable);
    Page<Transaction> findByCustomerUserId(String userId, Pageable pageable);
    Page<Transaction> findByCashierUserId(String userId, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchId(long userId, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndStatus(String userId,TransactionStatus status, Pageable pageable);
    Page<Transaction> findByStatus(TransactionStatus status, Pageable pageable);
    Page<Transaction> findByMerchantIdIn(List<String> userIds, Pageable pageable);

    List<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,LocalDateTime dayStart, LocalDateTime dayEnd);
   List<Transaction> findByMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long merchantBranchId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByCustomerUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(TransactionType userId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByMerchantIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByMerchantIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionType status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByMerchantBranchIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long userId,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByMerchantBranchIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long userId,TransactionType status,LocalDateTime dayStart, LocalDateTime dayEnd);

    List<Transaction> findByCashierUserIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByCashierUserIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionType status,LocalDateTime dayStart, LocalDateTime dayEnd);


    List<Transaction> findByTransactionTypeAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(TransactionType transactionType,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByCustomerUserIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByCustomerUserIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionType status,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByCustomerUserIdAndStatusAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionStatus status,TransactionType transactionType,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<Transaction> findByCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCustomerSurnameContainingIgnoreCaseAndTransactionType(String firstName,TransactionType transactionType,String surname,TransactionType transactionType2);
    List<Transaction> findByCustomerFirstNameContainingIgnoreCaseAndStatusOrCustomerSurnameContainingIgnoreCaseAndStatus(String firstName,TransactionStatus status,String surname,TransactionStatus status2);
    List<Transaction> findByCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String firstName,LocalDateTime dayStart, LocalDateTime dayEnd,String surname,LocalDateTime dayStart2, LocalDateTime dayEnd2);
    List<Transaction> findByCustomerFirstNameContainingIgnoreCaseOrCustomerSurnameContainingIgnoreCase(String firstName,String surname);
    List<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatus(LocalDateTime dayStart, LocalDateTime dayEnd, TransactionStatus status);
    List<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndTransactionType(LocalDateTime dayStart, LocalDateTime dayEnd, TransactionType status);



    Page<Transaction> findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long userId,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayStart2, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionType status,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByCustomerUserIdAndStatusAndTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,TransactionStatus status,TransactionType transactionType,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCustomerSurnameContainingIgnoreCaseAndTransactionType(String firstName,TransactionType transactionType,String surname,TransactionType transactionType2, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndTransactionType(String cashierId,String firstName,TransactionType transactionType,String cashierId2,String surname,TransactionType transactionType2, Pageable pageable);
    Page<Transaction> findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndTransactionType(String cashierId,String firstName,TransactionType transactionType,String cashierId2,String surname,TransactionType transactionType2, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndTransactionTypeOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndTransactionType(long cashierId,String firstName,TransactionType transactionType,long cashierId2,String surname,TransactionType transactionType2, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndStatusOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndStatus(String cashierId,String firstName,TransactionStatus transactionType,String cashierId2,String surname,TransactionStatus transactionType2, Pageable pageable);
    Page<Transaction> findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndStatusOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndStatus(String cashierId,String firstName,TransactionStatus transactionType,String cashierId2,String surname,TransactionStatus transactionType2, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndStatusOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndStatus(long cashierId,String firstName,TransactionStatus transactionType,long cashierId2,String surname,TransactionStatus transactionType2, Pageable pageable);
    Page<Transaction> findByCustomerFirstNameContainingIgnoreCaseAndStatusOrCustomerSurnameContainingIgnoreCaseAndStatus(String firstName,TransactionStatus status,String surname,TransactionStatus status2, Pageable pageable);
    Page<Transaction> findByCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String firstName,LocalDateTime dayStart, LocalDateTime dayEnd,String surname,LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierUserIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String cashierId,String firstName,LocalDateTime dayStart, LocalDateTime dayEnd,String cashierId2,String surname,LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<Transaction> findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrMerchantIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String cashierId,String firstName,LocalDateTime dayStart, LocalDateTime dayEnd,String cashierId2,String surname,LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long cashierId,String firstName,LocalDateTime dayStart, LocalDateTime dayEnd,long cashierId2,String surname,LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<Transaction> findByCustomerFirstNameContainingIgnoreCaseOrCustomerSurnameContainingIgnoreCase(String firstName,String surname, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndCustomerFirstNameContainingIgnoreCaseOrCashierUserIdAndCustomerSurnameContainingIgnoreCase(String cashierId,String firstName,String cashierId2,String surname, Pageable pageable);
    Page<Transaction> findByMerchantIdAndCustomerFirstNameContainingIgnoreCaseOrMerchantIdAndCustomerSurnameContainingIgnoreCase(String cashierId,String firstName,String cashierId2,String surname, Pageable pageable);
    Page<Transaction> findByCashierMerchantBranchIdAndCustomerFirstNameContainingIgnoreCaseOrCashierMerchantBranchIdAndCustomerSurnameContainingIgnoreCase(long cashierId,String firstName,long cashierId2,String surname, Pageable pageable);
    Page<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatus(LocalDateTime dayStart, LocalDateTime dayEnd, TransactionStatus status, Pageable pageable);
    Page<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndTransactionType(LocalDateTime dayStart, LocalDateTime dayEnd, TransactionType status, Pageable pageable);

    List<Transaction> findFirst10ByStatusAndMerchantIdOrderByCreatedAtDesc(TransactionStatus paymentStatus,String merchantId);
    List<Transaction> findFirst10ByStatusAndCashierMerchantBranchIdOrderByCreatedAtDesc(TransactionStatus paymentStatus,long branchId);
    List<Transaction> findFirst10ByStatusOrderByCreatedAtDesc(TransactionStatus paymentStatus);
    List<Transaction> findFirst10ByStatusAndCashierUserIdOrderByCreatedAtDesc(TransactionStatus paymentStatus,String userId);

    Page<Transaction> findByTransactionTypeAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(TransactionType userId,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByTransactionTypeAndStatusAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(TransactionType transactionType,TransactionStatus status,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);


    Page<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<Transaction> findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String cashierId,LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    List<Transaction> findByCashierUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String cashierId,LocalDateTime dayStart, LocalDateTime dayEnd);
   Page<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndMerchantId(LocalDateTime dayStart, LocalDateTime dayEnd,String userId, Pageable pageable);
    Page<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndCustomerUserId(LocalDateTime dayStart, LocalDateTime dayEnd,String userId, Pageable pageable);
    List<Transaction> findFirst10ByCustomerUserIdOrderByCreatedAtDesc(String userId);
    List<Transaction> findFirst10ByCustomerUserIdOrReceiverUserIdOrderByCreatedAtDesc(String userId,String userId2);
    List<Transaction> findFirst10ByCashierUserIdOrderByCreatedAtDesc(String userId);
    List<Transaction> findFirst10ByTellerUserIdOrderByCreatedAtDesc(String userId);
    List<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndMerchantId(LocalDateTime dayStart, LocalDateTime dayEnd,String userId);
    List<Transaction> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndMerchantBranchId(LocalDateTime dayStart, LocalDateTime dayEnd,long branchId);
   
    List<Transaction> findFirst10ByOrderByCreatedAtDesc();
    long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionType(LocalDateTime dayStart, LocalDateTime dayEnd,TransactionStatus status,TransactionType transactionType);
    long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndMerchantId(LocalDateTime dayStart, LocalDateTime dayEnd,TransactionStatus status,TransactionType transactionType,String merchantId);
    long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierMerchantBranchId(LocalDateTime dayStart, LocalDateTime dayEnd,TransactionStatus status,TransactionType transactionType,long branchId);
    long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualAndStatusAndTransactionTypeAndCashierUserId(LocalDateTime dayStart, LocalDateTime dayEnd,TransactionStatus status,TransactionType transactionType,String cashierId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status = :status", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionStatus(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("status") String status);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.transaction_type = :transaction_type", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionType(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange,@Param("transaction_type") String transaction_type);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status = :status and  p.transaction_type = :transaction_type", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionStatusAndTransactionType(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("status") String status, @Param("transaction_type") String transaction_type);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status = :status and  p.transaction_type = :transaction_type and  p.merchant = :merchantId", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndMerchantId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("status") String status, @Param("transaction_type") String transaction_type, @Param("merchantId") String merchantId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p inner join merchant_branch po on p.merchant = po.merchant where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status = :status and  p.transaction_type = :transaction_type and  po.id = :branchId", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndBranchId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("status") String status, @Param("transaction_type") String transaction_type, @Param("branchId") long branchId);


    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status = :status and  p.transaction_type = :transaction_type and  p.cashier = :cashierId", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndCashierId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("status") String status, @Param("transaction_type") String transaction_type, @Param("cashierId") String cashierId);

    @Query(value="SELECT COALESCE(sum(p.amount),0) from transactions p where  p.created_at <= :endRange and  p.created_at >= :startRange and  p.status = :status and  p.transaction_type = :transaction_type and  p.teller = :tellerId", nativeQuery = true)
    double sumAmountByDateRangeAndTransactionStatusAndTransactionTypeAndTellerId(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange, @Param("status") String status, @Param("transaction_type") String transaction_type, @Param("tellerId") String tellerId);


}
