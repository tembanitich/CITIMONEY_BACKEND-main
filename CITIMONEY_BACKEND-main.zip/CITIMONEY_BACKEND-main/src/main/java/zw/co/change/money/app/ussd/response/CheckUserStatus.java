package zw.co.change.money.app.ussd.response;

public enum CheckUserStatus {
    IS_FIRST_TIME_USER,IS_RESET_PIN,IS_NEW_USER,IS_ACTIVE,IS_INACTIVE,OTHER
}
