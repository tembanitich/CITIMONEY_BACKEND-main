package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.UserBackendAdmin;

import java.time.LocalDateTime;
import java.util.List;

public interface UserBackendAdminRepository extends JpaRepository<UserBackendAdmin, String> {
    List<UserBackendAdmin> findByEnabled(boolean status);
    Page<UserBackendAdmin> findByEnabled(boolean status, Pageable pageable);
    Long countByEnabled(boolean status);
    Page<UserBackendAdmin> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    Page<UserBackendAdmin> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<UserBackendAdmin> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status,String  surname, boolean status2,Pageable pageable);

}