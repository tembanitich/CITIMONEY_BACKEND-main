package zw.co.change.money.app.accounts.model;

public enum MerchantAccountHistoryType {
    DEBIT,CREDIT,DEPOSIT
}
