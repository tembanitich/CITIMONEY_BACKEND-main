package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.merchants.response.MerchantTransactionTotalInterface;
import zw.co.change.money.app.users.model.UserCustomer;
import zw.co.change.money.app.users.response.CustomerGrossRevenueInterface;
import zw.co.change.money.app.users.response.CustomerPaymentTotalInterface;
import zw.co.change.money.app.users.response.CustomerTransactionTotalInterface;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface UserCustomerRepository extends JpaRepository<UserCustomer, String> {

    @Query(value ="select p.*, sum(po.grand_total) as total_revenue from users_customers p inner join transactions po on p.user_id = po.user_customer and created_at > :startRange and created_at < :endRange group by p.user_id order by total_revenue desc LIMIT 50", nativeQuery = true)
    List<CustomerGrossRevenueInterface> getCustomersGrossRevenuesByDateRange(@Param("startRange") Timestamp startRange, @Param("endRange") Timestamp endRange);
    @Query(value ="select  p.*, sum(po.grand_total) as total_revenue from users_customers p inner join transactions po on p.user_id = po.user_customer group by p.user_id order by total_revenue desc", nativeQuery = true)
    List<CustomerGrossRevenueInterface> getCustomersGrossRevenues();
    List<UserCustomer> findByEnabled(boolean status);
    Page<UserCustomer> findByEnabled(boolean status, Pageable pageable);
    List<UserCustomer> findByFirstNameIgnoreCaseContainingOrSurnameIgnoreCaseContaining(String firstName,String surname);

    Boolean existsByMobileNumber(String mobileNumber);
    Optional<UserCustomer> findByMobileNumber(String mobileNumber);
    Optional<UserCustomer> findByEmail(String email);
    Long countByEnabled(boolean status);


    Page<UserCustomer> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    Page<UserCustomer> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<UserCustomer> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status,String  surname, boolean status2,Pageable pageable);
    @Query(value ="select po.user_id as id,po.mobile_number as name, sum(p.amount_in_usd) as total from transactions p inner join users_customers po on p.customer = po.user_id WHERE p.status='SUCCESS' group by po.user_id order by total desc LIMIT 10", nativeQuery = true)
    List<CustomerTransactionTotalInterface> getTop10Customers();
}
