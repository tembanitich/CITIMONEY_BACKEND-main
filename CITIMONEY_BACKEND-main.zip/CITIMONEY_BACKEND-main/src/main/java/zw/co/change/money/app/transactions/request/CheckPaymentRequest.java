package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CheckPaymentRequest {
    private String cashierCode;
    private String currencyCode;
    private double amount;
}
