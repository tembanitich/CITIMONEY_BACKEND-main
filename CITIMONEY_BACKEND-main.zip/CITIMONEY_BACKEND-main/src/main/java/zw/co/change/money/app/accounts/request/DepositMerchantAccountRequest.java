package zw.co.change.money.app.accounts.request;

import lombok.Data;

@Data
public class DepositMerchantAccountRequest {
    private long id;
    private double amount;
}
