package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CheckCashoutRequest {
    private String cashierCode;
    private String currencyCode;
    private double amount;
}
