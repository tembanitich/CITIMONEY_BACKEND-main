package zw.co.change.money.app.users.controller;


import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.users.request.*;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.authentication.request.ChangePasswordRequest;
import zw.co.change.money.app.authentication.request.UpdatePasswordRequest;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.users.service.UserService;
import zw.co.change.money.app.util.constants.AppConstants;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    UserService userService;
    @Autowired
    AuthenticationService authenticationService;


////////////////////Global Users/////////////////////////////////////////////////////////////////////////////////////////////////
    @GetMapping("/me")
    @Operation(description="get current user principal")
    //@PreAuthorize("hasAuthority('WRITE_PRIVILEGE')")
    public ResponseEntity getCurrentUser() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authenticationService.getUserByUserId(currentUser.getUserId());
    }
    @GetMapping("/activation/{userId}/{status}")
    @Operation(description="activate or deactivate users")
    public ResponseEntity activateOrDeactivateUsers(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.ActivateOrDeactivateUser(userId, status);
    }
    @PostMapping("/assignPermissions")
    @Operation(description="assign permissions to user ")
    public ResponseEntity assignPermissionsToUser(@Valid @RequestBody AssignPermissionsRequest signUpRequest) {
        return userService.assignPermissionsToUser(signUpRequest);
    }
    @PostMapping("/merchant/search/byName")
    @Operation(description="Search All Merchant Users")
    public ResponseEntity searchMerchantUserByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMerchantUserByName(request,currentUser.getUserId());

    }
    @PostMapping("/merchantBranch/search/byName")
    @Operation(description="Search All Merchant Barnch Users")
    public ResponseEntity searchMerchantBranchUserByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMerchantBranchUserByName(request,currentUser.getUserId());

    }
    @PostMapping("/backend/search/byName")
    @Operation(description="Search All Users")
    public ResponseEntity searchBackendUserByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchBackendUserByName(request,currentUser.getUserId());

    }

    @PostMapping("/profile/client/update")
    @Operation(description="Update Own Profile For User Who Is Logged In")
    public ResponseEntity updateClientProfile(@Valid @RequestBody UpdateClientRequest profileUpdate) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateClientProfile(profileUpdate, currentUser.getUserId());
    }
    @PostMapping("/profile/update")
    @Operation(description="Update Own Profile For User Who Is Logged In")
    public ResponseEntity updateUserProfile(@Valid @RequestBody UpdateUserRequest profileUpdate) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateUserProfile(profileUpdate, currentUser.getUserId());
    }
    @PostMapping("/passwords/change")
    public ResponseEntity changePassword(@Valid @RequestBody ChangePasswordRequest passwordChange) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authenticationService.ChangePassword(passwordChange, currentUser.getUserId());
    }

    @PostMapping("/passwords/update")
    public ResponseEntity UpdatePassword(@Valid @RequestBody UpdatePasswordRequest passwordChange) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authenticationService.InstantPasswordUpdate(passwordChange, currentUser.getUserId());
    }

    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////Backend Admins////////////////////////////////////////////////////////////////////
    @PostMapping("/backendAdmin/create")
    @Operation(description="Create Backend Admin")
    public ResponseEntity addBackendAdmin(@Valid @RequestBody AddBackendAdminRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addBackendAdmin(request, currentUser.getUserId());
    }
    @PostMapping("/backendAdmin/update")
    @Operation(description="Update Backend Admin")
    public ResponseEntity updateBackendAdmin(@Valid @RequestBody UpdateBackendAdminRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateBackendAdmin(request, currentUser.getUserId());
    }
    @GetMapping("/backendAdmin/activation/{userId}/{status}")
    @Operation(description="activate or deactivate backend Admins")
    public ResponseEntity changeBackendAdminStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeBackendAdminStatus(userId, status);
    }
    @GetMapping("/backendAdmin/view/active")
    public ResponseEntity getActiveBackendAdmins() {
        return userService.getActiveBackendAdmins();
    }
    @GetMapping("/backendAdmin/view/all")
    public ResponseEntity getAllBackendAdmins(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return userService.getAllBackendAdmins(page, size);
    }
    @GetMapping("/backendAdmin/view/byStatus/{status}")
    public ResponseEntity getBackendAdminsByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return userService.getBackendAdminsByStatus(status,page, size);
    }
    @PostMapping("/backendAdmin/search/byName")
    @Operation(description="Search Backend Admins")
    public ResponseEntity searchBackendAdminByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchBackendAdminByName(request,currentUser.getUserId());

    }
    @GetMapping("/backendAdmin/view/byUserId/{userId}")
    public ResponseEntity getBackendAdminById(@PathVariable String userId) {
        return userService.getBackendAdminById(userId);
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////Backend Agents////////////////////////////////////////////////////////////////////
    @PostMapping("/backendAgent/create")
    @Operation(description="Create Backend Agent")
    public ResponseEntity addBackendAgent(@Valid @RequestBody AddBackendAgentRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addBackendAgent(request, currentUser.getUserId());
    }
    @PostMapping("/backendAgent/search/byName")
    @Operation(description="Search Backend Agents")
    public ResponseEntity searchBackendAgentByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchBackendAgentByName(request,currentUser.getUserId());

    }
    @PostMapping("/backendAgent/update")
    @Operation(description="Update Backend Agent")
    public ResponseEntity updateBackendAgent(@Valid @RequestBody UpdateBackendAgentRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateBackendAgent(request, currentUser.getUserId());
    }
    @GetMapping("/backendAgent/activation/{userId}/{status}")
    @Operation(description="activate or deactivate backend Agents")
    public ResponseEntity changeBackendAgentStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeBackendAgentStatus(userId, status);
    }
    @GetMapping("/backendAgent/view/active")
    public ResponseEntity getActiveBackendAgents() {
        return userService.getActiveBackendAgents();
    }
    @GetMapping("/backendAgent/view/all")
    public ResponseEntity getAllBackendAgents(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllBackendAgents(page, size, currentUser.getUserId());
    }
    @GetMapping("/backendAgent/view/byStatus/{status}")
    public ResponseEntity getBackendAgentsByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBackendAgentsByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/backendAgent/view/byUserId/{userId}")
    public ResponseEntity getBackendAgentById(@PathVariable String userId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBackendAgentById(userId, currentUser.getUserId());
    }
    //////////////////////////BrandAmbassadors////////////////////////////////////////////////////////////////////
    @PostMapping("/brandAmbassadors/create")
    @Operation(description="Create BrandAmbassador")
    public ResponseEntity addBackendBrandAmbassador(@Valid @RequestBody AddBrandAmbassadorRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addBrandAmbassador(request, currentUser.getUserId());
    }
    @PostMapping("/brandAmbassadors/update")
    @Operation(description="Update BrandAmbassador")
    public ResponseEntity updateBrandAmbassador(@Valid @RequestBody UpdateBrandAmbassadorRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateBrandAmbassador(request, currentUser.getUserId());
    }
    @PostMapping("/brandAmbassadors/search/byName")
    @Operation(description="Search BrandAmbassadors")
    public ResponseEntity searchBrandAmbassadorsByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchBrandAmbassadorByName(request,currentUser.getUserId());

    }
    @GetMapping("/brandAmbassadors/view/active")
    public ResponseEntity getActiveBrandAmbassadors() {
        return userService.getActiveBrandAmbassadors();
    }
    @GetMapping("/brandAmbassadors/view/all")
    public ResponseEntity getAllBrandAmbassadors(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllBrandAmbassadors(page, size, currentUser.getUserId());
    }
    @GetMapping("/brandAmbassadors/activation/{userId}/{status}")
    @Operation(description="activate or deactivate BrandAmbassadors")
    public ResponseEntity changeBrandAmbassadorsStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeBrandAmbassadorsStatus(userId, status);
    }
    @GetMapping("/brandAmbassadors/view/byStatus/{status}")
    public ResponseEntity getBrandAmbassadorsByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBrandAmbassadorsByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/brandAmbassadors/view/byUserId/{brandAmbassadorId}")
    public ResponseEntity getBrandAmbassadorById(@PathVariable String brandAmbassadorId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBrandAmbassadorById(brandAmbassadorId, currentUser.getUserId());
    }
    @GetMapping("/brandAmbassadors/view/byMobileNumber/{mobileNumber}")
    public ResponseEntity getBrandAmbassadorByPhoneNumber(@PathVariable String mobileNumber) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBrandAmbassadorByPhoneNumber(mobileNumber, currentUser.getUserId());
    }
    //////////////////////////Customers////////////////////////////////////////////////////////////////////
    @PostMapping("/customers/create")
    @Operation(description="Create Customer")
    public ResponseEntity addBackendCustomer(@Valid @RequestBody AddCustomerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addCustomer(request, currentUser.getUserId());
    }
    @PostMapping("/customers/update")
    @Operation(description="Update Customer")
    public ResponseEntity updateCustomer(@Valid @RequestBody UpdateCustomerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateCustomer(request, currentUser.getUserId());
    }
    @PostMapping("/customers/search/byName")
    @Operation(description="Search Customers")
    public ResponseEntity searchCustomersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchCustomerByName(request,currentUser.getUserId());

    }
    @GetMapping("/customers/view/active")
    public ResponseEntity getActiveCustomers() {
        return userService.getActiveCustomers();
    }
    @GetMapping("/customers/view/all")
    public ResponseEntity getAllCustomers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllCustomers(page, size, currentUser.getUserId());
    }
    @GetMapping("/customers/activation/{userId}/{status}")
    @Operation(description="activate or deactivate Customers")
    public ResponseEntity changeCustomersStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeCustomersStatus(userId, status);
    }
    @GetMapping("/customers/view/byStatus/{status}")
    public ResponseEntity getCustomersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getCustomersByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/customers/view/byUserId/{customerId}")
    public ResponseEntity getCustomerById(@PathVariable String customerId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getCustomerById(customerId, currentUser.getUserId());
    }
    @GetMapping("/customers/view/byMobileNumber/{mobileNumber}")
    public ResponseEntity getCustomerByPhoneNumber(@PathVariable String mobileNumber) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getCustomerByPhoneNumber(mobileNumber, currentUser.getUserId());
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ////////////////////////////////User Audit Trail///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    @GetMapping("/auditTrail/search/byAction/{action}/{userId}")
    @Operation(description="search audit trail  by action")
    public ResponseEntity searchAuditTrailByAction(@PathVariable String userId,@PathVariable String action,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size){
        return userService.searchAuditTrailByAction(action,page, size,userId);
    }
    @GetMapping("/auditTrail/byUserId/{userId}")
    public ResponseEntity getAllUserAuditTrail(@PathVariable String userId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return userService.getAllUserAuditTrail(page, size,userId);
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @PostMapping("/backend/update/me")
    @Operation(description="Self Update Backend Profile")
    public ResponseEntity updateBackendProfile(@Valid @RequestBody BackendUpdateProfileRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateBackendProfile(request, currentUser.getUserId());
    }
    @PostMapping("/client/update/me")
    @Operation(description="Self Update Client Profile")
    public ResponseEntity updateClientProfile(@Valid @RequestBody ClientUpdateProfileRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateClientProfile(request, currentUser.getUserId());
    }

    //////////////////////////Merchant Users////////////////////////////////////////////////////////////////////
    @PostMapping("/merchantAdmin/create")
    @Operation(description="Create Merchant User")
    public ResponseEntity addMerchantUser(@Valid @RequestBody AddMerchantUserRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addMerchantUser(request, currentUser.getUserId());
    }
    @GetMapping("/merchantAdmin/activation/{userId}/{status}")
    @Operation(description="activate or deactivate Merchantr Users")
    public ResponseEntity changeMerchantUsersStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeMerchantUsersStatus(userId, status);
    }
    @PostMapping("/merchantAdmin/update")
    @Operation(description="Update Merchant Users")
    public ResponseEntity updateMerchantUser(@Valid @RequestBody UpdateMerchantUserRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateMerchantUser(request, currentUser.getUserId());
    }
    @PostMapping("/merchantAdmin/search/byName")
    @Operation(description="Search Merchant User")
    public ResponseEntity searchMerchantUsersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMerchantUsersByName(request,currentUser.getUserId());

    }
    @GetMapping("/merchantAdmin/view/active/me")
    public ResponseEntity getMyActiveMerchantUsers() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyActiveMerchantUsers(currentUser.getUserId());
    }
    @GetMapping("/merchantAdmin/view/active")
    public ResponseEntity getActiveMerchantUsers() {
        return userService.getActiveMerchantUsers();
    }
    @GetMapping("/merchantAdmin/view/me")
    public ResponseEntity getMyMerchantUsers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyMerchantUsers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantAdmin/view/all")
    public ResponseEntity getAllMerchantUsers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllMerchantUsers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantAdmin/view/byMerchantBranchId/{branchId}")
    public ResponseEntity getMerchantUsersByMerchantBranchId(@PathVariable String branchId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                         @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMerchantUsersByMerchantId(branchId,page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantAdmin/view/byStatus/me/{status}")
    public ResponseEntity getMyMerchantUsersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyMerchantUsersByStatus(status,page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantAdmin/view/byStatus/{status}")
    public ResponseEntity getMerchantUsersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMerchantUsersByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/merchantAdmin/view/byUserId/{userId}")
    public ResponseEntity getMerchantUserById(@PathVariable String userId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMerchantUserById(userId, currentUser.getUserId());
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////Merchant User Users////////////////////////////////////////////////////////////////////
    @PostMapping("/merchantCashier/create")
    @Operation(description="Create Merchant Cashier")
    public ResponseEntity addMerchantCashier(@Valid @RequestBody AddMerchantCashierRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addMerchantCashier(request, currentUser.getUserId());
    }
    @PostMapping("/merchantCashier/create/myBranch")
    @Operation(description="Create Merchant Cashier AS Branch Manager")
    public ResponseEntity addMyBranchMerchantCashier(@Valid @RequestBody AddMerchantCashierRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addMyBranchMerchantCashier(request, currentUser.getUserId());
    }
    @PostMapping("/merchantCashier/create/me")
    @Operation(description="Create Merchant Cashier AS Merchant Admin")
    public ResponseEntity addMyMerchantCashier(@Valid @RequestBody AddMerchantCashierRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addMyMerchantCashier(request, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/activation/{userId}/{status}")
    @Operation(description="activate or deactivate Merchant Cashier")
    public ResponseEntity changeMerchantCashiersStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeMerchantCashiersStatus(userId, status);
    }
    @PostMapping("/merchantCashier/update/myBranch")
    @Operation(description="Update Merchant Cashier As Branch Manager")
    public ResponseEntity updateMyBranchMerchantCashier(@Valid @RequestBody UpdateMerchantCashierRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateMyBranchMerchantCashier(request, currentUser.getUserId());
    }
    @PostMapping("/merchantCashier/update/me")
    @Operation(description="Update Merchant Cashier As Merchant Admin")
    public ResponseEntity updateMyMerchantCashier(@Valid @RequestBody UpdateMerchantCashierRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateMyMerchantCashier(request, currentUser.getUserId());
    }
    @PostMapping("/merchantCashier/update")
    @Operation(description="Update Merchant Cashier")
    public ResponseEntity updateMerchantCashier(@Valid @RequestBody UpdateMerchantCashierRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateMerchantCashier(request, currentUser.getUserId());
    }
    @PostMapping("/merchantCashier/search/byName/myBranch")
    @Operation(description="Search Merchant Cashier As Merchant Admin")
    public ResponseEntity searchMyBranchMerchantCashiersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMyBranchMerchantCashiersByName(request,currentUser.getUserId());

    }
    @PostMapping("/merchantCashier/search/byName/me")
    @Operation(description="Search Merchant Cashier As Merchant Admin")
    public ResponseEntity searchMyMerchantCashiersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMyMerchantCashiersByName(request,currentUser.getUserId());

    }
    @PostMapping("/merchantCashier/search/byName")
    @Operation(description="Search Merchant Cashier")
    public ResponseEntity searchMerchantCashiersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMerchantCashiersByName(request,currentUser.getUserId());

    }
    @GetMapping("/merchantCashier/view/active/myBranch")
    public ResponseEntity getMyBranchActiveMerchantCashiers() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyBranchActiveMerchantCashiers(currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/active/me")
    public ResponseEntity getMyActiveMerchantCashiers() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyActiveMerchantCashiers(currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/active")
    public ResponseEntity getActiveMerchantCashiers() {
        return userService.getActiveMerchantCashiers();
    }
    @GetMapping("/merchantCashier/view/myBranch")
    public ResponseEntity getMyBranchMerchantCashiers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyBranchMerchantCashiers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/me")
    public ResponseEntity getMyMerchantCashiers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyMerchantCashiers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/merchantBranch/view/all")
    public ResponseEntity getAllMerchantBranchMerchantCashiers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                         @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllMerchantBranchMerchantCashiers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/merchant/view/all")
    public ResponseEntity getAllMerchantMerchantCashiers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllMerchantMerchantCashiers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/all")
    public ResponseEntity getAllMerchantCashiers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllMerchantCashiers(page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/byMerchantBranchId/{branchId}")
    public ResponseEntity getMerchantCashiersByMerchantBranchId(@PathVariable long branchId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                             @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMerchantCashiersByMerchantId(branchId,page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/byStatus/myBranch/{status}")
    public ResponseEntity getMyBranchMerchantCashiersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                        @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyBranchMerchantCashiersByStatus(status,page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/byStatus/me/{status}")
    public ResponseEntity getMyMerchantCashiersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyMerchantCashiersByStatus(status,page, size, currentUser.getUserId());
    }
    @GetMapping("/merchantCashier/view/byStatus/{status}")
    public ResponseEntity getMerchantCashiersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMerchantCashiersByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/merchantCashier/view/byUserId/{userId}")
    public ResponseEntity getMerchantCashierById(@PathVariable String userId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMerchantCashierById(userId, currentUser.getUserId());
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////Merchant Dealer Users////////////////////////////////////////////////////////////////////
    @PostMapping("/accountManager/create")
    @Operation(description="Create MerchantAccount Manager User")
    public ResponseEntity addAccountManager(@Valid @RequestBody AddAccountManagerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addAccountManager(request, currentUser.getUserId());
    }
    @GetMapping("/accountManager/activation/{userId}/{status}")
    @Operation(description="activate or deactivate MerchantAccount Manager Users")
    public ResponseEntity changeAccountManagersStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeAccountManagersStatus(userId, status);
    }
    @PostMapping("/accountManager/assignMerchant")
    @Operation(description="Assign Merchant To MerchantAccount Manager Users")
    public ResponseEntity assignMerchant(@Valid @RequestBody AccountManagerAssignMerchantRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.assignMerchant(request, currentUser.getUserId());
    }
    @PostMapping("/accountManager/update")
    @Operation(description="Update MerchantAccount Manager Users")
    public ResponseEntity updateAccountManager(@Valid @RequestBody UpdateAccountManagerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateAccountManager(request, currentUser.getUserId());
    }
    @PostMapping("/accountManager/search/byName")
    @Operation(description="Search MerchantAccount Manager User")
    public ResponseEntity searchAccountManagersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchAccountManagersByName(request,currentUser.getUserId());

    }
    @GetMapping("/accountManager/view/active")
    public ResponseEntity getActiveAccountManagers() {
        return userService.getActiveAccountManagers();
    }
    @GetMapping("/accountManager/view/all")
    public ResponseEntity getAllAccountManagers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllAccountManagers(page, size, currentUser.getUserId());
    }

    @GetMapping("/accountManager/view/byStatus/{status}")
    public ResponseEntity getAccountManagersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAccountManagersByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/accountManager/view/byUserId/{userId}")
    public ResponseEntity getAccountManagerById(@PathVariable String userId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAccountManagerById(userId, currentUser.getUserId());
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //////////////////////////Merchant Dealer Users////////////////////////////////////////////////////////////////////
    @PostMapping("/branchManager/create")
    @Operation(description="Create Branch Manager User")
    public ResponseEntity addBranchManager(@Valid @RequestBody AddBranchManagerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addBranchManager(request, currentUser.getUserId());
    }
    @PostMapping("/branchManager/create/me")
    @Operation(description="Create Branch Manager User As Merchant Admin")
    public ResponseEntity addMyBranchManager(@Valid @RequestBody AddBranchManagerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addMyBranchManager(request, currentUser.getUserId());
    }
    @GetMapping("/branchManager/activation/{userId}/{status}")
    @Operation(description="activate or deactivate Branch Manager Users")
    public ResponseEntity changeBranchManagersStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeBranchManagersStatus(userId, status);
    }
    @PostMapping("/branchManager/update")
    @Operation(description="Update Branch Manager Users")
    public ResponseEntity updateBranchManager(@Valid @RequestBody UpdateBranchManagerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateBranchManager(request, currentUser.getUserId());
    }
    @PostMapping("/branchManager/update/me")
    @Operation(description="Update Branch Manager Users As Merchant Admin")
    public ResponseEntity updateMyBranchManager(@Valid @RequestBody UpdateBranchManagerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateMyBranchManager(request, currentUser.getUserId());
    }
    @PostMapping("/branchManager/search/byName/me")
    @Operation(description="Search Fuel Dealer User")
    public ResponseEntity searchMyBranchManagersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchMyBranchManagersByName(request,currentUser.getUserId());

    }
    @PostMapping("/branchManager/search/byName")
    @Operation(description="Search Fuel Dealer User")
    public ResponseEntity searchBranchManagersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchBranchManagersByName(request,currentUser.getUserId());

    }
    @GetMapping("/branchManager/view/active/me")
    public ResponseEntity getMyActiveBranchManagers() {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyActiveBranchManagers(currentUser.getUserId());
    }
    @GetMapping("/branchManager/view/active")
    public ResponseEntity getActiveBranchManagers() {
        return userService.getActiveBranchManagers();
    }
    @GetMapping("/branchManager/view/me")
    public ResponseEntity getMyBranchManagers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyBranchManagers(page, size, currentUser.getUserId());
    }
    @GetMapping("/branchManager/view/all")
    public ResponseEntity getAllBranchManagers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllBranchManagers(page, size, currentUser.getUserId());
    }
    @GetMapping("/branchManager/view/byMerchantBranchId/{branchId}")
    public ResponseEntity getBranchManagersByMerchantBranchId(@PathVariable long branchId,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBranchManagersByMerchantId(branchId,page, size, currentUser.getUserId());
    }
    @GetMapping("/branchManager/view/byStatus/me/{status}")
    public ResponseEntity getMyBranchManagersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getMyBranchManagersByStatus(status,page, size, currentUser.getUserId());
    }
    @GetMapping("/branchManager/view/byStatus/{status}")
    public ResponseEntity getBranchManagersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBranchManagersByStatus(status,page, size, currentUser.getUserId());
    }
    @GetMapping("/branchManager/view/byUserId/{userId}")
    public ResponseEntity getBranchManagerById(@PathVariable String userId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getBranchManagerById(userId, currentUser.getUserId());
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////Customers////////////////////////////////////////////////////////////////////
    @PostMapping("/tellers/create")
    @Operation(description="Create Teller")
    public ResponseEntity addBackendTeller(@Valid @RequestBody AddTellerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.addTeller(request, currentUser.getUserId());
    }
    @PostMapping("/tellers/update")
    @Operation(description="Update Teller")
    public ResponseEntity updateTeller(@Valid @RequestBody UpdateTellerRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.updateTeller(request, currentUser.getUserId());
    }
    @PostMapping("/tellers/search/byName")
    @Operation(description="Search Tellers")
    public ResponseEntity searchTellersByName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.searchTellersByName(request,currentUser.getUserId());

    }
    @GetMapping("/tellers/view/active")
    public ResponseEntity getActiveTellers() {
        return userService.getActiveTellers();
    }
    @GetMapping("/tellers/view/all")
    public ResponseEntity getAllTellers(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getAllTellers(page, size, currentUser.getUserId());
    }
    @GetMapping("/tellers/activation/{userId}/{status}")
    @Operation(description="activate or deactivate Tellers")
    public ResponseEntity changeTellersStatus(@PathVariable String userId, @PathVariable Boolean status) {
        return userService.changeTellerStatus(userId, status);
    }
    @GetMapping("/tellers/view/byStatus/{status}")
    public ResponseEntity getTellersByStatus(@PathVariable boolean status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getTellersByStatus(status,page, size, currentUser.getUserId());
    }

    @GetMapping("/tellers/view/byUserId/{customerId}")
    public ResponseEntity getTellerById(@PathVariable String customerId) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getTellerById(customerId, currentUser.getUserId());
    }
    @GetMapping("/tellers/view/byMobileNumber/{mobileNumber}")
    public ResponseEntity getTellerByPhoneNumber(@PathVariable String mobileNumber) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.getTellerByPhoneNumber(mobileNumber, currentUser.getUserId());
    }


}
