package zw.co.change.money.app.notifications.sms.executors;

import org.apache.commons.text.StringSubstitutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.notifications.sms.SmsUtil;
import zw.co.change.money.app.variables.repository.AppVariableRepository;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


@Service
public class SmsExecutor {

    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    SmsConfigRepository smsConfigRepository;
    @Autowired
    SmsUtil smsUtil;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    public void ScheduledRegistrationSmsExecutor(String phoneNumbers, String smsCode, int timeInSeconds, String pin) {

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("pin", pin);
                values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode(smsCode).getContent());

                smsUtil.SendSms(textMessage,phoneNumbers);
            } catch (Exception e) {
                // log the sms to be sent later

            }
        };

        executor.schedule(task, timeInSeconds, TimeUnit.SECONDS);
    }

    public void ScheduledSmsExecutor(String phoneNumber, String smsText, int timeInSeconds) {

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {

                smsUtil.SendSms(smsText,phoneNumber);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());
            }
        };

        executor.schedule(task, timeInSeconds, TimeUnit.SECONDS);
    }

    public void ScheduledEcocashPaymentFailureSmsExecutor(String phoneNumbers, String vrn) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("vehicleRegNumber", vrn);
                values.put("supportPhoneNumber", appVariableRepository.findByCodeAndActive("SUPPORT_PHONE_NUMBER", true).getValue());
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("PAYMENT_FAILURE").getContent());

                smsUtil.SendSms(textMessage,phoneNumbers);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());
            }
        };

        executor.schedule(task, 3, TimeUnit.SECONDS);
    }

    public void ScheduledEcocashPaymentSuccessSmsExecutor(String phoneNumbers, String vrn, Double total) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("total", String.valueOf(total));
                values.put("vehicleRegNumber", vrn);
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("PAYMENT_SUCCESS").getContent());
                smsUtil.SendSms(phoneNumbers, textMessage);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());
            }
        };

        executor.schedule(task, 3, TimeUnit.SECONDS);
    }

    public void ScheduledEcocashRefundSmsExecutor(String phoneNumbers, String ecocashReference) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("ecocashReference", ecocashReference);
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("PAYMENT_REFUND").getContent());

                smsUtil.SendSms(phoneNumbers, textMessage);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());
            }
        };

        executor.schedule(task, 3, TimeUnit.SECONDS);
    }

    public void CoverNoteCollectionSmsExecutor(String phoneNumbers, String collectionPointName, String vrn) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("vehicleRegNumber", vrn);
                values.put("collectionPoint", collectionPointName);
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("COVER_PRINTED_COLLECTION").getContent());

                smsUtil.SendSms(phoneNumbers, textMessage);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());
            }
        };

        executor.schedule(task, 3, TimeUnit.SECONDS);
    }

    public void CoverNoteDeliverySmsExecutor(String phoneNumbers, String deliveryAddress, String vrn) {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("deliveryAddress", deliveryAddress);
                values.put("vehicleRegNumber", vrn);
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("COVER_PRINTED_DELIVERY").getContent());

                smsUtil.SendSms(phoneNumbers, textMessage);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());
            }
        };

        executor.schedule(task, 3, TimeUnit.SECONDS);
    }

    public void LoyaltyPointsEarnSmsExecutor(String phoneNumbers) {

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("LOYALTY_POINTS_EARN").getContent());

                smsUtil.SendSms(phoneNumbers, textMessage);
            } catch (Exception e) {
                // log the sms to be sent later
                logger.error(e.getMessage());

            }
        };

        executor.schedule(task, 5, TimeUnit.SECONDS);
    }

    public void LoyaltyPointsRedeemSmsExecutor(String phoneNumbers, String discount, int quantity, String reference) {

        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        Runnable task = () -> {
            try {
                Map<String, String> values = new HashMap<>();
                values.put("discount", discount);
                values.put("quantity", String.valueOf(quantity));
                values.put("reference", reference);
                StringSubstitutor sub = new StringSubstitutor(values, "%(", ")");
                String textMessage = sub.replace(smsConfigRepository.findFirstByCode("LOYALTY_POINTS_REDEEM").getContent());

                smsUtil.SendSms(phoneNumbers, textMessage);
            } catch (Exception e) {
                // log the sms to be sent later

            }
        };

        executor.schedule(task, 5, TimeUnit.SECONDS);
    }
}
