package zw.co.change.money.app.currencies.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import zw.co.change.money.app.merchants.response.MerchantResponse;
@Data
public class CurrencyResponse {
    private Long id;
    private String code;
    private String name;
    private double exchangeRate;
    private boolean active;
}
