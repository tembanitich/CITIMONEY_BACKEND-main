package zw.co.change.money.app.accounts.request;

import lombok.Data;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
@Data
public class ChangeMerchantDepositStatusRequest {
    private long requestId;
}
