package zw.co.change.money.app.reports.request;

import lombok.Data;

@Data
public class TableHeader {
    private String name;
    private String fieldType;
    private String fieldName;
    private int position;
}
