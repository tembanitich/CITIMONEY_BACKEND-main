package zw.co.change.money.app.financialInstitutions.request;

import lombok.Data;

@Data
public class UpdateFinancialInstitutionRequest {
    private String institutionNumber;
    private String name;
    private String displayName;
    private boolean mobileMoney;
    private String url;
}
