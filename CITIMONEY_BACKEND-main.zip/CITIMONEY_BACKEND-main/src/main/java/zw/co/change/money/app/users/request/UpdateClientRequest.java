package zw.co.change.money.app.users.request;

import lombok.Data;

import javax.validation.constraints.NotNull;
@Data
public class UpdateClientRequest {
    @NotNull
    private String email;
    @NotNull
    private String firstName;
    @NotNull
    private String surname;
    @NotNull
    private String mobileNumber;
    @NotNull
    private String mobileNumberCountryCode;
}
