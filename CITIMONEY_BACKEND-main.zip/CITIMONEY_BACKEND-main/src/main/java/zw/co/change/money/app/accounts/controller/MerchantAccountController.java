package zw.co.change.money.app.accounts.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.accounts.model.MerchantAccountHistoryType;
import zw.co.change.money.app.accounts.model.MerchantAccountStatus;
import zw.co.change.money.app.accounts.request.ChangeMerchantDepositStatusRequest;
import zw.co.change.money.app.accounts.request.DepositMerchantAccountRequest;
import zw.co.change.money.app.accounts.request.UpdateMerchantAccountRequest;
import zw.co.change.money.app.accounts.service.AccountsService;
import zw.co.change.money.app.merchants.request.AddMerchantRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantRequest;
import zw.co.change.money.app.merchants.service.MerchantService;
import zw.co.change.money.app.security.user.UserPrincipal;
import zw.co.change.money.app.util.constants.AppConstants;
import zw.co.change.money.app.util.model.SearchRequest;

import javax.validation.Valid;
@RestController
@RequestMapping("/api/merchantAccounts")
public class MerchantAccountController {
    @Autowired
    AccountsService productService;
    ////////////////////////////////////////////////////////////////////////////////Merchant Account////////////////////////////////////////////////////////////////////////////////////

    @PostMapping("/update/accountManager")
    @Operation(description="update Merchant Account")
    public ResponseEntity updateAccountManagerMerchantAccount(@Valid @RequestBody UpdateMerchantAccountRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateAccountManagerMerchantAccount(request,currentUser.getUserId());
    }
    @PostMapping("/update/me")
    @Operation(description="update Merchant Account")
    public ResponseEntity updateMyMerchantAccount(@Valid @RequestBody UpdateMerchantAccountRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateMyMerchantAccount(request,currentUser.getUserId());
    }
    @PostMapping("/update")
    @Operation(description="update Merchant Account")
    public ResponseEntity updateMerchantAccount(@Valid @RequestBody UpdateMerchantAccountRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.updateMerchantAccount(request,currentUser.getUserId());
    }
    @PostMapping("/deposit")
    @Operation(description="Deposit Merchant Account")
    public ResponseEntity depositMerchantAccount(@Valid @RequestBody DepositMerchantAccountRequest request){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.depositMerchantAccount(request,currentUser.getUserId());
    }
    @PostMapping("/search/byName/accountManager")
    @Operation(description="Search Merchant Accounts")
    public ResponseEntity searchAccountManagerMerchantAccountsByMerchantName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchAccountManagerMerchantAccountsByMerchantName(request,currentUser.getUserId());
    }
    @PostMapping("/search/byName")
    @Operation(description="Search Merchant Accounts")
    public ResponseEntity searchMerchantAccountsByMerchantName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountsByMerchantName(request,currentUser.getUserId());
    }
    @GetMapping("/activation/{merchantAccountId}/{status}")
    @Operation(description="Change Merchant Account Status")
    public ResponseEntity changeMerchantAccountStatus(@PathVariable long merchantAccountId, @PathVariable MerchantAccountStatus status){
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.changeMerchantAccountStatus(merchantAccountId,status,currentUser.getUserId());
    }
    @GetMapping("/view/active")
    public ResponseEntity getActiveMerchantAccounts() {
        return productService.getActiveMerchantAccounts();
    }

    @GetMapping("/view/accountManager")
    public ResponseEntity getAllAccountManagerMerchantAccounts(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAllAccountManagerMerchantAccounts(page, size,currentUser.getUserId());
    }
    @GetMapping("/view/me")
    public ResponseEntity getAllMyMerchantAccounts(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAllMyMerchantAccounts(page, size,currentUser.getUserId());
    }
    @GetMapping("/view/all")
    public ResponseEntity getAllMerchantAccounts(@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getAllMerchantAccounts(page, size);
    }
    @GetMapping("/view/byStatus/accountManager/{status}")
    public ResponseEntity getAccountManagerMerchantAccountsByStatus(@PathVariable MerchantAccountStatus status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                      @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.getAccountManagerMerchantAccountsByStatus(status,page, size,currentUser.getUserId());
    }
    @GetMapping("/view/byStatus/{status}")
    public ResponseEntity getMerchantAccountsByStatus(@PathVariable MerchantAccountStatus status,@RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        return productService.getMerchantAccountsByStatus(status,page, size);
    }
    @GetMapping("/view/byMerchantId/{merchantAccountId}")
    public ResponseEntity getMerchantAccountById(@PathVariable long merchantAccountId) {
        return productService.getMerchantAccountById(merchantAccountId);
    }

    ///////////////////////////////////////////////////////////////////Accounts //////////////////////////////////////////
    @PostMapping("/history/search/byName")
    @Operation(description="Search Merchant Accounts History")
    public ResponseEntity searchMerchantAccountHistoriesByMerchantName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountHistoriesByMerchantName(request,currentUser.getUserId());
    }
    @PostMapping("/history/search/byNameAndMerchantId/me")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchMerchantAccountHistoriesByMerchantId(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountHistoriesByMerchantId(request,currentUser.getUserId());
    }
    @PostMapping("/history/search/byNameAndMerchantId/accountManager")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchAccountManagerMerchantAccountHistoriesByMerchantId(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchAccountManagerMerchantAccountHistoriesByMerchantId(request,currentUser.getUserId());
    }
    @PostMapping("/history/search/byNameAndMerchantId/{merchantId}")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchMerchantAccountHistoriesByMerchantId(@PathVariable String merchantId,@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountHistoriesByMerchantId(merchantId,request,currentUser.getUserId());
    }
    @GetMapping("/history/view/all")
    public ResponseEntity GetAllMerchantAccountHistories( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAllMerchantAccountHistories(page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisWeek")
    public ResponseEntity GetMerchantAccountHistoriesThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/today")
    public ResponseEntity GetMerchantAccountHistoriesToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisMonth")
    public ResponseEntity GetMerchantAccountHistoriesThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantAccountHistoriesFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                   @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byMerchantIdAndTransactionType/accountManager/{transactionType}")
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesByMerchantIdAndStatus( @PathVariable MerchantAccountHistoryType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountHistoriesByMerchantIdAndStatus(transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byMerchantIdAndTransactionType/me/{transactionType}")
    public ResponseEntity GetMyMerchantAccountHistoriesByMerchantIdAndStatus( @PathVariable MerchantAccountHistoryType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountHistoriesByMerchantIdAndStatus(transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byMerchantIdAndTransactionType/{merchantId}/{transactionType}")
    public ResponseEntity GetMerchantAccountHistoriesByMerchantIdAndStatus(@PathVariable String merchantId, @PathVariable MerchantAccountHistoryType transactionType, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesByMerchantIdAndStatus( merchantId,transactionType,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesByMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountHistoriesByMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byMerchantId/me")
    public ResponseEntity GetMyMerchantAccountHistoriesByMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountHistoriesByMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byMerchantId/{merchantId}")
    public ResponseEntity GetAllMerchantAccountHistoriesByMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAllMerchantAccountHistoriesByMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byAccountId/{accountId}")
    public ResponseEntity GetAllMerchantAccountHistoriesByAccountId(@PathVariable long accountId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAllMerchantAccountHistoriesByAccountId( accountId,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisWeekAndMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesThisWeekAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountHistoriesThisWeekAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisWeekAndMerchantId/me")
    public ResponseEntity GetMyMerchantAccountHistoriesThisWeekAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountHistoriesThisWeekAndMerchantId( page,size,currentUser.getUserId());
    }

    @GetMapping("/history/view/all/thisWeekAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantAccountHistoriesThisWeekAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesThisWeekAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/todayAndMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesTodayAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountHistoriesTodayAndMerchantId( page,size,currentUser.getUserId());
    }

    @GetMapping("/history/view/all/todayAndMerchantId/me")
    public ResponseEntity GetMyMerchantAccountHistoriesTodayAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                        @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountHistoriesTodayAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/todayAndMerchantId/{merchantId}")
    public ResponseEntity AndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesTodayAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisMonthAndMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountHistoriesThisMonthAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisMonthAndMerchantId/me")
    public ResponseEntity GetMyMerchantAccountHistoriesThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountHistoriesThisMonthAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/all/thisMonthAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantAccountHistoriesThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesThisMonthAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byDateRangeAndMerchantId/accountManager/{startDateTime}/{endDateTime}")
    public ResponseEntity GetAccountManagerMerchantAccountHistoriesFromRangeAndMerchantId(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountHistoriesFromRangeAndMerchantId(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byDateRangeAndMerchantId/me/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMyMerchantAccountHistoriesFromRangeAndMerchantId(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountHistoriesFromRangeAndMerchantId(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/history/view/byDateRangeAndMerchantId/{merchantId}/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantAccountHistoriesFromRangeAndMerchantId(@PathVariable String merchantId,@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountHistoriesFromRangeAndMerchantId( merchantId,startDateTime,endDateTime,page,size,currentUser.getUserId());
    }




    ///////////////////////////////////////////////////////////////////Accounts //////////////////////////////////////////
    @PostMapping("/depositRequests/approve")
    @Operation(description="Approve Deposit Request")
    public ResponseEntity approveMerchantDeposit(@Valid @RequestBody ChangeMerchantDepositStatusRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.approveMerchantDeposit(request,currentUser.getUserId());
    }
    @PostMapping("/depositRequests/decline")
    @Operation(description="Decline Deposit Request")
    public ResponseEntity declineMerchantDeposit(@Valid @RequestBody ChangeMerchantDepositStatusRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.declineMerchantDeposit(request,currentUser.getUserId());
    }
    @PostMapping("/depositRequests/search/byName")
    @Operation(description="Search Merchant Accounts History")
    public ResponseEntity searchMerchantAccountDepositRequestsByMerchantName(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountDepositRequestsByMerchantName(request,currentUser.getUserId());
    }
    @PostMapping("/depositRequests/search/byNameAndMerchantId/me")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchMerchantAccountDepositRequestsByMerchantId(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountDepositRequestsByMerchantId(request,currentUser.getUserId());
    }
    @PostMapping("/depositRequests/search/byNameAndMerchantId/accountManager")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchAccountManagerMerchantAccountDepositRequestsByMerchantId(@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchAccountManagerMerchantAccountDepositRequestsByMerchantId(request,currentUser.getUserId());
    }
    @PostMapping("/depositRequests/search/byNameAndMerchantId/{merchantId}")
    @Operation(description="Search Merchant Accounts History By Merchant Id")
    public ResponseEntity searchMerchantAccountDepositRequestsByMerchantId(@PathVariable String merchantId,@Valid @RequestBody SearchRequest request) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.searchMerchantAccountDepositRequestsByMerchantId(merchantId,request,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all")
    public ResponseEntity GetAllMerchantAccountDepositRequests( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAllMerchantAccountDepositRequests(page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisWeek")
    public ResponseEntity GetMerchantAccountDepositRequestsThisWeek( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsThisWeek(page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/today")
    public ResponseEntity GetMerchantAccountDepositRequestsToday( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsToday(page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisMonth")
    public ResponseEntity GetMerchantAccountDepositRequestsThisMonth( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsThisMonth(page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byDateRange/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantAccountDepositRequestsFromRange(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsFromRange(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byMerchantIdAndTransactionType/accountManager/{depositStatus}")
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsByMerchantIdAndStatus(@PathVariable DepositRequestStatus depositStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                               @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountDepositRequestsByMerchantIdAndStatus(depositStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byMerchantIdAndTransactionType/me/{depositStatus}")
    public ResponseEntity GetMyMerchantAccountDepositRequestsByMerchantIdAndStatus( @PathVariable DepositRequestStatus depositStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountDepositRequestsByMerchantIdAndStatus(depositStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byStatus/{depositStatus}")
    public ResponseEntity GetMerchantAccountDepositRequestsByStatus( @PathVariable DepositRequestStatus depositStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsByStatus( depositStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byMerchantIdAndTransactionType/{merchantId}/{depositStatus}")
    public ResponseEntity GetMerchantAccountDepositRequestsByMerchantIdAndStatus(@PathVariable String merchantId, @PathVariable DepositRequestStatus depositStatus, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsByMerchantIdAndStatus( merchantId,depositStatus,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsByMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                 @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountDepositRequestsByMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byMerchantId/me")
    public ResponseEntity GetMyMerchantAccountDepositRequestsByMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountDepositRequestsByMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byMerchantId/{merchantId}")
    public ResponseEntity GetAllMerchantAccountDepositRequestsByMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                     @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAllMerchantAccountDepositRequestsByMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byAccountId/{accountId}")
    public ResponseEntity GetAllMerchantAccountDepositRequestsByAccountId(@PathVariable long accountId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                    @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAllMerchantAccountDepositRequestsByAccountId( accountId,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisWeekAndMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsThisWeekAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountDepositRequestsThisWeekAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisWeekAndMerchantId/me")
    public ResponseEntity GetMyMerchantAccountDepositRequestsThisWeekAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountDepositRequestsThisWeekAndMerchantId( page,size,currentUser.getUserId());
    }

    @GetMapping("/depositRequests/view/all/thisWeekAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantAccountDepositRequestsThisWeekAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsThisWeekAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/todayAndMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsTodayAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                       @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountDepositRequestsTodayAndMerchantId( page,size,currentUser.getUserId());
    }

    @GetMapping("/depositRequests/view/all/todayAndMerchantId/me")
    public ResponseEntity GetMyMerchantAccountDepositRequestsTodayAndMerchantId( @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                           @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountDepositRequestsTodayAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/todayAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantAccountDepositRequestsTodayAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                        @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsTodayAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisMonthAndMerchantId/accountManager")
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountDepositRequestsThisMonthAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisMonthAndMerchantId/me")
    public ResponseEntity GetMyMerchantAccountDepositRequestsThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountDepositRequestsThisMonthAndMerchantId( page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/all/thisMonthAndMerchantId/{merchantId}")
    public ResponseEntity GetMerchantAccountDepositRequestsThisMonthAndMerchantId(@PathVariable String merchantId, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsThisMonthAndMerchantId( merchantId,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byDateRangeAndMerchantId/accountManager/{startDateTime}/{endDateTime}")
    public ResponseEntity GetAccountManagerMerchantAccountDepositRequestsFromRangeAndMerchantId(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                                          @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetAccountManagerMerchantAccountDepositRequestsFromRangeAndMerchantId(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byDateRangeAndMerchantId/me/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMyMerchantAccountDepositRequestsFromRangeAndMerchantId(@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                              @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMyMerchantAccountDepositRequestsFromRangeAndMerchantId(startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
    @GetMapping("/depositRequests/view/byDateRangeAndMerchantId/{merchantId}/{startDateTime}/{endDateTime}")
    public ResponseEntity GetMerchantAccountDepositRequestsFromRangeAndMerchantId(@PathVariable String merchantId,@PathVariable String startDateTime,@PathVariable String endDateTime, @RequestParam(value = "page", defaultValue = AppConstants.DEFAULT_PAGE_NUMBER) int page,
                                                                            @RequestParam(value = "size", defaultValue = AppConstants.DEFAULT_PAGE_SIZE) int size) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return productService.GetMerchantAccountDepositRequestsFromRangeAndMerchantId( merchantId,startDateTime,endDateTime,page,size,currentUser.getUserId());
    }
}
