package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.util.List;

@Data
public class TableRow {
    private List<TableCell> cells;
}
