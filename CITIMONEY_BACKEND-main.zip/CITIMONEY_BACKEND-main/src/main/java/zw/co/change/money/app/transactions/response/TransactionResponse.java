package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.currencies.response.CurrencyResponse;
import zw.co.change.money.app.financialInstitutions.response.FinancialInstitutionResponse;
import zw.co.change.money.app.merchants.response.MerchantBranchResponse;
import zw.co.change.money.app.merchants.response.MerchantResponse;
import zw.co.change.money.app.transactions.model.TransactionStatus;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.users.response.MerchantCashierResponse;
import zw.co.change.money.app.users.response.TellerResponse;
import zw.co.change.money.app.users.response.UserCustomerResponse;

@Data
public class TransactionResponse {
    private String id;
    private String reference;
    private double amount;
    private double amountInUsd;
    private double baseExchangeRateUsed;
    private double merchantIncentiveUsed;
    private double totalExchangeRateUsed;
    private double changeAlreadyIssued;
    private double changeAlreadyIssuedInUsd;
    private double requiredChange;
    private double requiredChangeInUsd;
    private String destinationAccount;
    private String dateOfTransaction;
    private double transactionCharge;
    private double transactionChargeInUsd;
    private String notificationMsisdn;
    private TransactionType transactionType;
    private TransactionStatus status;
    private MerchantResponse merchant;
    private MerchantCashierResponse cashier;
    private MerchantBranchResponse merchantBranch;
    private UserCustomerResponse customer;
    private TellerResponse teller;
    private UserCustomerResponse receiver;
    private CurrencyResponse currency;
    private FinancialInstitutionResponse financialInstitution;
}
