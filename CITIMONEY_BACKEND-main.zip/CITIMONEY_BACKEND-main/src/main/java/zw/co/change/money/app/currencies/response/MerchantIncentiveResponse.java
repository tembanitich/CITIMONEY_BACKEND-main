package zw.co.change.money.app.currencies.response;

import lombok.Data;
import zw.co.change.money.app.merchants.response.MerchantResponse;
@Data
public class MerchantIncentiveResponse {
    private Long id;
    private double amount;
    private MerchantResponse merchant;
    private CurrencyResponse currency;
}
