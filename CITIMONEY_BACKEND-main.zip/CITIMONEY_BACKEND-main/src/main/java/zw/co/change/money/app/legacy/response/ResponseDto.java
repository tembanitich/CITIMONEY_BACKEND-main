package zw.co.change.money.app.legacy.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ResponseDto<D> implements Serializable {

    @JsonProperty("success")
    protected boolean success;
    @JsonProperty("narrative")
    protected String narrative;
    @JsonProperty("dto")
    protected D dto;
    @JsonProperty("dtos")
    protected List<D> dtos;

    protected Map<String, String> additionalData;

    @JsonProperty("responseCode")
    protected String responseCode;
    @JsonProperty("pageResponseDto")
    protected PageResponseDto pageResponseDto;




}
