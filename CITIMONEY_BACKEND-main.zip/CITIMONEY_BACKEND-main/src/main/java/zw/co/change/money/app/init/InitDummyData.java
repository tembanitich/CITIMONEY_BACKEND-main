package zw.co.change.money.app.init;

import com.github.javafaker.Faker;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.RandomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.DependsOn;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import zw.co.change.money.app.accounts.model.MerchantAccount;
import zw.co.change.money.app.accounts.repository.AccountRepository;
import zw.co.change.money.app.currencies.model.MerchantIncentive;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;
import zw.co.change.money.app.currencies.repository.MerchantIncentiveRepository;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.financialInstitutions.repository.FinancialInstitutionRepository;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.users.model.*;
import zw.co.change.money.app.users.repository.*;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.security.roles.model.Permission;
import zw.co.change.money.app.security.roles.model.Privilege;
import zw.co.change.money.app.security.roles.model.Role;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.util.distance.DistanceUtil;
import zw.co.change.money.app.util.encryption.EncryptionUtil;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.generators.StringGeneratorUtility;
import zw.co.change.money.app.notifications.sms.model.SmsFailures;
import zw.co.change.money.app.notifications.sms.model.SmsResponses;
import zw.co.change.money.app.notifications.sms.repository.PendingSmsRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsFailuresRepository;
import zw.co.change.money.app.notifications.sms.repository.SmsResponsesRepository;
import zw.co.change.money.app.security.roles.repository.PermissionRepository;
import zw.co.change.money.app.security.roles.repository.RoleRepository;
import zw.co.change.money.app.variables.repository.AppVariableRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.*;

@Component("InitDummyData")
@DependsOn({"initRoles","initCurrencies"})
@Transactional
public class InitDummyData implements ApplicationListener<ApplicationReadyEvent> {
    @Autowired
    private CurrencyRepository currencyRepository;
    @Autowired
    BranchManagerRepository branchManagerRepository;
    @Autowired
    RoleRepository roleRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    PasswordEncoder passwordEncoder;
    @Autowired
    UserSystemAdminRepository userSystemAdminRepository;
    @Autowired
    UserCustomerRepository userCustomerRepository;
    @Autowired
    private PermissionRepository permissionRepository;
    @Autowired
    UserBackendAdminRepository userBackendAdminRepository;
    @Autowired
    UserBackendAgentRepository userBackendOfficerRepository;
    @Autowired
    MerchantIncentiveRepository merchantIncentiveRepository;

    @Autowired
    FormatUtility formatUtilty;

    @Autowired
    EncryptionUtil encryptionUtil;
    @Autowired
    DistanceUtil distanceUtil;

    @Autowired
    MerchantCashierRepository merchantCashierRepository;
    @Autowired
    AppVariableRepository appVariableRepository;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private MerchantAdminRepository merchantAdminRepository;
    @Autowired
    private AccountManagerRepository accountManagerRepository;
    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private MerchantBranchRepository merchantBranchRepository;
    @Autowired
    StringGeneratorUtility stringGeneratorUtility;
    @Autowired
    SmsResponsesRepository smsResponsesRepository;
    @Autowired
    PendingSmsRepository pendingSmsRepository;
    @Autowired
    SmsFailuresRepository smsFailuresRepository;
    @Autowired
    FinancialInstitutionRepository financialInstitutionRepository;
    private static String[] categoryNames ={"Breakfast","Lunch","Supper","Starters","Drinks & Beverages"};
    private static String[] roomNames ={"Standard","Deluxe","Studio Suite","Presidential Suite","Executive Suite", "King Suite"};
    private static String[] lodgeNames ={"Kariba Change Money Lodge","Vic Falls Change Money Lodge"};
    private static String[] activityNames ={
            "SWIMMING",
            "BOAT CRUISE",
            "HOUSE BOATING",
            "BANANA PLANTATION",
            "KARIBA FISHERIES",
            "GAME DRIVE",
            "CROCODILE FARM TOUR ONLY",
            "DAM WALL",
            "SAILING",
            "FISHING",
            "WATER ACTIVITIES",
            "CANOEING",
            "KARIBA VILLAGE TOUR",
            "FUN FISHING",
            "MANA POOLS DAY TRIP"
    };
    private static String[] roomFeaturesNames ={"WIFI","TV","Parking","Dinner"};
    private static int[] roomFeaturesIcons ={62061,61717,61760,61953};
    private static List<String> roomAttributes =new ArrayList<String>(Arrays.asList("2 Baths","2 Double beds"));
    private static String[] ingredients ={
            "½ tbsp olive oil 1 onion, peeled and finely chopped, 1 x 500g pack British Beef Steak Mince 15% fat, 1 tsp mixed dried herbs, 1 egg, beaten, 4 slices mature Cheddar (optional), 4 white rolls,few round lettuce leaves, torn, 1 beef tomato, sliced,ketchup, to serve (optional)",
            "150g rolled porridge oats, 120g dried apricots, roughly chopped, 75g 4-seed mix, 1 tsp mixed spice, plus a pinch (optional), 250g natural yogurt",
            "150g rolled porridge oats, 120g dried apricots, roughly chopped, 75g 4-seed mix, 1 tsp mixed spice, plus a pinch (optional), 250g natural yogurt",
            "150g rolled porridge oats, 120g dried apricots, roughly chopped, 75g 4-seed mix, 1 tsp mixed spice, plus a pinch (optional), 250g natural yogurt",
            "150g rolled porridge oats, 120g dried apricots, roughly chopped, 75g 4-seed mix, 1 tsp mixed spice, plus a pinch (optional), 250g natural yogurt"};

    private UserBackendAdmin saveBackendAdmin(String firstName, String surname, String username, String email,Role role, List<Permission> permissions) {

        UserBackendAdmin admin = new UserBackendAdmin();
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BACK_OFFICE_ADMIN));
        admin.setFirstName(firstName);
        admin.setSurname(surname);
        admin.setEmail(email);
        admin.setResetPin(false);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_ADMINS);
        admin.setCreatedAt(this.getPassedDate().atTime(LocalTime.now().minusMinutes(RandomUtils.nextInt(13,25))));
        admin.setEnabled(true);
        admin.setPassword(passwordEncoder.encode("#Pass2022"));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(username);
        UserBackendAdmin savedAdmin =userBackendAdminRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(permissions,savedAdmin);
        return savedAdmin;
    }
    private UserBackendAgent saveBackendAgent(String firstName, String surname, String username, String email, Role role, List<Permission> permissions) {

        UserBackendAgent admin = new UserBackendAgent();
        admin.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_BACK_OFFICE_AGENT));
        admin.setFirstName(firstName);
        admin.setSurname(surname);
        admin.setEmail(email);
        admin.setResetPin(false);
        admin.setMessageGroup(WebSocketMessageGroup.BACKEND_AGENT);
        admin.setCreatedAt(this.getPassedDate().atTime(LocalTime.now().minusMinutes(RandomUtils.nextInt(13,25))));
        admin.setEnabled(true);
        admin.setPassword(passwordEncoder.encode("#Pass2022"));
        admin.setRoles(Collections.singletonList(role));
        admin.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        admin.setUsername(username);
        UserBackendAgent savedAdmin = userBackendOfficerRepository.save(admin);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(permissions,savedAdmin);
        return savedAdmin;
    }
    private UserCustomer createCustomer(List<String> phoneNumbers, Role role, List<Permission> permissions){
        Faker faker;
        String email ="";
        String phoneNumber ="";
        do{
            faker=new Faker();
            email =faker.internet().emailAddress();
        }while(userRepository.existsByEmail(email));

        do{
            int random =new Random().nextInt(phoneNumbers.size() - 3 + 1) + 2;
            phoneNumber=phoneNumbers.get(random);

        }while(userRepository.existsByUsername(phoneNumber));


        UserCustomer driver = new UserCustomer();
        driver.setEmail(email);
        driver.setFirstName(faker.name().firstName());
        driver.setSurname(faker.name().lastName());
        driver.setMobileNumber(phoneNumber);
        driver.setUserId(stringGeneratorUtility.fetchValidUserId(RoleName.ROLE_CUSTOMER));
        driver.setResetPin(true);
        driver.setEnabled(true);
        driver.setCreatedAt(this.getPassedDate().atTime(LocalTime.now().minusMinutes(RandomUtils.nextInt(13,25))));
        driver.setMessageGroup(WebSocketMessageGroup.CUSTOMERS);
        driver.setPassword(passwordEncoder.encode("#Pass2022"));
        driver.setRoles(Collections.singletonList(role));
        driver.setTokenHash(stringGeneratorUtility.fetchValidTokenHash());
        driver.setUsername(phoneNumber);
        UserCustomer savedAdmin = userCustomerRepository.save(driver);
        //////////////////////assign Permissions////////////////////////
        assignPermissionsByRoleToUser(permissions,savedAdmin);
        return savedAdmin;
    }
    public void assignPermissionsByRoleToUser(List<Permission> permissions, User user) {

        List<Privilege> privileges = new ArrayList<>();
        for(Permission p: permissions){

            for(Privilege privilege: p.getPrivileges()){
                if(!privileges.contains(privilege)){
                    privileges.add(privilege);
                }
            }

        }
        user.setPermissions(permissions);
        user.setPrivileges(privileges);
        userRepository.save(user);

    }
    public void assignPermissionsByRoleToUser(RoleName roleName, User user) {
        Role role = roleRepository.findByName(roleName).orElse(null);
        List<Privilege> privileges = new ArrayList<>();

        List<Permission> permissions = permissionRepository.findByRoles_Id(role.getId());
        for(Permission p: permissions){
            for(Privilege privilege: p.getPrivileges()){
                if(!privileges.contains(privilege)){
                    privileges.add(privilege);
                }
            }

        }
        user.setPermissions(permissions);
        user.setPrivileges(privileges);
        userRepository.save(user);

    }
    private void saveFailedSMS(String message){
        int random =new Random().nextInt(7 - 2 + 1) + 0;
        Faker faker=new Faker();
        SmsFailures pendingSms = new SmsFailures();
        pendingSms.setContent(message);
        pendingSms.setReceiverPhoneNumber(faker.phoneNumber().phoneNumber().replace("+",""));
        pendingSms.setMultiple(false);
        pendingSms.setReference(RandomStringUtils.random(10));
        pendingSms.setReason(faker.lorem().characters(50));
        pendingSms.setCreatedAt(this.getPassedDate().atTime(LocalTime.now().minusMinutes(random)));
        smsFailuresRepository.save(pendingSms);
    }

    private void saveSuccessSMS(String message){
        Faker faker=new Faker();
        int random =new Random().nextInt(7 - 2 + 1) + 0;
        LocalDateTime date = this.getPassedDate().atTime(LocalTime.now().minusMinutes(random));
        SmsResponses smsResponses = new SmsResponses();
        smsResponses.setDestination(faker.phoneNumber().phoneNumber().replace("+",""));
        smsResponses.setReferenceId(RandomStringUtils.random(10));
        smsResponses.setTimeDelivered(date.plusMinutes(random));
        smsResponses.setTimeReceived(date);
        smsResponses.setTimeRouted(date);
        smsResponses.setCreatedAt(date);
        smsResponses.setMessage(message);
        smsResponses.setPhoneNumber(faker.phoneNumber().phoneNumber().replace("+",""));
        smsResponses.setMultiple(false);
        smsResponsesRepository.save(smsResponses);
    }
 private FinancialInstitution saveFinancialInstitution(String name,String displayName,boolean isMobileMoney){
        FinancialInstitution financialInstitution = new FinancialInstitution();
        financialInstitution.setInstitutionNumber(stringGeneratorUtility.generateInstitutionNumber());
        financialInstitution.setActive(true);
        financialInstitution.setDisplayName(displayName);
        financialInstitution.setName(name);
        financialInstitution.setMobileMoney(isMobileMoney);
        financialInstitution.setUrl("https://changemoney.com");
       return  financialInstitutionRepository.save(financialInstitution);
    }

 private LocalDate getPassedDate(){
        Random random = new Random();
        int randomAmountOfDays = random.nextInt(31 - 5 + 1) + 4;
        int randomAmountOfMonths = random.nextInt(12 - 2 + 1) + 0;
        int randomAmountOfYears = random.nextInt(3 - 2 + 1) + 0;
        return LocalDate.now().minusDays(randomAmountOfDays).minusMonths(randomAmountOfMonths).minusYears(randomAmountOfYears);
    }
    private LocalDate getFutureDate(){
        Random random = new Random();
        int randomAmountOfDays = random.nextInt(31 - 5 + 1) + 4;
        int randomAmountOfMonths = random.nextInt(12 - 2 + 1) + 0;
        return LocalDate.now().plusDays(randomAmountOfDays).plusMonths(randomAmountOfMonths);
    }
    private List<String> generateNetoneNumbers(){
        List<String> phoneNumbers =new ArrayList<>();
        for(int i=0;i<800;i++){
            String phoneNumber ="26371";
            phoneNumbers.add(phoneNumber+ RandomStringUtils.randomNumeric(7));

        }
        return phoneNumbers;
    }
    private List<String> generateEconetNumbers(){
        List<String> phoneNumbers =new ArrayList<>();
        for(int i=0;i<800;i++){
            String phoneNumber ="26377";
            phoneNumbers.add(phoneNumber+ RandomStringUtils.randomNumeric(7));

        }
        return phoneNumbers;
    }
    @Override
    public void onApplicationEvent(final ApplicationReadyEvent event) {

        if (financialInstitutionRepository.findAll().isEmpty()) {
            Role adminRole = roleRepository.findByName(RoleName.ROLE_BACK_OFFICE_ADMIN).orElse(null);
            Role agentRole = roleRepository.findByName(RoleName.ROLE_BACK_OFFICE_AGENT).orElse(null);
            Role customerRole = roleRepository.findByName(RoleName.ROLE_CUSTOMER).orElse(null);
            List<Permission> adminPermissions = permissionRepository.findByRoles_Id(adminRole.getId());
            List<Permission> agentPermissions = permissionRepository.findByRoles_Id(agentRole.getId());
            List<Permission> customerPermissions = permissionRepository.findByRoles_Id(customerRole.getId());
            List<String> econetNumbers = this.generateEconetNumbers();
            List<String> netoneNumbers = this.generateNetoneNumbers();

//            List<UserCustomer> customers = new ArrayList<>();
            List<UserBackendAdmin> admins = new ArrayList<>();
            List<UserBackendAgent> agents = new ArrayList<>();

            ///////////////////////create Backend Admins/////////////////////////
//            for(int i=0;i<RandomUtils.nextInt(5,10);i++){
//                Faker faker;
//                String email ="";
//                do{
//                    faker=new Faker();
//                    email =faker.internet().emailAddress();
//                }while(userRepository.existsByEmail(email));
//                admins.add(this.saveBackendAdmin(faker.name().firstName(), faker.name().lastName(), email, email,adminRole,adminPermissions));
//            }
//            for(int i=0;i<RandomUtils.nextInt(5,10);i++){
//                Faker faker;
//                String email ="";
//                do{
//                    faker=new Faker();
//                    email =faker.internet().emailAddress();
//                }while(userRepository.existsByEmail(email));
//                agents.add(this.saveBackendAgent(faker.name().firstName(), faker.name().lastName(), email, email,adminRole,agentPermissions));
//            }
//            for(int i=0;i<RandomUtils.nextInt(1,5);i++){
//                if(RandomUtils.nextBoolean()){
//                    customers.add(this.createCustomer(econetNumbers,customerRole,customerPermissions));
//                }else{
//                    customers.add(this.createCustomer(netoneNumbers,customerRole,customerPermissions));
//                }
//
//            }
            List<Merchant> merchants = new ArrayList<>();


            this.saveFinancialInstitution("BANCABC","Bancabc",false);
            this.saveFinancialInstitution("CABS","Cabs",false);
            this.saveFinancialInstitution("ECOCASH","Ecocash - ZWL",true);
            this.saveFinancialInstitution("ECOCASHFCA","Ecocash - FCA",true);
            this.saveFinancialInstitution("Datvest","Datvest",false);
            this.saveFinancialInstitution("Old Mutual","Old Mutual",false);
            this.saveFinancialInstitution("Nyaradzo","Nyaradzo",false);
            this.saveFinancialInstitution("Doves","Doves",false);




            MerchantBranch merchantBranch = merchantBranchRepository.findById(1L).orElse(null);


            System.out.println("DUMMY DATA DONE...........................................................................................................");
        }
        return;
    }
}
