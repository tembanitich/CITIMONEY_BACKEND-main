package zw.co.change.money.app.legacy.request;

import lombok.Data;

@Data
public class MerchantDepositRequest {
    private String merchantId;
    private String userId;
    private String reference;
    private double amount;
}
