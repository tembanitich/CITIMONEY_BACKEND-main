package zw.co.change.money.app.notifications.sms.response;

public enum SMSStatus {
    FAILED,DELIVERED,PENDING
}