package zw.co.change.money.app.init;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.stereotype.Component;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.currencies.repository.CurrencyRepository;

import javax.annotation.PostConstruct;

@Component("initCurrencies")
public class InitCurrencies {
    @Autowired
    private CurrencyRepository currencyRepository;

    private Currency saveCurrency(String name, String code, double exchangeRate){
        Currency currency = new Currency();
        currency.setActive(true);
        currency.setExchangeRate(exchangeRate);
        currency.setName(name);
        currency.setCode(code);
        return currencyRepository.save(currency);
    }


    @PostConstruct
    public void init() {

        if (currencyRepository.findAll().isEmpty()) {
            this.saveCurrency("USD","USD",1);
            this.saveCurrency("Pound","POUND",1.3);
            this.saveCurrency("Pula","PULA",20);
            this.saveCurrency("Rand","RAND",15);
            this.saveCurrency("ZWL","ZWL",310);
        }

        }
}
