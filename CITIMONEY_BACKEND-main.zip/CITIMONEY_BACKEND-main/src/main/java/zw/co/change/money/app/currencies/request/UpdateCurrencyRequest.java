package zw.co.change.money.app.currencies.request;

import lombok.Data;

@Data
public class UpdateCurrencyRequest {
    private String name;
    private String code;
}
