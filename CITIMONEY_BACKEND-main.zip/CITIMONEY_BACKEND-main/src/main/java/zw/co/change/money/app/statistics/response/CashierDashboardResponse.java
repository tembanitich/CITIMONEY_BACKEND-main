package zw.co.change.money.app.statistics.response;

import lombok.Data;
import zw.co.change.money.app.transactions.response.TransactionResponse;

import java.util.List;
@Data
public class CashierDashboardResponse {

    private List<CounterGraph> transactionCountersThisMonth;
    private List<CounterGraph> transactionCountersThisWeek;
    private List<CounterGraph> transactionCountersThisYear;

    private PieChartGraph transactionTypesPieChart;
    private  List<TransactionResponse> lastTransactions;
}
