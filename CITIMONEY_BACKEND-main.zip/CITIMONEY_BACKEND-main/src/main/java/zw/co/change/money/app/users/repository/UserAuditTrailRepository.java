package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import zw.co.change.money.app.users.model.UserAuditTrail;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

public interface UserAuditTrailRepository extends JpaRepository<UserAuditTrail, Long> {
    Page<UserAuditTrail> findByUserId(String userId, Pageable pageable);
    Page<UserAuditTrail> findByUserIdAndActionIgnoreCaseContaining(String userId,String action, Pageable pageable);
    List<UserAuditTrail> findByUserId(String userId);
    List<UserAuditTrail> findByUserIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<UserAuditTrail> findByUserIdAndMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,String merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<UserAuditTrail> findByUserIdAndBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String userId,long branchId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<UserAuditTrail> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    List<UserAuditTrail> findByMerchantIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String merchantId,LocalDateTime dayStart, LocalDateTime dayEnd);
    List<UserAuditTrail> findByBranchIdAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(long branchId,LocalDateTime dayStart, LocalDateTime dayEnd);



}
