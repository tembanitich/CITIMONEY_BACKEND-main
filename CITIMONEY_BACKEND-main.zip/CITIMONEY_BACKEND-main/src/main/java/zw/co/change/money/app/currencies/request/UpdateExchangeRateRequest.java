package zw.co.change.money.app.currencies.request;

import lombok.Data;

@Data
public class UpdateExchangeRateRequest {
    private double exchangeRate;
    private String code;
}

