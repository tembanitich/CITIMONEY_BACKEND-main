package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.UserBackendAgent;

import java.time.LocalDateTime;
import java.util.List;

public interface UserBackendAgentRepository extends JpaRepository<UserBackendAgent, String> {
    List<UserBackendAgent> findByEnabled(boolean status);
    Page<UserBackendAgent> findByEnabled(boolean status, Pageable pageable);
    Long countByEnabled(boolean status);
    Page<UserBackendAgent> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    Page<UserBackendAgent> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<UserBackendAgent> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status,String  surname, boolean status2,Pageable pageable);

}