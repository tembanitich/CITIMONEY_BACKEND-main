package zw.co.change.money.app.documents.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
@Data
public class MerchantProofOfResidenceDocumentResponse {
    private Long id;
    private String fileName;
    private String fileUrl;
    private String fileType;
    private String blurHash;
    private long fileSize;
    private String merchantId;
}
