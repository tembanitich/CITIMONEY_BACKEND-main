package zw.co.change.money.app.authentication.controller;


import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.authentication.request.*;
import zw.co.change.money.app.authentication.service.AuthenticationService;
import zw.co.change.money.app.security.roles.model.RoleName;
import zw.co.change.money.app.security.user.UserPrincipal;

import javax.validation.Valid;
@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {
    @Autowired
    AuthenticationService authenticationService;


    @GetMapping("/get/permissions/managed/{roleName}")
    @Operation(description="get list of managed system permissions by Role ")
    public ResponseEntity GetPermissionsByRole(@PathVariable RoleName roleName) {
        return authenticationService.GetPermissionsByRole(roleName);
    }
    @PostMapping("/login")
    @Operation(description="authenticate and fetch access token")
    public ResponseEntity authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {
        return authenticationService.Login(loginRequest);
    }
    @PostMapping("/customer/signUp")
    @Operation(description="Customer Self Sign Up")
    public ResponseEntity customerSignUp(@Valid @RequestBody CustomerSignUpRequest signUpRequest) {
        return authenticationService.customerSignUp(signUpRequest);
    }
    @GetMapping("/get/roles/managed")
    @Operation(description="get list of managed system roles ")
    public ResponseEntity getManagedSystemRoles() {
        return authenticationService.GetManagedRoles();
    }

    @GetMapping("/backend/registrationConfirmOtp/{mobileNumber}/{otp}")
    @Operation(description="Registration Confirm OTP")
    public ResponseEntity confirmOTP( @PathVariable String mobileNumber,@PathVariable String otp) {
        return authenticationService.confirmOTP(mobileNumber,otp);
    }
    @GetMapping("/backend/resetPasswordConfirmOtp/{mobileNumber}/{otp}")
    @Operation(description="Reset Password Confirm OTP")
    public ResponseEntity confirmOTPResetPassword( @PathVariable String mobileNumber,@PathVariable String otp) {
        return authenticationService.confirmOTPResetPassword(mobileNumber,otp);
    }
    @GetMapping("/cashier/resetPassword/{mobileNumber}")
    @Operation(description="Cashier reset forgot password using mobileNumber")
    public ResponseEntity cashierResetPasswordWithMobileNumber(@Valid @PathVariable String mobileNumber) {
        return authenticationService.cashierResetPasswordWithMobileNumber(mobileNumber);
    }
    @GetMapping("/backend/resetPassword/{email}")
    @Operation(description="reset forgot password using email")
    public ResponseEntity resetPasswordWithEmail(@Valid @PathVariable String email) {
        return authenticationService.resetPasswordWithEmail(email);
    }
    @PostMapping("/client/resendOtp")
    @Operation(description="resend OTP")
    public ResponseEntity resendOTP(@Valid @RequestBody ResendOTPRequest request ) {
        return authenticationService.resendOTP(request);
    }
    @PostMapping("/backend/resetPasswordUsingBoth")
    @Operation(description="reset forgot password using email and Mobile Number")
    public ResponseEntity resetPasswordWithBothEmailAndMobileNumber(@Valid @RequestBody ResetPasswordRequest request) {
        return authenticationService.resetPasswordWithBothEmailAndMobileNumber(request);
    }
    @PostMapping("/client/resetPassword")
    @Operation(description="reset forgot password using email")
    public ResponseEntity resetPasswordWithMobileNumber(@Valid @RequestBody ResetPasswordRequest request) {
        return authenticationService.resetPasswordWithMobileNumber(request);
    }
    @PostMapping("/passwords/change")
    public ResponseEntity changePassword(@Valid @RequestBody ChangePasswordRequest passwordChange) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authenticationService.ChangePassword(passwordChange, currentUser.getUserId());
    }

    @PostMapping("/passwords/update")
    public ResponseEntity UpdatePassword(@Valid @RequestBody UpdatePasswordRequest passwordChange) {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return authenticationService.InstantPasswordUpdate(passwordChange, currentUser.getUserId());
    }
}
