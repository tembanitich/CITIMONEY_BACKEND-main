package zw.co.change.money.app.notifications.websocket.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zw.co.change.money.app.notifications.websocket.model.WebSocketMessageGroup;
import zw.co.change.money.app.notifications.websocket.response.ResponseType;
import zw.co.change.money.app.notifications.websocket.service.WebSocketService;

@RestController
@RequestMapping("/api/webSocketTest")
public class WebSocketTestController {

    @Autowired
    WebSocketService webSocketService;


    @GetMapping("/send/toGroup/{group}/{message}")
    public ResponseEntity sendMessageToBackendAdminSpecific(@PathVariable WebSocketMessageGroup group, @PathVariable String message) {

        return webSocketService.sendMessageToGroup(message,group);
    }
}
