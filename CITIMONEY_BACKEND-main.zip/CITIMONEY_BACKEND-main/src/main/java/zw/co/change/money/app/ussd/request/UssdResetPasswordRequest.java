package zw.co.change.money.app.ussd.request;

import lombok.Data;

@Data
public class UssdResetPasswordRequest {
    private String mobileNumber;
}
