package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class CustomerTransferRequest {
    private String receiverNumber;
    private String reference;
    private String pin;
    private double amount;
}
