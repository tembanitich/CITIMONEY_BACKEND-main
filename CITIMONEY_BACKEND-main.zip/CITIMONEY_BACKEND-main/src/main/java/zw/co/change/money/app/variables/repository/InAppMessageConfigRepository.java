package zw.co.change.money.app.variables.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.variables.model.InAppMessageConfig;

import java.util.Optional;

public interface InAppMessageConfigRepository  extends JpaRepository<InAppMessageConfig, Long> {
    Optional<InAppMessageConfig> findByCode(String code);
    InAppMessageConfig findFirstByCode(String code);

}