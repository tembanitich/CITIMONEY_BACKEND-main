package zw.co.change.money.app.util.model;

import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
public class SearchRequest {
    @NotNull
    private SearchFilter searchFilter;

    private String filterValue;
    private String filterValueMax;
    @NotNull
    private String searchQuery;
    @NotNull
    private int page;
    @NotNull
    private int size;
}
