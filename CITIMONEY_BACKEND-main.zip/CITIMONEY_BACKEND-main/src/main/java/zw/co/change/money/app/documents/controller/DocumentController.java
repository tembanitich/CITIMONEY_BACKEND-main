package zw.co.change.money.app.documents.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zw.co.change.money.app.documents.service.DocumentService;

import java.io.IOException;
@RestController
@RequestMapping("/api/documents")
public class DocumentController {
    @Autowired
    DocumentService documentsService;


    @GetMapping(value = "/proofOfResidence/download/{merchantId}")
    public ResponseEntity<Resource> downloadMerchantProofOfResidenceDocument(@PathVariable String merchantId) throws IOException {
        return this.documentsService.downloadMerchantProofOfResidenceDocument(merchantId);
    }
    @GetMapping(value = "/taxtClearance/download/{merchantId}")
    public ResponseEntity<Resource> downloadMerchantTaxClearanceDocument(@PathVariable String merchantId) throws IOException {
        return this.documentsService.downloadMerchantTaxClearanceDocument(merchantId);
    }
}
