package zw.co.change.money.app.security.roles.response;

import lombok.Data;

@Data
public class PrivilegeResponse {
    private String name;
    private long id;
}
