package zw.co.change.money.app.users.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.users.model.AccountManager;

import java.time.LocalDateTime;
import java.util.List;

public interface AccountManagerRepository extends JpaRepository<AccountManager, String> {
    List<AccountManager> findByEnabled(boolean status);
    Page<AccountManager> findByEnabled(boolean status, Pageable pageable);
    Long countByEnabled(boolean status);
    Page<AccountManager> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname, Pageable pageable);
    List<AccountManager> findDistinctByFirstNameContainingIgnoreCaseOrSurnameContainingIgnoreCase(String  firstName,String  surname);
    List<AccountManager> findDistinctByFirstName(String  firstName);
    Page<AccountManager> findDistinctByFirstNameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqualOrSurnameContainingIgnoreCaseAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String  firstName, LocalDateTime dayStart, LocalDateTime dayEnd, String  surname, LocalDateTime dayStart2, LocalDateTime dayEnd2, Pageable pageable);
    Page<AccountManager> findDistinctByFirstNameContainingIgnoreCaseAndEnabledOrSurnameContainingIgnoreCaseAndEnabled(String  firstName, boolean status, String  surname, boolean status2, Pageable pageable);


}
