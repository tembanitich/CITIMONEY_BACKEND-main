package zw.co.change.money.app.variables.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import zw.co.change.money.app.variables.model.TermsAndConditions;

import java.util.List;

@Repository
public interface TermsAndConditionsRepository extends JpaRepository<TermsAndConditions, Long> {
    List<TermsAndConditions> findByEnabled(Boolean status);
}
