package zw.co.change.money.app.transactions.request;

import lombok.Data;

@Data
public class IssueChangeRequest {
    private double tenderedAmount;
    private String currencyCode;
    private String pin;
    private IssueChangeType issueChangeType;
    private String destinationAccount;
    private String accountPhoneNumber;
    private String receiptNumber;
    private double changeAlreadyIssued;
    private double changeRequired;
    private String acquiringFinancialInstitutionNumber;
    private String notificationMsisdn;
}
