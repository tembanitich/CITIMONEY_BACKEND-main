package zw.co.change.money.app.reports.controller;

import fr.opensagres.xdocreport.core.XDocReportException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import zw.co.change.money.app.reports.model.ReportTemplateName;
import zw.co.change.money.app.reports.request.ReportGenerationDTO;
import zw.co.change.money.app.reports.service.ReportDocumentService;
import zw.co.change.money.app.security.user.UserPrincipal;

import javax.validation.Valid;
import java.io.IOException;

@RestController
@RequestMapping("/api/reports")
public class ReportController {


    @Autowired
    private ReportDocumentService reportDocumentService;



    @RequestMapping(value={"/getColumnsByReportName/{reportName}"}, method = RequestMethod.GET)
    public ResponseEntity getReportFieldsByTemplateName(@PathVariable(value = "reportName") ReportTemplateName reportName)  {

        return reportDocumentService.getReportFieldsByTemplateName(reportName);

    }

    @RequestMapping(value={"/documents/generateCustomerWalletReport"}, method = RequestMethod.POST)
    public ResponseEntity generateCustomerWalletReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateCustomerWalletReport(request);
    }
    @RequestMapping(value={"/documents/generateAccountManagerMerchantAccountReport"}, method = RequestMethod.POST)
    public ResponseEntity generateAccountManagerMerchantAccountReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateAccountManagerMerchantAccountReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/generateMerchantMerchantAccountReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantMerchantAccountReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantMerchantAccountReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/generateMerchantAccountReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantAccountReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateMerchantAccountReport(request);
    }
    @RequestMapping(value={"/documents/generateMerchantTransactionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantTransactionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantTransactionsReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/generateMerchantBranchTransactionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantBranchTransactionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantBranchTransactionsReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/generateCashierTransactionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateCashierTransactionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateCashierTransactionsReport(request,currentUser.getUserId());
    }

    @RequestMapping(value={"/documents/generateTransactionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateTransactionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateTransactionsReport(request);
    }
    //backend reports

    @RequestMapping(value={"/documents/backend/generateMerchantBranchAuditTrailReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantBranchAuditTrailReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantBranchAuditTrailReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/backend/generateMerchantAuditTrailReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantAuditTrailReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantAuditTrailReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/backend/generateMerchantUserPermissionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantUserPermissionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantUserPermissionsReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/backend/generateMerchantBranchUserPermissionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantBranchUserPermissionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantBranchUserPermissionsReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/backend/generateUserPermissionsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateUserPermissionsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateUserPermissionsReport(request);
    }

    @RequestMapping(value={"/documents/backend/generateMerchantSystemUserActivityReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantSystemUserActivityReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantSystemUserActivityReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/backend/generateMerchantBranchSystemUserActivityReport"}, method = RequestMethod.POST)
    public ResponseEntity generateMerchantBranchSystemUserActivityReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        UserPrincipal currentUser = (UserPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return reportDocumentService.generateMerchantBranchSystemUserActivityReport(request,currentUser.getUserId());
    }
    @RequestMapping(value={"/documents/backend/generateSystemUserActivityReport"}, method = RequestMethod.POST)
    public ResponseEntity generateSystemUserActivityReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateSystemUserActivityReport(request);
    }
    @RequestMapping(value={"/documents/backend/generateAuditTrailReport"}, method = RequestMethod.POST)
    public ResponseEntity generateAuditTrailReportByDateRange(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateAuditTrailReport(request);
    }


    @RequestMapping(value={"/documents/backend/generateSmsReport"}, method = RequestMethod.POST)
    public ResponseEntity generateSmsReport(@Valid @RequestBody ReportGenerationDTO request) throws IOException, XDocReportException {
        return reportDocumentService.generateSmsReport(request);
    }

}
