package zw.co.change.money.app.notifications.sms.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import zw.co.change.money.app.notifications.sms.model.SmsFailures;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface SmsFailuresRepository extends JpaRepository<SmsFailures, Long> {
    Optional<SmsFailures> findByReference(String reference);

    Page<SmsFailures> findByReason(String failureCause, Pageable pageable);
    Page<SmsFailures> findByMethodInExecution(String failureCause, Pageable pageable);
    Page<SmsFailures> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    List<SmsFailures> findByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
    Page<SmsFailures> findByReceiverPhoneNumberIgnoreCaseContainingAndCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(String phoneNumber, LocalDateTime dayStart, LocalDateTime dayEnd, Pageable pageable);
    Page<SmsFailures> findByReceiverPhoneNumberIgnoreCaseContaining(String phoneNumber, Pageable pageable);
    Long countByReason(String failureCause);
    Long countByCreatedAtGreaterThanEqualAndCreatedAtLessThanEqual(LocalDateTime dayStart, LocalDateTime dayEnd);
}

