package zw.co.change.money.app.users.request;

import lombok.Data;

@Data
public class AccountManagerAssignMerchantRequest {
    private String userId;
    private String merchantId;
}
