package zw.co.change.money.app.statistics.response;

import lombok.Data;
import zw.co.change.money.app.transactions.response.TransactionResponse;

import java.util.List;

@Data
public class AdminDashboardResponse {
    private long customerCount;
    private long activeCustomerCount;
    private long inactiveCustomerCount;
    private long merchantCount;
    private long activeMerchantCount;
    private long inactiveMerchantCount;
    private long merchantAdminCount;
    private long activeMerchantAdminCount;
    private long inactiveMerchantAdminCount;
    private long cashierCount;
    private long activeCashierCount;
    private long inactiveCashierCount;
    private long accountManagerCount;
    private long activeAccountManagerCount;
    private long inactiveAccountManagerCount;
    private long branchManagerCount;
    private long activeBranchManagerCount;
    private long inactiveBranchManagerCount;
    private long branchCount;
    private long activeBranchCount;
    private long inactiveBranchCount;



    private List<CounterGraph> transactionCountersThisMonth;
    private List<CounterGraph> transactionCountersThisWeek;
    private List<CounterGraph> transactionCountersThisYear;

    private PieChartGraph transactionTypesPieChart;
    private  TopTenGraph topTenCustomers;
    private  TopTenGraph topTenMerchants;
    private  TopTenGraph topTenCashiers;
    private  List<TransactionResponse> lastTransactions;


}
