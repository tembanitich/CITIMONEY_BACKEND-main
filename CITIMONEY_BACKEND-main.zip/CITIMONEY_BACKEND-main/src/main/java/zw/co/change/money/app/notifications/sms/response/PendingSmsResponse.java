package zw.co.change.money.app.notifications.sms.response;

import lombok.Data;

@Data
public class PendingSmsResponse {
    private Long id;
    private String state;
    private String phoneNumber;
    private String message;
    private int reference;
    private String summary;
    private String dateOfProcessing;
    private String senderId;
}
