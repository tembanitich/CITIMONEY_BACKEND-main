package zw.co.change.money.app.chat.response;

import lombok.Data;
import zw.co.change.money.app.users.response.UserCustomerResponse;

import java.util.List;
@Data
public class GroupedChatResponse {
    private UserCustomerResponse customer;
    private List<ChatMessageResponse> messages;
}
