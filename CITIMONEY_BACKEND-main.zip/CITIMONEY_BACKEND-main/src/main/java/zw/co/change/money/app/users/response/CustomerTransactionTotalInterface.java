package zw.co.change.money.app.users.response;

public interface CustomerTransactionTotalInterface {
    String getName();
    String getId();
    double getTotal();
}
