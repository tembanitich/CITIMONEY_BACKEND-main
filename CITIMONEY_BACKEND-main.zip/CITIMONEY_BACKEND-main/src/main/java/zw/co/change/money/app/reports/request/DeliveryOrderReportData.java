package zw.co.change.money.app.reports.request;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class DeliveryOrderReportData {
    private String customer;
    private String driver;
    private LocalDateTime deliveryDate;
    private String orderNumber;
}
