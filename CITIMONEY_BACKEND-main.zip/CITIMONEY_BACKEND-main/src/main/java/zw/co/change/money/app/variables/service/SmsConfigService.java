package zw.co.change.money.app.variables.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import zw.co.change.money.app.variables.repository.SmsConfigRepository;
import zw.co.change.money.app.util.response.GenericApiError;
import zw.co.change.money.app.util.response.GenericApiResponse;
import zw.co.change.money.app.variables.request.SmsConfigRequest;
import zw.co.change.money.app.variables.response.SmsConfigResponse;
import zw.co.change.money.app.variables.model.SmsConfig;

import java.util.ArrayList;
import java.util.List;

@Service
public class SmsConfigService {
    @Autowired
    SmsConfigRepository smsConfigRepository;

    public ResponseEntity AddSmsConfig(SmsConfigRequest configRequest) {
        if(configRequest.getContent().length()>120){
            return new ResponseEntity<>(new GenericApiError("Content too long",129), HttpStatus.EXPECTATION_FAILED);
        }
        SmsConfig smsConfig = smsConfigRepository.findByCode(configRequest.getCode()).orElse(null);
        if (smsConfig != null) {
            smsConfig.setContent(configRequest.getContent());
            smsConfig.setVariables(configRequest.getVariables());
            smsConfigRepository.save(smsConfig);
            return ResponseEntity.ok(new GenericApiResponse("Text Message Config Updated"));
        }

        SmsConfig newConfig = new SmsConfig();
        newConfig.setCode(configRequest.getCode().toUpperCase());
        newConfig.setContent(configRequest.getContent());
        newConfig.setVariables(configRequest.getVariables());
        smsConfigRepository.save(newConfig);
        return ResponseEntity.ok(new GenericApiResponse("Text Message Config Added"));
    }

    public ResponseEntity changeSmsConfigStatus(String code,boolean status) {
        SmsConfig smsConfig = smsConfigRepository.findByCode(code).orElse(null);
        if(smsConfig==null){
            return new ResponseEntity<>(new GenericApiError("SMS Config Is not found",110), HttpStatus.NOT_FOUND);
        }
        smsConfig.setActive(status);
        smsConfigRepository.delete(smsConfig);
        return ResponseEntity.ok(new GenericApiResponse("Tex Message Config Status Updated"));
    }

    public ResponseEntity GetAllSmsConfigs() {

        List<SmsConfigResponse> smsConfigResponses = new ArrayList<>();
        for (SmsConfig smsConfig : smsConfigRepository.findAll()) {
            SmsConfigResponse smsConfigResponse = this.mapEntityToSmsConfigResponse(smsConfig);
            smsConfigResponses.add(smsConfigResponse);
        }
        return ResponseEntity.ok(smsConfigResponses);
    }


    private SmsConfigResponse mapEntityToSmsConfigResponse(SmsConfig smsConfig) {
        SmsConfigResponse theResponse = new SmsConfigResponse();
        theResponse.setCode(smsConfig.getCode());
        theResponse.setActive(smsConfig.isActive());
        theResponse.setContent(smsConfig.getContent());
        theResponse.setVariables(smsConfig.getVariables());
        return theResponse;
    }
}
