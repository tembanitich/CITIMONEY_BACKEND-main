package zw.co.change.money.app.currencies.response;

import lombok.Data;
import zw.co.change.money.app.authentication.response.UserSummary;
@Data
public class ExchangeRateHistoryResponse {
    private Long id;
    private UserSummary responsibleUser;
    private double previousExchangeRate;
    private double newExchangeRate;
    private String dateChanged;
    private CurrencyResponse currency;
}
