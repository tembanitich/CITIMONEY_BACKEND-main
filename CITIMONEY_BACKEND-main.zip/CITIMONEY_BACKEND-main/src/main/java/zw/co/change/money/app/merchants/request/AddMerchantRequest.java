package zw.co.change.money.app.merchants.request;

import lombok.Data;

@Data
public class AddMerchantRequest {
    private String name;
    private String tradingAs;
    private String companyRegNumber;
    private String officeAddress;
    private String contactPersonName;
    private String contactPersonSurname;
    private String contactPersonNumber;
    private String contactPersonEmail;
    private String contactPersonDesignation;
    private String withdrawalEmail;
    private String withdrawalPhoneNumber;
    private double minFloatLimit;
    private int numberOfBranches;
    private int projectedCashiers;
    private int projectedAdmins;
    private double projectedDailyFloatBalance;
    private double projectedNumberOfProducts;
}



