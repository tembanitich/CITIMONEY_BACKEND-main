package zw.co.change.money.app.transactions.response;

import lombok.Data;
import zw.co.change.money.app.accounts.model.DepositRequestStatus;
import zw.co.change.money.app.accounts.response.MerchantAccountResponse;
import zw.co.change.money.app.authentication.response.UserSummary;
import zw.co.change.money.app.users.response.MerchantUserResponse;
@Data
public class MerchantWithdrawalRequestResponse {
    private Long id;
    private MerchantAccountResponse account;
    private double amount;
    private String approvalCode;
    private String  dateOfEntry;
    private DepositRequestStatus status;
    private MerchantUserResponse requestedBy;
    private UserSummary approvedBy;
    private UserSummary completedBy;
    private String approvedDate;
    private UserSummary declinedBy;
    private String declinedDate;
    private String completedDate;
}
