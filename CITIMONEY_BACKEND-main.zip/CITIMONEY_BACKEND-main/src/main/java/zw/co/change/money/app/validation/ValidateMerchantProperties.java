package zw.co.change.money.app.validation;

import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import zw.co.change.money.app.currencies.model.Currency;
import zw.co.change.money.app.financialInstitutions.model.FinancialInstitution;
import zw.co.change.money.app.merchants.model.Merchant;
import zw.co.change.money.app.merchants.model.MerchantBranch;
import zw.co.change.money.app.merchants.repository.MerchantBranchRepository;
import zw.co.change.money.app.merchants.repository.MerchantRepository;
import zw.co.change.money.app.merchants.request.AddMerchantBranchRequest;
import zw.co.change.money.app.merchants.request.AddMerchantRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantBranchRequest;
import zw.co.change.money.app.merchants.request.UpdateMerchantRequest;
import zw.co.change.money.app.transactions.model.TransactionType;
import zw.co.change.money.app.transactions.request.IssueChangeRequest;
import zw.co.change.money.app.transactions.request.IssueChangeType;
import zw.co.change.money.app.users.model.MerchantCashier;
import zw.co.change.money.app.util.format.FormatUtility;
import zw.co.change.money.app.util.model.SearchFilter;
import zw.co.change.money.app.util.model.SearchRequest;
import zw.co.change.money.app.util.response.GenericApiError;
@Component
public class ValidateMerchantProperties {
    @Autowired
    private FormatUtility formatUtility;
    @Autowired
    private MerchantRepository merchantRepository;
    @Autowired
    private MerchantBranchRepository merchantBranchRepository;
    public ResponseEntity isValidSearchRequest(SearchRequest request){

        if(request.getSize()==0){
            return new ResponseEntity<>(new GenericApiError("Page Size cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchFilter()==null){
            return new ResponseEntity<>(new GenericApiError("Search Filter cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getSearchQuery()==null || request.getSearchQuery().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Search Query cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }


        if(request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_STATUS)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Payment Id",105), HttpStatus.EXPECTATION_FAILED);
            }
            try{
                TransactionStatus.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Status",110),HttpStatus.NOT_FOUND);
            }

        }
        if(request.getSearchFilter().equals(SearchFilter.BY_TRANSACTION_TYPE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Payment Id",105), HttpStatus.EXPECTATION_FAILED);
            }
            try{
                TransactionType.valueOf(request.getFilterValue());
            }catch(Exception e){
                return new ResponseEntity<>(new GenericApiError("Invalid Payment Method",110),HttpStatus.NOT_FOUND);
            }

        }
        if(request.getSearchFilter().equals(SearchFilter.BY_DATE_RANGE)){
            if(request.getFilterValue()==null || request.getFilterValue().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            } if(request.getFilterValueMax()==null || request.getFilterValueMax().isEmpty()){
                return new ResponseEntity<>(new GenericApiError("Search Filter Max Value cannot be empty for Filter Date Range",105), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid Start Date",108), HttpStatus.EXPECTATION_FAILED);
            }
            if(!formatUtility.isValidDate(request.getFilterValue())){
                return new ResponseEntity<>(new GenericApiError("Invalid End Date",108), HttpStatus.EXPECTATION_FAILED);
            }
        }
        return ResponseEntity.ok(true);
    }
    public  ResponseEntity validateAddMerchantBranchRequest(AddMerchantBranchRequest request){

        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getBranchEmail()==null || request.getBranchEmail().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Branch Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getBranchManagerName()==null || request.getBranchManagerName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Branch Manager Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactNumber()==null || request.getContactNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMerchantId()==null || request.getMerchantId().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Id cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }


        return ResponseEntity.ok(true);
    }
    public  ResponseEntity validateUpdateMerchantBranchRequest(UpdateMerchantBranchRequest request){
        MerchantBranch merchantBranch = merchantBranchRepository.findById(request.getId()).orElse(null);
        if(merchantBranch==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant Branch",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getBranchEmail()==null || request.getBranchEmail().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Branch Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getBranchManagerName()==null || request.getBranchManagerName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Branch Manager Name cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactNumber()==null || request.getContactNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMerchantId()==null || request.getMerchantId().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Id cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        Merchant merchant = merchantRepository.findById(request.getMerchantId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }


        return ResponseEntity.ok(true);
    }

    public  ResponseEntity validateAddMerchantRequest(AddMerchantRequest request, MultipartFile proofOfRes, MultipartFile taxClearance){
        if(taxClearance==null ){
            return new ResponseEntity<>(new GenericApiError("Tax Clearance cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(proofOfRes==null ){
            return new ResponseEntity<>(new GenericApiError("Proof Of Residence cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getWithdrawalEmail()==null || request.getWithdrawalEmail().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Withdrawal Notification Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getWithdrawalPhoneNumber()==null || request.getWithdrawalPhoneNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Withdrawal Notification Phone Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidPhoneNumber(request.getWithdrawalPhoneNumber())){
            return new ResponseEntity<>(new GenericApiError("Invalid Merchant Withdrawal Notification Phone Number ",105), HttpStatus.EXPECTATION_FAILED);

        }
        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getOfficeAddress()==null || request.getOfficeAddress().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Office Address cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCompanyRegNumber()==null || request.getCompanyRegNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Company Registration  Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonDesignation()==null || request.getContactPersonDesignation().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Designation cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonEmail()==null || request.getContactPersonEmail().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonNumber()==null || request.getContactPersonNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Phone Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonName()==null || request.getContactPersonName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonSurname()==null || request.getContactPersonSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedCashiers()==0){
            return new ResponseEntity<>(new GenericApiError("Projected Cashiers cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedCashiers()<0){
            return new ResponseEntity<>(new GenericApiError("Projected Cashiers cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMinFloatLimit()<0){
            return new ResponseEntity<>(new GenericApiError("Minimum Float Limit cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }


        if(request.getProjectedAdmins()<0){
            return new ResponseEntity<>(new GenericApiError("Projected Admins cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedAdmins()==0){
            return new ResponseEntity<>(new GenericApiError("Projected Admins cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedNumberOfProducts()==0){
            return new ResponseEntity<>(new GenericApiError("Projected Number of products cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
    public  ResponseEntity validateUpdateMerchantRequest(UpdateMerchantRequest request){
        Merchant merchant = merchantRepository.findById(request.getId()).orElse(null);
        if(merchant==null){
            return new ResponseEntity<>(new GenericApiError("Could not load Merchant",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getWithdrawalEmail()==null || request.getWithdrawalEmail().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Withdrawal Notification Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getWithdrawalPhoneNumber()==null || request.getWithdrawalPhoneNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant Withdrawal Notification Phone Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(!formatUtility.isValidPhoneNumber(request.getWithdrawalPhoneNumber())){
            return new ResponseEntity<>(new GenericApiError("Invalid Merchant Withdrawal Notification Phone Number ",105), HttpStatus.EXPECTATION_FAILED);

        }
        if(request.getName()==null || request.getName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Merchant cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getOfficeAddress()==null || request.getOfficeAddress().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Office Address cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getCompanyRegNumber()==null || request.getCompanyRegNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Company Registration  Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonDesignation()==null || request.getContactPersonDesignation().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Designation cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonEmail()==null || request.getContactPersonEmail().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonNumber()==null || request.getContactPersonNumber().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Phone Number cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonName()==null || request.getContactPersonName().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Email cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getContactPersonSurname()==null || request.getContactPersonSurname().isEmpty()){
            return new ResponseEntity<>(new GenericApiError("Contact Person Surname cannot be empty",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedCashiers()==0){
            return new ResponseEntity<>(new GenericApiError("Projected Cashiers cannot be 0",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedCashiers()<0){
            return new ResponseEntity<>(new GenericApiError("Projected Cashiers cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getMinFloatLimit()<0){
            return new ResponseEntity<>(new GenericApiError("Minimum Float Limit cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }

        if(request.getProjectedAdmins()<0){
            return new ResponseEntity<>(new GenericApiError("Projected Admins cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedAdmins()==0){
            return new ResponseEntity<>(new GenericApiError("Projected Admins cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }
        if(request.getProjectedNumberOfProducts()==0){
            return new ResponseEntity<>(new GenericApiError("Projected Number of products cannot be Negative",105), HttpStatus.EXPECTATION_FAILED);
        }

        return ResponseEntity.ok(true);
    }
}
