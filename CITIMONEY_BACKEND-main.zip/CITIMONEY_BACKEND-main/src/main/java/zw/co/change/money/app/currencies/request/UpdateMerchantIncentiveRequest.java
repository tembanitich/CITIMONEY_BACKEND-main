package zw.co.change.money.app.currencies.request;

import lombok.Data;

@Data
public class UpdateMerchantIncentiveRequest {
    private String merchantId;
    private double amount;
    private String currencyCode;
}
